﻿namespace HireLook
{
    partial class frmImportfromPortals
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmImportfromPortals));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.tsbar = new System.Windows.Forms.ToolStripStatusLabel();
            this.tspgrs = new System.Windows.Forms.ToolStripProgressBar();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.toolStripLabel1 = new System.Windows.Forms.ToolStripLabel();
            this.cmbSource = new System.Windows.Forms.ToolStripComboBox();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.tsLoadtoGrid = new System.Windows.Forms.ToolStripButton();
            this.tsDownload = new System.Windows.Forms.ToolStripButton();
            this.tsStop = new System.Windows.Forms.ToolStripButton();
            this.tsSummary = new System.Windows.Forms.ToolStripButton();
            this.tsExits = new System.Windows.Forms.ToolStripButton();
            this.cntTab = new Crownwood.Magic.Controls.TabControl();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.panel1 = new System.Windows.Forms.Panel();
            this.grdCandidate = new System.Windows.Forms.DataGridView();
            this.Check = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.IDs = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.RID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CandidateName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Mobile = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PhoneH = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TotalExp = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Education = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CandidateLocation = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.JobTitle = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PresentEmployer = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Skill = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PresentCTC = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PreviousDesignation = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PreviousEmployer = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.PrefLocationText = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SiteResumeID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.AutoResumeID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Indicator = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.URL = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SavedType = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ResumeID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.panel2 = new System.Windows.Forms.Panel();
            this.btnMinanMax = new System.Windows.Forms.Button();
            this.grpSummary = new System.Windows.Forms.GroupBox();
            this.btnSummaryClose = new System.Windows.Forms.Button();
            this.lblParsed = new System.Windows.Forms.Label();
            this.lblDuplicateDoc = new System.Windows.Forms.Label();
            this.lblUnknownFormatR = new System.Windows.Forms.Label();
            this.lblFailedSave = new System.Windows.Forms.Label();
            this.lblDuplicateOverwrite = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.webBrowser1 = new System.Windows.Forms.WebBrowser();
            this.statusStrip1.SuspendLayout();
            this.toolStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.grdCandidate)).BeginInit();
            this.panel2.SuspendLayout();
            this.grpSummary.SuspendLayout();
            this.SuspendLayout();
            // 
            // statusStrip1
            // 
            this.statusStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsbar,
            this.tspgrs});
            this.statusStrip1.Location = new System.Drawing.Point(0, 726);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Padding = new System.Windows.Forms.Padding(1, 0, 19, 0);
            this.statusStrip1.Size = new System.Drawing.Size(1283, 25);
            this.statusStrip1.TabIndex = 8;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // tsbar
            // 
            this.tsbar.Name = "tsbar";
            this.tsbar.Size = new System.Drawing.Size(95, 20);
            this.tsbar.Text = "Ready...         ";
            // 
            // tspgrs
            // 
            this.tspgrs.Name = "tspgrs";
            this.tspgrs.Size = new System.Drawing.Size(133, 20);
            this.tspgrs.Visible = false;
            // 
            // toolStrip1
            // 
            this.toolStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripLabel1,
            this.cmbSource,
            this.toolStripSeparator1,
            this.tsLoadtoGrid,
            this.tsDownload,
            this.tsStop,
            this.tsSummary,
            this.tsExits});
            this.toolStrip1.Location = new System.Drawing.Point(0, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(1283, 28);
            this.toolStrip1.TabIndex = 11;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // toolStripLabel1
            // 
            this.toolStripLabel1.Name = "toolStripLabel1";
            this.toolStripLabel1.Size = new System.Drawing.Size(54, 25);
            this.toolStripLabel1.Text = "Source";
            // 
            // cmbSource
            // 
            this.cmbSource.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbSource.Items.AddRange(new object[] {
            "<--None-->",
            "Monster India",
            "Naukri Website",
            "Timesjobs Website",
            "Monster Gulf",
            "Career Builder",
            "Dice",
            "Naukri Gulf",
            "Monster APAC",
            "Monster Malaysia",
            "SEA Portal",
            "Monster North America",
            "CATS",
            "OilCareers",
            "RecruitGulf",
            "Oil and Gas Jobs Search",
            "Corp-Corp",
            "Monster Philippines",
            "JobsDB",
            "JobStreet",
            "Shine",
            "RigZone",
            "Others"});
            this.cmbSource.Name = "cmbSource";
            this.cmbSource.Size = new System.Drawing.Size(160, 28);
            this.cmbSource.SelectedIndexChanged += new System.EventHandler(this.cmbSource_SelectedIndexChanged);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(6, 28);
            // 
            // tsLoadtoGrid
            // 
            this.tsLoadtoGrid.Enabled = false;
            this.tsLoadtoGrid.Image = ((System.Drawing.Image)(resources.GetObject("tsLoadtoGrid.Image")));
            this.tsLoadtoGrid.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsLoadtoGrid.Name = "tsLoadtoGrid";
            this.tsLoadtoGrid.Size = new System.Drawing.Size(208, 25);
            this.tsLoadtoGrid.Text = "Load Search Result to Grid";
            this.tsLoadtoGrid.Click += new System.EventHandler(this.tsLoadtoGrid_Click);
            // 
            // tsDownload
            // 
            this.tsDownload.Enabled = false;
            this.tsDownload.Image = ((System.Drawing.Image)(resources.GetObject("tsDownload.Image")));
            this.tsDownload.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsDownload.Name = "tsDownload";
            this.tsDownload.Size = new System.Drawing.Size(102, 25);
            this.tsDownload.Text = "Download";
            this.tsDownload.Click += new System.EventHandler(this.tsDownload_Click);
            // 
            // tsStop
            // 
            this.tsStop.Image = ((System.Drawing.Image)(resources.GetObject("tsStop.Image")));
            this.tsStop.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsStop.Name = "tsStop";
            this.tsStop.Size = new System.Drawing.Size(158, 25);
            this.tsStop.Text = "Stop Downloading";
            this.tsStop.Visible = false;
            // 
            // tsSummary
            // 
            this.tsSummary.Image = ((System.Drawing.Image)(resources.GetObject("tsSummary.Image")));
            this.tsSummary.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsSummary.Name = "tsSummary";
            this.tsSummary.Size = new System.Drawing.Size(95, 25);
            this.tsSummary.Text = "Summary";
            this.tsSummary.Visible = false;
            this.tsSummary.Click += new System.EventHandler(this.tsSummary_Click);
            // 
            // tsExits
            // 
            this.tsExits.Image = ((System.Drawing.Image)(resources.GetObject("tsExits.Image")));
            this.tsExits.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsExits.Name = "tsExits";
            this.tsExits.Size = new System.Drawing.Size(57, 25);
            this.tsExits.Text = "Exit";
            this.tsExits.Click += new System.EventHandler(this.tsExits_Click);
            // 
            // cntTab
            // 
            this.cntTab.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.cntTab.Dock = System.Windows.Forms.DockStyle.Fill;
            this.cntTab.IDEPixelArea = true;
            this.cntTab.Location = new System.Drawing.Point(0, 36);
            this.cntTab.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.cntTab.Name = "cntTab";
            this.cntTab.PositionTop = true;
            this.cntTab.ShowClose = true;
            this.cntTab.Size = new System.Drawing.Size(1283, 476);
            this.cntTab.TabIndex = 12;
            this.cntTab.ClosePressed += new System.EventHandler(this.cntTab_ClosePressed);
            // 
            // splitContainer1
            // 
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.FixedPanel = System.Windows.Forms.FixedPanel.Panel2;
            this.splitContainer1.Location = new System.Drawing.Point(0, 28);
            this.splitContainer1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.splitContainer1.Name = "splitContainer1";
            this.splitContainer1.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.cntTab);
            this.splitContainer1.Panel1.Controls.Add(this.panel1);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.grdCandidate);
            this.splitContainer1.Panel2.Controls.Add(this.panel2);
            this.splitContainer1.Size = new System.Drawing.Size(1283, 698);
            this.splitContainer1.SplitterDistance = 512;
            this.splitContainer1.SplitterWidth = 5;
            this.splitContainer1.TabIndex = 13;
            // 
            // panel1
            // 
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1283, 36);
            this.panel1.TabIndex = 13;
            this.panel1.Visible = false;
            // 
            // grdCandidate
            // 
            this.grdCandidate.AllowUserToAddRows = false;
            this.grdCandidate.AllowUserToDeleteRows = false;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.grdCandidate.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.grdCandidate.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.grdCandidate.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Check,
            this.IDs,
            this.RID,
            this.CandidateName,
            this.Mobile,
            this.PhoneH,
            this.TotalExp,
            this.Education,
            this.CandidateLocation,
            this.JobTitle,
            this.PresentEmployer,
            this.Skill,
            this.PresentCTC,
            this.PreviousDesignation,
            this.PreviousEmployer,
            this.PrefLocationText,
            this.SiteResumeID,
            this.AutoResumeID,
            this.Indicator,
            this.URL,
            this.SavedType,
            this.ResumeID});
            this.grdCandidate.Dock = System.Windows.Forms.DockStyle.Fill;
            this.grdCandidate.Location = new System.Drawing.Point(0, 28);
            this.grdCandidate.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.grdCandidate.Name = "grdCandidate";
            this.grdCandidate.Size = new System.Drawing.Size(1283, 153);
            this.grdCandidate.TabIndex = 1;
            // 
            // Check
            // 
            this.Check.DataPropertyName = "Check";
            this.Check.FillWeight = 50F;
            this.Check.HeaderText = "";
            this.Check.Name = "Check";
            this.Check.Width = 50;
            // 
            // IDs
            // 
            this.IDs.DataPropertyName = "IDs";
            this.IDs.HeaderText = "IDs";
            this.IDs.Name = "IDs";
            this.IDs.Visible = false;
            // 
            // RID
            // 
            this.RID.DataPropertyName = "RID";
            this.RID.HeaderText = "RID";
            this.RID.Name = "RID";
            this.RID.Visible = false;
            // 
            // CandidateName
            // 
            this.CandidateName.DataPropertyName = "CandidateName";
            this.CandidateName.HeaderText = "Candidate Name";
            this.CandidateName.Name = "CandidateName";
            this.CandidateName.ReadOnly = true;
            // 
            // Mobile
            // 
            this.Mobile.DataPropertyName = "Mobile";
            this.Mobile.HeaderText = "Mobile";
            this.Mobile.Name = "Mobile";
            // 
            // PhoneH
            // 
            this.PhoneH.DataPropertyName = "PhoneH";
            this.PhoneH.HeaderText = "Phone";
            this.PhoneH.Name = "PhoneH";
            // 
            // TotalExp
            // 
            this.TotalExp.DataPropertyName = "TotalExp";
            this.TotalExp.HeaderText = "Tot. Exp";
            this.TotalExp.Name = "TotalExp";
            // 
            // Education
            // 
            this.Education.DataPropertyName = "Education";
            this.Education.HeaderText = "Education";
            this.Education.Name = "Education";
            this.Education.ReadOnly = true;
            // 
            // CandidateLocation
            // 
            this.CandidateLocation.DataPropertyName = "CandidateLocation";
            this.CandidateLocation.HeaderText = "Location";
            this.CandidateLocation.Name = "CandidateLocation";
            this.CandidateLocation.ReadOnly = true;
            // 
            // JobTitle
            // 
            this.JobTitle.DataPropertyName = "JobTitle";
            this.JobTitle.HeaderText = "Designation";
            this.JobTitle.Name = "JobTitle";
            this.JobTitle.ReadOnly = true;
            // 
            // PresentEmployer
            // 
            this.PresentEmployer.DataPropertyName = "PresentEmployer";
            this.PresentEmployer.HeaderText = "Present Employer";
            this.PresentEmployer.Name = "PresentEmployer";
            // 
            // Skill
            // 
            this.Skill.DataPropertyName = "Skill";
            this.Skill.HeaderText = "Key Skill";
            this.Skill.Name = "Skill";
            // 
            // PresentCTC
            // 
            this.PresentCTC.DataPropertyName = "PresentCTC";
            this.PresentCTC.HeaderText = "Present CTC";
            this.PresentCTC.Name = "PresentCTC";
            // 
            // PreviousDesignation
            // 
            this.PreviousDesignation.DataPropertyName = "PreviousDesignation";
            this.PreviousDesignation.HeaderText = "Previous Designation";
            this.PreviousDesignation.Name = "PreviousDesignation";
            // 
            // PreviousEmployer
            // 
            this.PreviousEmployer.DataPropertyName = "PreviousEmployer";
            this.PreviousEmployer.HeaderText = "Previous Employer";
            this.PreviousEmployer.Name = "PreviousEmployer";
            // 
            // PrefLocationText
            // 
            this.PrefLocationText.DataPropertyName = "PrefLocationText";
            this.PrefLocationText.HeaderText = "Preferred Location";
            this.PrefLocationText.Name = "PrefLocationText";
            // 
            // SiteResumeID
            // 
            this.SiteResumeID.DataPropertyName = "SiteResumeID";
            this.SiteResumeID.HeaderText = "SiteResumeID";
            this.SiteResumeID.Name = "SiteResumeID";
            this.SiteResumeID.Visible = false;
            // 
            // AutoResumeID
            // 
            this.AutoResumeID.DataPropertyName = "AutoResumeID";
            this.AutoResumeID.HeaderText = "AutoResumeID";
            this.AutoResumeID.Name = "AutoResumeID";
            this.AutoResumeID.Visible = false;
            // 
            // Indicator
            // 
            this.Indicator.DataPropertyName = "Indicator";
            this.Indicator.HeaderText = "Indicator";
            this.Indicator.Name = "Indicator";
            this.Indicator.Visible = false;
            // 
            // URL
            // 
            this.URL.DataPropertyName = "URL";
            this.URL.HeaderText = "URL";
            this.URL.Name = "URL";
            this.URL.Visible = false;
            // 
            // SavedType
            // 
            this.SavedType.DataPropertyName = "SavedType";
            this.SavedType.HeaderText = "SavedType";
            this.SavedType.Name = "SavedType";
            this.SavedType.Visible = false;
            // 
            // ResumeID
            // 
            this.ResumeID.DataPropertyName = "ResumeID";
            this.ResumeID.HeaderText = "ResumeID";
            this.ResumeID.Name = "ResumeID";
            this.ResumeID.Visible = false;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.btnMinanMax);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1283, 28);
            this.panel2.TabIndex = 0;
            // 
            // btnMinanMax
            // 
            this.btnMinanMax.Dock = System.Windows.Forms.DockStyle.Right;
            this.btnMinanMax.Image = global::HireLook.Properties.Resources.Maximise;
            this.btnMinanMax.Location = new System.Drawing.Point(1255, 0);
            this.btnMinanMax.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnMinanMax.Name = "btnMinanMax";
            this.btnMinanMax.Size = new System.Drawing.Size(28, 28);
            this.btnMinanMax.TabIndex = 0;
            this.btnMinanMax.Text = "button1";
            this.btnMinanMax.UseVisualStyleBackColor = true;
            this.btnMinanMax.Click += new System.EventHandler(this.btnMinanMax_Click);
            // 
            // grpSummary
            // 
            this.grpSummary.Controls.Add(this.btnSummaryClose);
            this.grpSummary.Controls.Add(this.lblParsed);
            this.grpSummary.Controls.Add(this.lblDuplicateDoc);
            this.grpSummary.Controls.Add(this.lblUnknownFormatR);
            this.grpSummary.Controls.Add(this.lblFailedSave);
            this.grpSummary.Controls.Add(this.lblDuplicateOverwrite);
            this.grpSummary.Controls.Add(this.label1);
            this.grpSummary.Controls.Add(this.label2);
            this.grpSummary.Controls.Add(this.label3);
            this.grpSummary.Controls.Add(this.label10);
            this.grpSummary.Controls.Add(this.label11);
            this.grpSummary.ForeColor = System.Drawing.Color.Blue;
            this.grpSummary.Location = new System.Drawing.Point(243, 30);
            this.grpSummary.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.grpSummary.Name = "grpSummary";
            this.grpSummary.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.grpSummary.Size = new System.Drawing.Size(583, 110);
            this.grpSummary.TabIndex = 14;
            this.grpSummary.TabStop = false;
            this.grpSummary.Text = "Number of Resumes";
            this.grpSummary.Visible = false;
            // 
            // btnSummaryClose
            // 
            this.btnSummaryClose.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnSummaryClose.Location = new System.Drawing.Point(501, 84);
            this.btnSummaryClose.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnSummaryClose.Name = "btnSummaryClose";
            this.btnSummaryClose.Size = new System.Drawing.Size(80, 26);
            this.btnSummaryClose.TabIndex = 17;
            this.btnSummaryClose.Text = "Close";
            this.btnSummaryClose.UseVisualStyleBackColor = true;
            this.btnSummaryClose.Click += new System.EventHandler(this.btnSummaryClose_Click);
            // 
            // lblParsed
            // 
            this.lblParsed.AutoSize = true;
            this.lblParsed.ForeColor = System.Drawing.Color.Black;
            this.lblParsed.Location = new System.Drawing.Point(529, 53);
            this.lblParsed.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblParsed.Name = "lblParsed";
            this.lblParsed.Size = new System.Drawing.Size(16, 17);
            this.lblParsed.TabIndex = 13;
            this.lblParsed.Text = "0";
            // 
            // lblDuplicateDoc
            // 
            this.lblDuplicateDoc.AutoSize = true;
            this.lblDuplicateDoc.ForeColor = System.Drawing.Color.Black;
            this.lblDuplicateDoc.Location = new System.Drawing.Point(529, 23);
            this.lblDuplicateDoc.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblDuplicateDoc.Name = "lblDuplicateDoc";
            this.lblDuplicateDoc.Size = new System.Drawing.Size(16, 17);
            this.lblDuplicateDoc.TabIndex = 12;
            this.lblDuplicateDoc.Text = "0";
            // 
            // lblUnknownFormatR
            // 
            this.lblUnknownFormatR.AutoSize = true;
            this.lblUnknownFormatR.ForeColor = System.Drawing.Color.Black;
            this.lblUnknownFormatR.Location = new System.Drawing.Point(265, 82);
            this.lblUnknownFormatR.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblUnknownFormatR.Name = "lblUnknownFormatR";
            this.lblUnknownFormatR.Size = new System.Drawing.Size(16, 17);
            this.lblUnknownFormatR.TabIndex = 11;
            this.lblUnknownFormatR.Text = "0";
            // 
            // lblFailedSave
            // 
            this.lblFailedSave.AutoSize = true;
            this.lblFailedSave.ForeColor = System.Drawing.Color.Black;
            this.lblFailedSave.Location = new System.Drawing.Point(265, 53);
            this.lblFailedSave.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblFailedSave.Name = "lblFailedSave";
            this.lblFailedSave.Size = new System.Drawing.Size(16, 17);
            this.lblFailedSave.TabIndex = 10;
            this.lblFailedSave.Text = "0";
            // 
            // lblDuplicateOverwrite
            // 
            this.lblDuplicateOverwrite.AutoSize = true;
            this.lblDuplicateOverwrite.ForeColor = System.Drawing.Color.Black;
            this.lblDuplicateOverwrite.Location = new System.Drawing.Point(265, 23);
            this.lblDuplicateOverwrite.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblDuplicateOverwrite.Name = "lblDuplicateOverwrite";
            this.lblDuplicateOverwrite.Size = new System.Drawing.Size(16, 17);
            this.lblDuplicateOverwrite.TabIndex = 9;
            this.lblDuplicateOverwrite.Text = "0";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(307, 53);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(198, 17);
            this.label1.TabIndex = 6;
            this.label1.Text = "Successfully Parsed Resumes";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(307, 23);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(132, 17);
            this.label2.TabIndex = 6;
            this.label2.Text = "Duplicate (Skipped)";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.ForeColor = System.Drawing.Color.Black;
            this.label3.Location = new System.Drawing.Point(15, 23);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(153, 17);
            this.label3.TabIndex = 6;
            this.label3.Text = "Duplicate (Overwritten)";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.ForeColor = System.Drawing.Color.Black;
            this.label10.Location = new System.Drawing.Point(15, 82);
            this.label10.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(192, 17);
            this.label10.TabIndex = 6;
            this.label10.Text = "Resumes in Unknown Format";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.ForeColor = System.Drawing.Color.Black;
            this.label11.Location = new System.Drawing.Point(15, 53);
            this.label11.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(225, 17);
            this.label11.TabIndex = 5;
            this.label11.Text = "Failed to Save (Invalid documents)";
            // 
            // webBrowser1
            // 
            this.webBrowser1.CausesValidation = false;
            this.webBrowser1.IsWebBrowserContextMenuEnabled = false;
            this.webBrowser1.Location = new System.Drawing.Point(380, 145);
            this.webBrowser1.MinimumSize = new System.Drawing.Size(20, 20);
            this.webBrowser1.Name = "webBrowser1";
            this.webBrowser1.ScriptErrorsSuppressed = true;
            this.webBrowser1.Size = new System.Drawing.Size(202, 59);
            this.webBrowser1.TabIndex = 6;
            this.webBrowser1.WebBrowserShortcutsEnabled = false;
            // 
            // frmImportfromPortals
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1283, 751);
            this.Controls.Add(this.grpSummary);
            this.Controls.Add(this.splitContainer1);
            this.Controls.Add(this.toolStrip1);
            this.Controls.Add(this.statusStrip1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "frmImportfromPortals";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Import Resumes from Portal";
            this.Load += new System.EventHandler(this.frmImportfromPortals_Load);
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.grdCandidate)).EndInit();
            this.panel2.ResumeLayout(false);
            this.grpSummary.ResumeLayout(false);
            this.grpSummary.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel tsbar;
        private System.Windows.Forms.ToolStripProgressBar tspgrs;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripLabel toolStripLabel1;
        private System.Windows.Forms.ToolStripComboBox cmbSource;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripButton tsExits;
        internal Crownwood.Magic.Controls.TabControl cntTab;
        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button btnMinanMax;
        private System.Windows.Forms.ToolStripButton tsSummary;
        internal System.Windows.Forms.GroupBox grpSummary;
        private System.Windows.Forms.Button btnSummaryClose;
        internal System.Windows.Forms.Label lblParsed;
        internal System.Windows.Forms.Label lblDuplicateDoc;
        internal System.Windows.Forms.Label lblUnknownFormatR;
        internal System.Windows.Forms.Label lblFailedSave;
        internal System.Windows.Forms.Label lblDuplicateOverwrite;
        internal System.Windows.Forms.Label label1;
        internal System.Windows.Forms.Label label2;
        internal System.Windows.Forms.Label label3;
        internal System.Windows.Forms.Label label10;
        internal System.Windows.Forms.Label label11;
        private System.Windows.Forms.DataGridView grdCandidate;
        private System.Windows.Forms.ToolStripButton tsLoadtoGrid;
        private System.Windows.Forms.ToolStripButton tsDownload;
        private System.Windows.Forms.ToolStripButton tsStop;
        private System.Windows.Forms.WebBrowser webBrowser1;
        private System.Windows.Forms.DataGridViewCheckBoxColumn Check;
        private System.Windows.Forms.DataGridViewTextBoxColumn IDs;
        private System.Windows.Forms.DataGridViewTextBoxColumn RID;
        private System.Windows.Forms.DataGridViewTextBoxColumn CandidateName;
        private System.Windows.Forms.DataGridViewTextBoxColumn Mobile;
        private System.Windows.Forms.DataGridViewTextBoxColumn PhoneH;
        private System.Windows.Forms.DataGridViewTextBoxColumn TotalExp;
        private System.Windows.Forms.DataGridViewTextBoxColumn Education;
        private System.Windows.Forms.DataGridViewTextBoxColumn CandidateLocation;
        private System.Windows.Forms.DataGridViewTextBoxColumn JobTitle;
        private System.Windows.Forms.DataGridViewTextBoxColumn PresentEmployer;
        private System.Windows.Forms.DataGridViewTextBoxColumn Skill;
        private System.Windows.Forms.DataGridViewTextBoxColumn PresentCTC;
        private System.Windows.Forms.DataGridViewTextBoxColumn PreviousDesignation;
        private System.Windows.Forms.DataGridViewTextBoxColumn PreviousEmployer;
        private System.Windows.Forms.DataGridViewTextBoxColumn PrefLocationText;
        private System.Windows.Forms.DataGridViewTextBoxColumn SiteResumeID;
        private System.Windows.Forms.DataGridViewTextBoxColumn AutoResumeID;
        private System.Windows.Forms.DataGridViewTextBoxColumn Indicator;
        private System.Windows.Forms.DataGridViewTextBoxColumn URL;
        private System.Windows.Forms.DataGridViewTextBoxColumn SavedType;
        private System.Windows.Forms.DataGridViewTextBoxColumn ResumeID;
    }
}