﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Xml;
using System.Windows.Forms;
using System.Runtime.InteropServices;

namespace HireLook
{
    public partial class frmImportfromPortals : Form
    {
        public frmImportfromPortals()
        {
            InitializeComponent();
        }
        
        #region "Memebers"

        bool bStopped = false;
        DataSet dt = null;
        string tCookies = "";
        string tTimesJobCookies = "";
        string tNaukriCoockiesTest = "", tNaukriCoockiesACCESS = "", tNaukriCoockiesUNID = "";


        DataTable dtGridData;
        int iUnKnownFormatResumes = 0, iFailed2Save = 0, iDuplicateDocument = 0, iDuplicateOverwriteDocument = 0, iParsedResume = 0;
        int bFlagNaukri = 0;
        System.Xml.XmlDocument objXnm = null;
        System.Xml.XmlElement objEl = null;
        System.Xml.XmlElement objElSub = null;
        System.Xml.XmlElement objRoot = null;
        #endregion

        #region DllImport

        [DllImport("wininet.dll", CharSet = CharSet.Auto, SetLastError = true)]
        static extern bool InternetGetCookieEx(string pchURL, string pchCookieName, StringBuilder pchCookieData, ref uint pcchCookieData, int dwFlags, IntPtr lpReserved);
        const int INTERNET_COOKIE_HTTPONLY = 0x00002000;

        #endregion
        private void tsExits_Click(object sender, EventArgs e)
        {
            try
            { 
            this.Close();
            }
            catch (Exception ex)
            {
                Log.LogData("Error on Parsing : " + ex.Message + ex.StackTrace, Log.Status.Error);
            }
        }

        private void frmImportfromPortals_Load(object sender, EventArgs e)
        {
            try
            {
                cmbSource.Text = "<--None-->";
                tsExits.Tag = "";
                Crownwood.Magic.Controls.TabPage TP1 = new Crownwood.Magic.Controls.TabPage();
                TP1.VisibleChanged += Tp1_Visible;
                System.Windows.Forms.WebBrowser webBrowser2 = new System.Windows.Forms.WebBrowser();
                //webBrowser2.ScriptErrorsSuppressed = true;
                TP1.Controls.Add(webBrowser2);
                webBrowser2.NewWindow += Web_NewWindow;
                webBrowser2.Navigated += Tp1_DownloadComplited;
                //webBrowser2.CanGoBackChanged += Web_CanGoBackChanged;
                //webBrowser2.CanGoForwardChanged += Web_CanGoForwardChanged;
                webBrowser2.Dock = DockStyle.Fill;
                TP1.Dock = DockStyle.Fill;
                cntTab.TabPages.Add(TP1);
                opClearGrid();
            }
            catch (Exception ex)
            {
               // MessageBox.Show("Error in Parsing : " + ex.Message + ex.StackTrace);
                Log.LogData("Error on Parsing : " + ex.Message + ex.StackTrace, Log.Status.Error);
               
            }
        }
        private void cntTab_ClosePressed(object sender, EventArgs e)
        {
            try
            {
                if (((System.Windows.Forms.WebBrowser)(cntTab.SelectedTab.Controls[0])).Url == null)
                {
                    tsExits.Tag = "";
                }
                else if (tsExits.Tag == ((System.Windows.Forms.WebBrowser)(cntTab.SelectedTab.Controls[0])).Url.AbsoluteUri)
                {
                    tsExits.Tag = "";
                }
                cntTab.TabPages.Remove(cntTab.SelectedTab);
            }
            catch (Exception ex)
            {
                Log.LogData("Error on Parsing : " + ex.Message + ex.StackTrace, Log.Status.Error);
            }
        }

        private void cmbSource_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {

                ((System.Windows.Forms.WebBrowser)(cntTab.SelectedTab.Controls[0])).ScriptErrorsSuppressed = true;
                if (cmbSource.SelectedIndex == 0)
                {
                    ((System.Windows.Forms.WebBrowser)(cntTab.SelectedTab.Controls[0])).DocumentText = "";
                }
                else if (cmbSource.SelectedIndex == 1)
                    ((System.Windows.Forms.WebBrowser)(cntTab.SelectedTab.Controls[0])).Navigate("http://recruiter.monsterindia.com/login.html");
                else if (cmbSource.SelectedIndex == 2)
                {
                    ((System.Windows.Forms.WebBrowser)(cntTab.SelectedTab.Controls[0])).Navigate("http://www.naukri.com/pg/client/cpLogin.php");
                }
                else if (cmbSource.SelectedIndex == 3)
                {
                    ((System.Windows.Forms.WebBrowser)(cntTab.SelectedTab.Controls[0])).Navigate("http://hire.timesjobs.com/employer/login.html");
                }
                else if (cmbSource.SelectedIndex == 4)
                {
                    ((System.Windows.Forms.WebBrowser)(cntTab.SelectedTab.Controls[0])).Navigate("http://recruiter.monstergulf.com/");

                }
                else if (cmbSource.SelectedIndex == 5)
                    ((System.Windows.Forms.WebBrowser)(cntTab.SelectedTab.Controls[0])).Navigate("http://www.careerbuilder.com/share/login.aspx");
                else if (cmbSource.SelectedIndex == 6)
                    ((System.Windows.Forms.WebBrowser)(cntTab.SelectedTab.Controls[0])).Navigate("http://employer.dice.com/employer.epl");
                else if (cmbSource.SelectedIndex == 7)
                {
                    ((System.Windows.Forms.WebBrowser)(cntTab.SelectedTab.Controls[0])).Navigate("https://login.naukrigulf.com/ni/nimnr/mnr_login.php?source=");
                }
                else if (cmbSource.SelectedIndex == 8)
                    ((System.Windows.Forms.WebBrowser)(cntTab.SelectedTab.Controls[0])).Navigate("https://hiring.monster.com/login.aspx?redirect=http%3a%2f%2fhiring.monster.com%2findexprospect.aspx");
                else if (cmbSource.SelectedIndex == 9)
                    ((System.Windows.Forms.WebBrowser)(cntTab.SelectedTab.Controls[0])).Navigate("http://recruiter.monster.com.my/");
                else if (cmbSource.SelectedIndex == 10)
                    ((System.Windows.Forms.WebBrowser)(cntTab.SelectedTab.Controls[0])).Navigate("http://recruiter.monster.com.sg/resumedatabase/resume_search.html?ucid=4");
                else if (cmbSource.SelectedIndex == 11)
                    ((System.Windows.Forms.WebBrowser)(cntTab.SelectedTab.Controls[0])).Navigate("https://hiring.monster.com/login.aspx?redirect=http%3a%2f%2fhiring.monster.com%2findexprospect.2008.10.aspx");
                else if (cmbSource.SelectedIndex == 12)
                    ((System.Windows.Forms.WebBrowser)(cntTab.SelectedTab.Controls[0])).Navigate("http://ats.mcbarronwood.com/");
                else if (cmbSource.SelectedIndex == 13)
                {
                    ((System.Windows.Forms.WebBrowser)(cntTab.SelectedTab.Controls[0])).Navigate("http://www.oilcareers.com/content/login.asp");
                }
                else if (cmbSource.SelectedIndex == 14)
                    ((System.Windows.Forms.WebBrowser)(cntTab.SelectedTab.Controls[0])).Navigate("http://recruitgulf.com/RMS/Login.aspx?ReturnUrl=%2fRMS%2fLanding.aspx");
                else if (cmbSource.SelectedIndex == 15)
                    ((System.Windows.Forms.WebBrowser)(cntTab.SelectedTab.Controls[0])).Navigate("https://ae.oilandgasjobsearch.com/Account/LogOn");
                else if (cmbSource.SelectedIndex == 16)
                {
                    ((System.Windows.Forms.WebBrowser)(cntTab.SelectedTab.Controls[0])).Navigate("http://corp-corp.com/default.aspx?rec=true&Login=true");
                }
                else if (cmbSource.SelectedIndex == 17)
                {
                    ((System.Windows.Forms.WebBrowser)(cntTab.SelectedTab.Controls[0])).Navigate("https://recruiter.monster.com.ph/v2/login.html");
                }
                else if (cmbSource.SelectedIndex == 18)
                {
                    ((System.Windows.Forms.WebBrowser)(cntTab.SelectedTab.Controls[0])).Navigate("http://rms.jobsdb.com/PH/en/EmployerVisitor/RMS");
                }
                else if (cmbSource.SelectedIndex == 19)
                {
                    ((System.Windows.Forms.WebBrowser)(cntTab.SelectedTab.Controls[0])).Navigate("http://www.jobstreet.com.ph/employers/default.htm");
                }

                else if (cmbSource.SelectedIndex == 20)
                {
                    ((System.Windows.Forms.WebBrowser)(cntTab.SelectedTab.Controls[0])).Navigate("http://recruiter.shine.com/");
                }
                else if (cmbSource.SelectedIndex == 21)
                {
                    ((System.Windows.Forms.WebBrowser)(cntTab.SelectedTab.Controls[0])).Navigate("https://www.rigzone.com/login.asp");
                }
                tsLoadtoGrid.Enabled = true;
            }
            catch (Exception ex)
            {
                Log.LogData("Error on Parsing : " + ex.Message + ex.StackTrace, Log.Status.Error);
            }
             
        }

        #region "events"
        private void Tp1_Visible(object sender, System.EventArgs e)
        {
            try
            {
                cntTab.ShowClose = !(((Crownwood.Magic.Controls.TabPage)(sender))).Visible; 
            }
            catch (Exception ex)
            {
                Log.LogData("Error on Parsing : " + ex.Message + ex.StackTrace, Log.Status.Error);
            }
        }
        private void Tp1_DownloadComplited(object sender, System.Windows.Forms.WebBrowserNavigatedEventArgs e)
        {
            try
            {
                Crownwood.Magic.Controls.TabPage tabPageParent = (Crownwood.Magic.Controls.TabPage)((Control)sender).Parent;
                if (((System.Windows.Forms.WebBrowser)(sender)).DocumentTitle != "")
                    tabPageParent.Title = ((System.Windows.Forms.WebBrowser)(sender)).DocumentTitle;
                else if (((System.Windows.Forms.WebBrowser)(sender)) != null && ((System.Windows.Forms.WebBrowser)(sender)).Document != null && string.IsNullOrEmpty(((System.Windows.Forms.WebBrowser)(sender)).DocumentText) == false && ((System.Windows.Forms.WebBrowser)(sender)).DocumentTitle == "")
                {
                    string[] arr = ((System.Windows.Forms.WebBrowser)(sender)).DocumentText.Split(new string[] { "<title>", "</title>" }, StringSplitOptions.RemoveEmptyEntries);
                    if (arr != null && arr.Length > 1)
                        tabPageParent.Title = arr[1];
                }
                else
                    if (cmbSource.SelectedIndex == 0 || cmbSource.SelectedIndex == 21)
                        tabPageParent.Title = "Page";
                //SetDownloadManager();
                ((WebBrowser)sender).Document.Window.Error += new HtmlElementErrorEventHandler(Window_Error);
                //opSetLogoutEvent();

                try
                {
                    ((System.Windows.Forms.WebBrowser)(sender)).Document.GetElementsByTagName("form")["findsimilarform"].SetAttribute("target", "");
                }
                catch { }
            }
            catch (Exception ex)
            {
                Log.LogData("Error on Parsing : " + ex.Message + ex.StackTrace, Log.Status.Error);
            }
        }
        private void Window_Error(object sender, HtmlElementErrorEventArgs e)
        {
            // Ignore the error and suppress the error dialog box.  
            e.Handled = true;
        }
        private void Web_NewWindow(object sender, System.ComponentModel.CancelEventArgs e)
        {
            try
            {
                e.Cancel = true;
                if (cmbSource.SelectedIndex == 3)
                {
                    if (!string.IsNullOrEmpty(tsExits.Tag.ToString()))
                    {
                        if (tsExits.Tag == ((System.Windows.Forms.WebBrowser)(sender)).Document.ActiveElement.GetAttribute("href"))
                        {
                            return;
                        }
                        else if (((System.Windows.Forms.WebBrowser)(sender)).Document.ActiveElement.GetAttribute("href").StartsWith("resumeDetailView.html"))
                        {
                            if (tsExits.Tag == "http://hire.timesjobs.com/employer/" + ((System.Windows.Forms.WebBrowser)(sender)).Document.ActiveElement.GetAttribute("href"))
                            {
                                return;
                            }
                        }
                    }
                    if (((System.Windows.Forms.WebBrowser)(sender)).Document.ActiveElement.Parent != null && ((System.Windows.Forms.WebBrowser)(sender)).Document.ActiveElement.Parent.Id != null && ((System.Windows.Forms.WebBrowser)(sender)).Document.ActiveElement.Parent.Id.StartsWith("similar"))
                    {
                        string inputid = ((System.Windows.Forms.WebBrowser)(sender)).Document.ActiveElement.Parent.FirstChild.GetAttribute("value");
                        tsExits.Tag = "http://hire.timesjobs.com/employer/quickSearch.html?" + inputid;

                    }
                    else
                    {
                        tsExits.Tag = ((System.Windows.Forms.WebBrowser)(sender)).Document.ActiveElement.GetAttribute("href");
                        if (tsExits.Tag.ToString().StartsWith("resumeDetailView.html"))
                            tsExits.Tag = "http://hire.timesjobs.com/employer/" + tsExits.Tag;
                    }
                }
                else
                {
                    if (string.IsNullOrEmpty(((System.Windows.Forms.WebBrowser)(sender)).StatusText))
                    {
                        return;
                    }
                    if (!string.IsNullOrEmpty(tsExits.Tag.ToString()))
                    {
                        if (tsExits.Tag.ToString() == ((System.Windows.Forms.WebBrowser)(sender)).StatusText)
                        {
                            return;
                        }
                    }
                    tsExits.Tag = ((System.Windows.Forms.WebBrowser)(sender)).StatusText;
                }
                if (tsExits.Tag.ToString() == "Done" || tsExits.Tag.ToString().StartsWith("Opening page ") == true || tsExits.Tag.ToString().ToLower() == "fetching resume")
                    return;
                if (cntTab.TabPages.Count < 5)
                {
                    switch (cntTab.TabPages.Count)
                    {
                        case 1:
                            Crownwood.Magic.Controls.TabPage TP2 = new Crownwood.Magic.Controls.TabPage();
                            System.Windows.Forms.WebBrowser WebBrowser3 = new System.Windows.Forms.WebBrowser();
                              WebBrowser3.ScriptErrorsSuppressed = true;

                            TP2.Controls.Add(WebBrowser3);
                            WebBrowser3.NewWindow += Web_NewWindow;
                            WebBrowser3.Navigated += Tp1_DownloadComplited;
                            //WebBrowser3.CanGoBackChanged += Web_CanGoBackChanged;
                            //WebBrowser3.CanGoForwardChanged += Web_CanGoForwardChanged;
                            WebBrowser3.Navigate(tsExits.Tag + "");
                            WebBrowser3.Dock = DockStyle.Fill;
                            TP2.Dock = DockStyle.Fill;
                            cntTab.TabPages.Add(TP2);
                            cntTab.SelectedTab = TP2;
                            break;
                        case 2:
                            Crownwood.Magic.Controls.TabPage TP3 = new Crownwood.Magic.Controls.TabPage();
                            System.Windows.Forms.WebBrowser WebBrowser4 = new System.Windows.Forms.WebBrowser();
                           WebBrowser4.ScriptErrorsSuppressed = true;

                            TP3.Controls.Add(WebBrowser4);
                            WebBrowser4.NewWindow += Web_NewWindow;
                            WebBrowser4.Navigated += Tp1_DownloadComplited;
                            //WebBrowser4.CanGoBackChanged += Web_CanGoBackChanged;
                            //WebBrowser4.CanGoForwardChanged += Web_CanGoForwardChanged;
                            WebBrowser4.Navigate(tsExits.Tag + "");
                            WebBrowser4.Dock = DockStyle.Fill;
                            TP3.Dock = DockStyle.Fill;
                            cntTab.TabPages.Add(TP3);
                            cntTab.SelectedTab = TP3;

                            break;

                        case 3:
                            Crownwood.Magic.Controls.TabPage TP4 = new Crownwood.Magic.Controls.TabPage();
                            System.Windows.Forms.WebBrowser WebBrowser5 = new System.Windows.Forms.WebBrowser();
                           WebBrowser5.ScriptErrorsSuppressed = true;
                            TP4.Controls.Add(WebBrowser5);
                            WebBrowser5.NewWindow += Web_NewWindow;
                            WebBrowser5.Navigated += Tp1_DownloadComplited;
                            //WebBrowser5.CanGoBackChanged += Web_CanGoBackChanged;
                            //WebBrowser5.CanGoForwardChanged += Web_CanGoForwardChanged;
                            WebBrowser5.Navigate(tsExits.Tag + "");
                            WebBrowser5.Dock = DockStyle.Fill;
                            TP4.Dock = DockStyle.Fill;
                            cntTab.TabPages.Add(TP4);
                            cntTab.SelectedTab = TP4;

                            break;

                        case 4:
                            Crownwood.Magic.Controls.TabPage TP5 = new Crownwood.Magic.Controls.TabPage();
                            System.Windows.Forms.WebBrowser WebBrowser6 = new System.Windows.Forms.WebBrowser();
                    WebBrowser6.ScriptErrorsSuppressed = true;
                            TP5.Controls.Add(WebBrowser6);
                            WebBrowser6.NewWindow += Web_NewWindow;
                            WebBrowser6.Navigated += Tp1_DownloadComplited;
                            //WebBrowser6.CanGoBackChanged += Web_CanGoBackChanged;
                            //WebBrowser6.CanGoForwardChanged += Web_CanGoForwardChanged;
                            WebBrowser6.Navigate(tsExits.Tag + "");
                            WebBrowser6.Dock = DockStyle.Fill;
                            TP5.Dock = DockStyle.Fill;
                            cntTab.TabPages.Add(TP5);
                            cntTab.SelectedTab = TP5;

                            break;

                        case 5:

                            break;


                    }
                }
                else
                {

                    Crownwood.Magic.Controls.TabPage TP6 = new Crownwood.Magic.Controls.TabPage();
                    System.Windows.Forms.WebBrowser WebBrowser7 = new System.Windows.Forms.WebBrowser();
                    WebBrowser7.ScriptErrorsSuppressed = true;
                    TP6.Controls.Add(WebBrowser7);
                    WebBrowser7.NewWindow += Web_NewWindow;
                    WebBrowser7.Navigated += Tp1_DownloadComplited;
                    //WebBrowser7.CanGoBackChanged += Web_CanGoBackChanged;
                    //WebBrowser7.CanGoForwardChanged += Web_CanGoForwardChanged;
                    WebBrowser7.Navigate(tsExits.Tag+"");
                    WebBrowser7.Dock = DockStyle.Fill;
                    TP6.Dock = DockStyle.Fill;
                    cntTab.TabPages.Add(TP6);
                    cntTab.SelectedTab = TP6;
                }
            }
            catch (Exception ex)
            {
                Log.LogData("Error on Parsing : " + ex.Message + ex.StackTrace, Log.Status.Error);
            }
        }
        private void btnMinanMax_Click(object sender, EventArgs e)
        {
            try
            {
                if (!splitContainer1.Panel1Collapsed == true)
                    splitContainer1.Panel1Collapsed = true;
                else
                    splitContainer1.Panel1Collapsed = false;
            }
            catch (Exception ex)
            {
                Log.LogData("Error on Parsing : " + ex.Message + ex.StackTrace, Log.Status.Error);
            }

        }
        #endregion

        private void tsSummary_Click(object sender, EventArgs e)
        {
            try {
                grpSummary.Visible = true;
            }
            catch (Exception ex)
            {
                Log.LogData("Error on Parsing : " + ex.Message + ex.StackTrace, Log.Status.Error);
            }

        }

        private void btnSummaryClose_Click(object sender, EventArgs e)
        {

            try {
                grpSummary.Visible = false;
            }
            catch (Exception ex)
            {
                Log.LogData("Error on Parsing : " + ex.Message + ex.StackTrace, Log.Status.Error);
            }
        }

        private void tsLoadtoGrid_Click(object sender, EventArgs e)
        {
            try
            { 
                string tURL = (((System.Windows.Forms.WebBrowser)(cntTab.SelectedTab.Controls[0]))).Url.ToString();
                if (opValidJobSiteMonster(tURL))
                    bFlagNaukri = 1;
                else if (opValidJobSiteNaukri(tURL))
                    bFlagNaukri = 2;
                else if (opValidJobSiteResponseBRVNaukri(tURL))//response.
                    bFlagNaukri = 211;
                else if (opValidJobSiteResponseeAppNaukri(tURL))//response.
                    bFlagNaukri = 221;
                else if (opValidJobSiteResponseNaukriGulf(tURL))
                    bFlagNaukri = 231;
                else if (opValidJobSitetimesjobs(tURL))
                    bFlagNaukri = 3;
                else if (opValidJobSiteMonstergulf(tURL))
                    bFlagNaukri = 4;
                else if (opValidCareerBuilder(tURL))
                    bFlagNaukri = 5;
                else if (opValidDice(tURL))
                    bFlagNaukri = 6;
                else if (opValidJobSiteNaukrigulf(tURL))
                    bFlagNaukri = 7;
                else if (opValidJobSiteMonsterSingapore(tURL) && bFlagNaukri != 17)
                    bFlagNaukri = 8;
                else if (opValidJobSiteMonsterMalaysia(tURL))
                    bFlagNaukri = 9;
                tURL = null;

                System.Windows.Forms.Application.DoEvents();
                opSetCursorBusy();
                //HireCraft.UiCommonLinks.CheckMarkSelection.GridCheckMarksSelection sel;
                //sel = new HireCraft.UiCommonLinks.CheckMarkSelection.GridCheckMarksSelection(gvwCandidate);
                //sel.Attach(gvwCandidate, gcCandidateChk, rpchkCandidate);
                //sel.ClearSelection();

                dt = new DataSet("Main");
                System.Windows.Forms.Application.DoEvents();
                (((System.Windows.Forms.WebBrowser)(cntTab.SelectedTab.Controls[0]))).Focus();
                //grdCandidate.DataSource = null;
                //opClearGrid();
                tspgrs.Value = 1;
                tspgrs.Visible = true;
                dtGridData.Clear();
                grdCandidate.Refresh();
                opSetMessage("Loading into the grid ..."); 
                if ((((System.Windows.Forms.WebBrowser)(cntTab.SelectedTab.Controls[0]))).DocumentText.ToString().Trim() != "")
                {
                    #region "Monster "

                    if (bFlagNaukri == 1)//(opValidJobSiteMonster(br1.Url.ToString()))
                    {
                        //bFlagNaukri = 1;

                        objXnm = new System.Xml.XmlDocument();
                        objEl = objXnm.CreateElement("ROOT");
                        objXnm.AppendChild(objEl);
                        objRoot = objXnm.DocumentElement;

                        string[] st = { "<input type=\"checkbox\" name=\"resID\"", "<input name=\"resID\" type=\"checkbox\"" };
                        string[] st1 = { "<!--loop ends-->" };
                        string[] st2 = { "&nbsp;", "similar resumes", "Similar Resumes", "\r\n\r\n", "\r\n", "Viewed ", "New", "\n", "\t", "Contacted by Email" };//, "\r\n", "<BR>", "<br>", "<br />", "<br/>", "\n\t\n", "\n" 
                        string[] st3 = { "resumedatabase/resume.html?" };
                        string[] st4 = { ";words=", "\" target=_blank ;", "\" target=_blank>" };//" target=_blank ;
                        string[] tSpNewVMJun14 = { "<!--<td", " >-->" };
                        bool bNewVersion = false;
                        bool bNewNewVersion = false;
                        try
                        {
                            int i = 0; string[] str;
                            string[] str1 = (((System.Windows.Forms.WebBrowser)(cntTab.SelectedTab.Controls[0]))).Document.Body.InnerHtml.ToString().Split(st3, StringSplitOptions.RemoveEmptyEntries);
                            //if (str1.Length < 10)
                            //{
                            //    str = (((System.Windows.Forms.WebBrowser)(cntTab.SelectedTab.Controls[0]))).DocumentText.ToString().Split(st, StringSplitOptions.RemoveEmptyEntries);
                            //}
                            //else
                            {
                                str = str1; bNewVersion = true;
                                bNewNewVersion = true;
                            }
                            if ((((System.Windows.Forms.WebBrowser)(cntTab.SelectedTab.Controls[0]))).DocumentText.ToString().IndexOf("Old Version") >= 0)
                            {
                                bNewVersion = true;
                                if (str1.Length < 10)
                                {
                                    bNewNewVersion = true;
                                    string[] tSpNewVM = { "<table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"3\">", "<TABLE cellSpacing=0 cellPadding=3 width=\"100%\" border=0>", "<td width=\"19\" valign=\"top\" align=\"center\" style=\"padding: 0px 5px 0px 0px;\">", "<TD style=\"PADDING-RIGHT: 5px; PADDING-LEFT: 0px; PADDING-BOTTOM: 0px; PADDING-TOP: 15px\" vAlign=top align=middle width=19>" };
                                    str = ((System.Windows.Forms.WebBrowser)(cntTab.SelectedTab.Controls[0])).Document.Body.InnerHtml.ToString().Split(st3, StringSplitOptions.RemoveEmptyEntries);
                                }
                            }
                            int j = str.GetUpperBound(0);
                            tspgrs.Minimum = i;
                            tspgrs.Maximum = j;
                            tspgrs.Step = 1;
                            foreach (string stre in str)
                            {
                                if (i > 0 && i <= j)
                                {
                                    try
                                    {
                                        if (stre.IndexOf("function getRids()") >= 0) continue;

                                        string IDs = "";
                                        if (bNewNewVersion)
                                            IDs = stre.Split(st4, StringSplitOptions.RemoveEmptyEntries)[0];
                                        else if (bNewVersion)
                                            IDs = stre.Split(st3, StringSplitOptions.RemoveEmptyEntries)[1].Split(st4, StringSplitOptions.RemoveEmptyEntries)[0];
                                        string tNewStre = stre;
                                        string[] strJun14 = stre.Split(tSpNewVMJun14, StringSplitOptions.RemoveEmptyEntries);
                                        if (strJun14.Length >= 3)
                                            tNewStre = strJun14[2];
                                        string stText = "";
                                        string[] stSp;
                                        if (bNewVersion == false)
                                        {
                                            IDs = tNewStre.Split(st3, StringSplitOptions.RemoveEmptyEntries)[1].Split(st4, StringSplitOptions.RemoveEmptyEntries)[0];

                                            stText = RemoveHTMLNew("<input type=\"checkbox\" name=\"resID\" " + tNewStre).Trim();
                                            stSp = stText.Split(st2, StringSplitOptions.RemoveEmptyEntries);
                                            //opCreateNodes(stSp, IDs);
                                        }
                                        else
                                        {

                                            if (bNewNewVersion)
                                                stText = RemoveHTMLNew("<td><A   " + tNewStre).Replace("Click for contact details", "").Trim();
                                            else if (bNewVersion)
                                                stText = RemoveHTMLNew("<tr><td><input type=\"checkbox\" name=\"resID\"" + tNewStre).Replace("Click for contact details", "").Trim();
                                            string[] aNst2 = { "&nbsp;", "<br/>", "\r\n", "Viewed ", "New", "\n", "\t", "Contacted by Email" };
                                            string[] aEnd = { " Send Email", "Send Email", "Freshness:", "Similar Resumes", "<A", "<a" };
                                            stSp = stText.Split(aEnd, StringSplitOptions.RemoveEmptyEntries)[0].Trim().Split(aNst2, StringSplitOptions.RemoveEmptyEntries);//
                                        }

                                        int iMobFound = 0, iYearofParsing = 0, iEndDesignation = 0, iFoundSkill = 0;
                                        string[] stMain1 = new string[12];
                                        string tCurrentEmploye = "", tExp = "", tCTC = "", tPhone = "", tMobile = "", tREsumeID = "", preferredLocation = "", tLocation = "", tDesignation = "";
                                        for (int iLocCnt = 0; iLocCnt <= stSp.GetUpperBound(0); iLocCnt++)
                                        {
                                            if (stSp[iLocCnt].ToLower().IndexOf("annual salary:") >= 0 || stSp[iLocCnt].ToLower().IndexOf("annual salary") >= 0)
                                                tCTC = stSp[iLocCnt].Split(':')[stSp[iLocCnt].Split(':').GetUpperBound(0)].Replace("Rs.", "").Replace("annually", "").Replace(",", "").Trim();
                                            if (stSp[iLocCnt].ToLower().IndexOf("exp:") >= 0)
                                            {
                                                tExp = stSp[iLocCnt].Split(':')[stSp[iLocCnt].Split(':').GetUpperBound(0)];
                                                iFoundSkill = iLocCnt;
                                            }
                                            if (stSp[iLocCnt].IndexOf("Industry") >= 0 && iFoundSkill == 0)
                                            {
                                                iFoundSkill = iLocCnt;
                                            }
                                            if (stSp[iLocCnt].IndexOf("Year of Passing") >= 0)
                                            {
                                                iYearofParsing = iLocCnt;
                                            }
                                            if (stSp[iLocCnt].ToLower().IndexOf("mobile:") >= 0)
                                            {
                                                tMobile = stSp[iLocCnt].Split(':')[stSp[iLocCnt].Split(':').GetUpperBound(0)];
                                                iMobFound = iLocCnt;
                                            }
                                            if ((stSp[iLocCnt].IndexOf("Annual Salary") >= 0 || stSp[iLocCnt].IndexOf("Designation:") >= 0) && iEndDesignation == 0)
                                                iEndDesignation = iLocCnt;
                                            if (stSp[iLocCnt].ToLower().IndexOf("telephone:") >= 0)
                                            {
                                                tPhone = stSp[iLocCnt].Split(':')[stSp[iLocCnt].Split(':').GetUpperBound(0)];
                                                if (iMobFound == 0) iMobFound = iLocCnt;
                                            }
                                            if (stSp[iLocCnt].ToLower().IndexOf("resume id:") >= 0)
                                            {
                                                tREsumeID = stSp[iLocCnt].Split(':')[stSp[iLocCnt].Split(':').GetUpperBound(0)];

                                            }
                                            if (stSp[iLocCnt].ToLower().IndexOf("current:") >= 0)
                                            {
                                                tLocation = stSp[iLocCnt].Split(':')[stSp[iLocCnt].Split(':').GetUpperBound(0)];
                                                if (iMobFound == 0) iMobFound = iLocCnt;
                                                if (tLocation == "" && stSp[iLocCnt + 1].IndexOf("Nationality:") < 0)
                                                    tLocation = stSp[iLocCnt + 1].Split(':')[stSp[iLocCnt + 1].Split(':').GetUpperBound(0)];
                                            }
                                            if (stSp[iLocCnt].ToLower().IndexOf("preferred location:") >= 0 || stSp[iLocCnt].ToLower().IndexOf("preferred:") >= 0)
                                            {
                                                preferredLocation = stSp[iLocCnt].Split(':')[stSp[iLocCnt].Split(':').GetUpperBound(0)].Trim();

                                            }

                                            if (stSp[iLocCnt].ToLower().IndexOf("designation:") >= 0)
                                            {
                                                tDesignation = stSp[iLocCnt].Split(':')[stSp[iLocCnt].Split(':').GetUpperBound(0)].Trim();

                                            }

                                            //if (stSp[iLocCnt].ToLower().IndexOf("last active:") >= 0)
                                            //    if (stSp[iLocCnt + 1].IndexOf("Resume ID") >= 0)
                                            //    {
                                            //        if (stSp[iLocCnt + 2].IndexOf("Exp") < 0 && stSp[iLocCnt + 2].ToLower().IndexOf("annual salary") < 0 && stSp[iLocCnt + 2].IndexOf("year") < 0)
                                            //            tCurrentEmploye = stSp[iLocCnt + 2].Split(':')[stSp[iLocCnt + 2].Split(':').GetUpperBound(0)];
                                            //    }
                                            //    else
                                            //        tCurrentEmploye = stSp[iLocCnt + 1].Split(':')[stSp[iLocCnt + 1].Split(':').GetUpperBound(0)];
                                        }
                                        if (iMobFound > 0 && iEndDesignation == 0)
                                            iEndDesignation = iMobFound - 1;
                                        if (iYearofParsing > 0 && iEndDesignation > 0)
                                        {
                                            for (int iLocCnt = iYearofParsing + 1; iLocCnt < iEndDesignation && tCurrentEmploye == ""; iLocCnt++)
                                            {
                                                tCurrentEmploye = stSp[iLocCnt];
                                                break;
                                            }
                                        }
                                        string tSkill = "";
                                        if (iFoundSkill > 0)
                                        {
                                            for (int iLocCnt = 0; iLocCnt < iFoundSkill; iLocCnt++)
                                            {
                                                tSkill += stSp[iLocCnt];
                                            }
                                        }

                                        if (iMobFound == 0)
                                            stMain1[0] = stSp[stSp.GetUpperBound(0) - 1];
                                        else
                                            stMain1[0] = stSp[iMobFound - 1];
                                        if (stMain1[0].IndexOf("(") >= 0)
                                        {
                                            string[] a = stMain1[0].Split('(');
                                            stMain1[0] = a[0];
                                        }
                                        stMain1[1] = tPhone;
                                        stMain1[2] = tMobile;
                                        stMain1[3] = tLocation;// (stSp[stSp.GetUpperBound(0)].Trim() == "Viewed" ? stSp[stSp.GetUpperBound(0) - 1] : stSp[stSp.GetUpperBound(0)]);
                                        if (stMain1[3] == stMain1[0])
                                            stMain1[0] = "";

                                        stMain1[4] = tCurrentEmploye.Replace("Not employed currently", "").Replace("NA\t", "").Replace("None\t", "").Replace("nil\t", "").Replace("Nil\t", "").Replace("NOT EMPLOYED CURRENTLY", "").Replace(" no", "").Replace(" No", "").Trim();
                                        stMain1[5] = tSkill;//skill
                                        stMain1[6] = (iYearofParsing > 0 ? stSp[iYearofParsing - 1] : stSp[2]);//education
                                        stMain1[7] = tCTC;
                                        stMain1[8] = tExp;
                                        stMain1[9] = preferredLocation;
                                        stMain1[10] = tREsumeID.Trim();
                                        stMain1[11] = tDesignation.Trim();
                                        opCreateMonsterNewVersion(stMain1, IDs); 

                                    }
                                    catch { }

                                }
                                tspgrs.PerformStep();
                                //tspgrs.Refresh();
                                i++;
                            }

                            tspgrs.Value = 0;
                            i++;
                            dt.ReadXml(new System.IO.StringReader(objXnm.OuterXml));
                            try
                            {
                                //grdCandidate.BeginUpdate();
                                dtGridData.Merge(dt.Tables[0], true);
                                tsDownload.Enabled = true;
                            }
                            catch { }
                            finally
                            {
                                //grdCandidate.EndUpdate();
                                grdCandidate.Refresh();
                                //sel.SelectAll();
                                //grdCandidate_DataSourceChanged(null, null);
                            }
                            Application.DoEvents();
                        }
                        catch
                        { }
                    }
                    #endregion

                    #region "Monster Gulf "

                    if (bFlagNaukri == 4)//if (opValidJobSiteMonstergulf(br1.Url.ToString()))
                    {
                        objXnm = new System.Xml.XmlDocument();
                        objEl = objXnm.CreateElement("ROOT");
                        objXnm.AppendChild(objEl);
                        objRoot = objXnm.DocumentElement;

                        string[] st = { "<input type=\"checkbox\" name=\"resID\"", "<input name=\"resID\" type=\"checkbox\"" };
                        string[] st1 = { "<!--loop ends-->" };
                        string[] st2 = { "&nbsp;", "similar resumes", "Similar Resumes", "\r\n\r\n", "\r\n", "Viewed ", "New", "\n", "\t", "Contacted by Email" };//, "\r\n", "<BR>", "<br>", "<br />", "<br/>", "\n\t\n", "\n" 
                        string[] st3 = { "resumedatabase/resume.html?" };
                        string[] st4 = { ";words=", "\" target=_blank ;", "\" target=_blank>" };//" target=_blank ;
                        string[] tSpNewVMJun14 = { "<!--<td", " >-->" };
                        bool bNewVersion = false;
                        bool bNewNewVersion = false;
                        try
                        {
                            int i = 0; string[] str;
                            string[] str1 = (((System.Windows.Forms.WebBrowser)(cntTab.SelectedTab.Controls[0]))).Document.Body.InnerHtml.ToString().Split(st3, StringSplitOptions.RemoveEmptyEntries);
                            //if (str1.Length < 10)
                            //{
                            //    str = (((System.Windows.Forms.WebBrowser)(cntTab.SelectedTab.Controls[0]))).DocumentText.ToString().Split(st, StringSplitOptions.RemoveEmptyEntries);
                            //}
                            //else
                            {
                                str = str1; bNewVersion = true;
                                bNewNewVersion = true;
                            }
                            if ((((System.Windows.Forms.WebBrowser)(cntTab.SelectedTab.Controls[0]))).DocumentText.ToString().IndexOf("Old Version") >= 0)
                            {
                                bNewVersion = true;
                                if (str1.Length < 10)
                                {
                                    bNewNewVersion = true;
                                    string[] tSpNewVM = { "<table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"3\">", "<TABLE cellSpacing=0 cellPadding=3 width=\"100%\" border=0>", "<td width=\"19\" valign=\"top\" align=\"center\" style=\"padding: 0px 5px 0px 0px;\">", "<TD style=\"PADDING-RIGHT: 5px; PADDING-LEFT: 0px; PADDING-BOTTOM: 0px; PADDING-TOP: 15px\" vAlign=top align=middle width=19>" };
                                    str = ((System.Windows.Forms.WebBrowser)(cntTab.SelectedTab.Controls[0])).Document.Body.InnerHtml.ToString().Split(st3, StringSplitOptions.RemoveEmptyEntries);
                                }
                            }
                            int j = str.GetUpperBound(0);
                            foreach (string stre in str)
                            {
                                if (i > 0 && i <= j)
                                {
                                    try
                                    {
                                        if (stre.IndexOf("function getRids()") >= 0) continue;

                                        string IDs = "";
                                        if (bNewNewVersion)
                                            IDs = stre.Split(st4, StringSplitOptions.RemoveEmptyEntries)[0];
                                        else if (bNewVersion)
                                            IDs = stre.Split(st3, StringSplitOptions.RemoveEmptyEntries)[1].Split(st4, StringSplitOptions.RemoveEmptyEntries)[0];
                                        string tNewStre = stre;
                                        string[] strJun14 = stre.Split(tSpNewVMJun14, StringSplitOptions.RemoveEmptyEntries);
                                        if (strJun14.Length >= 3)
                                            tNewStre = strJun14[2];
                                        string stText = "";
                                        string[] stSp;
                                        if (bNewVersion == false)
                                        {
                                            IDs = tNewStre.Split(st3, StringSplitOptions.RemoveEmptyEntries)[1].Split(st4, StringSplitOptions.RemoveEmptyEntries)[0];

                                            stText = RemoveHTMLNew("<input type=\"checkbox\" name=\"resID\" " + tNewStre).Trim();
                                            stSp = stText.Split(st2, StringSplitOptions.RemoveEmptyEntries);
                                            //opCreateNodes(stSp, IDs);
                                        }
                                        else
                                        {

                                            if (bNewNewVersion)
                                                stText = RemoveHTMLNew("<td><A   " + tNewStre).Replace("Click for contact details", "").Trim();
                                            else if (bNewVersion)
                                                stText = RemoveHTMLNew("<tr><td><input type=\"checkbox\" name=\"resID\"" + tNewStre).Replace("Click for contact details", "").Trim();
                                            string[] aNst2 = { "&nbsp;", "<br/>", "\r\n", "Viewed ", "New", "\n", "\t", "Contacted by Email" };
                                            string[] aEnd = { " Send Email", "Send Email", "Freshness:", "Similar Resumes", "<A", "<a" };
                                            stSp = stText.Split(aEnd, StringSplitOptions.RemoveEmptyEntries)[0].Trim().Split(aNst2, StringSplitOptions.RemoveEmptyEntries);//
                                        }

                                        int iMobFound = 0, iYearofParsing = 0, iEndDesignation = 0, iFoundSkill = 0;
                                        string[] stMain1 = new string[12];
                                        string tCurrentEmploye = "", tExp = "", tCTC = "", tPhone = "", tMobile = "", tREsumeID = "", preferredLocation = "", tLocation = "", tDesignation = "";
                                        for (int iLocCnt = 0; iLocCnt <= stSp.GetUpperBound(0); iLocCnt++)
                                        {
                                            // Commented by Mohan G on 10-Sep-2014
                                            //if (stSp[iLocCnt].ToLower().IndexOf("annual salary:") >= 0 || stSp[iLocCnt].ToLower().IndexOf("annual salary") >= 0)
                                            //    tCTC = stSp[iLocCnt].Split(':')[stSp[iLocCnt].Split(':').GetUpperBound(0)].Replace("Rs.", "").Replace("annually", "").Replace(",", "").Trim();

                                            // Mohan G on 10-Sep-2014 :::::::::::::::::::::::::::::
                                            // For Picking the Salary.
                                            try
                                            {
                                                if (stSp[iLocCnt].ToLower().IndexOf("annual salary:") >= 0 || stSp[iLocCnt].ToLower().IndexOf("annual salary") >= 0)
                                                {
                                                    tCTC = stSp[iLocCnt].Split(':')[stSp[iLocCnt].Split(':').GetUpperBound(0)].Trim().ToLower().Replace("aed", "").Replace("inr", "").Replace("rs.", "").Replace("rs", "").Replace("usd", "").Replace("annually", "").Replace(",", "").Trim();
                                                }
                                                else if (stSp[iLocCnt].ToLower().IndexOf("salary:") >= 0 || stSp[iLocCnt].ToLower().IndexOf("salary") >= 0)
                                                {
                                                    // Checking Annual Salary
                                                    string tValue = stSp[iLocCnt].Split(':')[stSp[iLocCnt].Split(':').GetUpperBound(0)].Trim().ToLower();
                                                    if (tValue.Contains("annual") || tValue.Contains("annum"))
                                                    {
                                                        //  tCTC = tValue.Replace("aed", "").Replace("rs.", "").Replace("usd", "").Replace("annually", "").Replace("per/annum", "").Replace("per", "").Replace("annum", "").Replace("/", "").Replace(",", "").Trim();
                                                        string tValue1 = tValue.Replace("annually", "").Replace("per/annum", "").Replace("per", "").Replace("annum", "").Replace("/", "").Replace(",", "").Trim();
                                                        if (tValue1.Trim() != "")
                                                            tCTC = opGetCTC(tValue1.Trim());
                                                    }
                                                    else if (tValue.Contains("month"))
                                                    {
                                                        string tValue1 = tValue.Replace("per/month", "").Replace("per", "").Replace("month", "").Replace("/", "").Replace(",", "").Trim();
                                                        if (tValue1.Trim() != "")
                                                            tCTC = opGetCTC(tValue1.Trim());
                                                    }
                                                    else
                                                    {
                                                        tCTC = tValue.Replace("aed", "").Replace("inr", "").Replace("rs.", "").Replace("rs", "").Replace("usd", "").Replace(",", "").Replace(" ", "").Trim();
                                                    }
                                                }
                                            }

                                            catch { }

                                            // End ::::::::::::::::::::::::::::::::::::::::::::::::::  

                                            if (stSp[iLocCnt].ToLower().IndexOf("exp:") >= 0)
                                            {
                                                tExp = stSp[iLocCnt].Split(':')[stSp[iLocCnt].Split(':').GetUpperBound(0)];
                                                iFoundSkill = iLocCnt;
                                            }
                                            if (stSp[iLocCnt].IndexOf("Industry") >= 0 && iFoundSkill == 0)
                                            {
                                                iFoundSkill = iLocCnt;
                                            }
                                            if (stSp[iLocCnt].IndexOf("Year of Passing") >= 0)
                                            {
                                                iYearofParsing = iLocCnt;
                                            }
                                            if (stSp[iLocCnt].ToLower().IndexOf("mobile:") >= 0)
                                            {
                                                tMobile = stSp[iLocCnt].Split(':')[stSp[iLocCnt].Split(':').GetUpperBound(0)];
                                                iMobFound = iLocCnt;
                                            }
                                            if ((stSp[iLocCnt].IndexOf("Annual Salary") >= 0 || stSp[iLocCnt].IndexOf("Designation:") >= 0) && iEndDesignation == 0)
                                                iEndDesignation = iLocCnt;
                                            if (stSp[iLocCnt].ToLower().IndexOf("telephone:") >= 0)
                                            {
                                                tPhone = stSp[iLocCnt].Split(':')[stSp[iLocCnt].Split(':').GetUpperBound(0)];
                                                if (iMobFound == 0) iMobFound = iLocCnt;
                                            }
                                            if (stSp[iLocCnt].ToLower().IndexOf("resume id:") >= 0)
                                            {
                                                tREsumeID = stSp[iLocCnt].Split(':')[stSp[iLocCnt].Split(':').GetUpperBound(0)];

                                            }
                                            if (stSp[iLocCnt].ToLower().IndexOf("current:") >= 0)
                                            {
                                                tLocation = stSp[iLocCnt].Split(':')[stSp[iLocCnt].Split(':').GetUpperBound(0)];
                                                if (iMobFound == 0) iMobFound = iLocCnt;
                                                // Mohan G on 10-Sep-2014 ::::
                                                try
                                                {
                                                    if (tLocation.Trim() == "" && !stSp[iLocCnt + 1].Contains(":"))
                                                    {
                                                        tLocation = stSp[iLocCnt + 1].Trim();
                                                    }
                                                }
                                                catch { }
                                                // End ::::::::::::::::::::::::

                                                if (tLocation == "" && stSp[iLocCnt + 1].IndexOf("Nationality:") < 0)
                                                    tLocation = stSp[iLocCnt + 1].Split(':')[stSp[iLocCnt + 1].Split(':').GetUpperBound(0)];
                                            }
                                            if (stSp[iLocCnt].ToLower().IndexOf("preferred location:") >= 0 || stSp[iLocCnt].ToLower().IndexOf("preferred:") >= 0)
                                            {
                                                preferredLocation = stSp[iLocCnt].Split(':')[stSp[iLocCnt].Split(':').GetUpperBound(0)].Trim();

                                                // Mohan G on 10-Sep-2014 ::::
                                                try
                                                {
                                                    if (preferredLocation.Trim() == "" && !stSp[iLocCnt + 1].Contains(":"))
                                                    {
                                                        preferredLocation = stSp[iLocCnt + 1].Trim();
                                                    }
                                                }
                                                catch { }
                                                // End ::::::::::::::::::::::::
                                            }

                                            if (stSp[iLocCnt].ToLower().IndexOf("designation:") >= 0)
                                            {
                                                tDesignation = stSp[iLocCnt].Split(':')[stSp[iLocCnt].Split(':').GetUpperBound(0)].Trim();

                                                // Mohan G on 10-Sep-2014 ::::
                                                try
                                                {
                                                    if (tDesignation.Trim() == "" && !stSp[iLocCnt + 1].Contains(":"))
                                                    {
                                                        tDesignation = stSp[iLocCnt + 1].Trim();
                                                    }
                                                }
                                                catch { }

                                                // End ::::::::::::::::::::::::

                                            }
                                            //if (stSp[iLocCnt].ToLower().IndexOf("last active:") >= 0)
                                            //    if (stSp[iLocCnt + 1].IndexOf("Resume ID") >= 0)
                                            //    {
                                            //        if (stSp[iLocCnt + 2].IndexOf("Exp") < 0 && stSp[iLocCnt + 2].ToLower().IndexOf("annual salary") < 0 && stSp[iLocCnt + 2].IndexOf("year") < 0)
                                            //            tCurrentEmploye = stSp[iLocCnt + 2].Split(':')[stSp[iLocCnt + 2].Split(':').GetUpperBound(0)];
                                            //    }
                                            //    else
                                            //        tCurrentEmploye = stSp[iLocCnt + 1].Split(':')[stSp[iLocCnt + 1].Split(':').GetUpperBound(0)];
                                        }
                                        if (iMobFound > 0 && iEndDesignation == 0)
                                            iEndDesignation = iMobFound - 1;
                                        if (iYearofParsing > 0 && iEndDesignation > 0)
                                        {
                                            for (int iLocCnt = iYearofParsing + 1; iLocCnt < iEndDesignation && tCurrentEmploye == ""; iLocCnt++)
                                            {
                                                tCurrentEmploye = stSp[iLocCnt];
                                                break;
                                            }
                                        }
                                        string tSkill = "";
                                        if (iFoundSkill > 0)
                                        {
                                            for (int iLocCnt = 0; iLocCnt < iFoundSkill; iLocCnt++)
                                            {
                                                tSkill += stSp[iLocCnt];
                                            }
                                        }

                                        if (iMobFound == 0)
                                            stMain1[0] = stSp[stSp.GetUpperBound(0) - 1];
                                        else
                                            stMain1[0] = stSp[iMobFound - 1];
                                        if (stMain1[0].IndexOf("(") >= 0)
                                        {
                                            string[] a = stMain1[0].Split('(');
                                            stMain1[0] = a[0];
                                        }
                                        stMain1[1] = tPhone;
                                        stMain1[2] = tMobile;
                                        stMain1[3] = tLocation;// (stSp[stSp.GetUpperBound(0)].Trim() == "Viewed" ? stSp[stSp.GetUpperBound(0) - 1] : stSp[stSp.GetUpperBound(0)]);
                                        if (stMain1[3] == stMain1[0])
                                            stMain1[0] = "";

                                        stMain1[4] = tCurrentEmploye.Replace("Not employed currently", "").Replace("NA\t", "").Replace("None\t", "").Replace("nil\t", "").Replace("Nil\t", "").Replace("NOT EMPLOYED CURRENTLY", "").Replace(" no", "").Replace(" No", "").Trim();
                                        stMain1[5] = tSkill;//skill

                                        // Commented by Mohan G on 10-Sep-2014
                                        //  stMain1[6] = (iYearofParsing > 0 ? stSp[iYearofParsing - 1] : stSp[2]);//education

                                        // Mohan G on 10-sep-2014 :::::::::::::::
                                        try
                                        {
                                            if (iYearofParsing > 0)
                                            {
                                                if (!stSp[iYearofParsing - 1].Contains(":") && stSp[iYearofParsing - 1].Trim() != "," && stSp[iYearofParsing - 1].Trim() != "")
                                                {
                                                    stMain1[6] = stSp[iYearofParsing - 1];
                                                }
                                                else if (!stSp[iYearofParsing - 2].Contains(":") && stSp[iYearofParsing - 2].Trim() != "," && stSp[iYearofParsing - 2].Trim() != "")
                                                {
                                                    stMain1[6] = stSp[iYearofParsing - 2];

                                                }
                                                else stMain1[6] = stSp[2];
                                            }
                                            else
                                                stMain1[6] = stSp[2];
                                        }
                                        catch { stMain1[6] = ""; }
                                        // End :::::::::::::::::::::::::::::::::::::::::::

                                        stMain1[7] = tCTC;
                                        stMain1[8] = tExp;
                                        stMain1[9] = preferredLocation;
                                        stMain1[10] = tREsumeID.Trim();
                                        stMain1[11] = tDesignation.Trim();
                                        opCreateMonsterNewVersion(stMain1, IDs); 

                                    }
                                    catch { }

                                }
                                i++;
                            }


                            i++;
                            dt.ReadXml(new System.IO.StringReader(objXnm.OuterXml));
                            try
                            {
                                //grdCandidate.BeginUpdate();
                                dtGridData.Merge(dt.Tables[0], true);
                                tsDownload.Enabled = true;
                            }
                            catch { }
                            finally
                            {
                                //grdCandidate.EndUpdate();
                                grdCandidate.Refresh();
                                //sel.SelectAll();
                                //grdCandidate_DataSourceChanged(null, null);
                            }
                            Application.DoEvents();
                        }
                        catch
                        { }
                    }
                    #endregion

                    #region "Naukri India"

                    if (bFlagNaukri == 2)// if (opValidJobSiteNaukri(br1.Url.ToString()))
                    {
                        try
                        { 
                            objXnm = new System.Xml.XmlDocument();
                            objEl = objXnm.CreateElement("ROOT");
                            objXnm.AppendChild(objEl);
                            objRoot = objXnm.DocumentElement;


                            string[] spAt = { " at " };
                            string[] spAtIDs = { "','", "\",\"" };

                            HtmlAgilityPack.HtmlDocument objHTML = null;
                            objHTML = new HtmlAgilityPack.HtmlDocument();
                            objHTML.LoadHtml((((System.Windows.Forms.WebBrowser)(cntTab.SelectedTab.Controls[0]))).Document.Body.OuterHtml);

                            HtmlAgilityPack.HtmlNodeCollection nd_Mobile = objHTML.DocumentNode.SelectNodes("//div[@class='tuple'] | //div[@class='tuple viewed']");

                            if (nd_Mobile != null && nd_Mobile.Count > 0)
                            {
                                tspgrs.Minimum = 1;
                                tspgrs.Maximum = nd_Mobile.Count + 1;
                                tspgrs.Step = 1;

                                for (int i = 0; i < nd_Mobile.Count; i++)
                                {

                                    HtmlAgilityPack.HtmlNode CandInfo = nd_Mobile[i];

                                    string ids = CandInfo.GetAttributeValue("data-uobj", "");
                                    string tSid = "";
                                    try
                                    { tSid = objHTML.DocumentNode.SelectSingleNode("//input[@name='sid']").GetAttributeValue("Value", ""); }
                                    catch { }
                                    string[] aeeds = ids.Split(spAtIDs, StringSplitOptions.RemoveEmptyEntries);
                                    ids = aeeds[0].Replace("':'", "=").Replace("\":\"", "=").Replace("\"", "").Replace("{'", "").Replace("{", "") + "&sid=" + tSid;
                                    string key = aeeds[8].Replace("':'", "=").Replace("\"", "").Replace("{'", "");

                                    aeeds = null;
                                    HtmlAgilityPack.HtmlDocument objHTML1 = new HtmlAgilityPack.HtmlDocument();
                                    objHTML1.LoadHtml(CandInfo.SelectNodes("//div[@class='tupLeft']")[i].OuterHtml);



                                    string[] stMain1 = new string[13];
                                    stMain1[1] = objHTML1.DocumentNode.SelectSingleNode("//a[@class='name fl mr15']").InnerText;
                                    stMain1[3] = "";
                                    if (objHTML1.DocumentNode.SelectSingleNode("//em[@class='iconLoc']").NextSibling != null)
                                        stMain1[3] = (objHTML1.DocumentNode.SelectSingleNode("//em[@class='iconLoc']").NextSibling).InnerText;
                                    stMain1[2] = "";// tPhone + ", " + tMobile;
                                    try
                                    {
                                        if (false)//chkDownloadContactDetailsaswell.Checked ==
                                        {
                                            string tUrl = "";
                                            try
                                            {
                                                tUrl = "http://resdex.naukri.com/v2/ajax/getContactNumber?" + key + "&sid=" + tSid;
                                            }
                                            catch
                                            {
                                                tUrl = "http://resdex.naukri.com/v2/ajax/getContactNumber?" + key + "&xhr=1";
                                            }
                                            if (!string.IsNullOrEmpty(tUrl))
                                            {
                                                object objNull = null;
                                                MSXML2.XMLHTTP  xmlHttpMain = new MSXML2.XMLHTTP();
                                                xmlHttpMain.open("GET", tUrl, false, null, null);
                                                xmlHttpMain.setRequestHeader("Content-Type", "text/xml");
                                                xmlHttpMain.send(objNull);
                                                string tContactData = xmlHttpMain.responseText;
                                                 
                                                string[] tArry = tContactData.Split(new string[] { ",\"" }, StringSplitOptions.RemoveEmptyEntries);
                                                if (tArry.Length > 2)
                                                {
                                                    stMain1[2] = (tArry[1] + "," + tArry[2]).Replace("mobNo", "").Replace("\"0\"", "").Replace(":", "").Replace("phoneNo", "").Replace("\"", "");
                                                }
                                                tArry = null; tContactData = null;
                                                xmlHttpMain = null;
                                            }
                                        }
                                    }
                                    catch { }
                                    stMain1[4] = "";
                                    stMain1[5] = "";

                                    stMain1[6] = objHTML1.DocumentNode.SelectSingleNode("//span[@class='mtxt w90']|//span[@class='mtxt w80']").InnerText;
                                    stMain1[7] = objHTML1.DocumentNode.SelectSingleNode("//div[@class='desc prefSkill hKwd']").InnerText.Replace("Key Skills", "");//tkeyskill;


                                    stMain1[9] = "";
                                    try
                                    {

                                        stMain1[9] = objHTML1.DocumentNode.SelectSingleNode("//span[@class='mtxt ']").InnerText;
                                    }
                                    catch { }
                                    stMain1[10] = "";
                                    stMain1[11] = "";

                                    stMain1[12] = "";

                                    foreach (HtmlAgilityPack.HtmlNode CandInfo1 in objHTML1.DocumentNode.SelectNodes("//div[@class='desc']"))
                                    {
                                        if (CandInfo1.PreviousSibling != null && CandInfo1.PreviousSibling.PreviousSibling != null && CandInfo1.PreviousSibling.PreviousSibling.InnerText == "Pref Location")
                                        { stMain1[12] = CandInfo1.InnerText; }
                                        else if (CandInfo1.PreviousSibling != null && CandInfo1.PreviousSibling.PreviousSibling != null && CandInfo1.PreviousSibling.PreviousSibling.InnerText == "Current")
                                        {
                                            string[] tDesEmployer = CandInfo1.InnerText.Split(spAt, StringSplitOptions.RemoveEmptyEntries);
                                            if (tDesEmployer.Length > 0)
                                                if (tDesEmployer.Length == 2)
                                                {
                                                    stMain1[4] = tDesEmployer[1];
                                                    stMain1[5] = tDesEmployer[0];

                                                }
                                                else
                                                {
                                                    stMain1[5] = tDesEmployer[0];
                                                }
                                            tDesEmployer = null;
                                        }
                                        else if (CandInfo1.PreviousSibling != null && CandInfo1.PreviousSibling.PreviousSibling != null && CandInfo1.PreviousSibling.PreviousSibling.InnerText == "Education")
                                        {
                                            stMain1[8] = CandInfo1.InnerText;
                                        }
                                        else if (CandInfo1.PreviousSibling != null && CandInfo1.PreviousSibling.PreviousSibling != null && CandInfo1.PreviousSibling.PreviousSibling.InnerText == "Pref Loc")
                                        {
                                            stMain1[12] = CandInfo1.InnerText;
                                        }
                                        else if (CandInfo1.PreviousSibling != null && CandInfo1.PreviousSibling.PreviousSibling != null && CandInfo1.PreviousSibling.PreviousSibling.InnerText == "Previous")
                                        {
                                            string[] tDesEmployerPrev = CandInfo1.InnerText.Split(spAt, StringSplitOptions.RemoveEmptyEntries);

                                            if (tDesEmployerPrev.Length > 0)
                                                if (tDesEmployerPrev.Length == 2)
                                                {
                                                    stMain1[10] = tDesEmployerPrev[1];
                                                    stMain1[11] = tDesEmployerPrev[0];

                                                }
                                                else
                                                {
                                                    stMain1[10] = tDesEmployerPrev[0];
                                                }
                                            tDesEmployerPrev = null;
                                        }
                                    }
                                    opCreateNodesNaukri(stMain1, ids);
                                    objHTML1 = null;

                                    tspgrs.PerformStep();
                                    //tspgrs.Refresh();
                                }

                            }
                            else
                            {
                                int i = 0;
                                string[] st = { "<input name='UserNames[]'", "<input name=\"UserNames[]\"" };
                                string[] st12 = { "<!--<IMG SRC=" };
                                string[] st123 = { "\r\n" };
                                string[] st1234 = { "Currently in:" };
                                string[] s23t = { "value=", "type='checkbox'", "/>" };
                                string[] str = (((System.Windows.Forms.WebBrowser)(cntTab.SelectedTab.Controls[0]))).DocumentText.ToString().Split(st, StringSplitOptions.RemoveEmptyEntries);
                                string[] stMain = null;
                                string[] sEBoldt = { "<td class=\"dashedL resDivM1\" valign=\"top\">", "<td valign='top' class='dashedL resDivM1'>", "<TD class='dashedL resDivM1' vAlign=top>", "<br /><br />", "<BR><BR>", "<br/><br/><br/>" };
                                string[] sEBoldt1 = { "<span class='ltGrey'>", "<SPAN class=ltGrey>", "<SPAN class='ltGrey'>", "<BR>", "<br>", "<br />", "<br/>" };
                                string[] sEBoldt2 = { "<strong>", "</strong>", "<B>", "</B>", "<b>", "</b>" };
                                string[] sEmpt = { "At&nbsp;", " at " };
                                string[] tS = { "Current Job:" };
                                string[] tS1 = { "Current Job:", " as " };
                                string[] tS2 = { "Current Location:", "Current Location :" };
                                int j = str.GetUpperBound(0);
                                string[] stMain1 = new string[13];
                                object objNull = null;
                                string[] t = { "name", "sid", "value", "INPUT", "input", "<", ">", "type", "=", "hidden", " " };

                                tspgrs.Minimum = i;
                                tspgrs.Maximum = j;
                                tspgrs.Step = 1;
                                foreach (string stre in str)
                                {
                                    if (i >= 1 && i <= j)
                                    {
                                        string tUserID = "", tSid = "", tContactData = "";
                                        string ids = stre.Split(s23t, StringSplitOptions.RemoveEmptyEntries)[1].ToString();
                                        HtmlElement objELe = (((System.Windows.Forms.WebBrowser)(cntTab.SelectedTab.Controls[0]))).Document.GetElementById("u" + (i - 1).ToString());
                                        if (objELe != null)
                                        {
                                            ids = "uname=" + objELe.InnerText;
                                            string key = "";
                                            HtmlElementCollection objELe1 = objELe.NextSibling.GetElementsByTagName("INPUT");
                                            foreach (HtmlElement objELe3 in objELe1)
                                            {
                                                key = objELe3.GetAttribute("Value"); ;
                                            }
                                            try
                                            {
                                                tSid = (((System.Windows.Forms.WebBrowser)(cntTab.SelectedTab.Controls[0]))).Document.GetElementsByTagName("input").GetElementsByName("sid")[0].OuterHtml;

                                                string[] at = tSid.Split(t, StringSplitOptions.RemoveEmptyEntries);
                                                tSid = at[0];
                                                if (tSid != "") ids += "&sid=" + tSid;
                                            }
                                            catch { }
                                            tUserID = objELe.InnerText;
                                            try
                                            {
                                                if (true)
                                                {
                                                    string tUrl = "";
                                                    try
                                                    {
                                                        tUrl = "http://resdex.naukri.com/resumesList/getContactNumber?key=" + key + "&sid=" + tSid + "&xhr=1";
                                                    }
                                                    catch
                                                    {
                                                        tUrl = "http://resdex.naukri.com/resumesList/getContactNumber?key=" + key + "&xhr=1";
                                                    }

                                                     
                                                    MSXML2.XMLHTTP  xmlHttpMain = new MSXML2.XMLHTTP();
                                                    xmlHttpMain.open("GET", tUrl, false, null, null);
                                                    xmlHttpMain.setRequestHeader("Content-Type", "text/xml");
                                                    xmlHttpMain.send(objNull);
                                                    tContactData = xmlHttpMain.responseText;
                                                    xmlHttpMain = null;
                                                }
                                            }
                                            catch { }
                                        }
                                        else
                                            ids = "key=" + ids;
                                        string tData = RemoveHTML("<input name='UserNames[]' " + stre.Replace("<div class=\"rbox\" title=\"Resume added in the last 7 days\">New</div>", "").Replace("Pref Location:", " Pref Location:").Replace("Current Job:", " Current Job:").Replace("|", "\r\n").Replace("<br>", "\r\n").Replace("<br/>", "\r\n").Replace("<br />", "\r\n")).ToString().Trim();
                                        tData = tData.Replace("\r\n \n \r\n", "\r\n").Replace("\r\n \r\n", "\r\n").Replace("  \n                 ", "\r\n").Trim();
                                        //.Replace("\r\n\r\n\r\n \n", "\r\n").Replace("\r\n  \r\n  \r\n \r\n", "\r\n").Replace("\r\n\r\n\r\n","\r\n").Replace("\r\n  \r\n \r\n","\r\n")
                                        stMain = tData.Split(st123, StringSplitOptions.RemoveEmptyEntries);//.Split(st12, StringSplitOptions.RemoveEmptyEntries)[0].ToString()

                                        string tloc = "";
                                        int iLocCnt1 = 0, iLname = 0;
                                        string tPhone = "";
                                        string tMobile = "";
                                        string tCTC = "", tPresentEmp = "", tDesignation = "", tExperience = "", tName = "", tkeyskill = "", tEducation = "";
                                        int iEducationEnd = 0, iEducationStart = 0;
                                        string PrevDesignation = "", PrevEmployer = "", PrefLocation = "";
                                        for (int iLocCnt = 0; iLocCnt <= stMain.GetUpperBound(0); iLocCnt++)
                                        {
                                            if (stMain[iLocCnt].ToLower().IndexOf("current location") >= 0)//stMain[iLocCnt].ToLower().IndexOf("currently in") >= 0 ||
                                            {
                                                try
                                                {
                                                    //  tloc = stMain[iLocCnt].Split(tS2, StringSplitOptions.RemoveEmptyEntries)[1];
                                                    iLocCnt1 = iLocCnt;
                                                    tloc = stMain[iLocCnt1 + 1];
                                                    iEducationEnd = iLocCnt;
                                                }
                                                catch { }
                                            }
                                            if (stMain[iLocCnt].ToLower().IndexOf("mobile:") >= 0)
                                            {
                                                tMobile = stMain[iLocCnt].ToLower().Replace("mobile:", "").Replace("verified", "");
                                                if (tMobile == "")
                                                    tMobile = stMain[iLocCnt + 1];
                                            }
                                            if (stMain[iLocCnt].ToLower().IndexOf("phone:") >= 0)
                                                tPhone = stMain[iLocCnt];
                                            if (stMain[iLocCnt].ToLower().IndexOf("ctc:") >= 0)
                                            {
                                                tCTC = stMain[iLocCnt].Replace("CTC:", "").Replace("ctc:", "");
                                                if (tCTC.Trim() == "")
                                                    tCTC = stMain[iLocCnt + 1];
                                                iEducationStart = iLocCnt;
                                            }
                                            if (stMain[iLocCnt].ToLower().IndexOf("current company:") >= 0)
                                            {
                                                tPresentEmp = stMain[iLocCnt].Replace("Current Company:", "").Replace("current company:", "");
                                                if (tPresentEmp.Trim() == "")
                                                    tPresentEmp = stMain[iLocCnt + 1]; ;//.Split(tS1, StringSplitOptions.RemoveEmptyEntries);
                                                //if (aEmp.Length > 1)
                                                //    tPresentEmp = aEmp[1].Trim();
                                                //if (aEmp.Length > 2)
                                                //    tDesignation = aEmp[2].Replace("as ", "").Replace("/", "").Trim();
                                            }
                                            if (stMain[iLocCnt].ToLower().IndexOf("key skills:") >= 0 || stMain[iLocCnt].ToLower().IndexOf("skills:") >= 0)
                                            {
                                                tkeyskill = stMain[iLocCnt + 1] + " ";//.Split(tS1, StringSplitOptions.RemoveEmptyEntries);
                                                for (int icnt = iLocCnt + 2; icnt <= stMain.GetUpperBound(0); icnt++)
                                                {
                                                    if (stMain[icnt].Trim().ToLower().IndexOf("inactive") >= 0 || stMain[icnt].Trim().ToLower().IndexOf("resume viewed") >= 0) break;
                                                    tkeyskill += stMain[icnt];
                                                }
                                                //if (aEmp.Length > 1)
                                                //    tPresentEmp = aEmp[1].Trim();
                                                //if (aEmp.Length > 2)
                                                //    tDesignation = aEmp[2].Replace("as ", "").Replace("/", "").Trim();
                                            }
                                            //if (tName.Trim().ToLower().IndexOf("vinayaga moorthy") >= 0)
                                            //        break;
                                            if (stMain[iLocCnt].ToLower().IndexOf("education:") >= 0)
                                            {
                                                tEducation = stMain[iLocCnt];//.Split(tS1, StringSplitOptions.RemoveEmptyEntries);
                                                for (int icnt = iLocCnt + 1; icnt <= stMain.GetUpperBound(0); icnt++)
                                                {
                                                    if (stMain[icnt].Trim().ToLower().IndexOf("current location") >= 0 || stMain[icnt].Trim().ToLower().IndexOf("pref location") >= 0) break;
                                                    tEducation += stMain[icnt];
                                                }
                                                //if (aEmp.Length > 1)
                                                //    tPresentEmp = aEmp[1].Trim();
                                                //if (aEmp.Length > 2)
                                                //    tDesignation = aEmp[2].Replace("as ", "").Replace("/", "").Trim();
                                            }
                                            if (stMain[iLocCnt].ToLower().IndexOf("current designation:") >= 0)
                                            {
                                                tDesignation = stMain[iLocCnt];//.Split(tS1, StringSplitOptions.RemoveEmptyEntries);
                                                for (int icnt = iLocCnt + 1; icnt <= stMain.GetUpperBound(0); icnt++)
                                                {
                                                    if (stMain[icnt].Trim().ToLower().IndexOf("current company") >= 0 || stMain[icnt].Trim().ToLower().IndexOf("previous designation") >= 0) break;
                                                    tDesignation += stMain[icnt];
                                                }
                                                iLname = iLocCnt - 1;
                                                try
                                                {

                                                    if (stMain[iLname].Replace("New", "").Trim().Length > 1)
                                                        tName = stMain[iLname].Trim();
                                                    else if (stMain[iLname - 1].Replace("New", "").Trim().Length > 1)
                                                        tName = stMain[iLname - 1].Trim();
                                                    else if (stMain[iLname - 2].Replace("New", "").Trim().Length > 1)
                                                        tName = stMain[iLname - 2].Trim();
                                                    else if (stMain[iLname - 3].Replace("New", "").Trim().Length > 1)
                                                        tName = stMain[iLname - 3].Trim();
                                                    else if (stMain[iLname - 4].Replace("New", "").Trim().Length > 1)
                                                        tName = stMain[iLname - 4].Trim();
                                                }
                                                catch { }
                                            }
                                            if (stMain[iLocCnt].ToLower().IndexOf("experience:") >= 0 || stMain[iLocCnt].ToLower().IndexOf("exp:") >= 0)
                                                tExperience = stMain[iLocCnt];
                                            if (stMain[iLocCnt].ToLower().IndexOf("previous designation:") >= 0)
                                            {
                                                PrevDesignation = stMain[iLocCnt];//.Split(tS1, StringSplitOptions.RemoveEmptyEntries);
                                                for (int icnt = iLocCnt + 1; icnt <= stMain.GetUpperBound(0); icnt++)
                                                {
                                                    if (stMain[icnt].Trim().ToLower().IndexOf("previous company") >= 0 || stMain[icnt].Trim().ToLower().IndexOf("view") >= 0) break;
                                                    PrevDesignation += " " + stMain[icnt].Trim();
                                                }
                                            }
                                            if (stMain[iLocCnt].ToLower().IndexOf("previous company:") >= 0)
                                            {
                                                PrevEmployer = stMain[iLocCnt].Replace("Previous Company:", "").Replace("previous company:", "");
                                                if (PrevEmployer.Trim() == "")
                                                    PrevEmployer = stMain[iLocCnt + 1];

                                            }
                                            if (stMain[iLocCnt].ToLower().IndexOf("pref location:") >= 0)
                                            {
                                                PrefLocation = stMain[iLocCnt].Replace("Pref Location:", "").Replace("pref location:", "");
                                                if (PrefLocation.Trim() == "")
                                                    PrefLocation = stMain[iLocCnt + 1];

                                            }

                                        }
                                        if (tPhone == "" && tMobile == "" && tContactData != "")
                                        {
                                            tPhone = RemoveHTML(tContactData.Replace("<br>", "\r\n").Replace("<br />", "\r\n")).ToString().Trim();//.Split(st123, StringSplitOptions.RemoveEmptyEntries);//.Split(st12, StringSplitOptions.RemoveEmptyEntries)[0].ToString()
                                        }
                                        stMain1[1] = tName;
                                        stMain1[3] = tloc;
                                        stMain1[2] = tPhone + ", " + tMobile;
                                        stMain1[4] = tPresentEmp.Replace("Current Company:", "");//stMain[7].Split(sEmpt, StringSplitOptions.RemoveEmptyEntries)[stMain[7].Split(sEmpt, StringSplitOptions.RemoveEmptyEntries).GetUpperBound(0)];
                                        stMain1[5] = tDesignation.Replace("Current Designation:", "");// st.Main[6].Split(sEmpt, StringSplitOptions.RemoveEmptyEntries)[stMain[7].Split(sEmpt, StringSplitOptions.RemoveEmptyEntries).GetLowerBound(0)];
                                        stMain1[6] = tExperience;
                                        stMain1[7] = tkeyskill;
                                        ////if (stMain[3].ToLower().IndexOf("current job:") >= 0)
                                        ////{
                                        ////    stMain1[7] = stMain[3].Split(tS, StringSplitOptions.RemoveEmptyEntries)[0];
                                        ////}
                                        ////else
                                        ////    stMain1[7] = stMain[3];
                                        //  string tEducation = "";
                                        if (tEducation == "" && iEducationStart > 0 && iEducationEnd > 0 && iEducationStart < iEducationEnd)
                                        {
                                            try
                                            {
                                                for (int iCnt1 = iEducationStart + 1; iCnt1 < iEducationEnd; iCnt1++)
                                                {
                                                    if (stMain[iCnt1].ToLower().IndexOf("span") < 0)
                                                    {
                                                        if (tEducation == "")
                                                            tEducation = stMain[iCnt1];
                                                        else
                                                            tEducation = tEducation + "," + stMain[iCnt1];
                                                    }
                                                }
                                            }
                                            catch { }
                                        }

                                        stMain1[8] = tEducation;
                                        stMain1[9] = tCTC;
                                        stMain1[10] = PrevDesignation.Replace("Previous Designation:", "").Replace("N/A", "").Trim();
                                        stMain1[11] = PrevEmployer.Replace("N/A", "").Trim();
                                        stMain1[12] = PrefLocation.Trim();
                                        opCreateNodesNaukri(stMain1, ids);
                                    }
                                    i++;

                                    tspgrs.PerformStep();
                                    //tspgrs.Refresh();
                                }

                                i++;
                            }

                            //tspgrs.Value = 0;
                            dt.ReadXml(new System.IO.StringReader(objXnm.OuterXml));
                            //grdCandidate.DataSource = dt.Tables[0].DefaultView;
                            try
                            {
                                //grdCandidate.BeginUpdate();
                                dtGridData.Merge(dt.Tables[0], true);
                                tsDownload.Enabled = true;
                            }
                            catch { }
                            finally
                            {
                                //grdCandidate.EndUpdate();
                                grdCandidate.Refresh();
                                //sel.SelectAll();
                                //grdCandidate_DataSourceChanged(null, null);
                            }
                            Application.DoEvents();
                        }
                        catch
                        {
                        }
                    }
                    #endregion

                    #region "Naukri - Response"

                    if (bFlagNaukri == 211)// if (opValidJobSiteResponseNaukri(br1.Url.ToString()))
                    {
                        try
                        {
                            if (tCookies == null || tCookies == "")
                            {
                                tCookies = GetGlobalCookies((((System.Windows.Forms.WebBrowser)(cntTab.SelectedTab.Controls[0]))).Url.AbsoluteUri);
                                if (tCookies != null && tCookies.IndexOf("ACCESS") >= 0)
                                {
                                    string[] tCook = tCookies.Split(new char[] { ';', ',' });
                                    char[] ch = new char[] { '=' };
                                    foreach (string st in tCook)
                                    {
                                        if (st.IndexOf("test") >= 0)
                                            tNaukriCoockiesTest = st.Split(ch)[1];
                                        else if (st.IndexOf("ACCESS") >= 0)
                                            tNaukriCoockiesACCESS = st.Split(ch)[1];
                                        else if (st.IndexOf("UNID") >= 0)
                                            tNaukriCoockiesUNID = st.Split(ch)[1];
                                    }
                                }
                            }
                        }
                        catch { }

                        try
                        {


                            objXnm = new System.Xml.XmlDocument();
                            objEl = objXnm.CreateElement("ROOT");
                            objXnm.AppendChild(objEl);
                            objRoot = objXnm.DocumentElement;
                            bool bFlag = false;
                            try
                            {
                                int iDisplay = 0;
                                while (iDisplay < 61)
                                {
                                    object objNull = null;
                                    string tURI = "http://response.naukri.com/brv/response2/data?file=[FileIDs]&fID=1&filters=&sortBy=[sortBy]&displayed=" + iDisplay.ToString() + "&page=[PageNo]&max=[MaxID]";
                                    string referenceURL = "http://response.naukri.com/brv/response2/list?file=[FileIDs]";
                                    string[] stp = { "max='", "', file='" };
                                    string tmax = (((System.Windows.Forms.WebBrowser)(cntTab.SelectedTab.Controls[0]))).DocumentText.ToString().Split(stp, StringSplitOptions.RemoveEmptyEntries)[1];
                                    string FileID = "";
                                    int iPageNo = 0;
                                    int.TryParse((((System.Windows.Forms.WebBrowser)(cntTab.SelectedTab.Controls[0]))).Document.GetElementById("pageNo").GetAttribute("Value"), out iPageNo);
                                    string SortBy = "r";
                                    foreach (HtmlElement elfile in (((System.Windows.Forms.WebBrowser)(cntTab.SelectedTab.Controls[0]))).Document.GetElementsByTagName("input"))
                                    {
                                        if (elfile.Name == null) continue;
                                        if (elfile.Name == "file")
                                            FileID = elfile.GetAttribute("Value");
                                    }
                                    string tSortData = (((System.Windows.Forms.WebBrowser)(cntTab.SelectedTab.Controls[0]))).Document.GetElementById("sortBy").InnerHtml;
                                    if (tSortData.IndexOf("sortBy='r'") >= 0)
                                    {
                                        SortBy = "d";
                                    }
                                    tURI = tURI.Replace("[FileIDs]", FileID).Replace("[sortBy]", SortBy).Replace("[PageNo]", iPageNo.ToString()).Replace("[MaxID]", tmax);
                                    referenceURL = referenceURL.Replace("[FileIDs]", FileID); ;



                                    System.Net.WebClient sbC = new System.Net.WebClient();
                                    sbC.Headers.Set("Content-Type", "text/xml");
                                    sbC.Headers.Set("Cookie", (((System.Windows.Forms.WebBrowser)(cntTab.SelectedTab.Controls[0]))).Document.Cookie);
                                    sbC.Headers.Set("Referer", referenceURL);
                                    string tContactData = sbC.DownloadString(tURI);
                                    sbC = null;


                                    //MSXML2.XMLHTTPClass xmlHttpMain = new MSXML2.XMLHTTPClass();
                                    //xmlHttpMain.open("GET", tURI, false, null, null);
                                    ////xmlHttpMain.setRequestHeader("X-Requested-With", "XMLHttpRequest");
                                    //xmlHttpMain.setRequestHeader("Cookie", (((System.Windows.Forms.WebBrowser)(cntTab.SelectedTab.Controls[0]))).Document.Cookie);
                                    //xmlHttpMain.setRequestHeader("Referer", referenceURL);
                                    //xmlHttpMain.send(objNull);
                                    //string tContactData = xmlHttpMain.responseText;
                                    //xmlHttpMain = null;
                                    iDisplay += 20;
                                    string[] st = { "<RESULT>", "</RESULT>" };
                                    string[] str = tContactData.Split(st, StringSplitOptions.RemoveEmptyEntries);

                                    System.Xml.XmlDocument objXMLResult = new XmlDocument();
                                    objXMLResult.LoadXml("<RESULT></RESULT>");
                                    objXMLResult.GetElementsByTagName("RESULT").Item(0).InnerXml = str[1].ToString();

                                    int j = objXMLResult.GetElementsByTagName("RESUME_DETAIL").Count;
                                    for (int i = 0; i < j; i++)
                                    {
                                        opCreateNodesNaukriResponse(objXMLResult.GetElementsByTagName("RESUME_DETAIL").Item(i).OuterXml);
                                    }
                                }
                                dt.ReadXml(new System.IO.StringReader(objXnm.OuterXml));
                                try
                                {
                                    //grdCandidate.BeginUpdate();
                                    dtGridData.Merge(dt.Tables[0], true);
                                    tsDownload.Enabled = true;
                                }
                                catch { }
                                finally
                                {
                                    //grdCandidate.EndUpdate();
                                    grdCandidate.Refresh();
                                    //sel.SelectAll();
                                    //grdCandidate_DataSourceChanged(null, null);
                                }
                                Application.DoEvents();
                                bFlag = true;
                            }
                            catch { }
                            if (!bFlag)
                            {

                                string[] st = { "<RESULT>", "</RESULT>" };
                                string[] str = (((System.Windows.Forms.WebBrowser)(cntTab.SelectedTab.Controls[0]))).DocumentText.ToString().Split(st, StringSplitOptions.RemoveEmptyEntries);

                                System.Xml.XmlDocument objXMLResult = new XmlDocument();
                                objXMLResult.LoadXml("<RESULT></RESULT>");
                                objXMLResult.GetElementsByTagName("RESULT").Item(0).InnerXml = str[1].ToString();

                                int j = objXMLResult.GetElementsByTagName("RESUME_DETAIL").Count;
                                for (int i = 0; i < j; i++)
                                {
                                    opCreateNodesNaukriResponse(objXMLResult.GetElementsByTagName("RESUME_DETAIL").Item(i).OuterXml);
                                }
                                dt.ReadXml(new System.IO.StringReader(objXnm.OuterXml));
                                try
                                {
                                    //grdCandidate.BeginUpdate();
                                    dtGridData.Merge(dt.Tables[0], true);
                                    tsDownload.Enabled = true;
                                }
                                catch { }
                                finally
                                {
                                    //grdCandidate.EndUpdate();
                                    grdCandidate.Refresh();
                                    //sel.SelectAll();
                                    //grdCandidate_DataSourceChanged(null, null);
                                }
                                Application.DoEvents();
                            }
                        }
                        catch
                        {
                        }
                    }
                    #endregion

                    #region "Naukri - Responce eApp"

                    if (bFlagNaukri == 221)
                    {
                        try
                        {
                            objXnm = new System.Xml.XmlDocument();
                            objEl = objXnm.CreateElement("ROOT");
                            objXnm.AppendChild(objEl);
                            objRoot = objXnm.DocumentElement;

                            int i = 0;
                            string[] st = { "<input name='responseID[]'", "<input name=\"responseID[]\"", "<input name=\"respID[]\"", "<input name='respID[]'" };

                            string[] st123 = { "\r\n", "&nbsp;", "\t\t\t\t\t", "\t\t\t\t", "\t\t\t" };

                            string[] s23t = { "/responsemanager/preview/preview?applyId=", "&searchAcross=J&searchType=", };
                            //string[] s23t ={ "value=", "type='checkbox'", "/>" };
                            string[] str = (((System.Windows.Forms.WebBrowser)(cntTab.SelectedTab.Controls[0]))).DocumentText.ToString().Split(st, StringSplitOptions.RemoveEmptyEntries);
                            string[] stMain = null;
                            int j = str.GetUpperBound(0);
                            string[] stMain1 = new string[13];
                            object objNull = null;
                            string[] t = { "name", "sid", "value", "INPUT", "input", "<", ">", "type", "=", "hidden", " " };
                            //string[] tstrKey ={ "href=\"/eapps/preview/show?id=&resid=", "\" target=\"_blank\">" };

                            string tPhone = "", tMobile = "", tEmailIDs = "";
                            foreach (string stre in str)
                            {
                                if (i >= 1 && i <= j)
                                {
                                    Application.DoEvents();
                                    tPhone = ""; tMobile = ""; tEmailIDs = "";
                                    string tContactData = "";
                                    //string ids = stre.Split(tstrKey, StringSplitOptions.RemoveEmptyEntries)[1].ToString();
                                    string ids = stre.Split(s23t, StringSplitOptions.RemoveEmptyEntries)[1].ToString();

                                    if ( true)
                                    {
                                        try
                                        {
                                            string[] stT = { " href=", " target=\"_blank\">" };
                                            string tUr = stre.Split(stT, StringSplitOptions.RemoveEmptyEntries)[1].Replace("\"", "");

                                            //MSXML2.XMLHTTPClass xmlHttpMain = new MSXML2.XMLHTTPClass();
                                            //xmlHttpMain.open("GET", , false, null, null);
                                            //xmlHttpMain.setRequestHeader("Content-Type", "text/xml");
                                            //xmlHttpMain.send(objNull);
                                            //tContactData = xmlHttpMain.responseText;

                                            System.Net.WebClient sbC = new System.Net.WebClient();
                                            sbC.Headers.Set("Content-Type", "text/xml");
                                            tContactData = sbC.DownloadString("http://response.naukri.com" + tUr);
                                            sbC = null;
                                            try
                                            {
                                                if (tContactData.IndexOf("In order to prevent misuse of your account.") >= 0 || tContactData.IndexOf("You have either exceeding or completely utilized the maximum limit of CV views available for this week") >= 0 || tContactData.IndexOf("Someone is already logged into Resdex with this username. Please log-in using one of the available subuser accounts. You can also reset the subuser who is currently accessing Resdex with this username.") >= 0)
                                                {
                                                    frmBrowserValidationPopup objpopup = new frmBrowserValidationPopup();
                                                    objpopup.tAuthURL = "http://response.naukri.com" + tUr;
                                                    objpopup.ShowDialog(); objpopup = null;
                                            opSetMessage("Communication from the site has interrupted. Please relogin...");
                                                    break;
                                                }
                                            }
                                            catch { }

                                            string[] stEmail = { "<img src=\"http://static.naukimg.com/rstatic/images/mail.gif\" align=\"absmiddle\" />", "<h3 class=\"rphead\">" };
                                            tEmailIDs = tContactData.Split(stEmail, StringSplitOptions.RemoveEmptyEntries)[1].Replace("</div>", "").Replace("&nbsp;", "").Trim();
                                        }
                                        catch { }
                                    }

                                    string tData = RemoveHTML("<input  " + stre.Replace("<div class=\"rbox\" title=\"Resume added in the last 7 days\">New</div>", "").Replace("Pref Location:", " Pref Location:").Replace("Current Job:", " Current Job:").Replace("|", "\r\n").Replace("<br>", "\r\n").Replace("<br/>", "\r\n").Replace("<br />", "\r\n")).ToString().Trim();
                                    tData = tData.Replace("\n\r\n  \r\n\n  \r\n", "\r\n").Replace("\r\n\n\r\n\n", "\r\n").Replace("\n\r\n\n  \r\n", "\r\n").Replace("\r\n  \r\n\n  \r\n", "\r\n").Replace("\r\n\n\t", "\r\n").Replace("\r\n \r\n", "\r\n").Replace("  \n                 ", "\r\n").Replace("\r\n    \r\n\n  \r\n ", "\r\n").Replace("\r\n\n", "\r\n").Replace("\r\n\n  \r\n\n\r\n\n\r\n", "\r\n").Replace("\r\n  \r\n", "\r\n").Replace("\r\n  \r\n\n\r\n", "\r\n").Replace("\n\r\n  \r\n", "\r\n").Trim();
                                    stMain = tData.Split(st123, StringSplitOptions.RemoveEmptyEntries);//.Split(st12, StringSplitOptions.RemoveEmptyEntries)[0].ToString()
                                    string tloc = "";
                                    int iLocCnt1 = 0;
                                    //string tPhone = "";
                                    //string tMobile = "";
                                    string tCTC = "", tPresentEmp = "", tDesignation = "", tExperience = "", tkeyskill = "", tEducation = "";
                                    int iEducationEnd = 0, iEducationStart = 0;
                                    string PrevDesignation = "", PrevEmployer = "", PrefLocation = "";
                                    for (int iLocCnt = 0; iLocCnt <= stMain.GetUpperBound(0); iLocCnt++)
                                    {
                                        if (stMain[iLocCnt].ToLower().IndexOf("current location") >= 0)//stMain[iLocCnt].ToLower().IndexOf("currently in") >= 0 ||
                                        {
                                            try
                                            {
                                                //  tloc = stMain[iLocCnt].Split(tS2, StringSplitOptions.RemoveEmptyEntries)[1];
                                                iLocCnt1 = iLocCnt;
                                                tloc = stMain[iLocCnt1 + 1];
                                                iEducationEnd = iLocCnt;
                                            }
                                            catch { }
                                        }
                                        if (stMain[iLocCnt].ToLower().IndexOf("mobile number:") >= 0)
                                        {
                                            tMobile = stMain[iLocCnt].ToLower().Replace("mobile:", "").Replace("verified", "");
                                            if (tMobile == "")
                                                tMobile = stMain[iLocCnt + 1];
                                        }
                                        if (stMain[iLocCnt].ToLower().IndexOf("phone number:") >= 0)
                                            tPhone = stMain[iLocCnt].Replace("phone number:", "").Replace("Phone Number:", "").Replace("Verified", "").Trim();
                                        if (stMain[iLocCnt].ToLower().IndexOf("ctc:") >= 0)
                                        {
                                            tCTC = stMain[iLocCnt].Replace("CTC:", "").Replace("ctc:", "");
                                            iEducationStart = iLocCnt;
                                            if (tCTC.Trim() == "")
                                            {
                                                tCTC = stMain[iLocCnt + 1];
                                                iEducationStart = iLocCnt + 1;
                                            }
                                        }
                                        if (stMain[iLocCnt].ToLower().IndexOf("current company:") >= 0)
                                        {
                                            tPresentEmp = stMain[iLocCnt].Replace("Current Company:", "").Replace("current company:", "");
                                            if (tPresentEmp.Trim() == "")
                                                tPresentEmp = stMain[iLocCnt + 1]; ;//.Split(tS1, StringSplitOptions.RemoveEmptyEntries);
                                            //if (aEmp.Length > 1)
                                            //    tPresentEmp = aEmp[1].Trim();
                                            //if (aEmp.Length > 2)
                                            //    tDesignation = aEmp[2].Replace("as ", "").Replace("/", "").Trim();
                                        }
                                        if (stMain[iLocCnt].ToLower().IndexOf("key skills:") >= 0 || stMain[iLocCnt].ToLower().IndexOf("skills:") >= 0)
                                        {
                                            tkeyskill = stMain[iLocCnt + 1] + " ";//.Split(tS1, StringSplitOptions.RemoveEmptyEntries);
                                            for (int icnt = iLocCnt + 2; icnt <= stMain.GetUpperBound(0); icnt++)
                                            {
                                                if (stMain[icnt].Trim().ToLower().IndexOf("inactive") >= 0 || stMain[icnt].Trim().ToLower().IndexOf("resume viewed") >= 0) break;
                                                tkeyskill += stMain[icnt];
                                            }
                                            //if (aEmp.Length > 1)
                                            //    tPresentEmp = aEmp[1].Trim();
                                            //if (aEmp.Length > 2)
                                            //    tDesignation = aEmp[2].Replace("as ", "").Replace("/", "").Trim();
                                        }
                                        //if (tName.Trim().ToLower().IndexOf("vinayaga moorthy") >= 0)
                                        //        break;
                                        if (stMain[iLocCnt].ToLower().IndexOf("education:") >= 0)
                                        {
                                            tEducation = stMain[iLocCnt];//.Split(tS1, StringSplitOptions.RemoveEmptyEntries);
                                            for (int icnt = iLocCnt + 1; icnt <= stMain.GetUpperBound(0); icnt++)
                                            {
                                                if (stMain[icnt].Trim().ToLower().IndexOf("current location") >= 0 || stMain[icnt].Trim().ToLower().IndexOf("pref location") >= 0) break;
                                                tEducation += stMain[icnt];
                                            }
                                            //if (aEmp.Length > 1)
                                            //    tPresentEmp = aEmp[1].Trim();
                                            //if (aEmp.Length > 2)
                                            //    tDesignation = aEmp[2].Replace("as ", "").Replace("/", "").Trim();
                                        }
                                        if (stMain[iLocCnt].ToLower().IndexOf("current designation:") >= 0)
                                        {
                                            tDesignation = stMain[iLocCnt];//.Split(tS1, StringSplitOptions.RemoveEmptyEntries);
                                            for (int icnt = iLocCnt + 1; icnt <= stMain.GetUpperBound(0); icnt++)
                                            {
                                                if (stMain[icnt].Trim().ToLower().IndexOf("current company") >= 0 || stMain[icnt].Trim().ToLower().IndexOf("previous designation") >= 0) break;
                                                tDesignation += stMain[icnt];
                                            }
                                            //iLname = iLocCnt - 1;
                                            //try
                                            //{

                                            //    if (stMain[iLname].Replace("New", "").Trim().Length > 1)
                                            //        tName = stMain[iLname].Trim();
                                            //    else if (stMain[iLname - 1].Replace("New", "").Trim().Length > 1)
                                            //        tName = stMain[iLname - 1].Trim();
                                            //    else if (stMain[iLname - 2].Replace("New", "").Trim().Length > 1)
                                            //        tName = stMain[iLname - 2].Trim();
                                            //    else if (stMain[iLname - 3].Replace("New", "").Trim().Length > 1)
                                            //        tName = stMain[iLname - 3].Trim();
                                            //    else if (stMain[iLname - 4].Replace("New", "").Trim().Length > 1)
                                            //        tName = stMain[iLname - 4].Trim();
                                            //}
                                            //catch { }
                                        }
                                        if (stMain[iLocCnt].ToLower().IndexOf("experience:") >= 0 || stMain[iLocCnt].ToLower().IndexOf("exp:") >= 0)
                                            tExperience = stMain[iLocCnt];
                                        if (stMain[iLocCnt].ToLower().IndexOf("previous designation:") >= 0)
                                        {
                                            PrevDesignation = stMain[iLocCnt];//.Split(tS1, StringSplitOptions.RemoveEmptyEntries);
                                            for (int icnt = iLocCnt + 1; icnt <= stMain.GetUpperBound(0); icnt++)
                                            {
                                                if (stMain[icnt].Trim().ToLower().IndexOf("previous company") >= 0 || stMain[icnt].Trim().ToLower().IndexOf("view") >= 0) break;
                                                PrevDesignation += " " + stMain[icnt].Trim();
                                            }
                                        }
                                        if (stMain[iLocCnt].ToLower().IndexOf("previous company:") >= 0)
                                        {
                                            PrevEmployer = stMain[iLocCnt].Replace("Previous Company:", "").Replace("previous company:", "");
                                            if (PrevEmployer.Trim() == "")
                                                PrevEmployer = stMain[iLocCnt + 1];

                                        }
                                        if (stMain[iLocCnt].ToLower().IndexOf("pref location:") >= 0)
                                        {
                                            PrefLocation = stMain[iLocCnt].Replace("Pref Location:", "").Replace("pref location:", "");
                                            if (PrefLocation.Trim() == "")
                                                PrefLocation = stMain[iLocCnt + 1];

                                        }

                                    }
                                    if (tPhone == "" && tMobile == "" && tContactData != "")
                                    {
                                        tPhone = RemoveHTML(tContactData.Replace("<br>", "\r\n").Replace("<br />", "\r\n")).ToString().Trim();//.Split(st123, StringSplitOptions.RemoveEmptyEntries);//.Split(st12, StringSplitOptions.RemoveEmptyEntries)[0].ToString()
                                    }
                                    stMain1[1] = stMain[1];
                                    stMain1[3] = tloc;
                                    stMain1[2] = tPhone + ", " + tMobile;
                                    stMain1[4] = tPresentEmp.Replace("Current Company:", "");//stMain[7].Split(sEmpt, StringSplitOptions.RemoveEmptyEntries)[stMain[7].Split(sEmpt, StringSplitOptions.RemoveEmptyEntries).GetUpperBound(0)];
                                    stMain1[5] = tDesignation.Replace("Current Designation:", "");// st.Main[6].Split(sEmpt, StringSplitOptions.RemoveEmptyEntries)[stMain[7].Split(sEmpt, StringSplitOptions.RemoveEmptyEntries).GetLowerBound(0)];
                                    stMain1[6] = tExperience;
                                    stMain1[7] = tkeyskill;

                                    if (tEducation == "" && iEducationStart > 0 && iEducationEnd > 0 && iEducationStart < iEducationEnd)
                                    {
                                        try
                                        {
                                            for (int iCnt1 = iEducationStart + 1; iCnt1 < iEducationEnd; iCnt1++)
                                            {
                                                if (stMain[iCnt1].ToLower().IndexOf("span") < 0)
                                                {
                                                    if (tEducation == "")
                                                        tEducation = stMain[iCnt1];
                                                    else
                                                        tEducation = tEducation + "," + stMain[iCnt1];
                                                }
                                            }
                                        }
                                        catch { }
                                    }

                                    stMain1[8] = tEducation;
                                    stMain1[9] = tCTC;
                                    stMain1[10] = PrevDesignation.Replace("Previous Designation:", "").Replace("N/A", "").Trim();
                                    stMain1[11] = PrevEmployer.Replace("N/A", "").Trim();
                                    stMain1[12] = PrefLocation.Trim();
                                    //string tloc = "", tCTC = "", tPresentEmp = "", tDesignation = "", tExperience = "", tName = "", tkeyskill = "", tEducation = "";
                                    //int iEducationStart = 0;
                                    //for (int iLocCnt = 0; iLocCnt <= stMain.GetUpperBound(0); iLocCnt++)
                                    //{
                                    //    if (stMain[iLocCnt].ToLower().IndexOf("current location") >= 0)//stMain[iLocCnt].ToLower().IndexOf("currently in") >= 0 ||
                                    //    {
                                    //        tloc = stMain[iLocCnt].Replace("Current Location:", "").Trim();
                                    //    }
                                    //    if (stMain[iLocCnt].ToLower().IndexOf("mobile:") >= 0)
                                    //    {
                                    //        tMobile = stMain[iLocCnt].ToLower().Replace("mobile:", "").Replace("verified", "").Trim();
                                    //        if (tMobile == "")
                                    //            tMobile = stMain[iLocCnt + 1].Trim();
                                    //    }
                                    //    if (stMain[iLocCnt].ToLower().IndexOf("phone:") >= 0)
                                    //    {
                                    //        tPhone = stMain[iLocCnt].ToLower().Replace("phone:", "").Replace("verified", "").Trim();
                                    //        if (tPhone == "")
                                    //            tPhone = stMain[iLocCnt + 1].Replace("SET_BLANK", "").Trim();
                                    //    }
                                    //    if (stMain[iLocCnt].ToLower().IndexOf("ctc:") >= 0)
                                    //    {
                                    //        tCTC = stMain[iLocCnt].Replace("CTC:", "").Replace("ctc:", "").Replace("INR", "").Replace("inr", "").Trim();
                                    //    }
                                    //    if (stMain[iLocCnt].ToLower().IndexOf("current job:") >= 0)
                                    //    {
                                    //        try
                                    //        {
                                    //            tDesignation = stMain[iLocCnt].Replace("Current Job:", "").Trim();
                                    //            tPresentEmp = stMain[iLocCnt + 1].ToString().Trim().Substring(3).Trim();
                                    //        }
                                    //        catch { }
                                    //    }
                                    //    if (stMain[iLocCnt].ToLower().IndexOf("experience:") >= 0 || stMain[iLocCnt].ToLower().IndexOf("exp:") >= 0)
                                    //        tExperience = stMain[iLocCnt].Replace("Experience:", "").Trim();

                                    //    tName = stMain[1].Trim();
                                    //    try
                                    //    {
                                    //        tkeyskill = stMain[3].Trim();
                                    //    }
                                    //    catch { }
                                    //    try
                                    //    {

                                    //        if (tEducation == "")
                                    //        {
                                    //            tEducation = stMain[4].Trim();
                                    //            if (iEducationStart == 0 && stMain[7].Trim().StartsWith("(") == true && stMain[7].Trim().EndsWith(")") == true)
                                    //            {
                                    //                iEducationStart = 1;
                                    //                tEducation = tEducation + "," + stMain[6].Trim();
                                    //            }
                                    //            else if (iEducationStart == 0 && stMain[8].Trim().StartsWith("(") == true && stMain[8].Trim().EndsWith(")") == true)
                                    //            {
                                    //                iEducationStart = 1;
                                    //                tEducation = tEducation + "," + stMain[7].Trim();
                                    //            }
                                    //        }
                                    //    }
                                    //    catch { }

                                    //}

                                    //stMain1[1] = tName;
                                    //stMain1[3] = tloc;
                                    //stMain1[2] = tPhone + ", " + tMobile;
                                    //stMain1[4] = tPresentEmp.Replace("Current Company:", "");
                                    //stMain1[5] = tDesignation.Replace("Current Designation:", "");
                                    //stMain1[6] = tExperience;
                                    //stMain1[7] = tkeyskill;
                                    //stMain1[8] = tEducation;
                                    //stMain1[9] = tCTC;
                                    //stMain1[10] = tEmailIDs;
                                    opCreateNodesNaukri(stMain1, ids);
                                }

                                i++;
                            }

                            i++;
                            dt.ReadXml(new System.IO.StringReader(objXnm.OuterXml));
                            try
                            {
                                //grdCandidate.BeginUpdate();
                                dtGridData.Merge(dt.Tables[0], true);
                                tsDownload.Enabled = true;
                            }
                            catch { }
                            finally
                            {
                                //grdCandidate.EndUpdate();
                                grdCandidate.Refresh();
                                //sel.SelectAll();
                                //grdCandidate_DataSourceChanged(null, null);
                            }
                            Application.DoEvents();
                        }
                        catch
                        {
                        }
                    }
                    #endregion

                    #region "Times Job.com"
                    if (bFlagNaukri == 3)//   if (opValidJobSitetimesjobs(br1.Url.ToString()))
                    {
                        try
                        {
                            objXnm = new System.Xml.XmlDocument();
                            objEl = objXnm.CreateElement("ROOT");
                            objXnm.AppendChild(objEl);
                            objRoot = objXnm.DocumentElement;

                            string[] spAt = { " at " };
                            string[] spAtIDs = { "','" };

                            HtmlAgilityPack.HtmlDocument objHTML = null;
                            objHTML = new HtmlAgilityPack.HtmlDocument();
                            objHTML.LoadHtml((((System.Windows.Forms.WebBrowser)(cntTab.SelectedTab.Controls[0]))).Document.Body.OuterHtml);

                            HtmlAgilityPack.HtmlNodeCollection nd_Mobile = objHTML.DocumentNode.SelectNodes("//div[@class='srp-container clearfix']");

                            tspgrs.Minimum = 1;
                            tspgrs.Maximum = nd_Mobile.Count + 1;
                            tspgrs.Step = 1;

                            if (nd_Mobile != null && nd_Mobile.Count > 0)
                            {

                                for (int i = 0; i < nd_Mobile.Count; i++)
                                {

                                    HtmlAgilityPack.HtmlNode CandInfo = nd_Mobile[i];
                                    if (!CandInfo.SelectNodes("//div[@class='srp-sec-lft']")[i].OuterHtml.Contains("href=\"resumeDetailView.html?_q="))
                                        continue;
                                    HtmlAgilityPack.HtmlDocument objHTML1 = new HtmlAgilityPack.HtmlDocument();
                                    objHTML1.LoadHtml(CandInfo.SelectNodes("//div[@class='srp-sec-lft']")[i].OuterHtml);
                                    string ids = "http://hire.timesjobs.com/employer/" + objHTML1.DocumentNode.SelectSingleNode("//a").GetAttributeValue("href", "");
                                    string RID = objHTML1.DocumentNode.SelectSingleNode("//a").Id.Replace("jobDtailUrl", "").Trim();

                                    string[] stMain1 = new string[13];

                                    stMain1[1] = "";
                                    stMain1[3] = "";
                                    stMain1[2] = "";
                                    stMain1[4] = "";
                                    stMain1[5] = "";
                                    stMain1[6] = "";
                                    stMain1[7] = "";
                                    stMain1[8] = "";
                                    stMain1[9] = "";
                                    stMain1[10] = "";
                                    stMain1[11] = "";
                                    stMain1[12] = "";
                                    if (!string.IsNullOrEmpty(RID))
                                    {
                                        if (objHTML1.DocumentNode.SelectSingleNode("//span[@id='name" + RID + "']") != null)
                                            stMain1[1] = objHTML1.DocumentNode.SelectSingleNode("//span[@id='name" + RID + "']").InnerText.Replace("|", "").Trim();
                                        if (objHTML1.DocumentNode.SelectSingleNode("//span[@id='location" + RID + "']") != null)
                                            stMain1[3] = objHTML1.DocumentNode.SelectSingleNode("//span[@id='location" + RID + "']").InnerText.Replace("|", "").Trim();
                                        stMain1[2] = "";
                                        if (objHTML1.DocumentNode.SelectSingleNode("//span[@id='designation" + RID + "']") != null)
                                            stMain1[9] = objHTML1.DocumentNode.SelectSingleNode("//span[@id='designation" + RID + "']").InnerText.Replace("|", "").Trim();
                                        if (objHTML1.DocumentNode.SelectSingleNode("//span[@id='keySkill" + RID + "']") != null)
                                            stMain1[5] = objHTML1.DocumentNode.SelectSingleNode("//span[@id='keySkill" + RID + "']").InnerText.Replace("|", "").Trim();
                                        if (objHTML1.DocumentNode.SelectSingleNode("//span[@id='ctc" + RID + "']") != null)
                                            stMain1[6] = objHTML1.DocumentNode.SelectSingleNode("//span[@id='ctc" + RID + "']").InnerText.Replace("|", "").Replace("lacs pa", "").Trim();
                                        if (objHTML1.DocumentNode.SelectSingleNode("//span[@id='exp" + RID + "']") != null)
                                            stMain1[7] = objHTML1.DocumentNode.SelectSingleNode("//span[@id='exp" + RID + "']").InnerText.Replace("|", "").Trim();
                                        if (objHTML1.DocumentNode.SelectSingleNode("//span[@id='edu" + RID + "']") != null)
                                            stMain1[8] = objHTML1.DocumentNode.SelectSingleNode("//span[@id='edu" + RID + "']").InnerText.Trim();
                                        if (objHTML1.DocumentNode.SelectSingleNode("//span[@id='currEmp" + RID + "']") != null)
                                            stMain1[4] = objHTML1.DocumentNode.SelectSingleNode("//span[@id='currEmp" + RID + "']").InnerText.Replace("|", "").Trim();
                                        if (objHTML1.DocumentNode.SelectSingleNode("//span[@id='prevdesignation" + RID + "']") != null)
                                            stMain1[10] = objHTML1.DocumentNode.SelectSingleNode("//span[@id='prevdesignation" + RID + "']").InnerText.Replace("|", "").Replace("Previous", "").Replace(":", "").Trim();
                                        if (objHTML1.DocumentNode.SelectSingleNode("//span[@id='preveEmp" + RID + "']") != null)
                                            stMain1[11] = objHTML1.DocumentNode.SelectSingleNode("//span[@id='preveEmp" + RID + "']").InnerText.Replace("|", "").Trim();
                                        stMain1[12] = "";
                                    }
                                    else
                                    {

                                        if (objHTML1.DocumentNode.SelectSingleNode("//li") != null)
                                        {
                                            //HtmlAgilityPack.HtmlNodeCollection nd_Mobile2= null;


                                            HtmlAgilityPack.HtmlNodeCollection nd_Mobile2 = objHTML1.DocumentNode.SelectNodes("//li");

                                            foreach (string tar in nd_Mobile2[0].InnerText.Split(new string[] { "|" }, StringSplitOptions.RemoveEmptyEntries))
                                            {


                                                if (System.Text.RegularExpressions.Regex.IsMatch(tar.Trim(), "(^Name)"))
                                                { stMain1[1] = tar.Trim().Replace("Name: click to show", ""); }


                                                else if (System.Text.RegularExpressions.Regex.IsMatch(tar.Trim(), "(lacs|lac| pa)"))
                                                { stMain1[6] = tar.Trim().Replace("lacs pa", ""); }
                                                else if (System.Text.RegularExpressions.Regex.IsMatch(tar.Trim(), "(Year|Month)"))
                                                { stMain1[7] = tar.Trim(); }
                                                else
                                                { stMain1[3] = tar.Trim(); }
                                            }
                                            if (nd_Mobile2.Count > 1 && System.Text.RegularExpressions.Regex.IsMatch(nd_Mobile2[1].InnerText.Trim(), @"\d{4}"))
                                            { stMain1[8] = nd_Mobile2[1].InnerText.Trim(); }
                                            else if (nd_Mobile2.Count > 1 && System.Text.RegularExpressions.Regex.IsMatch(nd_Mobile2[1].InnerText.Trim(), @"\|") && !System.Text.RegularExpressions.Regex.IsMatch(nd_Mobile2[1].InnerText.Trim(), @"Previous"))
                                            {
                                                try
                                                {
                                                    string[] Arry1 = nd_Mobile2[1].InnerText.Split(new string[] { "|" }, StringSplitOptions.RemoveEmptyEntries);
                                                    stMain1[9] = Arry1[0].Trim();
                                                    stMain1[4] = Arry1[1].Trim();
                                                }
                                                catch { }


                                            }
                                            if (nd_Mobile2.Count > 2 && System.Text.RegularExpressions.Regex.IsMatch(nd_Mobile2[2].InnerText.Trim(), @"\d{4}"))
                                            { stMain1[8] = nd_Mobile2[2].InnerText.Trim(); }
                                            else if (nd_Mobile2.Count > 2 && System.Text.RegularExpressions.Regex.IsMatch(nd_Mobile2[2].InnerText.Trim(), @"\|") && System.Text.RegularExpressions.Regex.IsMatch(nd_Mobile2[2].InnerText.Trim(), @"Previous"))
                                            {
                                                try
                                                {
                                                    string[] Arry1 = nd_Mobile2[2].InnerText.Split(new string[] { "|" }, StringSplitOptions.RemoveEmptyEntries);
                                                    stMain1[10] = Arry1[0].Replace("Previous :", "").Trim();
                                                    stMain1[11] = Arry1[1].Trim();
                                                }
                                                catch { }
                                            }
                                            else if (nd_Mobile2.Count > 2)
                                                stMain1[8] = nd_Mobile2[2].InnerText.Trim();


                                            if (nd_Mobile2.Count > 3)//&& System.Text.RegularExpressions.Regex.IsMatch(nd_Mobile2[3].InnerText.Trim(), @"\d{4}"))
                                            { stMain1[8] = nd_Mobile2[3].InnerText.Trim(); }

                                        }
                                        try
                                        {
                                            stMain1[5] = CandInfo.SelectNodes("//p[@class='padd5 paddR15 gry keySkill']")[i - 1].InnerText;
                                        }
                                        catch { }
                                    }








                                    opCreateNodesTimesJob(stMain1, ids);
                                    objHTML1 = null;
                                    tspgrs.PerformStep();
                                    //tspgrs.Refresh();
                                    RID = null;
                                }

                            }
                            tspgrs.Value = 0;
                            //i++;
                            dt.ReadXml(new System.IO.StringReader(objXnm.OuterXml));
                            try
                            {
                                //grdCandidate.BeginUpdate();
                                dtGridData.Merge(dt.Tables[0], true);
                                tsDownload.Enabled = true;
                            }
                            catch { }
                            finally
                            {
                                //grdCandidate.EndUpdate();
                                grdCandidate.Refresh();
                                //sel.SelectAll();
                                //grdCandidate_DataSourceChanged(null, null);
                            }
                            Application.DoEvents();
                        }
                        catch { }
                    }
                    #endregion

                    #region "www.careeerbuilder.com"
                    if (bFlagNaukri == 5)//  if (opValidCareerBuilder(br1.Url.ToString()))
                    {
                        try
                        {
                            // bFlagNaukri = 5;
                            string[] tMainSpt = { "ResumeDetails.aspx?Resume_DID=" };
                            string[] tGetIDSpt = { "\">" };
                            // richTextBox1.Text = (((System.Windows.Forms.WebBrowser)(cntTab.SelectedTab.Controls[0]))).DocumentText;
                            objXnm = new System.Xml.XmlDocument();
                            objEl = objXnm.CreateElement("ROOT");
                            objXnm.AppendChild(objEl);
                            objRoot = objXnm.DocumentElement;


                            string[] st2 = { "&nbsp;", "\r\n", "New", "Similar Resumes", "\r\n\r\n\r\n\r\n", "My Tags", "Add Tag", "Flip View", "Save Cancel" };
                            string[] aEnd = { " Send Email", "Similar Resumes", "Viewed ", "Send Email", "Freshness:", "Will Relocate To", "<a" };
                            string[] str = (((System.Windows.Forms.WebBrowser)(cntTab.SelectedTab.Controls[0]))).Document.Body.InnerHtml.ToString().Split(tMainSpt, StringSplitOptions.RemoveEmptyEntries);
                            int i = 0;
                            int j = str.GetUpperBound(0);
                            foreach (string stre in str)
                            {
                                if (i > 0 && i <= j)
                                {

                                    string IDs = stre.Split(tGetIDSpt, StringSplitOptions.RemoveEmptyEntries)[0];
                                    string stText = RemoveHTML("<A " + stre).Trim();
                                    //string[] stSp1 = stText.Split(st2, StringSplitOptions.RemoveEmptyEntries);

                                    string[] stSp = stText.Split(aEnd, StringSplitOptions.RemoveEmptyEntries)[0].Trim().Split(st2, StringSplitOptions.RemoveEmptyEntries);
                                    if (stSp.Length > 0 && stSp[0].Trim() == "Window")
                                    { i++; continue; }
                                    string[] stMain1 = new string[10];
                                    string tCurrentEmploye = "", tExp = "", tCTC = "", tPhone = "", tMobile = "", tEducation = "", tDesignation = "";
                                    for (int iLocCnt = 0; iLocCnt <= stSp.GetUpperBound(0); iLocCnt++)
                                    {
                                        if (stSp[iLocCnt].Trim() == "") continue;
                                        if (stSp[iLocCnt].ToLower().IndexOf("recent pay") >= 0)
                                            tCTC = stSp[iLocCnt + 1].Replace("Rs.", "").Replace("$", "").Replace("N/A", "").Replace("annually", "").Replace(",", "").Trim();
                                        if (stSp[iLocCnt].ToLower().IndexOf("experience") >= 0)
                                        {
                                            tExp = stSp[iLocCnt + 1].Replace("years", "").Trim();
                                        }
                                        if (stSp[iLocCnt].ToLower().IndexOf("recent company") >= 0)
                                        {
                                            tCurrentEmploye = stSp[iLocCnt + 1];
                                        }
                                        if (stSp[iLocCnt].ToLower().IndexOf("recent company") >= 0)
                                        {
                                            tCurrentEmploye = stSp[iLocCnt + 1];
                                        }
                                        if (stSp[iLocCnt].ToLower().IndexOf("degree level") >= 0)
                                        {
                                            tEducation = stSp[iLocCnt + 1];
                                        }
                                        if (stSp[iLocCnt].ToLower().IndexOf("recent position") >= 0)
                                        {
                                            tDesignation = stSp[iLocCnt + 1];
                                        }
                                    }
                                    stMain1[0] = stSp[0];
                                    stMain1[1] = tPhone;
                                    stMain1[2] = tMobile;
                                    stMain1[3] = stSp[1];
                                    stMain1[4] = tCurrentEmploye.Replace("Not employed currently", "").Replace("NA\t", "").Replace("None\t", "").Replace("nil\t", "").Replace("Nil\t", "").Replace("NOT EMPLOYED CURRENTLY", "").Replace(" no", "").Replace(" No", "").Trim();
                                    stMain1[5] = tDesignation;//skill
                                    stMain1[6] = tEducation;//education
                                    stMain1[7] = tCTC;
                                    stMain1[8] = tExp;






                                    opCreateMonsterGulf(stMain1, IDs);
                                }
                                i++;

                            }
                            #region "old"
                            //HtmlElement col = null;
                            //string[] stMain1 = new string[4];
                            //for (int i = 1; i <= 100; i++)
                            //{
                            //    try
                            //    {
                            //        string tContactNameID = "_ResResultsV4_mxdlResumes__ctl" + i.ToString() + "_Title ";
                            //        col = (((System.Windows.Forms.WebBrowser)(cntTab.SelectedTab.Controls[0]))).Document.GetElementById(tContactNameID);
                            //        if (col != null)
                            //        {
                            //            objEl = objXnm.CreateElement("Main");
                            //            objElSub = objXnm.CreateElement("Check");
                            //            objElSub.InnerText = true.ToString();
                            //            objEl.AppendChild(objElSub);
                            //            objElSub = objXnm.CreateElement("ResumeID");
                            //            objElSub.InnerText = "0";
                            //            objEl.AppendChild(objElSub);
                            //            objElSub = objXnm.CreateElement("SavedType");
                            //            objElSub.InnerText = "0";
                            //            objEl.AppendChild(objElSub);
                            //            objElSub = objXnm.CreateElement("CandidateName");
                            //            objElSub.InnerText = col.InnerText;
                            //            objEl.AppendChild(objElSub);
                            //            tContactNameID = "_ResResultsV4_mxdlResumes__ctl" + i.ToString() + "_cblnkTitle";
                            //            string tPresentEmployer = "", OtherData = "";
                            //            HtmlElementCollection col1 = (((System.Windows.Forms.WebBrowser)(cntTab.SelectedTab.Controls[0]))).Document.GetElementsByTagName("A");
                            //            foreach (HtmlElement htmlEle in col1)
                            //            {
                            //                if (string.Compare(htmlEle.Id, tContactNameID, true) == 0)
                            //                {
                            //                    tContactNameID = htmlEle.GetAttribute("href");
                            //                    tPresentEmployer = htmlEle.OffsetParent.OuterText;
                            //                    try
                            //                    {
                            //                        OtherData = htmlEle.OffsetParent.NextSibling.OffsetParent.OffsetParent.InnerText;
                            //                    }
                            //                    catch { OtherData = ""; }
                            //                    break;
                            //                }
                            //            }
                            //            string[] st123 ={ "\r\n" };
                            //            string tCTC = "", tDesignation = "", tExp = "", tEdicatopm = "";

                            //            string[] aPresntEmployer = OtherData.Split(st123, StringSplitOptions.RemoveEmptyEntries);
                            //            tPresentEmployer = "";
                            //            for (int iLocCnt = 0; iLocCnt <= aPresntEmployer.GetUpperBound(0); iLocCnt++)
                            //            {
                            //                if (aPresntEmployer[iLocCnt].ToLower().IndexOf("recent employer") >= 0)
                            //                    tPresentEmployer = aPresntEmployer[iLocCnt].Split(':')[aPresntEmployer[iLocCnt].Split(':').GetUpperBound(0)];
                            //                if (aPresntEmployer[iLocCnt].ToLower().IndexOf("recent pay") >= 0)
                            //                    tCTC = aPresntEmployer[iLocCnt].Split(':')[aPresntEmployer[iLocCnt].Split(':').GetUpperBound(0)].Replace("Recent Pay", "").Replace("Rs.", "").Replace("N/A", "").Trim();
                            //                if (aPresntEmployer[iLocCnt].ToLower().IndexOf("recent job title") >= 0 || aPresntEmployer[iLocCnt].ToLower().IndexOf("recent position") >= 0)
                            //                {
                            //                    tDesignation = aPresntEmployer[iLocCnt].Split(':')[aPresntEmployer[iLocCnt].Split(':').GetUpperBound(0)].Replace("Rs.", "").Replace("Recent Position", "").Trim();
                            //                    if (tDesignation.Trim() == "" && iLocCnt + 1 <= aPresntEmployer.GetUpperBound(0))
                            //                    {
                            //                        tDesignation = aPresntEmployer[iLocCnt + 1].Split(':')[aPresntEmployer[iLocCnt + 1].Split(':').GetUpperBound(0)].Replace("Rs.", "").Replace("Recent Position", "").Trim();

                            //                    }
                            //                }
                            //                if (aPresntEmployer[iLocCnt].ToLower().IndexOf("years experience") >= 0)
                            //                    tExp = aPresntEmployer[iLocCnt].Split(':')[aPresntEmployer[iLocCnt].Split(':').GetUpperBound(0)].Replace("Years Experience", "").Trim();
                            //                if (aPresntEmployer[iLocCnt].ToLower().IndexOf("degree level") >= 0)
                            //                    tEdicatopm = aPresntEmployer[iLocCnt].Split(':')[aPresntEmployer[iLocCnt].Split(':').GetUpperBound(0)].Replace("Degree Level", "").Trim();
                            //            }
                            //            objElSub = objXnm.CreateElement("IDs");
                            //            objElSub.InnerText = tContactNameID;
                            //            objEl.AppendChild(objElSub);
                            //            objElSub = objXnm.CreateElement("PresentEmployer");
                            //            objElSub.InnerText = tPresentEmployer;
                            //            objEl.AppendChild(objElSub);
                            //            objElSub = objXnm.CreateElement("Mobile");
                            //            objElSub.InnerText = "";
                            //            objEl.AppendChild(objElSub);
                            //            tContactNameID = "_ResResultsV4_mxdlResumes__ctl" + i.ToString() + "_lblLocation";
                            //            col = (((System.Windows.Forms.WebBrowser)(cntTab.SelectedTab.Controls[0]))).Document.GetElementById(tContactNameID);
                            //            objElSub = objXnm.CreateElement("CandidateLocation");
                            //            objElSub.InnerText = col.InnerText;
                            //            objEl.AppendChild(objElSub);
                            //            objElSub = objXnm.CreateElement("PhoneH");
                            //            objElSub.InnerText = "";
                            //            objEl.AppendChild(objElSub);
                            //            string tEducationTitle = "", tEducationIDs = "";
                            //            opGetIDs(tEdicatopm.Replace("Experience:", "").Replace("\n", "").Replace("\t", "").Replace("&nbsp;", "").Trim().Replace("Confidential", "").Trim().ToString(), ref tEducationIDs, ref tEducationTitle, HireCraft.ClsFcommonXML.objfXMLEducationTypes, "EducationType", "EducationAlias");

                            //            objElSub = objXnm.CreateElement("Education");
                            //            objElSub.InnerText = tEducationTitle;
                            //            objEl.AppendChild(objElSub);
                            //            objElSub = objXnm.CreateElement("EducationIDs");
                            //            objElSub.InnerText = tEducationIDs;
                            //            objEl.AppendChild(objElSub);
                            //            objElSub = objXnm.CreateElement("PresentCTC");
                            //            objElSub.InnerText = getSalary(tCTC.Trim());
                            //            objEl.AppendChild(objElSub);
                            //            objElSub = objXnm.CreateElement("TotalExp");
                            //            objElSub.InnerText = tExp;
                            //            objEl.AppendChild(objElSub);
                            //            objElSub = objXnm.CreateElement("Skill");
                            //            objElSub.InnerText = "";
                            //            objEl.AppendChild(objElSub);
                            //            string tDesignationTitle = "", tDesignationIDs = "";
                            //            opGetIDs(tDesignation.Replace("Experience:", "").Replace("\n", "").Replace("\t", "").Replace("&nbsp;", "").Trim().Replace("Confidential", "").Trim().ToString(), ref tDesignationIDs, ref tDesignationTitle, HireCraft.ClsFcommonXML.objfXMLJobTitle, "JobTitle", "Includelist");

                            //            objElSub = objXnm.CreateElement("JobTitle");
                            //            objElSub.InnerText = tDesignationTitle.Split(',')[tDesignationTitle.Split(',').GetLowerBound(0)];
                            //            if (objElSub.InnerText.Trim() == "")
                            //                objElSub.InnerText = "<--None-->";
                            //            objEl.AppendChild(objElSub);

                            //            objElSub = objXnm.CreateElement("DesignationID");
                            //            objElSub.InnerText = tDesignationIDs.Split(',')[tDesignationIDs.Split(',').GetLowerBound(0)];
                            //            objEl.AppendChild(objElSub);
                            //            objRoot.AppendChild(objEl);
                            //        }
                            //    }
                            //    catch { }
                            //}
                            #endregion

                            i++;
                            dt.ReadXml(new System.IO.StringReader(objXnm.OuterXml));
                            try
                            {
                                //grdCandidate.BeginUpdate();
                                dtGridData.Merge(dt.Tables[0], true);
                                tsDownload.Enabled = true;
                            }
                            catch { }
                            finally
                            {
                                //grdCandidate.EndUpdate();
                                grdCandidate.Refresh();
                                //sel.SelectAll();
                                //grdCandidate_DataSourceChanged(null, null);
                            }
                            Application.DoEvents();
                        }
                        catch { }
                    }

                    #endregion

                    #region "www.employer.dice.com"
                    if (bFlagNaukri == 6)// if (opValidDice(br1.Url.ToString()))
                    {
                        try
                        {
                            bFlagNaukri = 6; 
                            objXnm = new System.Xml.XmlDocument();
                            objEl = objXnm.CreateElement("ROOT");
                            objXnm.AppendChild(objEl);
                            objRoot = objXnm.DocumentElement;
                            string[] spID = { "dockey=", "@endecaindex" };
                            HtmlElementCollection eleCollection = (((System.Windows.Forms.WebBrowser)(cntTab.SelectedTab.Controls[0]))).Document.All;// ActiveElement.All;// br1.Document.All;
                            string[] s23t = { "makeNoteVisible('", "', 0)" };
                            HtmlAgilityPack.HtmlDocument objHTML = null;
                            objHTML = new HtmlAgilityPack.HtmlDocument();
                            objHTML.LoadHtml((((System.Windows.Forms.WebBrowser)(cntTab.SelectedTab.Controls[0]))).Document.Body.OuterHtml);

                            HtmlAgilityPack.HtmlNodeCollection nd_Mobile = objHTML.DocumentNode.SelectNodes(@"//*[contains(@class,'candidateContent')]");
                            for (int i = 0; i <= nd_Mobile.Count - 1; i++)
                            {
                                HtmlAgilityPack.HtmlNode CandInfo = nd_Mobile[i];
                                tURL = "";
                                string ID = "", Location = "", Name = "", tSalary = "", tExp = "", tSkill = "";

                                string[] idss = CandInfo.InnerHtml.Split(s23t, StringSplitOptions.RemoveEmptyEntries);
                                ID = idss[1].Split(spID, StringSplitOptions.RemoveEmptyEntries)[0].ToString();
                                tURL = CandInfo.SelectNodes(@"//*[contains(@class,'candidateName')]")[i].GetAttributeValue("href", "NO URL FOUND");

                                Name = CandInfo.SelectNodes(@"//*[contains(@class,'candidateName')]")[i].InnerText;

                                System.Text.StringBuilder sbSkill = new StringBuilder();
                                System.Text.RegularExpressions.Regex exFind = new System.Text.RegularExpressions.Regex("<DIV class=\"skillName\">.*?</DIV>", System.Text.RegularExpressions.RegexOptions.IgnoreCase);
                                System.Text.RegularExpressions.MatchCollection mMatch = exFind.Matches(nd_Mobile[i].InnerHtml);
                                foreach (System.Text.RegularExpressions.Match m in mMatch)
                                {
                                    sbSkill.Append(System.Text.RegularExpressions.Regex.Replace(m.Value, "(<DIV class=skillName>|</DIV>)", string.Empty).Trim() + ",");
                                }
                                tSkill = StripHTML(sbSkill.ToString()).Replace(" ,", ", ");
                                if (tSkill.Trim().EndsWith(","))
                                    tSkill = tSkill.Trim().Substring(0, tSkill.Trim().Length - 1);
                                exFind = null; mMatch = null;
                                int iLoc = 0;
                                System.Text.RegularExpressions.Regex exFind1 = new System.Text.RegularExpressions.Regex("<DIV class=\"padRow\">.*?</DIV>", System.Text.RegularExpressions.RegexOptions.IgnoreCase);
                                System.Text.RegularExpressions.MatchCollection mMatch1 = exFind1.Matches(CandInfo.InnerHtml);
                                foreach (System.Text.RegularExpressions.Match m in mMatch1)
                                {
                                    if (m.Value == "<DIV class=padRow>") continue;
                                    if (m.Value.ToLower().IndexOf("$") >= 0 && tSalary.Trim().Length == 0)
                                    {
                                        tSalary = StripHTML(m.Value).Replace("/hr", "").Replace("$", "").Trim();
                                    }
                                    if (m.Value.ToLower().IndexOf("year") >= 0)
                                    {
                                        tExp = StripHTML(m.Value).Replace("Years", "").Replace("years", "").Replace("&gt;", "").Replace("&lt;", "").Trim();
                                    }
                                    if (iLoc == 2 || iLoc == 2)
                                    {
                                        Location = StripHTML(m.Value);
                                    }
                                    iLoc += 1;
                                }
                                if (ID != "")
                                {
                                    objEl = objXnm.CreateElement("Main");
                                    objElSub = objXnm.CreateElement("Check");
                                    objElSub.InnerText = true.ToString();
                                    objEl.AppendChild(objElSub);
                                    objElSub = objXnm.CreateElement("ResumeID");
                                    objElSub.InnerText = "0";
                                    objEl.AppendChild(objElSub);
                                    objElSub = objXnm.CreateElement("SavedType");
                                    objElSub.InnerText = "0";
                                    objEl.AppendChild(objElSub);
                                    objElSub = objXnm.CreateElement("CandidateName");
                                    objElSub.InnerText = Name;
                                    objEl.AppendChild(objElSub);
                                    objElSub = objXnm.CreateElement("IDs");
                                    objElSub.InnerText = ID;
                                    objEl.AppendChild(objElSub);
                                    objElSub = objXnm.CreateElement("Mobile");
                                    objElSub.InnerText = "";
                                    objEl.AppendChild(objElSub);
                                    objElSub = objXnm.CreateElement("CandidateLocation");
                                    objElSub.InnerText = Location.Replace("Willing to Relocate:", "").Trim();
                                    objEl.AppendChild(objElSub);
                                    objElSub = objXnm.CreateElement("PhoneH");
                                    objElSub.InnerText = "";
                                    objEl.AppendChild(objElSub);
                                    objElSub = objXnm.CreateElement("Education");
                                    objElSub.InnerText = "";
                                    objEl.AppendChild(objElSub);
                                    //objElSub = objXnm.CreateElement("EducationIDs");
                                    //objElSub.InnerText = "";
                                    //objEl.AppendChild(objElSub);
                                    objElSub = objXnm.CreateElement("PresentCTC");
                                    objElSub.InnerText = tSalary.Replace(",", "").Trim();
                                    objEl.AppendChild(objElSub);
                                    objElSub = objXnm.CreateElement("TotalExp");
                                    objElSub.InnerText = tExp.Replace("years", "").Trim();
                                    objEl.AppendChild(objElSub);
                                    objElSub = objXnm.CreateElement("Skill");
                                    objElSub.InnerText = tSkill;
                                    objEl.AppendChild(objElSub);
                                    objElSub = objXnm.CreateElement("PresentEmployer");
                                    objElSub.InnerText = "";
                                    objEl.AppendChild(objElSub);
                                    string tDesignationTitle = "", tDesignationIDs = "";
                                    objElSub = objXnm.CreateElement("JobTitle");
                                    objElSub.InnerText = tDesignationTitle.Split(',')[tDesignationTitle.Split(',').GetLowerBound(0)];
                                    if (objElSub.InnerText.Trim() == "")
                                        objElSub.InnerText = "<--None-->";
                                    objEl.AppendChild(objElSub);

                                    //objElSub = objXnm.CreateElement("DesignationID");
                                    //objElSub.InnerText = tDesignationIDs.Split(',')[tDesignationIDs.Split(',').GetLowerBound(0)];
                                    //objEl.AppendChild(objElSub);

                                    objElSub = objXnm.CreateElement("URL");
                                    objElSub.InnerText = tURL;
                                    objEl.AppendChild(objElSub);
                                    objElSub = objXnm.CreateElement("PreviousDesignation");
                                    objElSub.InnerText = "";
                                    objEl.AppendChild(objElSub);
                                    objElSub = objXnm.CreateElement("PreviousEmployer");
                                    objElSub.InnerText = "";
                                    objEl.AppendChild(objElSub);
                                    objElSub = objXnm.CreateElement("PrefLocationText");
                                    objElSub.InnerText = "";
                                    objEl.AppendChild(objElSub);

                                    //objElSub = objXnm.CreateElement("PrefLocationIDs");
                                    //objElSub.InnerText = "";
                                    //objEl.AppendChild(objElSub);
                                    objElSub = objXnm.CreateElement("SiteResumeID");
                                    objElSub.InnerText = "";
                                    objEl.AppendChild(objElSub);
                                    objElSub = objXnm.CreateElement("AutoResumeID");
                                    objElSub.InnerText = "";
                                    objEl.AppendChild(objElSub);
                                    objElSub = objXnm.CreateElement("Indicator");
                                    objElSub.InnerText = "";
                                    objEl.AppendChild(objElSub);
                                    objRoot.AppendChild(objEl);
                                }
                            }
                            dt.ReadXml(new System.IO.StringReader(objXnm.OuterXml));
                            try
                            {
                                //grdCandidate.BeginUpdate();
                                dtGridData.Merge(dt.Tables[0], true);
                                tsDownload.Enabled = true;
                            }
                            catch { }
                            finally
                            {
                                //grdCandidate.EndUpdate();
                                grdCandidate.Refresh();
                                //sel.SelectAll();
                                //grdCandidate_DataSourceChanged(null, null);
                            }
                            Application.DoEvents();
                        }
                        catch { }
                    }

                    #endregion

                    #region "Naugri"

                    if (bFlagNaukri == 7)// if (opValidJobSiteNaukrigulf(br1.Url.ToString()))
                    {
                        try
                        {
                            //  bFlagNaukri = 7;
                            string tempop = (((System.Windows.Forms.WebBrowser)(cntTab.SelectedTab.Controls[0]))).Document.Body.InnerHtml;


                            objXnm = new System.Xml.XmlDocument();
                            objEl = objXnm.CreateElement("ROOT");
                            objXnm.AppendChild(objEl);
                            objRoot = objXnm.DocumentElement;
                            int i = 0;
                            string[] st = { "<DIV class=leftchk>", "<div class=\"leftchk\">" };
                            string[] st12 = { "<!--<IMG SRC=" };
                            string[] st123 = { "\r\n", " \r\n \r\n", "\r\n \r\n", "\n" };
                            string[] st1234 = { "Currently in:" };
                            string[] s23t = { "http://www.naukrigulf.com/ni/niresdex/rdx_preview.php?", "target=_blank name=resumeLink", "target=_blank>", "target=_blank", " target=\"_blank\"><strong>" };
                            //string[] str = richTextBox1.Text.ToString().Split(st, StringSplitOptions.RemoveEmptyEntries);
                            string[] str = tempop.ToString().Split(st, StringSplitOptions.RemoveEmptyEntries);

                            string[] stMain = null;
                            string[] sEBoldt = { "<td valign='top' class='dashedL resDivM1'>", "<br /><br />" };
                            string[] sEBoldt1 = { "<span class='ltGrey'>", "<BR>", "<br>", "<br />" };
                            string[] sEBoldt2 = { "<strong>", "</strong>" };
                            string[] sEmpt = { "At&nbsp;", " at " };
                            int j = str.GetUpperBound(0);

                            tspgrs.Minimum = i;
                            tspgrs.Maximum = j;
                            tspgrs.Step = 1;
                            string[] stMain1 = new string[10];
                            foreach (string stre in str)
                            {
                                if (i >= 1 && i <= j)
                                {
                                    if (stre.IndexOf("<STRONG class=f12>Similar CVs</STRONG> - Showing <STRONG>") > 0)
                                        continue;

                                    string ids = stre.Split(s23t, StringSplitOptions.RemoveEmptyEntries)[1].ToString();
                                    //string[] sIDt = { "&amp;" };
                                    //string[] aIds = ids.Split(sIDt, StringSplitOptions.RemoveEmptyEntries);
                                    //ids = aIds[0] + "&" + aIds[2];//.Replace("'","");


                                    HtmlAgilityPack.HtmlDocument objHTML1 = new HtmlAgilityPack.HtmlDocument();
                                    objHTML1.LoadHtml("<DIV class=leftchk>" + stre);
                                    HtmlAgilityPack.HtmlNodeCollection nd_Mobile2 = objHTML1.DocumentNode.SelectNodes("//div");
                                    string tloc = "";
                                    string tPhone = "";
                                    string tMobile = "";
                                    string tCTC = "", tPresentEmp = "", tDesignation = "", tExperience = "", tskills = "";
                                    for (int iCnt = 0; iCnt < nd_Mobile2.Count; iCnt++)
                                    {

                                        if (System.Text.RegularExpressions.Regex.IsMatch(nd_Mobile2[iCnt].InnerText, "Location|location") && System.Text.RegularExpressions.Regex.IsMatch(nd_Mobile2[iCnt].InnerText, "Salary Bracket"))
                                        {
                                            string[] ALocSal = nd_Mobile2[iCnt].InnerText.Split(new string[] { "\n\t" }, StringSplitOptions.RemoveEmptyEntries);
                                            try
                                            {
                                                tloc = ALocSal[1].Trim();
                                                tCTC = ALocSal[3].Trim();
                                            }
                                            catch { }
                                            ALocSal = null;

                                        }
                                        if (System.Text.RegularExpressions.Regex.IsMatch(nd_Mobile2[iCnt].InnerText, "Nationality") && System.Text.RegularExpressions.Regex.IsMatch(nd_Mobile2[iCnt].InnerText, "Current Employer"))
                                        {
                                            string[] ALocSal = nd_Mobile2[iCnt].InnerText.Split(new string[] { "\n\t" }, StringSplitOptions.RemoveEmptyEntries);
                                            try
                                            {
                                                tPresentEmp = ALocSal[2].Trim();
                                            }
                                            catch { }
                                            ALocSal = null;

                                        }
                                        if (System.Text.RegularExpressions.Regex.IsMatch(nd_Mobile2[iCnt].InnerText.Trim(), "^Skills") && System.Text.RegularExpressions.Regex.IsMatch(nd_Mobile2[iCnt].InnerText, "Languages Known"))
                                        {
                                            string[] ALocSal = nd_Mobile2[iCnt].InnerText.Split(new string[] { "\n\t", "\n" }, StringSplitOptions.RemoveEmptyEntries);
                                            try
                                            {
                                                tskills = ALocSal[1].Trim();
                                            }
                                            catch { }
                                            ALocSal = null;

                                        }
                                    }
                                    try
                                    {
                                        if (objHTML1.DocumentNode.SelectSingleNode("//a[@class='col06C f12 wrapword searchanc']").InnerText.ToLower().IndexOf("yrs.") >= 0)
                                        {
                                            try
                                            {
                                                string[] tdp = { "(", ")", "yrs." };
                                                tExperience = objHTML1.DocumentNode.SelectSingleNode("//a[@class='col06C f12 wrapword searchanc']").InnerText;
                                                string[] aExp = tExperience.Split(tdp, StringSplitOptions.RemoveEmptyEntries);
                                                tExperience = aExp[aExp.Length - 2].Trim();
                                                tDesignation = aExp[aExp.Length - 3].Replace("  - ", "").Trim();
                                                stMain1[1] = aExp[0];
                                            }
                                            catch { }
                                        }
                                    }
                                    catch { }

                                    ;
                                    stMain1[3] = tloc;
                                    stMain1[2] = tPhone + " " + tMobile;
                                    stMain1[4] = tPresentEmp;//stMain[7].Split(sEmpt, StringSplitOptions.RemoveEmptyEntries)[stMain[7].Split(sEmpt, StringSplitOptions.RemoveEmptyEntries).GetUpperBound(0)];
                                    stMain1[5] = tDesignation;// stMain[6].Split(sEmpt, StringSplitOptions.RemoveEmptyEntries)[stMain[7].Split(sEmpt, StringSplitOptions.RemoveEmptyEntries).GetLowerBound(0)];
                                    stMain1[6] = tExperience;
                                    stMain1[7] = tskills;
                                    stMain1[8] = "";//stMain[2];
                                    stMain1[9] = tCTC;// (bFound == true ? stMain[iLocCnt1 + 1] : "");
                                    //richTextBox3.Text += System.Environment.NewLine + "_______+______+________" + System.Environment.NewLine + RemoveHTML("<TR><TD><INPUT TYPE='CHECKBOX' NAME='chkb[]'" + stre).ToString().Split(st12, StringSplitOptions.RemoveEmptyEntries)[0].ToString().Trim();
                                    opCreateNodesNaukri(stMain1, ids);


                                }
                                tspgrs.PerformStep();
                                //tspgrs.Refresh();

                                i++;
                            }

                            i++;

                            tspgrs.Value = 0;
                            dt.ReadXml(new System.IO.StringReader(objXnm.OuterXml));
                            try
                            {
                                //grdCandidate.BeginUpdate();
                                dtGridData.Merge(dt.Tables[0], true);
                                tsDownload.Enabled = true;
                            }
                            catch { }
                            finally
                            {
                                //grdCandidate.EndUpdate();
                                grdCandidate.Refresh();
                                //sel.SelectAll();
                                //grdCandidate_DataSourceChanged(null, null);
                            }
                            Application.DoEvents();
                        }
                        catch
                        {
                        }
                    }
                    #endregion

                    #region "sig"

                    if (bFlagNaukri == 8)// if (opValidJobSiteMonsterMalaysia(br1.Url.ToString()))
                    {
                        //  bFlagNaukri = 9;

                        objXnm = new System.Xml.XmlDocument();
                        objEl = objXnm.CreateElement("ROOT");
                        objXnm.AppendChild(objEl);
                        objRoot = objXnm.DocumentElement;

                        string[] st = { "<input type=\"checkbox\" name=\"resID\"", "<input name=\"resID\" type=\"checkbox\"" };
                        string[] st1 = { "<!--loop ends-->" };
                        string[] st2 = { "&nbsp;", "similar resumes", "Similar Resumes", "\r\n\r\n", "\r\n", "Viewed ", "New", "\n", "\t", "Contacted by Email" };//, "\r\n", "<BR>", "<br>", "<br />", "<br/>", "\n\t\n", "\n" 
                        string[] st3 = { "resumedatabase/resume.html?" };
                        string[] st4 = { ";words=", "\" target=_blank ;", "\" target=_blank>" };//" target=_blank ;
                        string[] tSpNewVMJun14 = { "<!--<td", " >-->" };
                        try
                        {
                            int i = 0;
                            string[] str = (((System.Windows.Forms.WebBrowser)(cntTab.SelectedTab.Controls[0]))).Document.Body.InnerHtml.ToString().Split(st, StringSplitOptions.RemoveEmptyEntries);

                            int j = str.GetUpperBound(0);
                            foreach (string stre in str)
                            {
                                if (i > 0 && i <= j)
                                {
                                    try
                                    {

                                        string[] stSp = null;
                                        string IDs = stre.Split(st3, StringSplitOptions.RemoveEmptyEntries)[1].Split(st4, StringSplitOptions.RemoveEmptyEntries)[0];
                                        string stText = "";

                                        string tNewStre = stre;
                                        string[] strJun14 = stre.Split(tSpNewVMJun14, StringSplitOptions.RemoveEmptyEntries);
                                        if (strJun14.Length >= 3)
                                            tNewStre = strJun14[2];

                                        stText = RemoveHTMLNew("<td><A   " + tNewStre).Replace("Click for contact details", "").Trim();
                                        // stText = RemoveHTMLNew("<input   " + stre).Trim();
                                        string[] aNst2 = { "&nbsp;", "<br/>", "\r\n", "Viewed ", "New", "\n", "\t", "Contacted by Email" };
                                        string[] aEnd = { " Send Email", "Send Email", "Freshness:", "Similar Resumes", "<A", "<a" };
                                        stSp = stText.Split(aEnd, StringSplitOptions.RemoveEmptyEntries)[0].Trim().Split(aNst2, StringSplitOptions.RemoveEmptyEntries);//
                                        int iMobFound = 0, iYearofParsing = 0, iEndDesignation = 0, iFoundSkill = 0;
                                        string[] stMain1 = new string[12];
                                        string tCurrentEmploye = "", tExp = "", tCTC = "", tPhone = "", tMobile = "", tREsumeID = "", preferredLocation = "", tLocation = "", tDesignation = "";
                                        for (int iLocCnt = 0; iLocCnt <= stSp.GetUpperBound(0); iLocCnt++)
                                        {
                                            // For Picking the Salary.
                                            try
                                            {
                                                if (stSp[iLocCnt].ToLower().IndexOf("annual salary:") >= 0 || stSp[iLocCnt].ToLower().IndexOf("annual salary") >= 0)
                                                {
                                                    //tCTC = stSp[iLocCnt].Split(':')[stSp[iLocCnt].Split(':').GetUpperBound(0)].Trim().ToLower().Replace("aed", "").Replace("inr", "").Replace("rs.", "").Replace("rs", "").Replace("usd", "").Replace("annually", "").Replace(",", "").Trim();
                                                    tCTC = stSp[iLocCnt].Split(':')[stSp[iLocCnt].Split(':').GetUpperBound(0)].Trim();
                                                    tCTC = System.Text.RegularExpressions.Regex.Match(tCTC, @"\d+").Value.ToString();
                                                }
                                                else if (stSp[iLocCnt].ToLower().IndexOf("salary:") >= 0 || stSp[iLocCnt].ToLower().IndexOf("salary") >= 0)
                                                {
                                                    // Checking Annual Salary
                                                    string tValue = stSp[iLocCnt].Split(':')[stSp[iLocCnt].Split(':').GetUpperBound(0)].Trim().ToLower();
                                                    if (tValue.Contains("annual") || tValue.Contains("annum"))
                                                    {
                                                        //  tCTC = tValue.Replace("aed", "").Replace("rs.", "").Replace("usd", "").Replace("annually", "").Replace("per/annum", "").Replace("per", "").Replace("annum", "").Replace("/", "").Replace(",", "").Trim();
                                                        string tValue1 = tValue.Replace("annually", "").Replace("per/annum", "").Replace("per", "").Replace("annum", "").Replace("/", "").Replace(",", "").Trim();
                                                        if (tValue1.Trim() != "")
                                                            tCTC = opGetCTC(tValue1.Trim());
                                                    }
                                                    else if (tValue.Contains("month"))
                                                    {
                                                        string tValue1 = tValue.Replace("per/month", "").Replace("per", "").Replace("month", "").Replace("/", "").Replace(",", "").Trim();
                                                        if (tValue1.Trim() != "")
                                                            tCTC = opGetCTC(tValue1.Trim());
                                                    }
                                                    else
                                                    {
                                                        tCTC = tValue.Replace("aed", "").Replace("inr", "").Replace("rs.", "").Replace("rs", "").Replace("usd", "").Replace(",", "").Replace(" ", "").Trim();
                                                    }
                                                }
                                            }

                                            catch { }

                                            if (stSp[iLocCnt].ToLower().IndexOf("exp:") >= 0)
                                            {
                                                tExp = stSp[iLocCnt].Split(':')[stSp[iLocCnt].Split(':').GetUpperBound(0)];
                                                iFoundSkill = iLocCnt;
                                            }
                                            if (stSp[iLocCnt].IndexOf("Industry") >= 0 && iFoundSkill == 0)
                                            {
                                                iFoundSkill = iLocCnt;
                                            }
                                            if (stSp[iLocCnt].IndexOf("Year of Passing") >= 0)
                                            {
                                                iYearofParsing = iLocCnt;
                                            }
                                            if (stSp[iLocCnt].ToLower().IndexOf("mobile:") >= 0)
                                            {
                                                tMobile = stSp[iLocCnt].Split(':')[stSp[iLocCnt].Split(':').GetUpperBound(0)];
                                                iMobFound = iLocCnt;
                                            }
                                            if ((stSp[iLocCnt].IndexOf("Annual Salary") >= 0 || stSp[iLocCnt].IndexOf("Designation:") >= 0) && iEndDesignation == 0)
                                                iEndDesignation = iLocCnt;
                                            if (stSp[iLocCnt].ToLower().IndexOf("telephone:") >= 0)
                                            {
                                                tPhone = stSp[iLocCnt].Split(':')[stSp[iLocCnt].Split(':').GetUpperBound(0)];
                                                if (iMobFound == 0) iMobFound = iLocCnt;
                                            }
                                            if (stSp[iLocCnt].ToLower().IndexOf("resume id:") >= 0)
                                            {
                                                tREsumeID = stSp[iLocCnt].Split(':')[stSp[iLocCnt].Split(':').GetUpperBound(0)];

                                            }
                                            if (stSp[iLocCnt].ToLower().IndexOf("current:") >= 0)
                                            {
                                                tLocation = stSp[iLocCnt].Split(':')[stSp[iLocCnt].Split(':').GetUpperBound(0)];
                                                if (iMobFound == 0) iMobFound = iLocCnt;

                                                try
                                                {
                                                    if (tLocation.Trim() == "" && !stSp[iLocCnt + 1].Contains(":"))
                                                    {
                                                        tLocation = stSp[iLocCnt + 1].Trim();
                                                    }
                                                }
                                                catch { }
                                                if (tLocation == "" && stSp[iLocCnt + 1].IndexOf("Nationality:") < 0)
                                                    tLocation = stSp[iLocCnt + 1].Split(':')[stSp[iLocCnt + 1].Split(':').GetUpperBound(0)];
                                            }
                                            if (stSp[iLocCnt].ToLower().IndexOf("preferred location:") >= 0 || stSp[iLocCnt].ToLower().IndexOf("preferred:") >= 0)
                                            {
                                                preferredLocation = stSp[iLocCnt].Split(':')[stSp[iLocCnt].Split(':').GetUpperBound(0)].Trim();
                                                try
                                                {
                                                    if (preferredLocation.Trim() == "" && !stSp[iLocCnt + 1].Contains(":"))
                                                    {
                                                        preferredLocation = stSp[iLocCnt + 1].Trim();
                                                    }
                                                }
                                                catch { }
                                            }

                                            if (stSp[iLocCnt].ToLower().IndexOf("designation:") >= 0)
                                            {
                                                tDesignation = stSp[iLocCnt].Split(':')[stSp[iLocCnt].Split(':').GetUpperBound(0)].Trim();

                                                try
                                                {
                                                    if (tDesignation.Trim() == "" && !stSp[iLocCnt + 1].Contains(":"))
                                                    {
                                                        tDesignation = stSp[iLocCnt + 1].Trim();
                                                    }
                                                }
                                                catch { }
                                            }
                                        }
                                        if (iMobFound > 0 && iEndDesignation == 0)
                                            iEndDesignation = iMobFound - 1;
                                        if (iYearofParsing > 0 && iEndDesignation > 0)
                                        {
                                            for (int iLocCnt = iYearofParsing + 1; iLocCnt < iEndDesignation && tCurrentEmploye == ""; iLocCnt++)
                                            {
                                                tCurrentEmploye = stSp[iLocCnt];
                                                break;
                                            }
                                        }
                                        string tSkill = "";
                                        if (iFoundSkill > 0)
                                        {
                                            for (int iLocCnt = 0; iLocCnt < iFoundSkill; iLocCnt++)
                                            {
                                                tSkill += stSp[iLocCnt];
                                            }
                                        }

                                        if (iMobFound == 0)
                                            stMain1[0] = stSp[stSp.GetUpperBound(0) - 1];
                                        else
                                            stMain1[0] = stSp[iMobFound - 1];
                                        if (stMain1[0].IndexOf("(") >= 0)
                                        {
                                            string[] a = stMain1[0].Split('(');
                                            stMain1[0] = a[0];
                                        }
                                        stMain1[1] = tPhone;
                                        stMain1[2] = tMobile;
                                        stMain1[3] = tLocation;// (stSp[stSp.GetUpperBound(0)].Trim() == "Viewed" ? stSp[stSp.GetUpperBound(0) - 1] : stSp[stSp.GetUpperBound(0)]);
                                        if (stMain1[3] == stMain1[0])
                                            stMain1[0] = "";

                                        stMain1[4] = tCurrentEmploye.Replace("Not employed currently", "").Replace("NA\t", "").Replace("None\t", "").Replace("nil\t", "").Replace("Nil\t", "").Replace("NOT EMPLOYED CURRENTLY", "").Replace(" no", "").Replace(" No", "").Trim();
                                        stMain1[5] = tSkill;//skill

                                        try
                                        {
                                            if (iYearofParsing > 0)
                                            {
                                                if (!stSp[iYearofParsing - 1].Contains(":") && stSp[iYearofParsing - 1].Trim() != "," && stSp[iYearofParsing - 1].Trim() != "")
                                                {
                                                    stMain1[6] = stSp[iYearofParsing - 1];
                                                }
                                                else if (!stSp[iYearofParsing - 2].Contains(":") && stSp[iYearofParsing - 2].Trim() != "," && stSp[iYearofParsing - 2].Trim() != "")
                                                {
                                                    stMain1[6] = stSp[iYearofParsing - 2];

                                                }
                                                else stMain1[6] = stSp[2];
                                            }
                                            else
                                                stMain1[6] = stSp[2];
                                        }
                                        catch { stMain1[6] = ""; }

                                        stMain1[7] = tCTC;
                                        stMain1[8] = tExp;
                                        stMain1[9] = preferredLocation;
                                        stMain1[10] = tREsumeID.Trim();
                                        stMain1[11] = tDesignation.Trim();
                                        opCreateMonsterNewVersion(stMain1, IDs);
                                    }
                                    catch { }

                                }
                                i++;
                            }

                            i++;
                            dt.ReadXml(new System.IO.StringReader(objXnm.OuterXml));
                            try
                            {
                                //grdCandidate.BeginUpdate();
                                dtGridData.Merge(dt.Tables[0], true);
                                tsDownload.Enabled = true;
                            }
                            catch { }
                            finally
                            {
                                //grdCandidate.EndUpdate();
                                grdCandidate.Refresh();
                                //sel.SelectAll();
                                //grdCandidate_DataSourceChanged(null, null);
                            }
                            Application.DoEvents();

                        }
                        catch
                        { }
                    }

                    // Commented by Mohan G on 19-Sep-2014
                    //if (bFlagNaukri == 8)// if (opValidJobSiteMonsterMalaysia(br1.Url.ToString()))
                    //{
                    //    //  bFlagNaukri = 9;

                    //    objXnm = new System.Xml.XmlDocument();
                    //    objEl = objXnm.CreateElement("ROOT");
                    //    objXnm.AppendChild(objEl);
                    //    objRoot = objXnm.DocumentElement;

                    //    string[] st = { "<INPUT type=checkbox value=", "<input type=\"checkbox\" name=\"resID\"", "<input name=\"resID\" type=\"checkbox\" value=" };
                    //    string[] st1 = { "<!--loop ends-->" };
                    //    string[] st2 = { "&nbsp;" };
                    //    string[] st3 = { "resumedatabase/resume.html?" };
                    //    string[] st4 = { ";words=" };

                    //    try
                    //    {
                    //        int i = 0;
                    //        string[] str = (((System.Windows.Forms.WebBrowser)(cntTab.SelectedTab.Controls[0]))).Document.Body.InnerHtml.ToString().Split(st, StringSplitOptions.RemoveEmptyEntries);

                    //        int j = str.GetUpperBound(0);
                    //        foreach (string stre in str)
                    //        {
                    //            if (i > 0 && i <= j)
                    //            {
                    //                try
                    //                {
                    //                    int iNameSearch = 0, iYearofParsing = 0, iEndDesignation = 0;
                    //                    string[] stSp = null;
                    //                    string IDs = stre.Split(st3, StringSplitOptions.RemoveEmptyEntries)[1].Split(st4, StringSplitOptions.RemoveEmptyEntries)[0];
                    //                    string stText = "";
                    //                    stText = RemoveHTMLNew("<input   " + stre).Trim();
                    //                    string[] aNst2 = { "&nbsp;", "\r\n", "Similar Resumes", "Viewed", "New" };
                    //                    string[] aEnd = { " Send Email", "Freshness:" };
                    //                    stSp = stText.Split(aEnd, StringSplitOptions.RemoveEmptyEntries)[0].Trim().Split(aNst2, StringSplitOptions.RemoveEmptyEntries);//
                    //                    int iMobFound = 0;
                    //                    string[] stMain1 = new string[12];
                    //                    string tCurrentEmploye = "", tExp = "", tCTC = "", tPhone = "", tMobile = "", tREsumeID = "", preferredLocation = "", tLocation = "", tDesignation = "";
                    //                    for (int iLocCnt = 0; iLocCnt <= stSp.GetUpperBound(0); iLocCnt++)
                    //                    {
                    //                        if (stSp[iLocCnt].IndexOf("Year of Passing") >= 0)
                    //                        {
                    //                            iYearofParsing = iLocCnt;
                    //                        }
                    //                        if ((stSp[iLocCnt].IndexOf("Annual Salary") >= 0 || stSp[iLocCnt].IndexOf("Salary:") >= 0 || stSp[iLocCnt].IndexOf("Designation:") >= 0) && iEndDesignation == 0)
                    //                            iEndDesignation = iLocCnt;
                    //                        if (stSp[iLocCnt].ToLower().IndexOf("salary:") >= 0)
                    //                            tCTC = stSp[iLocCnt].Split(':')[stSp[iLocCnt].Split(':').GetUpperBound(0)].Replace("Rs.", "").Replace("annually", "").Replace(",", "").Trim();
                    //                        if (stSp[iLocCnt].ToLower().IndexOf("exp:") >= 0)
                    //                        {
                    //                            tExp = stSp[iLocCnt].Split(':')[stSp[iLocCnt].Split(':').GetUpperBound(0)];
                    //                            iNameSearch = iLocCnt;
                    //                        }
                    //                        if (stSp[iLocCnt].ToLower().IndexOf("mobile:") >= 0)
                    //                        {
                    //                            tMobile = stSp[iLocCnt].Split(':')[stSp[iLocCnt].Split(':').GetUpperBound(0)];
                    //                            iMobFound = iLocCnt;
                    //                        }
                    //                        if (stSp[iLocCnt].ToLower().IndexOf("telephone:") >= 0)
                    //                        {
                    //                            tPhone = stSp[iLocCnt].Split(':')[stSp[iLocCnt].Split(':').GetUpperBound(0)];
                    //                            if (iMobFound == 0) iMobFound = iLocCnt;
                    //                        }
                    //                        if (stSp[iLocCnt].ToLower().IndexOf("current:") >= 0)
                    //                        {
                    //                            tLocation = stSp[iLocCnt].Split(':')[stSp[iLocCnt].Split(':').GetUpperBound(0)];
                    //                            if (iMobFound == 0) iMobFound = iLocCnt;
                    //                            if (tLocation == "" && stSp[iLocCnt + 1].IndexOf("Nationality:") < 0)
                    //                                tLocation = stSp[iLocCnt + 1].Split(':')[stSp[iLocCnt + 1].Split(':').GetUpperBound(0)];
                    //                        }
                    //                        if (stSp[iLocCnt].ToLower().IndexOf("preferred location:") >= 0 || stSp[iLocCnt].ToLower().IndexOf("preferred:") >= 0)
                    //                        {
                    //                            preferredLocation = stSp[iLocCnt].Split(':')[stSp[iLocCnt].Split(':').GetUpperBound(0)].Trim();

                    //                        }
                    //                        if (stSp[iLocCnt].ToLower().IndexOf("resume id:") >= 0)
                    //                        {
                    //                            tREsumeID = stSp[iLocCnt].Split(':')[stSp[iLocCnt].Split(':').GetUpperBound(0)];

                    //                        }
                    //                        if (stSp[iLocCnt].ToLower().IndexOf("designation:") >= 0)
                    //                        {
                    //                            tDesignation = stSp[iLocCnt].Split(':')[stSp[iLocCnt].Split(':').GetUpperBound(0)].Trim();

                    //                        }

                    //                    }
                    //                    //if (iNameSearch > 0 && stSp[iNameSearch + 1].ToLower().IndexOf("preferred location") < 0)
                    //                    //    stMain1[0] = stSp[iNameSearch + 1];
                    //                    //else 
                    //                    if (iMobFound > 0 && iEndDesignation == 0)
                    //                        iEndDesignation = iMobFound - 1;
                    //                    if (iYearofParsing > 0 && iEndDesignation > 0)
                    //                    {
                    //                        for (int iLocCnt = iYearofParsing + 1; iLocCnt < iEndDesignation && tCurrentEmploye == ""; iLocCnt++)
                    //                        {
                    //                            tCurrentEmploye = stSp[iLocCnt];
                    //                            break;
                    //                        }
                    //                    }
                    //                    if (iMobFound == 0)
                    //                        stMain1[0] = stSp[stSp.GetUpperBound(0) - 1];
                    //                    else
                    //                        stMain1[0] = stSp[iMobFound - 1];
                    //                    if (stMain1[0].IndexOf("(") >= 0)
                    //                    {
                    //                        string[] a = stMain1[0].Split('(');
                    //                        stMain1[0] = a[0];
                    //                    }
                    //                    stMain1[1] = tPhone;
                    //                    stMain1[2] = tMobile;
                    //                    stMain1[3] = tLocation;// stMain1[3] = (stSp[stSp.GetUpperBound(0)].IndexOf("Nationality") >= 0 ? stSp[stSp.GetUpperBound(0) - 1] : stSp[stSp.GetUpperBound(0)]);
                    //                    stMain1[4] = tCurrentEmploye.Replace("Not employed currently", "").Replace("NA\t", "").Replace("None\t", "").Replace("nil\t", "").Replace("Nil\t", "").Replace("NOT EMPLOYED CURRENTLY", "").Replace(" no", "").Replace(" No", "").Trim();
                    //                    stMain1[5] = tDesignation;//skill
                    //                    stMain1[6] = (iYearofParsing > 0 ? stSp[iYearofParsing - 1] : stSp[2]); //stSp[2];//education
                    //                    stMain1[7] = tCTC;
                    //                    stMain1[8] = tExp;
                    //                    stMain1[9] = preferredLocation;
                    //                    stMain1[10] = tREsumeID.Trim();
                    //                    opCreateMonsterNewVersionMy(stMain1, IDs);
                    //                }
                    //                catch { }

                    //            }
                    //            i++;
                    //        }

                    //        i++;
                    //        dt.ReadXml(new System.IO.StringReader(objXnm.OuterXml));
                    //        try
                    //        {
                    //            //grdCandidate.BeginUpdate();
                    //            dtGridData.Merge(dt.Tables[0], true);
                    //            tsDownload.Enabled = true;
                    //        }
                    //        catch { }
                    //        finally
                    //        {
                    //            //grdCandidate.EndUpdate();
                    //            grdCandidate.Refresh();
                    //            //sel.SelectAll();
                    //            //grdCandidate_DataSourceChanged(null, null);
                    //        }
                    //        Application.DoEvents();

                    //    }
                    //    catch
                    //    { }
                    //}
                    #endregion

                    #region "Monster Singapore"
                    if (bFlagNaukri == 88)// if (opValidJobSiteMonsterSingapore(br1.Url.ToString()) && bFlagNaukri!=1)
                    {
                        objXnm = new System.Xml.XmlDocument();
                        objEl = objXnm.CreateElement("ROOT");
                        objXnm.AppendChild(objEl);
                        objRoot = objXnm.DocumentElement;

                        string[] st = { "<input type=\"checkbox\" name=\"resID\"", " type=checkbox name=resID>" };
                        string[] st1 = { "<!--loop ends-->" };
                        string[] st2 = { "&nbsp;", "similar resumes", "Similar Resumes", "\r\n\r\n", "\r\n", "Viewed ", "New", "\n", "\t", "Contacted by Email" };//, "\r\n", "<BR>", "<br>", "<br />", "<br/>", "\n\t\n", "\n" 

                        string[] st3 = { "resumedatabase/resume.html?" };
                        string[] st4 = { ";\">", "\" target=_blank ;", ";\"" };//" target=_blank ;
                        bool bNewVersion = false;
                        bool bNewNewVersion = false;
                        try
                        {
                            int i = 0;
                            string[] str1 = (((System.Windows.Forms.WebBrowser)(cntTab.SelectedTab.Controls[0]))).Document.Body.InnerHtml.ToString().Split(st, StringSplitOptions.RemoveEmptyEntries);
                            string[] str = null;// (((System.Windows.Forms.WebBrowser)(cntTab.SelectedTab.Controls[0]))).DocumentText.ToString().Split(st, StringSplitOptions.RemoveEmptyEntries);
                            if (str1.Length < 10)
                            {
                                str = (((System.Windows.Forms.WebBrowser)(cntTab.SelectedTab.Controls[0]))).Document.Body.InnerHtml.ToString().Split(st, StringSplitOptions.RemoveEmptyEntries);
                            }
                            else
                            {
                                str = str1; bNewVersion = true;
                                bNewNewVersion = true;
                            }
                            if ((((System.Windows.Forms.WebBrowser)(cntTab.SelectedTab.Controls[0]))).DocumentText.ToString().IndexOf("Old Version") >= 0)
                            {
                                bNewVersion = true;
                                if (str1.Length < 10)
                                {
                                    bNewNewVersion = true;
                                    string[] tSpNewVM = { "<table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"3\">", "<TABLE cellSpacing=0 cellPadding=3 width=\"100%\" border=0>", "<td width=\"19\" valign=\"top\" align=\"center\" style=\"padding: 0px 5px 0px 0px;\">", "<TD style=\"PADDING-RIGHT: 5px; PADDING-LEFT: 0px; PADDING-BOTTOM: 0px; PADDING-TOP: 15px\" vAlign=top align=middle width=19>" };
                                    str = ((System.Windows.Forms.WebBrowser)(cntTab.SelectedTab.Controls[0])).Document.Body.InnerHtml.ToString().Split(st3, StringSplitOptions.RemoveEmptyEntries);
                                }
                            }
                            int j = str.GetUpperBound(0);
                            foreach (string stre in str)
                            {
                                if (i > 0 && i <= j)
                                {
                                    try
                                    {
                                        string IDs = "";
                                        if (bNewNewVersion)
                                            IDs = stre.Split(st3, StringSplitOptions.RemoveEmptyEntries)[1].Split(st4, StringSplitOptions.RemoveEmptyEntries)[0];
                                        else if (bNewVersion)
                                            IDs = stre.Split(st3, StringSplitOptions.RemoveEmptyEntries)[1].Split(st4, StringSplitOptions.RemoveEmptyEntries)[0];


                                        string stText = "";
                                        string[] stSp;
                                        if (bNewVersion == false)
                                        {
                                            IDs = stre.Split(st3, StringSplitOptions.RemoveEmptyEntries)[1].Split(st4, StringSplitOptions.RemoveEmptyEntries)[0];

                                            stText = RemoveHTMLNew("<input type=\"checkbox\" name=\"resID\" " + stre).Trim();
                                            stSp = stText.Split(st2, StringSplitOptions.RemoveEmptyEntries);

                                        }
                                        else
                                        {
                                            if (bNewNewVersion)
                                                stText = RemoveHTMLNew("<td><A   " + stre).Replace("Click for contact details", "").Trim();
                                            else if (bNewVersion)
                                                stText = RemoveHTMLNew("<tr><td><input type=\"checkbox\" name=\"resID\"" + stre).Replace("Click for contact details", "").Trim();
                                            string[] aNst2 = { "&nbsp;", "<br/>", "\r\n", "Similar Resumes", "Viewed ", "New", "\n", "\t", "Contacted by Email" };
                                            string[] aEnd = { " Send Email", "Send Email", "Freshness:", "<A", "<a", "Similar Resumes" };
                                            stSp = stText.Split(aEnd, StringSplitOptions.RemoveEmptyEntries)[0].Trim().Split(aNst2, StringSplitOptions.RemoveEmptyEntries);//
                                        }
                                        int iMobFound = 0;
                                        string[] stMain1 = new string[10];
                                        string tCurrentEmploye = "", tExp = "", tCTC = "", tPhone = "", tMobile = "";
                                        for (int iLocCnt = 0; iLocCnt <= stSp.GetUpperBound(0); iLocCnt++)
                                        {
                                            if (stSp[iLocCnt].ToLower().IndexOf("annual salary:") >= 0)
                                                tCTC = stSp[iLocCnt].Split(':')[stSp[iLocCnt].Split(':').GetUpperBound(0)].Replace("Rs.", "").Replace("annually", "").Replace(",", "").Trim();
                                            if (stSp[iLocCnt].ToLower().IndexOf("exp:") >= 0)
                                                tExp = stSp[iLocCnt].Split(':')[stSp[iLocCnt].Split(':').GetUpperBound(0)];
                                            if (stSp[iLocCnt].ToLower().IndexOf("mobile:") >= 0)
                                            {
                                                tMobile = stSp[iLocCnt].Split(':')[stSp[iLocCnt].Split(':').GetUpperBound(0)];
                                                iMobFound = iLocCnt;
                                            }
                                            if (stSp[iLocCnt].ToLower().IndexOf("telephone:") >= 0)
                                            {
                                                tPhone = stSp[iLocCnt].Split(':')[stSp[iLocCnt].Split(':').GetUpperBound(0)];
                                                if (iMobFound == 0) iMobFound = iLocCnt;
                                            }
                                            if (stSp[iLocCnt].ToLower().IndexOf("last active:") >= 0)
                                                if (stSp[iLocCnt + 1].IndexOf("Resume ID") >= 0)
                                                {
                                                    if (stSp[iLocCnt + 2].IndexOf("Exp") < 0 && stSp[iLocCnt + 2].ToLower().IndexOf("annual salary") < 0 && stSp[iLocCnt + 2].IndexOf("year") < 0)
                                                        tCurrentEmploye = stSp[iLocCnt + 2].Split(':')[stSp[iLocCnt + 2].Split(':').GetUpperBound(0)];
                                                }
                                                else
                                                    tCurrentEmploye = stSp[iLocCnt + 1].Split(':')[stSp[iLocCnt + 1].Split(':').GetUpperBound(0)];
                                        }
                                        if (iMobFound == 0)
                                            stMain1[0] = stSp[stSp.GetUpperBound(0) - 1];
                                        else
                                            stMain1[0] = stSp[iMobFound - 1];
                                        if (stMain1[0].IndexOf("(") >= 0)
                                        {
                                            string[] a = stMain1[0].Split('(');
                                            stMain1[0] = a[0];
                                        }
                                        stMain1[1] = tPhone;
                                        stMain1[2] = tMobile;
                                        stMain1[3] = (stSp[stSp.GetUpperBound(0)].Trim() == "Viewed" ? stSp[stSp.GetUpperBound(0) - 1] : stSp[stSp.GetUpperBound(0)]);
                                        stMain1[4] = tCurrentEmploye.Replace("Not employed currently", "").Replace("NA\t", "").Replace("None\t", "").Replace("nil\t", "").Replace("Nil\t", "").Replace("NOT EMPLOYED CURRENTLY", "").Replace(" no", "").Replace(" No", "").Trim();
                                        stMain1[5] = stSp[1];//skill
                                        stMain1[6] = stSp[2];//education
                                        stMain1[7] = tCTC;
                                        stMain1[8] = tExp;
                                        opCreateMonsterNewVersion(stMain1, IDs);

                                    }
                                    catch { }

                                }
                                i++;
                            }

                            i++;
                            dt.ReadXml(new System.IO.StringReader(objXnm.OuterXml));
                            try
                            {
                                //grdCandidate.BeginUpdate();
                                dtGridData.Merge(dt.Tables[0], true);
                                tsDownload.Enabled = true;
                            }
                            catch { }
                            finally
                            {
                                //grdCandidate.EndUpdate();
                                grdCandidate.Refresh();
                                //sel.SelectAll();
                                //grdCandidate_DataSourceChanged(null, null);
                            }
                            Application.DoEvents();

                        }
                        catch
                        { }

                    }
                    #endregion

                    #region "Monster Malaysia"

                    if (bFlagNaukri == 9)//(opValidJobSiteMonster(br1.Url.ToString()))
                    {
                        //bFlagNaukri = 1;

                        objXnm = new System.Xml.XmlDocument();
                        objEl = objXnm.CreateElement("ROOT");
                        objXnm.AppendChild(objEl);
                        objRoot = objXnm.DocumentElement;

                        string[] st = { "<input type=\"checkbox\" name=\"resID\"", "<input name=\"resID\" type=\"checkbox\"" };
                        string[] st1 = { "<!--loop ends-->" };
                        string[] st2 = { "&nbsp;", "similar resumes", "Similar Resumes", "\r\n\r\n", "\r\n", "Viewed ", "New", "\n", "\t", "Contacted by Email" };//, "\r\n", "<BR>", "<br>", "<br />", "<br/>", "\n\t\n", "\n" 
                        string[] st3 = { "resumedatabase/resume.html?" };
                        string[] st4 = { ";words=", "\" target=_blank ;", "\" target=_blank>" };//" target=_blank ;
                        string[] tSpNewVMJun14 = { "<!--<td", " >-->" };
                        bool bNewVersion = false;
                        bool bNewNewVersion = false;
                        try
                        {
                            int i = 0; string[] str;
                            string[] str1 = (((System.Windows.Forms.WebBrowser)(cntTab.SelectedTab.Controls[0]))).Document.Body.InnerHtml.ToString().Split(st3, StringSplitOptions.RemoveEmptyEntries);
                            //if (str1.Length < 10)
                            //{
                            //    str = (((System.Windows.Forms.WebBrowser)(cntTab.SelectedTab.Controls[0]))).DocumentText.ToString().Split(st, StringSplitOptions.RemoveEmptyEntries);
                            //}
                            //else
                            {
                                str = str1; bNewVersion = true;
                                bNewNewVersion = true;
                            }
                            if ((((System.Windows.Forms.WebBrowser)(cntTab.SelectedTab.Controls[0]))).DocumentText.ToString().IndexOf("Old Version") >= 0)
                            {
                                bNewVersion = true;
                                if (str1.Length < 10)
                                {
                                    bNewNewVersion = true;
                                    string[] tSpNewVM = { "<table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"3\">", "<TABLE cellSpacing=0 cellPadding=3 width=\"100%\" border=0>", "<td width=\"19\" valign=\"top\" align=\"center\" style=\"padding: 0px 5px 0px 0px;\">", "<TD style=\"PADDING-RIGHT: 5px; PADDING-LEFT: 0px; PADDING-BOTTOM: 0px; PADDING-TOP: 15px\" vAlign=top align=middle width=19>" };
                                    str = ((System.Windows.Forms.WebBrowser)(cntTab.SelectedTab.Controls[0])).Document.Body.InnerHtml.ToString().Split(st3, StringSplitOptions.RemoveEmptyEntries);
                                }
                            }
                            int j = str.GetUpperBound(0);
                            tspgrs.Minimum = i;
                            tspgrs.Maximum = j;
                            tspgrs.Step = 1;
                            foreach (string stre in str)
                            {
                                if (i > 0 && i <= j)
                                {
                                    try
                                    {
                                        if (stre.IndexOf("function getRids()") >= 0) continue;

                                        string IDs = "";
                                        if (bNewNewVersion)
                                            IDs = stre.Split(st4, StringSplitOptions.RemoveEmptyEntries)[0];
                                        else if (bNewVersion)
                                            IDs = stre.Split(st3, StringSplitOptions.RemoveEmptyEntries)[1].Split(st4, StringSplitOptions.RemoveEmptyEntries)[0];
                                        string tNewStre = stre;
                                        string[] strJun14 = stre.Split(tSpNewVMJun14, StringSplitOptions.RemoveEmptyEntries);
                                        if (strJun14.Length >= 3)
                                            tNewStre = strJun14[2];
                                        string stText = "";
                                        string[] stSp;
                                        if (bNewVersion == false)
                                        {
                                            IDs = tNewStre.Split(st3, StringSplitOptions.RemoveEmptyEntries)[1].Split(st4, StringSplitOptions.RemoveEmptyEntries)[0];

                                            stText = RemoveHTMLNew("<input type=\"checkbox\" name=\"resID\" " + tNewStre).Trim();
                                            stSp = stText.Split(st2, StringSplitOptions.RemoveEmptyEntries);
                                            //opCreateNodes(stSp, IDs);
                                        }
                                        else
                                        {

                                            if (bNewNewVersion)
                                                stText = RemoveHTMLNew("<td><A   " + tNewStre).Replace("Click for contact details", "").Trim();
                                            else if (bNewVersion)
                                                stText = RemoveHTMLNew("<tr><td><input type=\"checkbox\" name=\"resID\"" + tNewStre).Replace("Click for contact details", "").Trim();
                                            string[] aNst2 = { "&nbsp;", "<br/>", "\r\n", "Viewed ", "New", "\n", "\t", "Contacted by Email" };
                                            string[] aEnd = { " Send Email", "Send Email", "Freshness:", "Similar Resumes", "<A", "<a" };
                                            stSp = stText.Split(aEnd, StringSplitOptions.RemoveEmptyEntries)[0].Trim().Split(aNst2, StringSplitOptions.RemoveEmptyEntries);//
                                        }

                                        int iMobFound = 0, iYearofParsing = 0, iEndDesignation = 0, iFoundSkill = 0;
                                        string[] stMain1 = new string[12];
                                        string tCurrentEmploye = "", tExp = "", tCTC = "", tPhone = "", tMobile = "", tREsumeID = "", preferredLocation = "", tLocation = "", tDesignation = "";
                                        for (int iLocCnt = 0; iLocCnt <= stSp.GetUpperBound(0); iLocCnt++)
                                        {
                                            if (stSp[iLocCnt].ToLower().IndexOf("annual salary:") >= 0 || stSp[iLocCnt].ToLower().IndexOf("annual salary") >= 0)
                                                tCTC = stSp[iLocCnt].Split(':')[stSp[iLocCnt].Split(':').GetUpperBound(0)].Replace("Rs.", "").Replace("annually", "").Replace(",", "").Trim();
                                            if (stSp[iLocCnt].ToLower().IndexOf("exp:") >= 0)
                                            {
                                                tExp = stSp[iLocCnt].Split(':')[stSp[iLocCnt].Split(':').GetUpperBound(0)];
                                                iFoundSkill = iLocCnt;
                                            }
                                            if (stSp[iLocCnt].IndexOf("Industry") >= 0 && iFoundSkill == 0)
                                            {
                                                iFoundSkill = iLocCnt;
                                            }
                                            if (stSp[iLocCnt].IndexOf("Year of Passing") >= 0)
                                            {
                                                iYearofParsing = iLocCnt;
                                            }
                                            if (stSp[iLocCnt].ToLower().IndexOf("mobile:") >= 0)
                                            {
                                                tMobile = stSp[iLocCnt].Split(':')[stSp[iLocCnt].Split(':').GetUpperBound(0)];
                                                iMobFound = iLocCnt;
                                            }
                                            if ((stSp[iLocCnt].IndexOf("Annual Salary") >= 0 || stSp[iLocCnt].IndexOf("Designation:") >= 0) && iEndDesignation == 0)
                                                iEndDesignation = iLocCnt;
                                            if (stSp[iLocCnt].ToLower().IndexOf("telephone:") >= 0)
                                            {
                                                tPhone = stSp[iLocCnt].Split(':')[stSp[iLocCnt].Split(':').GetUpperBound(0)];
                                                if (iMobFound == 0) iMobFound = iLocCnt;
                                            }
                                            if (stSp[iLocCnt].ToLower().IndexOf("resume id:") >= 0)
                                            {
                                                tREsumeID = stSp[iLocCnt].Split(':')[stSp[iLocCnt].Split(':').GetUpperBound(0)];

                                            }
                                            if (stSp[iLocCnt].ToLower().IndexOf("current:") >= 0)
                                            {
                                                tLocation = stSp[iLocCnt].Split(':')[stSp[iLocCnt].Split(':').GetUpperBound(0)];
                                                if (iMobFound == 0) iMobFound = iLocCnt;
                                                if (tLocation == "" && stSp[iLocCnt + 1].IndexOf("Nationality:") < 0)
                                                    tLocation = stSp[iLocCnt + 1].Split(':')[stSp[iLocCnt + 1].Split(':').GetUpperBound(0)];
                                            }
                                            if (stSp[iLocCnt].ToLower().IndexOf("preferred location:") >= 0 || stSp[iLocCnt].ToLower().IndexOf("preferred:") >= 0)
                                            {
                                                preferredLocation = stSp[iLocCnt].Split(':')[stSp[iLocCnt].Split(':').GetUpperBound(0)].Trim();

                                            }

                                            if (stSp[iLocCnt].ToLower().IndexOf("designation:") >= 0)
                                            {
                                                tDesignation = stSp[iLocCnt].Split(':')[stSp[iLocCnt].Split(':').GetUpperBound(0)].Trim();

                                            }

                                            //if (stSp[iLocCnt].ToLower().IndexOf("last active:") >= 0)
                                            //    if (stSp[iLocCnt + 1].IndexOf("Resume ID") >= 0)
                                            //    {
                                            //        if (stSp[iLocCnt + 2].IndexOf("Exp") < 0 && stSp[iLocCnt + 2].ToLower().IndexOf("annual salary") < 0 && stSp[iLocCnt + 2].IndexOf("year") < 0)
                                            //            tCurrentEmploye = stSp[iLocCnt + 2].Split(':')[stSp[iLocCnt + 2].Split(':').GetUpperBound(0)];
                                            //    }
                                            //    else
                                            //        tCurrentEmploye = stSp[iLocCnt + 1].Split(':')[stSp[iLocCnt + 1].Split(':').GetUpperBound(0)];
                                        }
                                        if (iMobFound > 0 && iEndDesignation == 0)
                                            iEndDesignation = iMobFound - 1;
                                        if (iYearofParsing > 0 && iEndDesignation > 0)
                                        {
                                            for (int iLocCnt = iYearofParsing + 1; iLocCnt < iEndDesignation && tCurrentEmploye == ""; iLocCnt++)
                                            {
                                                tCurrentEmploye = stSp[iLocCnt];
                                                break;
                                            }
                                        }
                                        string tSkill = "";
                                        if (iFoundSkill > 0)
                                        {
                                            for (int iLocCnt = 0; iLocCnt < iFoundSkill; iLocCnt++)
                                            {
                                                tSkill += stSp[iLocCnt];
                                            }
                                        }

                                        if (iMobFound == 0)
                                            stMain1[0] = stSp[stSp.GetUpperBound(0) - 1];
                                        else
                                            stMain1[0] = stSp[iMobFound - 1];
                                        if (stMain1[0].IndexOf("(") >= 0)
                                        {
                                            string[] a = stMain1[0].Split('(');
                                            stMain1[0] = a[0];
                                        }
                                        stMain1[1] = tPhone;
                                        stMain1[2] = tMobile;
                                        stMain1[3] = tLocation;// (stSp[stSp.GetUpperBound(0)].Trim() == "Viewed" ? stSp[stSp.GetUpperBound(0) - 1] : stSp[stSp.GetUpperBound(0)]);
                                        if (stMain1[3] == stMain1[0])
                                            stMain1[0] = "";

                                        stMain1[4] = tCurrentEmploye.Replace("Not employed currently", "").Replace("NA\t", "").Replace("None\t", "").Replace("nil\t", "").Replace("Nil\t", "").Replace("NOT EMPLOYED CURRENTLY", "").Replace(" no", "").Replace(" No", "").Trim();
                                        stMain1[5] = tSkill;//skill
                                        stMain1[6] = (iYearofParsing > 0 ? stSp[iYearofParsing - 1] : stSp[2]);//education
                                        stMain1[7] = tCTC;
                                        stMain1[8] = tExp;
                                        stMain1[9] = preferredLocation;
                                        stMain1[10] = tREsumeID.Trim();
                                        stMain1[11] = tDesignation.Trim();
                                        opCreateMonsterNewVersion(stMain1, IDs); 

                                    }
                                    catch { }

                                }
                                tspgrs.PerformStep();
                                //tspgrs.Refresh();
                                i++;
                            }

                            tspgrs.Value = 0;
                            i++;
                            dt.ReadXml(new System.IO.StringReader(objXnm.OuterXml));
                            try
                            {
                                //grdCandidate.BeginUpdate();
                                dtGridData.Merge(dt.Tables[0], true);
                                tsDownload.Enabled = true;
                            }
                            catch { }
                            finally
                            {
                                //grdCandidate.EndUpdate();
                                grdCandidate.Refresh();
                                //sel.SelectAll();
                                //grdCandidate_DataSourceChanged(null, null);
                            }
                            Application.DoEvents();
                        }
                        catch
                        { }
                    }
                    #endregion

                    #region "SEA Portal"

                    if (bFlagNaukri == 10)// if (opValidJobSiteMonsterMalaysia(br1.Url.ToString()))
                    {
                        //  bFlagNaukri = 9;

                        objXnm = new System.Xml.XmlDocument();
                        objEl = objXnm.CreateElement("ROOT");
                        objXnm.AppendChild(objEl);
                        objRoot = objXnm.DocumentElement;

                        string[] st = { "<input type=\"checkbox\" name=\"resID\"" };
                        string[] st1 = { "<!--loop ends-->" };
                        string[] st2 = { "&nbsp;" };
                        string[] st3 = { "resumedatabase/resume.html?" };
                        string[] st4 = { ";words=" };
                        bool bNewVersion = false;
                        try
                        {
                            int i = 0;
                            string[] str = (((System.Windows.Forms.WebBrowser)(cntTab.SelectedTab.Controls[0]))).DocumentText.ToString().Split(st, StringSplitOptions.RemoveEmptyEntries);
                            if (str.Length == 1)
                            {
                                i = -1; bNewVersion = true;
                                string[] tSpNewVM = { "<table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"3\">", "<TABLE cellSpacing=0 cellPadding=3 width=\"100%\" border=0>" };
                                str = (((System.Windows.Forms.WebBrowser)(cntTab.SelectedTab.Controls[0]))).Document.Body.InnerHtml.ToString().Split(tSpNewVM, StringSplitOptions.RemoveEmptyEntries);
                            }
                            int j = str.GetUpperBound(0);
                            foreach (string stre in str)
                            {
                                if (i > 0 && i <= j)
                                {
                                    try
                                    {
                                        string IDs = stre.Split(st3, StringSplitOptions.RemoveEmptyEntries)[1].Split(st4, StringSplitOptions.RemoveEmptyEntries)[0];
                                        string stText = "";
                                        if (bNewVersion == false)
                                        {
                                            stText = RemoveHTMLTimeSheet("<input type=\"checkbox\" name=\"resID\" " + stre).Trim();
                                            string[] stSp = stText.Split(st2, StringSplitOptions.RemoveEmptyEntries);
                                            opCreateNodes(stSp, IDs);
                                        }
                                        else
                                        {
                                            stText = RemoveHTMLNew("<TABLE cellSpacing=0 cellPadding=3 width=\"100%\" border=0>" + stre).Trim();
                                            string[] aNst2 = { "&nbsp;", "\r\n", "Similar Resumes", "Viewed " };
                                            string[] aEnd = { " Send Email" };
                                            string[] stSp = stText.Split(aEnd, StringSplitOptions.RemoveEmptyEntries)[0].Trim().Split(aNst2, StringSplitOptions.RemoveEmptyEntries);//
                                            int iMobFound = 0;
                                            string[] stMain1 = new string[10];
                                            string tCurrentEmploye = "", tExp = "", tCTC = "", tPhone = "", tMobile = "";
                                            for (int iLocCnt = 0; iLocCnt <= stSp.GetUpperBound(0); iLocCnt++)
                                            {
                                                if (stSp[iLocCnt].ToLower().IndexOf("annual salary:") >= 0)
                                                    tCTC = stSp[iLocCnt].Split(':')[stSp[iLocCnt].Split(':').GetUpperBound(0)].Replace("Rs.", "").Replace("annually", "").Replace(",", "").Trim();
                                                if (stSp[iLocCnt].ToLower().IndexOf("exp:") >= 0)
                                                    tExp = stSp[iLocCnt].Split(':')[stSp[iLocCnt].Split(':').GetUpperBound(0)];
                                                if (stSp[iLocCnt].ToLower().IndexOf("mobile:") >= 0)
                                                {
                                                    tMobile = stSp[iLocCnt].Split(':')[stSp[iLocCnt].Split(':').GetUpperBound(0)];
                                                    iMobFound = iLocCnt;
                                                }
                                                if (stSp[iLocCnt].ToLower().IndexOf("telephone:") >= 0)
                                                {
                                                    tPhone = stSp[iLocCnt].Split(':')[stSp[iLocCnt].Split(':').GetUpperBound(0)];
                                                    if (iMobFound == 0) iMobFound = iLocCnt;
                                                }
                                                if (stSp[iLocCnt].ToLower().IndexOf("last active:") >= 0)
                                                    if (stSp[iLocCnt + 1].IndexOf("Resume ID") >= 0)
                                                    {
                                                        if (stSp[iLocCnt + 2].IndexOf("Exp") < 0 && stSp[iLocCnt + 2].ToLower().IndexOf("annual salary") < 0 && stSp[iLocCnt + 2].IndexOf("year") < 0)
                                                            tCurrentEmploye = stSp[iLocCnt + 2].Split(':')[stSp[iLocCnt + 2].Split(':').GetUpperBound(0)];
                                                    }
                                                    else
                                                        tCurrentEmploye = stSp[iLocCnt + 1].Split(':')[stSp[iLocCnt + 1].Split(':').GetUpperBound(0)];
                                            }
                                            if (iMobFound == 0)
                                                stMain1[0] = (stSp[stSp.GetUpperBound(0) - 2].IndexOf("Exp") == 0 ? "" : stSp[stSp.GetUpperBound(0) - 2]);
                                            else
                                                stMain1[0] = stSp[iMobFound - 1];
                                            stMain1[1] = tPhone;
                                            stMain1[2] = tMobile;
                                            stMain1[3] = (stSp[stSp.GetUpperBound(0)] == "New" ? stSp[stSp.GetUpperBound(0) - 1] : stSp[stSp.GetUpperBound(0)]);
                                            stMain1[4] = tCurrentEmploye.Replace("Not employed currently", "").Replace("NA\t", "").Replace("None\t", "").Replace("nil\t", "").Replace("Nil\t", "").Replace("NOT EMPLOYED CURRENTLY", "").Replace(" no", "").Replace(" No", "").Trim();
                                            stMain1[5] = stSp[1];
                                            stMain1[6] = stSp[2];
                                            stMain1[7] = tCTC;
                                            stMain1[8] = tExp;
                                            opCreateMonsterNewVersionMy(stMain1, IDs); 
                                        }
                                    }
                                    catch { }

                                }
                                i++;
                            }

                            i++;
                            dt.ReadXml(new System.IO.StringReader(objXnm.OuterXml));
                            try
                            {
                                //grdCandidate.BeginUpdate();
                                dtGridData.Merge(dt.Tables[0], true);
                                tsDownload.Enabled = true;
                            }
                            catch { }
                            finally
                            {
                                //grdCandidate.EndUpdate();
                                grdCandidate.Refresh();
                                //sel.SelectAll();
                                //grdCandidate_DataSourceChanged(null, null);
                            }
                            Application.DoEvents();

                        }
                        catch
                        { }
                    }
                    #endregion

                    #region "Monster NOrth America "

                    if (bFlagNaukri == 11)
                    {
                        objXnm = new System.Xml.XmlDocument();
                        objEl = objXnm.CreateElement("ROOT");
                        objXnm.AppendChild(objEl);
                        objRoot = objXnm.DocumentElement;
                        HtmlAgilityPack.HtmlDocument objHTML = null;
                        objHTML = new HtmlAgilityPack.HtmlDocument();
                        objHTML.LoadHtml((((System.Windows.Forms.WebBrowser)(cntTab.SelectedTab.Controls[0]))).Document.Body.OuterHtml);

                        string[] stArrMiddle = { "[{", "}]," };
                        string[] tArrsplitCol = { "," };
                        string[] tArrsplit = { "}" };
                        string tCurrentPage = "1";
                        string tPageCount = "20", tSortOrderTitle = "0", tSortOrder = "0", tSTitle = "", tSOTitle = "";
                        try
                        {
                            tCurrentPage = objHTML.DocumentNode.SelectSingleNode("//*[contains(@id,'ctl00_ctl00_ContentPlaceHolderBase_ContentPlaceHolderRight_CndTop_pagingHeader_currPage')]").GetAttributeValue("value", "");


                            tSTitle = objHTML.DocumentNode.SelectSingleNode("//*[contains(@id,'ctl00_ctl00_ContentPlaceHolderBase_ContentPlaceHolderRight_ctl00_ctl04')]").GetAttributeValue("value", "");
                            tSTitle = objHTML.DocumentNode.SelectSingleNode("//*[contains(@id,'ctl00_ctl00_ContentPlaceHolderBase_ContentPlaceHolderRight_ctl00_ctl04')]").GetAttributeValue("value", "");

                            tSOTitle = objHTML.DocumentNode.SelectSingleNode("//*[contains(@id,'ctl00_ctl00_ContentPlaceHolderBase_ContentPlaceHolderRight_ctl00_ctl05')]").GetAttributeValue("value", "");
                            tPageCount = objHTML.DocumentNode.SelectSingleNode("//*[contains(@id,'ctl00_ctl00_ContentPlaceHolderBase_ContentPlaceHolderRight_CndTop_lblRecordPortion')]").InnerText;

                            if (tPageCount != "")
                            {
                                tPageCount = tPageCount.Replace("(", "").Replace(")", "").Replace("of", "").Replace("-", " ").Replace("Candidates", "").Trim();
                                string[] tPArr = tPageCount.Split(' ');
                                tPageCount = Convert.ToString(Convert.ToInt32(tPArr[1]) - Convert.ToInt32(tPArr[0]) + 1);
                            }
                            else { tPageCount = "20"; }
                        }
                        catch { }
                        if (tSTitle == "Resume Title")
                            tSortOrderTitle = "1";
                        else if (tSTitle == "Resume Updated")
                            tSortOrderTitle = "2";
                        else if (tSTitle == "Location")
                            tSortOrderTitle = "5";
                        else if (tSTitle == "Relevance")
                            tSortOrderTitle = "4";
                        if (tSOTitle == "Descending")
                            tSortOrder = "2";
                        else
                            tSortOrder = "1";


                        string tFetchCandidateInfoUrl = "http://hiring.monster.com/jcm/SharedUI/Services/Secure/jcmiiwebservices/resumesearch.asmx/GetResumes?rsfltv=null&gtv={\"__type\":\"Presenters.Base.Views.GridTypeView\"}&pv={\"__type\":\"Presenters.Base.Views.PagingView\",\"PageIndex\":[PageIndex],\"PageSize\":\"[PageSize]\"}&rssvd={\"__type\":\"Presenters.JCMII.Views.ResumeSearchSorterView\",\"ResumeSearchSortColumn\":\"[ResumeSearchSortColumn]\",\"SortOrder\":\"[SortOrder]\"}";
                        tFetchCandidateInfoUrl = tFetchCandidateInfoUrl.Replace("[PageSize]", tPageCount);
                        tFetchCandidateInfoUrl = tFetchCandidateInfoUrl.Replace("[PageIndex]", tCurrentPage);
                        tFetchCandidateInfoUrl = tFetchCandidateInfoUrl.Replace("[ResumeSearchSortColumn]", tSortOrderTitle);
                        tFetchCandidateInfoUrl = tFetchCandidateInfoUrl.Replace("[SortOrder]", tSortOrder);


                        object objNull = null;
                        //MSXML2.XMLHTTPClass xmlHttpMain = new MSXML2.XMLHTTPClass();
                        //xmlHttpMain.open("GET", tFetchCandidateInfoUrl, false, null, null);
                        //xmlHttpMain.setRequestHeader("Content-Type", "application/json; charset=utf-8");
                        ////xmlHttpMain.setRequestHeader("Cookie", tCookies);
                        //xmlHttpMain.send(objNull);
                        //string tContactData = xmlHttpMain.responseText;
                        //xmlHttpMain = null;

                        System.Net.WebClient sbC = new System.Net.WebClient(); 
                        sbC.Headers.Set("Content-Type", "application/json; charset=utf-8");
                        string tContactData = sbC.DownloadString(tFetchCandidateInfoUrl);
                        sbC = null;

                        try
                        {
                            string[] str1 = tContactData.Split(stArrMiddle, StringSplitOptions.RemoveEmptyEntries);
                            string tArrayData = str1[1];
                            string[] tSplitData = tArrayData.Split(tArrsplit, StringSplitOptions.RemoveEmptyEntries);
                            foreach (string tA in tSplitData)
                            {
                                string[] stMain1 = new string[10];
                                string[] tSplitInnerData = tA.Replace(@"""", "").Trim().Split(tArrsplitCol, StringSplitOptions.RemoveEmptyEntries);
                                string IDs = "";
                                string tCurrentEmploye = "", tExp = "", tLocation = "", tCTC = "", tPhone = "", tMobile = "", tDesignation = "", tEducation = "", tSkiill = "", tName = "";
                                for (int iLocCnt = 0; iLocCnt <= tSplitInnerData.GetUpperBound(0); iLocCnt++)
                                {
                                    if (tSplitInnerData[iLocCnt].ToLower().IndexOf("desiredsalary") >= 0)
                                        tCTC = tSplitInnerData[iLocCnt].Split(':')[tSplitInnerData[iLocCnt].Split(':').GetUpperBound(0)].Split('-')[0]; ;
                                    if (tSplitInnerData[iLocCnt].ToLower().IndexOf("resumevalue") >= 0)
                                        IDs = tSplitInnerData[iLocCnt].Split(':')[tSplitInnerData[iLocCnt].Split(':').GetUpperBound(0)]; ;
                                    if (tSplitInnerData[iLocCnt].ToLower().IndexOf("recentcompanyname") >= 0)
                                        tCurrentEmploye = tSplitInnerData[iLocCnt].Split(':')[tSplitInnerData[iLocCnt].Split(':').GetUpperBound(0)]; ;
                                    if (tSplitInnerData[iLocCnt].ToLower().IndexOf("recentjobtitle") >= 0)
                                        tDesignation = tSplitInnerData[iLocCnt].Split(':')[tSplitInnerData[iLocCnt].Split(':').GetUpperBound(0)]; ;
                                    if (tSplitInnerData[iLocCnt].ToLower().IndexOf("highesteducationdegree") >= 0)
                                        tEducation = tSplitInnerData[iLocCnt].Split(':')[tSplitInnerData[iLocCnt].Split(':').GetUpperBound(0)]; ;
                                    if (tSplitInnerData[iLocCnt].ToLower().IndexOf("location") >= 0)
                                        tLocation = tSplitInnerData[iLocCnt].Split(':')[tSplitInnerData[iLocCnt].Split(':').GetUpperBound(0)]; ;
                                    if (tSplitInnerData[iLocCnt].ToLower().IndexOf("candidatename") >= 0)
                                        tName = tSplitInnerData[iLocCnt].Split(':')[tSplitInnerData[iLocCnt].Split(':').GetUpperBound(0)]; ;

                                }
                                stMain1[0] = tName.Replace("&nbsp;", " ");
                                stMain1[1] = tPhone.Trim();
                                stMain1[2] = tMobile.Trim();
                                stMain1[3] = tLocation;
                                stMain1[4] = tCurrentEmploye.Trim().Replace("Not employed currently", "").Replace("NA\t", "").Replace("None\t", "").Replace("nil\t", "").Replace("Nil\t", "").Replace("NOT EMPLOYED CURRENTLY", "").Replace(" no", "").Replace(" No", "").Trim();
                                stMain1[5] = tDesignation;
                                stMain1[6] = tEducation.Trim();
                                stMain1[7] = tCTC.Trim();
                                stMain1[8] = tExp.Trim();
                                stMain1[9] = tSkiill.Trim();
                                opCreateMonsterNewVersionINT(stMain1, IDs);
                            }
                            dt.ReadXml(new System.IO.StringReader(objXnm.OuterXml));
                            try
                            {
                                //grdCandidate.BeginUpdate();
                                dtGridData.Merge(dt.Tables[0], true);
                                tsDownload.Enabled = true;
                            }
                            catch { }
                            finally
                            {
                                //grdCandidate.EndUpdate();
                                grdCandidate.Refresh();
                                //sel.SelectAll();
                                //grdCandidate_DataSourceChanged(null, null);
                            }
                            Application.DoEvents();
                        }
                        catch
                        { }
                    }
                    #endregion

                    #region "CATS Applicant Tracking System"

                    if (bFlagNaukri == 12)
                    {
                        try
                        {
                            string tDocument = (((System.Windows.Forms.WebBrowser)(cntTab.SelectedTab.Controls[0]))).DocumentText;

                            objXnm = new System.Xml.XmlDocument();
                            objEl = objXnm.CreateElement("ROOT");
                            objXnm.AppendChild(objEl);
                            objRoot = objXnm.DocumentElement;


                            bool bAllData = false;
                            int i = 0;
                            string[] st = { "<td valign=\"top\" nowrap=\"nowrap\">", "<tr class=\"evenTableRow\">", "<tr class=\"oddTableRow\">" };
                            string[] st12 = { "&nbsp;" };
                            string[] st123 = { "\r\n", "\n" };

                            string[] s23t = { "<a href=\"index.php?m=candidates&amp;a=show&amp;candidateID=", "<a href=\"index.php?m=candidates&a=show&candidateID=" };
                            string[] s21t = { ">", "class=\"jobLinkCold\">" };
                            string[] s23t1 = { "<BR>", "<br>" };
                            string[] spID = { "adId=" };
                            string[] str = tDocument.ToString().Split(st, StringSplitOptions.RemoveEmptyEntries);
                            if (tDocument.IndexOf("dataGrid.js") >= 0)
                                bAllData = true;
                            string[] stMain = null;
                            int j = str.GetUpperBound(0);
                            string[] stMain1 = new string[9];
                            foreach (string stre in str)
                            {
                                if (i >= 1 && i <= j)
                                {
                                    if (stre.IndexOf("<input type=\"checkbox\"") < 0)
                                    {
                                        i++;
                                        continue;
                                    }
                                    string[] idss = stre.Split(s23t, StringSplitOptions.RemoveEmptyEntries)[1].Split(s21t, StringSplitOptions.RemoveEmptyEntries);
                                    string t = "http://ats.mcbarronwood.com/index.php?m=candidates&amp;a=show&amp;candidateID=" + idss[0].Replace("\"", "").Trim();
                                    stMain = RemoveHTMLTimeSheet(stre).ToString().Trim().Split(st123, StringSplitOptions.RemoveEmptyEntries);
                                    stMain1[1] = stMain[0].Trim() + " " + stMain[1].Trim();
                                    if (bAllData)
                                    {
                                        if (stMain.Length > 8)
                                            stMain1[2] = stMain[8];
                                        else
                                            stMain1[2] = "";
                                        stMain1[3] = stMain[2];
                                        stMain1[4] = "";
                                        stMain1[5] = "";
                                        if (stMain.Length > 7)
                                            stMain1[6] = stMain[7].Replace("+", "");
                                        else if (stMain.Length > 6)
                                            stMain1[6] = stMain[6];
                                        else
                                            stMain1[6] = "";
                                        stMain1[7] = "";
                                        if (stMain.Length > 9)
                                            stMain1[8] = stMain[9];
                                        else
                                            stMain1[8] = "";
                                    }
                                    else
                                    {
                                        stMain1[2] = "";
                                        if (stMain.Length > 8)
                                            stMain1[3] = stMain[8];
                                        else
                                            stMain1[3] = "";
                                        stMain1[4] = "";
                                        stMain1[5] = "";
                                        stMain1[6] = "";
                                        stMain1[7] = "";
                                        stMain1[8] = "";
                                    }
                                    opCreateNodesCATS(stMain1, t);
                                }

                                i++;
                            }

                            i++;
                            dt.ReadXml(new System.IO.StringReader(objXnm.OuterXml));
                            try
                            {
                                //grdCandidate.BeginUpdate();
                                dtGridData.Merge(dt.Tables[0], true);
                                tsDownload.Enabled = true;
                            }
                            catch { }
                            finally
                            {
                                //grdCandidate.EndUpdate();
                                grdCandidate.Refresh();
                                //sel.SelectAll();
                                //grdCandidate_DataSourceChanged(null, null);
                            }
                            Application.DoEvents();
                        }
                        catch { }
                    }

                    #endregion

                    #region "www.oilcareers.com"
                    if (bFlagNaukri == 13)
                    {
                        try
                        {
                            objXnm = new System.Xml.XmlDocument();
                            objEl = objXnm.CreateElement("ROOT");
                            objXnm.AppendChild(objEl);
                            objRoot = objXnm.DocumentElement;
                            string[] st123 = { "\r\n", "&nbsp;", "\t" };
                            string[] s23t = { "&JobTerms=" };
                            int i = 0;
                            string[] st = { "  href=\"cv_detail.asp?id=" };
                            string[] str = (((System.Windows.Forms.WebBrowser)(cntTab.SelectedTab.Controls[0]))).DocumentText.ToString().Split(st, StringSplitOptions.RemoveEmptyEntries);
                            string[] stSp = null;
                            int j = str.GetUpperBound(0);
                            string[] stMain1 = new string[14];
                            foreach (string stre in str)
                            {
                                if (i >= 1 && i <= j)
                                {
                                    string ids = stre.Split(s23t, StringSplitOptions.RemoveEmptyEntries)[0].ToString();
                                    stSp = RemoveHTML("<a href=\"cv_detail.asp?id= " + stre.Replace("<br>", "\r\n").Replace("<tr>", "<tr>\r\n").Replace("<td align=\"center\">", "\r\n").Replace("</td><td width=\"60%\" align=\"center\" bgcolor=\"#ffffff\">", "\r\n").Replace("<br />", "\r\n")).ToString().Trim().Split(st123, StringSplitOptions.RemoveEmptyEntries);


                                    int iFoundSkill = 0, iFoundSkillEnd = 0;
                                    string tExp = "", tCTC = "", tREsumeID = "", education = "", tLocation = "", tDesignation = "";
                                    for (int iLocCnt = 0; iLocCnt <= stSp.GetUpperBound(0); iLocCnt++)
                                    {
                                        if (stSp[iLocCnt].IndexOf("Minimum Remuneration:") >= 0)
                                            tCTC = stSp[iLocCnt].Split(':')[stSp[iLocCnt].Split(':').GetUpperBound(0)].Replace("Rs.", "").Replace("Minimum Remuneration", "").Replace(",", "").Trim();
                                        if (stSp[iLocCnt].IndexOf("Total Industry Experience (years):") >= 0)
                                        {
                                            tExp = stSp[iLocCnt].Split(':')[stSp[iLocCnt].Split(':').GetUpperBound(0)];
                                        }
                                        if (stSp[iLocCnt].IndexOf("Skills:") >= 0)
                                        {
                                            iFoundSkill = iLocCnt;
                                        }
                                        if (stSp[iLocCnt].IndexOf("Highest Qualification:") >= 0)
                                        {
                                            iFoundSkillEnd = iLocCnt;
                                        }
                                        if (stSp[iLocCnt].Trim().StartsWith("CV"))
                                        {
                                            tREsumeID = stSp[iLocCnt];

                                        }
                                        if (stSp[iLocCnt].IndexOf("Location:") >= 0)
                                        {
                                            tLocation = stSp[iLocCnt].Split(':')[stSp[iLocCnt].Split(':').GetUpperBound(0)];
                                        }

                                        if (stSp[iLocCnt].IndexOf("Current Position:") >= 0)
                                        {
                                            tDesignation = stSp[iLocCnt].Split(':')[stSp[iLocCnt].Split(':').GetUpperBound(0)].Trim();

                                        }
                                        if (stSp[iLocCnt].IndexOf("Highest Qualification:") >= 0)
                                        {
                                            education = stSp[iLocCnt].Split(':')[stSp[iLocCnt].Split(':').GetUpperBound(0)].Trim();

                                        }
                                    }
                                    string tSkill = "";
                                    if (iFoundSkillEnd > 0)
                                    {
                                        for (int iLocCnt = iFoundSkill; iLocCnt < iFoundSkillEnd; iLocCnt++)
                                        {
                                            tSkill += stSp[iLocCnt];
                                        }
                                    }

                                    stMain1[1] = stSp[0].Trim();
                                    stMain1[3] = tLocation;
                                    stMain1[2] = "";
                                    stMain1[4] = "";//tPresentEmp;
                                    stMain1[5] = tDesignation;// tDesignation;// stMain[6].Split(sEmpt, StringSplitOptions.RemoveEmptyEntries)[stMain[7].Split(sEmpt, StringSplitOptions.RemoveEmptyEntries).GetLowerBound(0)];
                                    stMain1[7] = tSkill;
                                    stMain1[8] = education;
                                    stMain1[9] = tCTC;
                                    stMain1[6] = tExp;
                                    stMain1[10] = "";
                                    stMain1[11] = "";
                                    stMain1[12] = "";
                                    stMain1[13] = tREsumeID;
                                    opCreateNodesNaukri(stMain1, ids);
                                }
                                i++;
                            }

                            i++;
                            dt.ReadXml(new System.IO.StringReader(objXnm.OuterXml));
                            try
                            {
                                //grdCandidate.BeginUpdate();
                                dtGridData.Merge(dt.Tables[0], true);
                                tsDownload.Enabled = true;
                            }
                            catch { }
                            finally
                            {
                                //grdCandidate.EndUpdate();
                                grdCandidate.Refresh();
                                //sel.SelectAll();
                                //grdCandidate_DataSourceChanged(null, null);
                            }
                            Application.DoEvents();
                        }
                        catch
                        {
                        }
                    }
                    #endregion

                    #region "www.recruitgulf.com"
                    if (bFlagNaukri == 14)
                    {
                        try
                        {
                            objXnm = new System.Xml.XmlDocument();
                            objEl = objXnm.CreateElement("ROOT");
                            objXnm.AppendChild(objEl);
                            objRoot = objXnm.DocumentElement;
                            string[] st123 = { "\r\n", "&nbsp;", "\t" };
                            string[] s23t = { "&terms=\">" };
                            string[] s24t = { "add notes" };
                            int i = 0;
                            string[] st = { "<td width=\"50%\" colspan=\"2\" rowspan=\"9\" class=\"cvresults\" style=\"border-top: 1px dotted #ccc;" };

                            string[] str = (((System.Windows.Forms.WebBrowser)(cntTab.SelectedTab.Controls[0]))).DocumentText.ToString().Split(st, StringSplitOptions.RemoveEmptyEntries);
                            string[] stMain = null;
                            int j = str.GetUpperBound(0);
                            string[] stMain1 = new string[10];
                            int iViewCnt = 0;
                            foreach (string stre in str)
                            {
                                if (i >= 1 && i <= j)
                                {
                                    HtmlElement objELe = null;
                                    if (iViewCnt < 10)
                                        objELe = (((System.Windows.Forms.WebBrowser)(cntTab.SelectedTab.Controls[0]))).Document.GetElementById("ctl00_cphMain_ucCVList_dlResult_ctl0" + iViewCnt.ToString() + "_hlViewCV");
                                    else
                                        objELe = (((System.Windows.Forms.WebBrowser)(cntTab.SelectedTab.Controls[0]))).Document.GetElementById("ctl00_cphMain_ucCVList_dlResult_ctl" + iViewCnt.ToString() + "_hlViewCV");
                                    string ids = "";
                                    if (objELe != null)
                                    {
                                        ids = objELe.GetAttribute("href");
                                    }
                                    else
                                        ids = "";

                                    string tData = RemoveHTML("<td width=\"50%\" colspan=\"2\" rowspan=\"9\" class=\"cvresults\" style=\"border-top: 1px dotted #ccc;  " + stre.Replace("<br>", "\r\n").Replace("<br />", "\r\n")).ToString().Trim().Split(s24t, StringSplitOptions.RemoveEmptyEntries)[0];

                                    stMain = tData.Split(st123, StringSplitOptions.RemoveEmptyEntries);



                                    stMain1[0] = "";
                                    stMain1[1] = "";
                                    stMain1[2] = "";
                                    stMain1[3] = "";
                                    stMain1[4] = "";
                                    stMain1[5] = "";
                                    stMain1[6] = "";
                                    stMain1[7] = "";
                                    stMain1[8] = "";
                                    stMain1[9] = "";
                                    for (int arcnt = 0; arcnt < stMain.Length; arcnt++)
                                    {
                                        if (string.Compare(stMain[arcnt], "Education Level", true) == 0)
                                            stMain1[8] = stMain[arcnt + 2].Replace("Not Available", "").Replace("Not Available", "").Replace("not available", "");
                                        if (string.Compare(stMain[arcnt], "Current Role", true) == 0)
                                            stMain1[5] = stMain[arcnt + 2].Replace("Not Available", "").Replace("not available", ""); ;
                                        if (string.Compare(stMain[arcnt], "Salary", true) == 0)
                                        {
                                            stMain1[9] = stMain[arcnt + 2].Replace("Not Available", "").Replace("not available", "").Replace("Negotiable", "");
                                            if (stMain1[9].Contains("-"))
                                            {
                                                stMain1[9] = stMain1[9].Split('-')[1];
                                            }
                                        }
                                        if (string.Compare(stMain[arcnt], "Current Location", true) == 0)
                                            stMain1[3] = stMain[arcnt + 2].Replace("Not Available", "").Replace("not available", ""); ;

                                    }
                                    opCreateNodesRecruitGulf(stMain1, ids);
                                    iViewCnt++;
                                }

                                i++;
                            }

                            i++;
                            dt.ReadXml(new System.IO.StringReader(objXnm.OuterXml));
                            try
                            {
                                //grdCandidate.BeginUpdate();
                                dtGridData.Merge(dt.Tables[0], true);
                                tsDownload.Enabled = true;
                            }
                            catch { }
                            finally
                            {
                                //grdCandidate.EndUpdate();
                                grdCandidate.Refresh();
                                //sel.SelectAll();
                                //grdCandidate_DataSourceChanged(null, null);
                            }
                            Application.DoEvents();
                        }
                        catch
                        {
                        }
                    }
                    #endregion

                    #region "oilandgasjobsearch"
                    if (bFlagNaukri == 15)
                    {
                        try
                        {
                            objXnm = new System.Xml.XmlDocument();
                            objEl = objXnm.CreateElement("ROOT");
                            objXnm.AppendChild(objEl);
                            objRoot = objXnm.DocumentElement;
                            HtmlAgilityPack.HtmlDocument objHTML1 = null;
                            objHTML1 = new HtmlAgilityPack.HtmlDocument();
                            objHTML1.LoadHtml((((System.Windows.Forms.WebBrowser)(cntTab.SelectedTab.Controls[0]))).DocumentText.ToString());


                            HtmlAgilityPack.HtmlNodeCollection nd_Mobile = objHTML1.DocumentNode.SelectNodes("//tr[@class='candidate']");
                            try
                            {
                                for (int i = 0; i <= nd_Mobile.Count - 1; i++)
                                {
                                    if (nd_Mobile == null) continue;
                                    HtmlAgilityPack.HtmlNode CandInfo = nd_Mobile[i];
                                    string ID = CandInfo.SelectNodes("//a[@class='candidate-details']")[i].GetAttributeValue("href", "");

                                    if (ID != "")
                                    {
                                        string[] stMain1 = new string[10];
                                        stMain1[0] = "";
                                        stMain1[1] = CandInfo.SelectNodes("//a[@class='popup-iframe candidate-details']")[i].InnerText;
                                        stMain1[2] = "";
                                        stMain1[3] = "";
                                        stMain1[4] = "";
                                        stMain1[5] = "";
                                        stMain1[6] = "";
                                        stMain1[7] = "";
                                        stMain1[8] = "";
                                        stMain1[9] = "";
                                        opCreateNodesRecruitGulf(stMain1, ID);
                                    }
                                }
                            }
                            catch { }
                            dt.ReadXml(new System.IO.StringReader(objXnm.OuterXml));
                            try
                            {
                                //grdCandidate.BeginUpdate();
                                dtGridData.Merge(dt.Tables[0], true);
                                tsDownload.Enabled = true;
                            }
                            catch { }
                            finally
                            {
                                //grdCandidate.EndUpdate();
                                grdCandidate.Refresh();
                                //sel.SelectAll();
                                //grdCandidate_DataSourceChanged(null, null);
                            }
                            Application.DoEvents();
                        }
                        catch
                        {
                        }
                    }
                    #endregion

                    #region "corp-corp.com"
                    if (bFlagNaukri == 16)
                    {
                        try
                        {
                            objXnm = new System.Xml.XmlDocument();
                            objEl = objXnm.CreateElement("ROOT");
                            objXnm.AppendChild(objEl);
                            objRoot = objXnm.DocumentElement;


                            HtmlAgilityPack.HtmlDocument objHTML = null;
                            objHTML = new HtmlAgilityPack.HtmlDocument();
                            objHTML.LoadHtml((((System.Windows.Forms.WebBrowser)(cntTab.SelectedTab.Controls[0]))).Document.Body.OuterHtml);
                            HtmlAgilityPack.HtmlNode SelectedTab = objHTML.DocumentNode.SelectSingleNode("//*[@class='ui-state-default ui-corner-top ui-tabs-selected ui-state-active']/a");
                            Int32 iSelectedTab = 0;
                            if (SelectedTab != null)
                            {
                                string tURL1 = SelectedTab.GetAttributeValue("href", "");
                                Int32.TryParse((System.Text.RegularExpressions.Regex.Replace(tURL1, @"\D", "")), out iSelectedTab);
                            }
                            objHTML = null;
                            objHTML = new HtmlAgilityPack.HtmlDocument();
                            objHTML.LoadHtml((((System.Windows.Forms.WebBrowser)(cntTab.SelectedTab.Controls[0]))).Document.Window.Frames[iSelectedTab + 2].Document.Body.OuterHtml);

                            HtmlAgilityPack.HtmlNodeCollection nd_Mobile = objHTML.DocumentNode.SelectNodes(@"//*[contains(@id,'lblName')]/table/tbody/tr/td/b");


                            for (int i = 0; i <= nd_Mobile.Count - 1; i++)
                            {
                                HtmlAgilityPack.HtmlNode CandInfo = nd_Mobile[i];
                                string ID = "http://www.corp-corp.com/emp/" + CandInfo.SelectNodes("//*[contains(@id,'hlViewProfile1')]")[i].GetAttributeValue("href", "NO URL FOUND");
                                if (ID != "")
                                {
                                    objEl = objXnm.CreateElement("Main");
                                    objElSub = objXnm.CreateElement("Check");
                                    objElSub.InnerText = true.ToString();
                                    objEl.AppendChild(objElSub);
                                    objElSub = objXnm.CreateElement("ResumeID");
                                    objElSub.InnerText = "0";
                                    objEl.AppendChild(objElSub);
                                    objElSub = objXnm.CreateElement("SavedType");
                                    objElSub.InnerText = "0";
                                    objEl.AppendChild(objElSub);
                                    objElSub = objXnm.CreateElement("CandidateName");
                                    objElSub.InnerText = nd_Mobile[i].InnerText;//.SelectSingleNode("//*[contains(@id,'lblName')]").GetAttributeValue("Value", "");
                                    objEl.AppendChild(objElSub);
                                    objElSub = objXnm.CreateElement("IDs");
                                    objElSub.InnerText = ID;
                                    objEl.AppendChild(objElSub);
                                    objElSub = objXnm.CreateElement("Mobile");
                                    objElSub.InnerText = "";
                                    objEl.AppendChild(objElSub);
                                    objElSub = objXnm.CreateElement("CandidateLocation");
                                    objElSub.InnerText = CandInfo.SelectNodes("//*[contains(@id,'lblPlace')]")[i].InnerText;
                                    objEl.AppendChild(objElSub);
                                    objElSub = objXnm.CreateElement("PhoneH");
                                    objElSub.InnerText = "";
                                    objEl.AppendChild(objElSub);
                                    objElSub = objXnm.CreateElement("PresentCTC");
                                    try
                                    {
                                        objElSub.InnerText = CandInfo.SelectNodes("//*[contains(@id,'lblYearly')]/b")[i].InnerText.Replace("years", "").Trim();
                                        objElSub.InnerText = objElSub.InnerText.Replace("K", "");
                                    }
                                    catch
                                    {
                                        objElSub.InnerText = "";
                                    }
                                    objEl.AppendChild(objElSub);
                                    objElSub = objXnm.CreateElement("TotalExp");
                                    try
                                    {
                                        objElSub.InnerText = CandInfo.SelectNodes("//*[contains(@id,'lblTotExp')]/b")[i].InnerText.Replace("years", "").Trim();

                                    }
                                    catch
                                    {
                                        objElSub.InnerText = "";
                                    }
                                    objEl.AppendChild(objElSub);
                                    objElSub = objXnm.CreateElement("Skill");
                                    objElSub.InnerText = CandInfo.SelectNodes("//*[contains(@id,'lblSkills')]")[i].InnerText;
                                    objEl.AppendChild(objElSub);
                                    objElSub = objXnm.CreateElement("PresentEmployer");
                                    objElSub.InnerText = "";
                                    objEl.AppendChild(objElSub);
                                    string tDesignationTitle = "", tDesignationIDs = "";
                                    objElSub = objXnm.CreateElement("JobTitle");
                                    objElSub.InnerText = tDesignationTitle.Split(',')[tDesignationTitle.Split(',').GetLowerBound(0)];
                                    if (objElSub.InnerText.Trim() == "")
                                        objElSub.InnerText = "<--None-->";
                                    objEl.AppendChild(objElSub);

                                     

                                    objElSub = objXnm.CreateElement("Education");
                                    objElSub.InnerText = "";// ArrSub[8].ToString().Replace("\n", "").Replace("\t\t\t\t\t", ",").Replace("\t", "").Replace("&nbsp;", "").Trim();
                                    objEl.AppendChild(objElSub);
                                     





                                    objElSub = objXnm.CreateElement("URL");
                                    objElSub.InnerText = "";
                                    objEl.AppendChild(objElSub);
                                    objElSub = objXnm.CreateElement("PreviousDesignation");
                                    objElSub.InnerText = "";
                                    objEl.AppendChild(objElSub);
                                    objElSub = objXnm.CreateElement("PreviousEmployer");
                                    objElSub.InnerText = "";
                                    objEl.AppendChild(objElSub);
                                    objElSub = objXnm.CreateElement("PrefLocationText");
                                    objElSub.InnerText = "";
                                    objEl.AppendChild(objElSub);
                                     
                                    objElSub = objXnm.CreateElement("SiteResumeID");
                                    objElSub.InnerText = "";
                                    objEl.AppendChild(objElSub);
                                    objElSub = objXnm.CreateElement("AutoResumeID");
                                    objElSub.InnerText = "";
                                    objEl.AppendChild(objElSub);
                                    objElSub = objXnm.CreateElement("Indicator");
                                    objElSub.InnerText = "";
                                    objEl.AppendChild(objElSub);
                                    objRoot.AppendChild(objEl);
                                }
                            }
                            dt.ReadXml(new System.IO.StringReader(objXnm.OuterXml));
                            try
                            {
                                //grdCandidate.BeginUpdate();
                                dtGridData.Merge(dt.Tables[0], true);
                                tsDownload.Enabled = true;
                            }
                            catch { }
                            finally
                            {
                                //grdCandidate.EndUpdate();
                                grdCandidate.Refresh();
                                //sel.SelectAll();
                                //grdCandidate_DataSourceChanged(null, null);
                            }
                            Application.DoEvents();
                        }
                        catch
                        {
                        }
                    }
                    #endregion

                    #region "Monster Philippines"
                    if (bFlagNaukri == 17)// if (opValidJobSiteMonsterSingapore(br1.Url.ToString()) && bFlagNaukri!=1)
                    {
                        objXnm = new System.Xml.XmlDocument();
                        objEl = objXnm.CreateElement("ROOT");
                        objXnm.AppendChild(objEl);
                        objRoot = objXnm.DocumentElement;

                        string[] st = { "<input type=\"checkbox\" name=\"resID\"", " type=checkbox name=resID>" };
                        string[] st1 = { "<!--loop ends-->" };
                        string[] st2 = { "&nbsp;", "similar resumes", "Similar Resumes", "\r\n\r\n", "\r\n", "Viewed ", "New", "\n", "\t", "Contacted by Email" };//, "\r\n", "<BR>", "<br>", "<br />", "<br/>", "\n\t\n", "\n" 

                        string[] st3 = { "resumedatabase/resume.html?" };
                        string[] st4 = { ";\">", "\" target=_blank ;", ";\"", "\" target=_blank" };//" target=_blank ;
                        bool bNewVersion = false;
                        bool bNewNewVersion = false;
                        try
                        {
                            int i = 0;
                            string[] str1 = (((System.Windows.Forms.WebBrowser)(cntTab.SelectedTab.Controls[0]))).Document.Body.InnerHtml.ToString().Split(st, StringSplitOptions.RemoveEmptyEntries);
                            string[] str = null;// (((System.Windows.Forms.WebBrowser)(cntTab.SelectedTab.Controls[0]))).DocumentText.ToString().Split(st, StringSplitOptions.RemoveEmptyEntries);
                            if (str1.Length < 10)
                            {
                                str = (((System.Windows.Forms.WebBrowser)(cntTab.SelectedTab.Controls[0]))).Document.Body.InnerHtml.ToString().Split(st, StringSplitOptions.RemoveEmptyEntries);
                            }
                            else
                            {
                                str = str1; bNewVersion = true;
                                bNewNewVersion = true;
                            }
                            if ((((System.Windows.Forms.WebBrowser)(cntTab.SelectedTab.Controls[0]))).DocumentText.ToString().IndexOf("Old Version") >= 0)
                            {
                                bNewVersion = true;
                                if (str1.Length < 10)
                                {
                                    bNewNewVersion = true;
                                    string[] tSpNewVM = { "<table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"3\">", "<TABLE cellSpacing=0 cellPadding=3 width=\"100%\" border=0>", "<td width=\"19\" valign=\"top\" align=\"center\" style=\"padding: 0px 5px 0px 0px;\">", "<TD style=\"PADDING-RIGHT: 5px; PADDING-LEFT: 0px; PADDING-BOTTOM: 0px; PADDING-TOP: 15px\" vAlign=top align=middle width=19>" };
                                    str = ((System.Windows.Forms.WebBrowser)(cntTab.SelectedTab.Controls[0])).Document.Body.InnerHtml.ToString().Split(st3, StringSplitOptions.RemoveEmptyEntries);
                                }
                            }
                            int j = str.GetUpperBound(0);
                            foreach (string stre in str)
                            {
                                if (i > 0 && i <= j)
                                {
                                    try
                                    {
                                        string IDs = "";
                                        if (bNewNewVersion)
                                            IDs = stre.Split(st3, StringSplitOptions.RemoveEmptyEntries)[1].Split(st4, StringSplitOptions.RemoveEmptyEntries)[0];
                                        else if (bNewVersion)
                                            IDs = stre.Split(st3, StringSplitOptions.RemoveEmptyEntries)[1].Split(st4, StringSplitOptions.RemoveEmptyEntries)[0];


                                        string stText = "";
                                        string[] stSp;
                                        if (bNewVersion == false)
                                        {
                                            IDs = stre.Split(st3, StringSplitOptions.RemoveEmptyEntries)[1].Split(st4, StringSplitOptions.RemoveEmptyEntries)[0];

                                            stText = RemoveHTMLNew("<input type=\"checkbox\" name=\"resID\" " + stre).Trim();
                                            stSp = stText.Split(st2, StringSplitOptions.RemoveEmptyEntries);

                                        }
                                        else
                                        {
                                            if (bNewNewVersion)
                                                stText = RemoveHTMLNew("<td><A   " + stre).Replace("Click for contact details", "").Trim();
                                            else if (bNewVersion)
                                                stText = RemoveHTMLNew("<tr><td><input type=\"checkbox\" name=\"resID\"" + stre).Replace("Click for contact details", "").Trim();
                                            string[] aNst2 = { "&nbsp;", "<br/>", "\r\n", "Similar Resumes", "Viewed ", "New", "\n", "\t", "Contacted by Email" };
                                            string[] aEnd = { " Send Email", "Send Email", "Freshness:", "<A", "<a", "Similar Resumes" };
                                            stSp = stText.Split(aEnd, StringSplitOptions.RemoveEmptyEntries)[0].Trim().Split(aNst2, StringSplitOptions.RemoveEmptyEntries);//
                                        }
                                        int iMobFound = 0;
                                        string[] stMain1 = new string[10];
                                        string tCurrentEmploye = "", tExp = "", tCTC = "", tPhone = "", tMobile = "";
                                        for (int iLocCnt = 0; iLocCnt <= stSp.GetUpperBound(0); iLocCnt++)
                                        {
                                            if (stSp[iLocCnt].ToLower().IndexOf("annual salary:") >= 0)
                                                tCTC = stSp[iLocCnt].Split(':')[stSp[iLocCnt].Split(':').GetUpperBound(0)].Replace("Rs.", "").Replace("annually", "").Replace(",", "").Trim();
                                            if (stSp[iLocCnt].ToLower().IndexOf("exp:") >= 0)
                                                tExp = stSp[iLocCnt].Split(':')[stSp[iLocCnt].Split(':').GetUpperBound(0)];
                                            if (stSp[iLocCnt].ToLower().IndexOf("mobile:") >= 0)
                                            {
                                                tMobile = stSp[iLocCnt].Split(':')[stSp[iLocCnt].Split(':').GetUpperBound(0)];
                                                iMobFound = iLocCnt;
                                            }
                                            if (stSp[iLocCnt].ToLower().IndexOf("telephone:") >= 0)
                                            {
                                                tPhone = stSp[iLocCnt].Split(':')[stSp[iLocCnt].Split(':').GetUpperBound(0)];
                                                if (iMobFound == 0) iMobFound = iLocCnt;
                                            }
                                            if (stSp[iLocCnt].ToLower().IndexOf("last active:") >= 0)
                                                if (stSp[iLocCnt + 1].IndexOf("Resume ID") >= 0)
                                                {
                                                    if (stSp[iLocCnt + 2].IndexOf("Exp") < 0 && stSp[iLocCnt + 2].ToLower().IndexOf("annual salary") < 0 && stSp[iLocCnt + 2].IndexOf("year") < 0)
                                                        tCurrentEmploye = stSp[iLocCnt + 2].Split(':')[stSp[iLocCnt + 2].Split(':').GetUpperBound(0)];
                                                }
                                                else
                                                    tCurrentEmploye = stSp[iLocCnt + 1].Split(':')[stSp[iLocCnt + 1].Split(':').GetUpperBound(0)];
                                        }

                                        //if (true)

                                        //{
                                        //    string[] tSpMobile ={ "/contact_details.html?data=" ,") white no-"};
                                        //    string[] tSptData = stre.Split(tSpMobile, StringSplitOptions.RemoveEmptyEntries);
                                        //    string tContactData="";
                                        //    if (tSptData.Length > 2)
                                        //        tContactData = tSptData[1];
                                        //    if (tContactData.Trim() != "")
                                        //    {
                                        //        tContactData = "http://recruiter.monster.com.ph/v2/contact_details.html?data=" + tContactData;
                                        //        object objNull1 = null;
                                        //        MSXML2.XMLHTTPClass xmlHttpMain = new MSXML2.XMLHTTPClass();
                                        //        xmlHttpMain.open("GET", tContactData, false, null, null);
                                        //        xmlHttpMain.setRequestHeader("Content-Type", "text/urlencoded");
                                        //        xmlHttpMain.send(objNull1);
                                        //        if (xmlHttpMain.statusText == "OK"  )
                                        //        {
                                        //           HtmlAgilityPack. 
                                        //        }
                                        //        xmlHttpMain = null;
                                        //    }

                                        //}
                                        if (iMobFound == 0)
                                            stMain1[0] = stSp[stSp.GetUpperBound(0) - 1];
                                        else
                                            stMain1[0] = stSp[iMobFound - 1];
                                        if (stMain1[0].IndexOf("(") >= 0)
                                        {
                                            string[] a = stMain1[0].Split('(');
                                            stMain1[0] = a[0];
                                        }
                                        stMain1[1] = tPhone;
                                        stMain1[2] = tMobile;
                                        stMain1[3] = (stSp[stSp.GetUpperBound(0)].Trim() == "Viewed" ? stSp[stSp.GetUpperBound(0) - 1] : stSp[stSp.GetUpperBound(0)]);
                                        stMain1[4] = tCurrentEmploye.Replace("Not employed currently", "").Replace("NA\t", "").Replace("None\t", "").Replace("nil\t", "").Replace("Nil\t", "").Replace("NOT EMPLOYED CURRENTLY", "").Replace(" no", "").Replace(" No", "").Trim();
                                        stMain1[5] = stSp[1];//skill
                                        stMain1[6] = stSp[2];//education
                                        stMain1[7] = tCTC;
                                        stMain1[8] = tExp;
                                        opCreateMonsterNewVersion(stMain1, IDs);

                                    }
                                    catch { }

                                }
                                i++;
                            }

                            i++;
                            dt.ReadXml(new System.IO.StringReader(objXnm.OuterXml));
                            try
                            {
                                //grdCandidate.BeginUpdate();
                                dtGridData.Merge(dt.Tables[0], true);
                                tsDownload.Enabled = true;
                            }
                            catch { }
                            finally
                            {
                                //grdCandidate.EndUpdate();
                                grdCandidate.Refresh();
                                //sel.SelectAll();
                                //grdCandidate_DataSourceChanged(null, null);
                            }
                            Application.DoEvents();

                        }
                        catch
                        { }
                    }

                    #endregion

                    #region "RMS"
                    if (bFlagNaukri == 18)
                    {
                        try
                        {
                            objXnm = new System.Xml.XmlDocument();
                            objEl = objXnm.CreateElement("ROOT");
                            objXnm.AppendChild(objEl);
                            objRoot = objXnm.DocumentElement;


                            HtmlAgilityPack.HtmlDocument objHTML = null;
                            objHTML = new HtmlAgilityPack.HtmlDocument();
                            objHTML.LoadHtml((((System.Windows.Forms.WebBrowser)(cntTab.SelectedTab.Controls[0]))).Document.Body.OuterHtml);

                            HtmlAgilityPack.HtmlNodeCollection nd_Mobile = objHTML.DocumentNode.SelectNodes(@"//tr[@style='CURSOR: pointer']");


                            for (int i = 0; i <= nd_Mobile.Count - 1; i++)
                            {
                                HtmlAgilityPack.HtmlNode CandInfo = nd_Mobile[i];
                                string ID = CandInfo.SelectNodes("//input[@name='CMRowControl']")[i].GetAttributeValue("value", "");
                                if (ID != "")
                                {
                                    objEl = objXnm.CreateElement("Main");
                                    objElSub = objXnm.CreateElement("Check");
                                    objElSub.InnerText = true.ToString();
                                    objEl.AppendChild(objElSub);
                                    objElSub = objXnm.CreateElement("ResumeID");
                                    objElSub.InnerText = "0";
                                    objEl.AppendChild(objElSub);
                                    objElSub = objXnm.CreateElement("SavedType");
                                    objElSub.InnerText = "0";
                                    objEl.AppendChild(objElSub);
                                    objElSub = objXnm.CreateElement("CandidateName");
                                    objElSub.InnerText = CandInfo.SelectNodes("//a[@class='dgLink ViewCandidate candidateNameColumn']")[i].InnerText;//.SelectSingleNode("//*[contains(@id,'lblName')]").GetAttributeValue("Value", "");
                                    objEl.AppendChild(objElSub);
                                    objElSub = objXnm.CreateElement("IDs");
                                    objElSub.InnerText = ((CandInfo.InnerHtml.Contains("imgIcon img16h imgClip left")) ? ID : ID + ":PDF");
                                    objEl.AppendChild(objElSub);
                                    objElSub = objXnm.CreateElement("Mobile");
                                    objElSub.InnerText = "";
                                    objEl.AppendChild(objElSub);
                                    objElSub = objXnm.CreateElement("CandidateLocation");
                                    objElSub.InnerText = "";// CandInfo.SelectNodes("//*[contains(@id,'lblPlace')]")[i].InnerText;
                                    objEl.AppendChild(objElSub);
                                    objElSub = objXnm.CreateElement("PhoneH");
                                    objElSub.InnerText = "";
                                    objEl.AppendChild(objElSub);
                                    objElSub = objXnm.CreateElement("PresentCTC");
                                    try
                                    {
                                        //objElSub.InnerText = CandInfo.SelectNodes("//*[contains(@id,'lblYearly')]/b")[i].InnerText.Replace("years", "").Trim();
                                        objElSub.InnerText = "";//objElSub.InnerText.Replace("K", "");
                                    }
                                    catch
                                    {
                                        objElSub.InnerText = "";
                                    }
                                    objEl.AppendChild(objElSub);
                                    objElSub = objXnm.CreateElement("TotalExp");
                                    try
                                    {
                                        objElSub.InnerText = "";//CandInfo.SelectNodes("//*[contains(@id,'lblTotExp')]/b")[i].InnerText.Replace("years", "").Trim();

                                    }
                                    catch
                                    {
                                        objElSub.InnerText = "";
                                    }
                                    objEl.AppendChild(objElSub);
                                    objElSub = objXnm.CreateElement("Skill");
                                    objElSub.InnerText = "";//CandInfo.SelectNodes("//*[contains(@id,'lblSkills')]")[i].InnerText;
                                    objEl.AppendChild(objElSub);
                                    objElSub = objXnm.CreateElement("PresentEmployer");
                                    objElSub.InnerText = "";
                                    objEl.AppendChild(objElSub);
                                    string tDesignationTitle = "" ;
                                    objElSub = objXnm.CreateElement("JobTitle");
                                    //string tDesignation = CandInfo.SelectNodes("//a[@class='greyLink candidateLatestJobTitleColumn']")[i].InnerText;
                                    //opGetIDs(tDesignation.Replace("Experience:", "").Replace("N/A", "").Replace("\n", "").Replace("\t", "").Replace("&nbsp;", "").Trim().Replace("Confidential", "").Trim().ToString(), ref tDesignationIDs, ref tDesignationTitle, HireCraft.ClsFcommonXML.objfXMLJobTitle, "JobTitle", "Includelist");
                                    objElSub.InnerText = tDesignationTitle.Split(',')[tDesignationTitle.Split(',').GetLowerBound(0)];
                                    if (objElSub.InnerText.Trim() == "")
                                        objElSub.InnerText = "<--None-->";
                                    objEl.AppendChild(objElSub);


                                    //objElSub = objXnm.CreateElement("DesignationID");
                                    //objElSub.InnerText = tDesignationIDs.Split(',')[tDesignationIDs.Split(',').GetLowerBound(0)];
                                    //objEl.AppendChild(objElSub);

                                    objElSub = objXnm.CreateElement("Education"); 
                                    string tEdu = CandInfo.SelectNodes("//a[@class='blackLink highestEducationLevelColumn']")[i].InnerText; 

                                    objElSub.InnerText = tEdu.Replace("\n", "").Replace("\t\t\t\t\t", ",").Replace("\t", "").Replace("&nbsp;", "").Trim();
                                    objEl.AppendChild(objElSub);
                                     





                                    objElSub = objXnm.CreateElement("URL");
                                    objElSub.InnerText = "";
                                    objEl.AppendChild(objElSub);
                                    objElSub = objXnm.CreateElement("PreviousDesignation");
                                    objElSub.InnerText = "";
                                    objEl.AppendChild(objElSub);
                                    objElSub = objXnm.CreateElement("PreviousEmployer");
                                    objElSub.InnerText = "";
                                    objEl.AppendChild(objElSub);
                                    objElSub = objXnm.CreateElement("PrefLocationText");
                                    objElSub.InnerText = "";
                                    objEl.AppendChild(objElSub);

                                    //objElSub = objXnm.CreateElement("PrefLocationIDs");
                                    //objElSub.InnerText = "";
                                    //objEl.AppendChild(objElSub);
                                    objElSub = objXnm.CreateElement("SiteResumeID");
                                    objElSub.InnerText = "";
                                    objEl.AppendChild(objElSub);
                                    objElSub = objXnm.CreateElement("AutoResumeID");
                                    objElSub.InnerText = "";
                                    objEl.AppendChild(objElSub);
                                    objElSub = objXnm.CreateElement("Indicator");
                                    objElSub.InnerText = "";
                                    objEl.AppendChild(objElSub);
                                    objRoot.AppendChild(objEl);
                                }
                            }
                            dt.ReadXml(new System.IO.StringReader(objXnm.OuterXml));
                            try
                            {
                                //grdCandidate.BeginUpdate();
                                dtGridData.Merge(dt.Tables[0], true);
                                tsDownload.Enabled = true;
                            }
                            catch { }
                            finally
                            {
                                //grdCandidate.EndUpdate();
                                grdCandidate.Refresh();
                                //sel.SelectAll();
                                //grdCandidate_DataSourceChanged(null, null);
                            }
                            Application.DoEvents();
                        }
                        catch
                        {
                        }
                    }
                    #endregion

                    #region "rs-sg.jobstreet.com"
                    if (bFlagNaukri == 19)
                    {
                        try
                        {
                            objXnm = new System.Xml.XmlDocument();
                            objEl = objXnm.CreateElement("ROOT");
                            objXnm.AppendChild(objEl);
                            objRoot = objXnm.DocumentElement;

                            string[] ts = { "http://rs-sg.jobstreet.com/rsBridge.asp?", "' name=" };
                            string[] tData = (((System.Windows.Forms.WebBrowser)(cntTab.SelectedTab.Controls[0]))).DocumentText.Split(ts, StringSplitOptions.RemoveEmptyEntries);
                            string tUrl = "";
                            if (tData.Length > 2)
                            {
                                tUrl = tData[2];
                            }
                            ts = null; tData = null;
                            if (tUrl != "")
                            {
                                object objNull = null;
                                string tURI = "http://rs-sg.jobstreet.com/listSearchResults.asp?Kwords=&SavedCriteria=&JID=&JGID=0" + tUrl + "&ReqType=&prPrefCode=&QID=&PCID=&SID=80&OfCtry=PH&UKwords=&TB=False&Cdt=461|0&SSC=&CoName=Factset+Philippines&SearchAgent=False&Title=&URC=&S2=1&Freshness=0&tempKWords=&Sort=&BUserId=-1&TMode=&SO=&Start=41";
                                tURI = "http://rs-sg.jobstreet.com/listSearchResults.asp?" + tUrl;
                                 
                                //MSXML2.XMLHTTPClass xmlHttpMain = new MSXML2.XMLHTTPClass();

                                //xmlHttpMain.open("GET", tURI, false, null, null);
                                //xmlHttpMain.setRequestHeader("Cookie", (((System.Windows.Forms.WebBrowser)(cntTab.SelectedTab.Controls[0]))).Document.Cookie);
                                //xmlHttpMain.setRequestHeader("Referer", "http://rs-sg.jobstreet.com/rsBridge.asp?" + tUrl);
                                //xmlHttpMain.send(objNull);
                                //string tContactData = xmlHttpMain.responseText;
                                //xmlHttpMain = null;

                                System.Net.WebClient sbC = new System.Net.WebClient();
                                sbC.Headers.Set("Referer", "http://rs-sg.jobstreet.com/rsBridge.asp?" + tUrl);
                                sbC.Headers.Set("Cookie", (((System.Windows.Forms.WebBrowser)(cntTab.SelectedTab.Controls[0]))).Document.Cookie);
                                sbC.Headers.Set("Content-Type", "text/xml");
                                    string   tContactData = sbC.DownloadString( tURI);
                                sbC  = null;

                                HtmlAgilityPack.HtmlDocument objHTML1 = null;
                                objHTML1 = new HtmlAgilityPack.HtmlDocument();
                                objHTML1.LoadHtml(tContactData);
                                string[] ts1 = { "<td align='left'>Viewed Resumes <b>", "</b> of" };
                                tData = tContactData.Split(ts1, StringSplitOptions.RemoveEmptyEntries);
                                Int64 iMaxCount = 0;
                                if (tData.Length > 2)
                                {
                                    Int64.TryParse(tData[1].Split('-')[1].Trim(), out iMaxCount);
                                }
                                tData = null; ts1 = null;
                                for (int j = 0; j < iMaxCount; j++)
                                {
                                    HtmlAgilityPack.HtmlNodeCollection nd_Mobile = objHTML1.DocumentNode.SelectNodes(@"//*[contains(@id,'resultRow" + j.ToString() + "')]");
                                    if (nd_Mobile == null) continue;
                                    for (int i = 0; i <= nd_Mobile.Count - 1; i++)
                                    {
                                        HtmlAgilityPack.HtmlNode CandInfo = nd_Mobile[i];
                                        string[] tSP22 = { "javascript:GetAttachment(", ");return false;\">" };
                                        tData = nd_Mobile[i].InnerHtml.Split(tSP22, StringSplitOptions.RemoveEmptyEntries);
                                        string ID = ""; //"http://www.corp-corp.com/emp/" + CandInfo.SelectNodes("//*[contains(@id,'hlViewProfile1')]")[i].GetAttributeValue("href", "NO URL FOUND");
                                        if (tData.Length > 1)
                                            ID = tData[1];
                                        string stText = RemoveHTMLNew(nd_Mobile[i].InnerHtml).Trim();
                                        //string[] stSp = stText.Split(st2, StringSplitOptions.RemoveEmptyEntries);
                                        //string[] stMain1 = new string[10];
                                        //int k = 0;
                                        string tName = "", PresentEmployer = "", tExp = "", tEdu = "", tDes = "";
                                        foreach (HtmlAgilityPack.HtmlNode bChild in nd_Mobile[i].ChildNodes)
                                        {
                                            //k++;
                                            if (bChild.InnerHtml.Contains("onclick='javascript: return ShowFullResume"))
                                            {
                                                tName = RemoveHTMLNew(bChild.InnerHtml.Replace("<br>", ",")).Split(',')[0];
                                            }
                                            if (bChild.OuterHtml.Contains("valign='top' style=\"word-break:break-all;"))
                                            {
                                                string[] tn = RemoveHTMLNew(bChild.InnerHtml.Replace("<br>", ",").Replace("<p>", ",")).Split(',');
                                                PresentEmployer = tn[1].Replace("&amp;", "&");
                                                tDes = tn[0].Replace("&nbsp;", "");
                                                tExp = tn[tn.GetUpperBound(0) - 1].Replace("Total of ", "").Replace("yrs experience", "").Replace("yr experience", "").Trim();
                                            }
                                            if (bChild.OuterHtml.Contains("<td valign=\"top\" width=\"21%\" style=\"word-break:break-all;\">"))
                                            {
                                                string[] tn = RemoveHTMLNew(bChild.InnerHtml.Replace("<br>", ",").Replace("<p>", ",")).Split(',');
                                                tEdu = RemoveHTMLNew(bChild.InnerHtml.Replace("<br>", ",").Replace("<p>", ","));
                                            }

                                        }
                                        //if (ID != "")
                                        {
                                            objEl = objXnm.CreateElement("Main");
                                            objElSub = objXnm.CreateElement("Check");
                                            objElSub.InnerText = true.ToString();
                                            objEl.AppendChild(objElSub);
                                            objElSub = objXnm.CreateElement("ResumeID");
                                            objElSub.InnerText = "0";
                                            objEl.AppendChild(objElSub);
                                            objElSub = objXnm.CreateElement("SavedType");
                                            objElSub.InnerText = "0";
                                            objEl.AppendChild(objElSub);
                                            objElSub = objXnm.CreateElement("CandidateName");
                                            objElSub.InnerText = tName;
                                            objEl.AppendChild(objElSub);
                                            objElSub = objXnm.CreateElement("IDs");
                                            objElSub.InnerText = ID;
                                            objEl.AppendChild(objElSub);
                                            objElSub = objXnm.CreateElement("Mobile");
                                            objElSub.InnerText = "";
                                            objEl.AppendChild(objElSub);
                                            objElSub = objXnm.CreateElement("CandidateLocation");
                                            objElSub.InnerText = "";// CandInfo.SelectNodes("//*[contains(@id,'lblPlace')]")[i].InnerText;
                                            objEl.AppendChild(objElSub);
                                            objElSub = objXnm.CreateElement("PhoneH");
                                            objElSub.InnerText = "";
                                            objEl.AppendChild(objElSub);
                                            objElSub = objXnm.CreateElement("PresentCTC");
                                            try
                                            {
                                                //objElSub.InnerText = CandInfo.SelectNodes("//*[contains(@id,'lblYearly')]/b")[i].InnerText.Replace("years", "").Trim();
                                                objElSub.InnerText = "";//objElSub.InnerText.Replace("K", "");
                                            }
                                            catch
                                            {
                                                objElSub.InnerText = "";
                                            }
                                            objEl.AppendChild(objElSub);
                                            objElSub = objXnm.CreateElement("TotalExp");
                                            try
                                            {
                                                objElSub.InnerText = tExp;//CandInfo.SelectNodes("//*[contains(@id,'lblTotExp')]/b")[i].InnerText.Replace("years", "").Trim();

                                            }
                                            catch
                                            {
                                                objElSub.InnerText = "";
                                            }
                                            objEl.AppendChild(objElSub);
                                            objElSub = objXnm.CreateElement("Skill");
                                            objElSub.InnerText = "";//CandInfo.SelectNodes("//*[contains(@id,'lblSkills')]")[i].InnerText;
                                            objEl.AppendChild(objElSub);
                                            objElSub = objXnm.CreateElement("PresentEmployer");
                                            objElSub.InnerText = PresentEmployer;
                                            objEl.AppendChild(objElSub);
                                            string tDesignationTitle = "", tDesignationIDs = "";
                                            objElSub = objXnm.CreateElement("JobTitle");
                                            //opGetIDs(tDes.Replace("Experience:", "").Replace("N/A", "").Replace("\n", "").Replace("\t", "").Replace("&nbsp;", "").Trim().Replace("Confidential", "").Trim().ToString(), ref tDesignationIDs, ref tDesignationTitle, HireCraft.ClsFcommonXML.objfXMLJobTitle, "JobTitle", "Includelist");
                                            //if (tDesignationTitle == "")
                                            //    tDesignationTitle = tDes.Replace("Experience:", "").Replace("N/A", "").Replace("\n", "").Replace("\t", "").Replace("&nbsp;", "").Trim().Replace("Confidential", "").Replace("\n", "").Replace("\t", "").Replace("&nbsp;", "").Trim();

                                            objElSub.InnerText = tDesignationTitle.Split(',')[tDesignationTitle.Split(',').GetLowerBound(0)];
                                            if (objElSub.InnerText.Trim() == "")
                                                objElSub.InnerText = "<--None-->";
                                            objEl.AppendChild(objElSub);


                                            //objElSub = objXnm.CreateElement("DesignationID");
                                            //objElSub.InnerText = tDesignationIDs.Split(',')[tDesignationIDs.Split(',').GetLowerBound(0)];
                                            //objEl.AppendChild(objElSub);

                                            objElSub = objXnm.CreateElement("Education");
                                      

                                            objElSub.InnerText = tEdu.Replace("\n", "").Replace("\t\t\t\t\t", ",").Replace("\t", "").Replace("&nbsp;", "").Trim();
                                            objEl.AppendChild(objElSub);

                                            //objElSub = objXnm.CreateElement("EducationIDs");
                                            //objElSub.InnerText = tEducationIDs;
                                            //objEl.AppendChild(objElSub);





                                            objElSub = objXnm.CreateElement("URL");
                                            objElSub.InnerText = "";
                                            objEl.AppendChild(objElSub);
                                            objElSub = objXnm.CreateElement("PreviousDesignation");
                                            objElSub.InnerText = "";
                                            objEl.AppendChild(objElSub);
                                            objElSub = objXnm.CreateElement("PreviousEmployer");
                                            objElSub.InnerText = "";
                                            objEl.AppendChild(objElSub);
                                            objElSub = objXnm.CreateElement("PrefLocationText");
                                            objElSub.InnerText = "";
                                            objEl.AppendChild(objElSub);
                                             
                                            objElSub = objXnm.CreateElement("SiteResumeID");
                                            objElSub.InnerText = "";
                                            objEl.AppendChild(objElSub);
                                            objElSub = objXnm.CreateElement("AutoResumeID");
                                            objElSub.InnerText = "";
                                            objEl.AppendChild(objElSub);
                                            objElSub = objXnm.CreateElement("Indicator");
                                            objElSub.InnerText = "";
                                            objEl.AppendChild(objElSub);
                                            objRoot.AppendChild(objEl);
                                        }
                                    }

                                }



                            }
                            dt.ReadXml(new System.IO.StringReader(objXnm.OuterXml));
                            try
                            {
                                //grdCandidate.BeginUpdate();
                                dtGridData.Merge(dt.Tables[0], true);
                                tsDownload.Enabled = true;
                            }
                            catch { }
                            finally
                            {
                                //grdCandidate.EndUpdate();
                                grdCandidate.Refresh();
                                //sel.SelectAll();
                                //grdCandidate_DataSourceChanged(null, null);
                            }
                            Application.DoEvents();
                        }
                        catch
                        {
                        }
                    }
                    #endregion

                    #region "http://recruiter.shine.com/"
                    if (bFlagNaukri == 20)
                    {
                        try
                        {
                            objXnm = new System.Xml.XmlDocument();
                            objEl = objXnm.CreateElement("ROOT");
                            objXnm.AppendChild(objEl);
                            objRoot = objXnm.DocumentElement;


                            HtmlAgilityPack.HtmlDocument objHTML = null;
                            objHTML = new HtmlAgilityPack.HtmlDocument();
                            objHTML.LoadHtml((((System.Windows.Forms.WebBrowser)(cntTab.SelectedTab.Controls[0]))).Document.Body.OuterHtml);

                            HtmlAgilityPack.HtmlNodeCollection nd_Mobile1 = objHTML.DocumentNode.SelectNodes(@"//div[@class=' cls_loop_chng search_result2 premium srch_res_profile']");
                            //    HtmlAgilityPack.HtmlNodeCollection nd_Mobile1 = objHTML.DocumentNode.SelectNodes(@"//div[@class=' cls_loop_chng search_result2 premium']");

                            try
                            {
                                if (nd_Mobile1 == null || nd_Mobile1.Count <= 0)
                                {
                                    nd_Mobile1 = objHTML.DocumentNode.SelectNodes(@"//div[@class='cls_loop_chng search_result2 premium']");
                                }


                                if (nd_Mobile1 != null && nd_Mobile1.Count > 0)
                                {
                                    opFetchShineValue(nd_Mobile1, ref objXnm);
                                }
                            }
                            catch { }



                            HtmlAgilityPack.HtmlNodeCollection nd_Mobile = objHTML.DocumentNode.SelectNodes(@"//div[@class='cls_loop_chng search_result2 srch_res_profile inactive']");

                            if (nd_Mobile.Count > 0)
                            {
                                opFetchShineValue(nd_Mobile, ref objXnm);
                            }




                            dt.ReadXml(new System.IO.StringReader(objXnm.OuterXml));
                            try
                            {
                                //grdCandidate.BeginUpdate();
                                dtGridData.Merge(dt.Tables[0], true);
                                tsDownload.Enabled = true;
                            }
                            catch { }
                            finally
                            {
                                //grdCandidate.EndUpdate();
                                grdCandidate.Refresh();
                                //sel.SelectAll();
                                //grdCandidate_DataSourceChanged(null, null);
                            }
                            Application.DoEvents();
                        }
                        catch
                        {
                        }
                    }
                    #endregion

                    #region "www.rigzone.com"

                    if (bFlagNaukri == 21)
                    {
                        objXnm = new System.Xml.XmlDocument();
                        objEl = objXnm.CreateElement("ROOT");
                        objXnm.AppendChild(objEl);
                        objRoot = objXnm.DocumentElement;
                        string[] stMain = { "<INPUT onclick=BkOnChange(this)", "<input name=\"bk_" };
                        string[] st = { "resume.asp?r_id=" };
                        string[] st3 = { "\">" };
                        string[] aNst2 = { "<br/>", "\r\n", "Viewed ", "New", "\n", "\t", "Career Summary" };
                        string[] aEnd = { " Send Email", "Send Email", "Freshness:", "Similar Resumes", "<A", "<a" };

                        try
                        {
                            int i = 0;
                            string[] str = (((System.Windows.Forms.WebBrowser)(cntTab.SelectedTab.Controls[0]))).Document.Body.InnerHtml.ToString().Split(stMain, StringSplitOptions.RemoveEmptyEntries);

                            int j = str.GetUpperBound(0);
                            foreach (string stre in str)
                            {
                                if (i > 0 && i <= j)
                                {
                                    try
                                    {

                                        string[] stSp = null;
                                        string IDs = stre.Split(st, StringSplitOptions.RemoveEmptyEntries)[1].Split(st3, StringSplitOptions.RemoveEmptyEntries)[0];
                                        string stText = "";
                                        stText = RemoveHTML("<table><tbody><input   " + stre.Replace("<br>", "\r\n").Replace("<td class=\"cursor\">", "<td class=\"cursor\">\r\n")).Trim();
                                        stSp = stText.Split(aNst2, StringSplitOptions.RemoveEmptyEntries);// 
                                        string[] stMain1 = new string[12];

                                        if (stSp.Length > 18)
                                        {
                                            stMain1[0] = stSp[0];
                                            stMain1[1] = "";
                                            stMain1[2] = "";
                                            stMain1[3] = stSp[5];// (stSp[stSp.GetUpperBound(0)].Trim() == "Viewed" ? stSp[stSp.GetUpperBound(0) - 1] : stSp[stSp.GetUpperBound(0)]);


                                            stMain1[4] = "";// tCurrentEmploye.Replace("Not employed currently", "").Replace("NA\t", "").Replace("None\t", "").Replace("nil\t", "").Replace("Nil\t", "").Replace("NOT EMPLOYED CURRENTLY", "").Replace(" no", "").Replace(" No", "").Trim();
                                            stMain1[5] = stSp[4]; ;//skill

                                            stMain1[6] = stSp[3];

                                            stMain1[7] = "";// tCTC;
                                            stMain1[8] = stSp[2].Replace("&nbsp;", "");// tExp;
                                            stMain1[9] = "";// preferredLocation;
                                            stMain1[10] = IDs;
                                            stMain1[11] = stSp[1]; ;//;
                                        }
                                        else
                                        {
                                            if (stSp[0].Contains(",") == false)
                                                stMain1[0] = stSp[0];
                                            else
                                                stMain1[0] = "";
                                            stMain1[1] = "";
                                            stMain1[2] = "";
                                            stMain1[3] = stSp[5];// (stSp[stSp.GetUpperBound(0)].Trim() == "Viewed" ? stSp[stSp.GetUpperBound(0) - 1] : stSp[stSp.GetUpperBound(0)]);


                                            stMain1[4] = "";// tCurrentEmploye.Replace("Not employed currently", "").Replace("NA\t", "").Replace("None\t", "").Replace("nil\t", "").Replace("Nil\t", "").Replace("NOT EMPLOYED CURRENTLY", "").Replace(" no", "").Replace(" No", "").Trim();
                                            stMain1[5] = stSp[4]; ;//skill

                                            stMain1[6] = stSp[3];

                                            stMain1[7] = "";// tCTC;
                                            stMain1[8] = stSp[2].Replace("&nbsp;", "");// tExp;
                                            stMain1[9] = "";// preferredLocation;
                                            stMain1[10] = IDs;
                                            stMain1[11] = stSp[1];//;
                                        }
                                        stText = null;
                                        opCreateMonsterNewVersion(stMain1, IDs);
                                    }
                                    catch { }

                                }
                                i++;
                            }
                            str = null;

                            i++;
                            dt.ReadXml(new System.IO.StringReader(objXnm.OuterXml));
                            try
                            {
                                //grdCandidate.BeginUpdate();
                                dtGridData.Merge(dt.Tables[0], true);
                                tsDownload.Enabled = true;
                            }
                            catch { }
                            finally
                            {
                                //grdCandidate.EndUpdate();
                                grdCandidate.Refresh();
                                //sel.SelectAll();
                                //grdCandidate_DataSourceChanged(null, null);
                            }
                            Application.DoEvents();

                        }
                        catch
                        { }
                    }


                    #endregion

                    #region "Naugri Gulf Response"

                    if (bFlagNaukri == 231)// if (opValidJobSiteNaukrigulf(br1.Url.ToString()))
                    {
                        try
                        {
                            //  bFlagNaukri = 7;
                            string tempop = (((System.Windows.Forms.WebBrowser)(cntTab.SelectedTab.Controls[0]))).Document.Body.InnerHtml; 

                            objXnm = new System.Xml.XmlDocument();
                            objEl = objXnm.CreateElement("ROOT");
                            objXnm.AppendChild(objEl);
                            objRoot = objXnm.DocumentElement;
                            int i = 0;
                            string[] st = { "<DIV class=col2nd>" };
                            string[] st12 = { "<!--<IMG SRC=" };
                            string[] st123 = { "\r\n", " \r\n \r\n", "\r\n \r\n" };
                            string[] st1234 = { "Currently in:" };
                            string[] s23t = { "A href=/ng/rm/CvPreview?", "target=_blank name=resumeLink", "target=_blank>", "target=_blank" };
                            //string[] str = richTextBox1.Text.ToString().Split(st, StringSplitOptions.RemoveEmptyEntries);
                            string[] str = tempop.ToString().Split(st, StringSplitOptions.RemoveEmptyEntries);

                            string[] stMain = null;
                            string[] sEBoldt = { "<td valign='top' class='dashedL resDivM1'>", "<br /><br />" };
                            string[] sEBoldt1 = { "<span class='ltGrey'>", "<BR>", "<br>", "<br />" };
                            string[] sEBoldt2 = { "<strong>", "</strong>" };
                            string[] sEmpt = { "At&nbsp;", " at " };
                            int j = str.GetUpperBound(0);
                            string[] stMain1 = new string[13];
                            foreach (string stre in str)
                            {
                                if (i >= 1 && i <= j)
                                {
                                    if (stre.IndexOf("<STRONG class=f12>Similar CVs</STRONG> - Showing <STRONG>") > 0)
                                        continue;

                                    string ids = stre.Split(s23t, StringSplitOptions.RemoveEmptyEntries)[0].ToString();
                                    string[] sIDt = { "&amp;" };
                                    string[] aIds = ids.Split(sIDt, StringSplitOptions.RemoveEmptyEntries);
                                    ids = aIds[0].Replace("<A href=\"/ng/rm/CvPreview?", "");
                                    stMain = RemoveHTML("<DIV class=leftchk>" + stre.Replace("<br>", "\r\n").Replace("<br />", "\r\n").Replace("> <", "><")).ToString().Trim().Split(st123, StringSplitOptions.RemoveEmptyEntries);//.Split(st12, StringSplitOptions.RemoveEmptyEntries)[0].ToString()
                                    //stMain1[1] = (stMain[1].Trim() == "" ? stMain[2].Split('(')[0] : stMain[1].Split('(')[0]);
                                    string tloc = "";
                                    int iLocCnt1 = 0;
                                    //bool bFound = false;
                                    string tPhone = "";
                                    string tMobile = "";
                                    string tCTC = "", tPresentEmp = "", tDesignation = "", tExperience = "", tskills = "";
                                    for (int iLocCnt = 0; iLocCnt <= stMain.GetUpperBound(0); iLocCnt++)
                                    {
                                        if ((stMain[iLocCnt].ToLower().IndexOf("location") >= 0 || stMain[iLocCnt].ToLower().IndexOf("current location") >= 0) && stMain[iLocCnt].ToLower().IndexOf("c=window.location.href") < 0)
                                        {
                                            tloc = stMain[iLocCnt].Replace("Current Location:", "").Replace("Location:", "").Replace("Salary Bracket:", "");
                                            if (tloc == "")
                                            {
                                                tloc = stMain[iLocCnt + 1];
                                                iLocCnt1 = iLocCnt + 1;
                                            }
                                            else
                                                iLocCnt1 = iLocCnt;
                                        }
                                        if (stMain[iLocCnt].ToLower().IndexOf("mobile:") >= 0)
                                            tMobile = stMain[iLocCnt];
                                        if (stMain[iLocCnt].ToLower().IndexOf("phone:") >= 0)
                                            tPhone = stMain[iLocCnt];
                                        if (stMain[iLocCnt].ToLower().IndexOf("salary bracket:") >= 0)
                                            try
                                            {
                                                if (stMain[iLocCnt].ToLower().IndexOf("location") == 0 || stMain[iLocCnt].ToLower().IndexOf("current location") == 0)
                                                    tCTC = stMain[iLocCnt + 1].Split('-')[0].Split('$')[1];
                                                else

                                                    tCTC = stMain[iLocCnt].Split('-')[0].Split('$')[1];
                                            }
                                            catch { }
                                        if (stMain[iLocCnt].ToLower().IndexOf("current employer:") >= 0)
                                        {
                                            tPresentEmp = stMain[iLocCnt].Replace("At ", "").Replace("Current Employer:", "").Trim();
                                            if (tPresentEmp.ToLower().IndexOf("nationality") == 0)
                                            {
                                                if (stMain[iLocCnt + 1].ToLower().IndexOf("apply date") >= 0)
                                                    tPresentEmp = "";
                                                else
                                                    tPresentEmp = stMain[iLocCnt + 1];
                                            }

                                        }
                                        if (stMain[iLocCnt].ToLower().IndexOf("skills:") >= 0)
                                        {
                                            tskills = stMain[iLocCnt].Replace("Skills:", "").Replace("Languages Known:", "").Trim();
                                            if (tskills == "") tskills = stMain[iLocCnt + 1];
                                        }

                                    }
                                    if (stMain[1].ToLower().IndexOf("yrs.") >= 0)
                                    {
                                        try
                                        {
                                            string[] tdp = { "(", ")", "yrs." };
                                            tExperience = stMain[1].TrimStart().TrimEnd();
                                            string[] aExp = tExperience.Split(tdp, StringSplitOptions.RemoveEmptyEntries);
                                            if (aExp != null)
                                                tExperience = aExp[0];
                                        }
                                        catch { }
                                    }
                                    //Splitting name
                                    string tCandidateName = "";
                                    if (stMain[0] != null && stMain[0] != "")
                                    {
                                        string[] name = { "-", "(", ")", "Male", "Female", "male", "female" };
                                        tCandidateName = stMain[0].TrimStart().TrimEnd();
                                        string[] aName = tCandidateName.Split(name, StringSplitOptions.RemoveEmptyEntries);
                                        tCandidateName = aName[0].TrimStart().TrimEnd();
                                        if (aName.Length == 2)
                                            tDesignation = aName[1].TrimStart().TrimEnd();
                                        else if (aName.Length == 3)
                                            tDesignation = aName[2].TrimStart().TrimEnd();
                                    }

                                    stMain1[1] = tCandidateName;
                                    stMain1[2] = "";
                                    stMain1[3] = tloc;
                                    stMain1[4] = tPresentEmp;
                                    stMain1[5] = tDesignation;
                                    stMain1[6] = tExperience;
                                    stMain1[7] = tskills;
                                    stMain1[8] = "";
                                    stMain1[9] = tCTC;
                                    stMain1[10] = "";
                                    stMain1[11] = "";
                                    stMain1[12] = "";
 
                                    opCreateNodesNaukri(stMain1, ids);
                                }

                                i++;
                            }

                            i++;
                            dt.ReadXml(new System.IO.StringReader(objXnm.OuterXml));
                            try
                            {
                                //grdCandidate.BeginUpdate();
                                dtGridData.Merge(dt.Tables[0], true);
                                tsDownload.Enabled = true;
                            }
                            catch { }
                            finally
                            {
                                //grdCandidate.EndUpdate();
                                grdCandidate.Refresh();
                                //sel.SelectAll();
                                //grdCandidate_DataSourceChanged(null, null);
                            }
                            Application.DoEvents();
                        }
                        catch
                        {
                        }
                    }
                    #endregion
                }
            }
            catch (Exception ex)
            {
                Log.LogData("Error on Parsing : " + ex.Message + ex.StackTrace, Log.Status.Error);
            }
            finally
            {

                opSetMessage("Ready ..."); 
                tspgrs.Visible = false;
                opSetCursorNormal();
            }
        }

        #region "delegates"

        public delegate HtmlDocument CreateBrowseronThread(bool replaceInHistory);
        private HtmlDocument opCreateBrowser(bool replaceInHistory)
        {
            try
            {
                if (webBrowser1.Document == null)
                {
                    webBrowser1.DocumentText = "<html><body></body></html>";
                    Application.DoEvents();
                }
                return webBrowser1.Document.OpenNew(replaceInHistory);
            }
            catch
            {
                return null;
            }
        }
        public delegate void CreateAuthorizePopup(string URL);
        private void opAuthorizePopup(string URL)
        {
            try
            {
                frmBrowserValidationPopup objpopup = new frmBrowserValidationPopup();
                objpopup.tAuthURL = URL;
                objpopup.ShowDialog(); objpopup = null;

            }
            catch { }
        }
        delegate void bUpdateGridInfoAfterDownload(string tREturnData, string tDirectoryName, string FileName, string UniqueID);
        delegate void bUpdateGridInfoUnknown(string UniqueID);

        private void opUpdateColumnInfoAfterDownload(string tREturnData, string tDirectoryName, string FileName, string UniqueID)
        {
            try
            {
                DataRow[] dr = dtGridData.Select("IDs='" + UniqueID + "'");
                dr[0]["Indicator"] = "0";
                dr[0]["Check"] = false.ToString();
                System.Windows.Forms.Application.DoEvents();
                string[] tReturnStatus = tREturnData.Split(':');
                if (tREturnData.StartsWith("-") == true)
                {
                    if (tREturnData.StartsWith("-1000") == true)
                    {
                        iDuplicateDocument++; 
                         
                         
                        dr[0]["ResumeID"] = tReturnStatus[1];
                        dr[0]["AutoResumeID"] = tReturnStatus[1];
                        dr[0]["SavedType"] = -1000;

                    }
                    else if (tREturnData.StartsWith("-1002") == true)
                    {
                        iDuplicateOverwriteDocument++; 
                        dr[0]["ResumeID"] = tReturnStatus[1];
                        dr[0]["AutoResumeID"] = tReturnStatus[1];
                        dr[0]["SavedType"] = -1002; 
                    }
                    else if (tREturnData.StartsWith("-22") == true || tREturnData.StartsWith("-1") == true)
                    {
                        iUnKnownFormatResumes++;
                        dr[0]["SavedType"] = -1;
                    }
                    else if (tREturnData == "-2" || tREturnData == "-3" || tREturnData == "-4" || tREturnData == "-7")
                    {
                        iFailed2Save++;
                        dr[0]["SavedType"] = -3;
                    }
                    else if (tREturnData.StartsWith("-245") == true)
                    { }
                    else if (tREturnData.StartsWith("-11") == true)
                    {
                        opSetMessage(tREturnData.Replace("-11:", "").Trim());
                        iUnKnownFormatResumes++;
                        dr[0]["SavedType"] = -1;
                    }
                    else
                        iUnKnownFormatResumes++;
                }
                else
                {
                    iParsedResume++; 
                    dr[0]["ResumeID"] = tReturnStatus[tReturnStatus.GetLowerBound(0)];
                    dr[0]["AutoResumeID"] = tReturnStatus[tReturnStatus.GetLowerBound(0)];
                    dr[0]["SavedType"] = 1; 
                }
                if (System.IO.File.Exists( GetLocalTempPath() + FileName))
                    System.IO.File.Delete( GetLocalTempPath() + FileName);
                System.Windows.Forms.Application.DoEvents();
                System.Windows.Forms.Application.DoEvents();
                lblDuplicateDoc.Text = iDuplicateDocument.ToString();
                lblDuplicateOverwrite.Text = iDuplicateOverwriteDocument.ToString();
                lblFailedSave.Text = iFailed2Save.ToString();
                lblUnknownFormatR.Text = iUnKnownFormatResumes.ToString();
                lblParsed.Text = iParsedResume.ToString();
                System.Windows.Forms.Application.DoEvents();
                System.Windows.Forms.Application.DoEvents();
                grdCandidate.Refresh();
                dr = null;
            }
            catch { }
        }

        private void opUpdateGridInfoUnknown(string UniqueID)
        {
            try
            {
                DataRow[] dr = dtGridData.Select("IDs='" + UniqueID + "'");
                dr[0]["SavedType"] = -1;
                dr[0]["Check"] = false.ToString();
                grdCandidate.Refresh();
                dr = null;
            }
            catch { }
        }
        #endregion

        #region "User defined Functions"

        private void opClearGrid()
        {
            try
            {
                dtGridData = new DataTable("Main");
                DataSet dtClear = new DataSet("Main");
                dtClear.ReadXml(new System.IO.StringReader(
                "<ROOT><Check/><ResumeID/><SavedType/><IDs/><CandidateName/><Mobile/><PhoneH/><CandidateLocation/><PresentEmployer/><JobTitle/><Skill/><Education/><PresentCTC/><TotalExp/><PreviousDesignation/><PreviousEmployer/><PrefLocationText/><SiteResumeID/><AutoResumeID/><Indicator/></ROOT>"));

                dtClear.Tables[0].Rows.Clear();
                dtGridData = dtClear.Tables[0].Copy();
                grdCandidate.DataSource = dtGridData.DefaultView;
                grdCandidate.Refresh();
                dtClear.Dispose();
                dtClear = null;
            }
            catch { }
        }
        public void opSetCursorBusy()
        {
            this.Cursor = Cursors.WaitCursor;
            System.Windows.Forms.Application.DoEvents();
        }

        public void opSetCursorNormal()
        {
            this.Cursor = Cursors.Arrow;
            System.Windows.Forms.Application.DoEvents();
        }

        /// <summary>
        /// set message in status bar
        /// </summary>
        /// <param name="tMessage"></param>
        private void opSetMessage(string tMessage)
        {
            tsbar.Text = tMessage;
        }


        private void opFetchShineValue(HtmlAgilityPack.HtmlNodeCollection nd_Mobile, ref System.Xml.XmlDocument objXnm)
        {
            for (int i = 0; i <= nd_Mobile.Count - 1; i++)
            {

                HtmlAgilityPack.HtmlNode CandInfo = nd_Mobile[i];
                HtmlAgilityPack.HtmlDocument objHTML1 = new HtmlAgilityPack.HtmlDocument();
                objHTML1.LoadHtml(nd_Mobile[i].OuterHtml);
                //   HtmlAgilityPack.HtmlNode CandInfo = nd_Mobile[i];
                // string ID = CandInfo.SelectNodes("//input[@name='CMRowControl']")[i].GetAttributeValue("value", "");
                //   string ID = CandInfo.SelectNodes(@"//div[@class='cls_loop_chng search_result2 inactive']")[i].GetAttributeValue("ID", "");  
                string ID = objHTML1.DocumentNode.SelectNodes(@"//input[@name]")[0].GetAttributeValue("value", "");//CandInfo.SelectNodes(@"//input[@name]")[i].GetAttributeValue("value", "");
                //string tURL = CandInfo.SelectNodes("//*[contains(@onclick,'profile')]")[0].GetAttributeValue("href", "NO URL FOUND");
                string tURL = CandInfo.SelectNodes("//*[contains(@onclick,'profile')]")[i].GetAttributeValue("href", "NO URL FOUND");

                tURL = objHTML1.DocumentNode.SelectNodes("//*[contains(@onclick,'profile')]")[0].GetAttributeValue("href", "NO URL FOUND");
                if (tURL != "")
                {
                    try
                    {
                        objEl = objXnm.CreateElement("Main");

                        objElSub = objXnm.CreateElement("Check");
                        objElSub.InnerText = true.ToString();
                        objEl.AppendChild(objElSub);

                        objElSub = objXnm.CreateElement("ResumeID");
                        objElSub.InnerText = "0";
                        objEl.AppendChild(objElSub);

                        objElSub = objXnm.CreateElement("SavedType");
                        objElSub.InnerText = "0";
                        objEl.AppendChild(objElSub);

                        objElSub = objXnm.CreateElement("CandidateName");
                        objElSub.InnerText = objHTML1.DocumentNode.SelectNodes("//*[contains(@onclick,'profile')]")[0].InnerText.Replace("\n", "").Trim();//CandInfo.SelectNodes("//*[contains(@onclick,'profile')]")[i].InnerText;//.SelectSingleNode("//*[contains(@id,'lblName')]").GetAttributeValue("Value", "");
                        objEl.AppendChild(objElSub);

                        objElSub = objXnm.CreateElement("Can_Description");
                        objElSub.InnerText = "";// CandInfo.SelectNodes("//p")[i].InnerText;//.SelectSingleNode("//*[contains(@id,'lblName')]").GetAttributeValue("Value", "");
                        objEl.AppendChild(objElSub);

                        objElSub = objXnm.CreateElement("IDs");
                        objElSub.InnerText = tURL;//((CandInfo.InnerHtml.Contains("imgIcon img16h imgClip left")) ? ID : ID + ":PDF");
                        objEl.AppendChild(objElSub);
                        objElSub = objXnm.CreateElement("Mobile");
                        objElSub.InnerText = "";
                        objEl.AppendChild(objElSub);

                        string CandInfo_Loc = "", CandInfo_Desig = "", tSkills = "", tPreferedLocation = "";
                        try
                        {
                            if (CandInfo.SelectNodes(@"//div[@class='loca_box']").Count > 0)
                            {
                                //   if (i == 0)
                                CandInfo_Loc = objHTML1.DocumentNode.SelectNodes(@"//div[@class='loca_box']")[0].InnerHtml;
                                // else
                                //   CandInfo_Loc = CandInfo.SelectNodes(@"//div[@class='loca_box']")[i + 1].InnerHtml;
                            }
                            if (CandInfo.SelectNodes(@"//div[@class='loca_box']").Count > 0)
                            {
                                //  if (i == 0)
                                CandInfo_Desig = objHTML1.DocumentNode.SelectNodes(@"//div[@class='loca_box']")[1].InnerHtml;
                                // else
                                //  CandInfo_Desig = CandInfo.SelectNodes(@"//div[@class='loca_box']")[i + 2].InnerHtml;

                            }

                            //if (CandInfo.SelectNodes(@"//span[@class='truncate floatleft sslist']").Count > 0)
                            //    tSkills = CandInfo.SelectNodes(@"//span[@class='truncate floatleft sslist']")[i].InnerText;
                            //if (CandInfo.SelectNodes(@"//span[@class='truncate floatleft pllist']").Count > 0)
                            //    tPreferedLocation = CandInfo.SelectNodes(@"//span[@class='truncate floatleft pllist']")[i].InnerText;

                            //if (objHTML1.DocumentNode.SelectNodes(@"//span[@class='truncate floatleft sslist']") != null && objHTML1.DocumentNode.SelectNodes(@"//span[@class='truncate floatleft sslist']").Count > 0)
                            //    tSkills = objHTML1.DocumentNode.SelectNodes(@"//span[@class='truncate floatleft sslist']")[0].InnerHtml;
                            //if (objHTML1.DocumentNode.SelectNodes(@"//span[@class='truncate floatleft pllist']") != null && objHTML1.DocumentNode.SelectNodes(@"//span[@class='truncate floatleft pllist']").Count > 0)
                            //    tPreferedLocation = objHTML1.DocumentNode.SelectNodes(@"//span[@class='truncate floatleft pllist']")[0].InnerHtml;


                        }
                        catch { }
                        if (tSkills.Trim() != "")
                        {
                            tSkills = tSkills.Replace(",,", ",").Replace("<u>", "").Replace("</u>", "").Trim();
                            if (tSkills.Trim().StartsWith(","))
                            {
                                tSkills = tSkills.Remove(0).Trim();
                            }
                            else if (tSkills.Trim().EndsWith(","))
                            {
                                tSkills = tSkills.Remove(tSkills.Length - 1).Trim();
                            }
                        }
                        if (tSkills.Trim() != "")
                        {
                            tPreferedLocation = tPreferedLocation.Replace(",,", ",").Replace("<u>", "").Replace("</u>", "").Trim();
                            if (tPreferedLocation.Trim().StartsWith(","))
                            {
                                tPreferedLocation = tPreferedLocation.Remove(0).Trim();
                            }
                            else if (tPreferedLocation.Trim().EndsWith(","))
                            {
                                tPreferedLocation = tPreferedLocation.Remove(tPreferedLocation.Length - 1).Trim();
                            }
                        }

                        string tLocation = "", tExp = "", tEducation = "";
                        string tDesignation = "", tCTC = "", tPrsantCompany = "";

                        try
                        {
                            CandInfo_Loc = CandInfo_Loc.Replace("<ul>", "").Replace("</ul>", "").Replace("<strong>", "").Replace("</strong>", "").Replace("<li>", "").Replace("</li>", "^").Replace("<u>", "").Replace("</u>", "").Trim();
                            CandInfo_Desig = CandInfo_Desig.Replace("<ul>", "").Replace("</ul>", "").Replace("<strong>", "").Replace("</strong>", "").Replace("<li>", "").Replace("</li>", "^").Replace("<u>", "").Replace("</u>", "").Trim();
                            if (CandInfo_Loc.Trim() != "")
                            {
                                if (CandInfo_Loc.Trim().StartsWith("^"))
                                {
                                    CandInfo_Loc = CandInfo_Loc.Remove(0).Trim();
                                }
                                else if (CandInfo_Loc.Trim().EndsWith("^"))
                                {
                                    CandInfo_Loc = CandInfo_Loc.Remove(CandInfo_Loc.Length - 1).Trim();
                                }

                                string[] tDetails = CandInfo_Loc.Split('^');
                                foreach (string tVal in tDetails)
                                {
                                    if (tVal.Trim() != "")
                                    {
                                        if (tVal.Trim().Split(':')[0].Trim().ToLower() == "location")
                                            tLocation = tVal.Trim().Split(':')[1].Trim();
                                        else if (tVal.Trim().Split(':')[0].Trim().ToLower() == "experience")
                                        {
                                            tExp = tVal.Trim().Split(':')[1].Trim();
                                            tExp = System.Text.RegularExpressions.Regex.Replace(tExp, @"[^-?\d+\.]", "").Trim();

                                        }
                                        else if (tVal.Trim().Split(':')[0].Trim().ToLower() == "education")
                                        {
                                            tEducation = StripHTML(tVal.Trim().Split(':')[1].Trim());
                                            //if (tVal.Trim().Split(':')[1].Trim().Contains(","))
                                            //{
                                            //    string tFTemVal = "";
                                            //    foreach (string tFVa in tVal.Trim().Split(':')[1].Trim().Split(','))
                                            //    {
                                            //        if (tFTemVal.Trim() == "" && (!tFTemVal.Trim().ToLower().Contains("college") || !tFTemVal.Trim().ToLower().Contains("university")))
                                            //            tFTemVal = tFVa;
                                            //        else if (!tFTemVal.Trim().ToLower().Contains("college") || !tFTemVal.Trim().ToLower().Contains("university"))
                                            //            tFTemVal = "," + tFVa;
                                            //    }
                                            //    tEducation = tFTemVal.Trim();
                                            //}
                                            //else
                                            //    tEducation = tVal.Trim().Split(':')[1].Trim();

                                        }
                                        else if (tVal.Trim().Split(':')[0].Trim().ToLower() == "designation")
                                        {
                                            tDesignation = tVal.Trim().Split(':')[1].Trim();
                                        }
                                        else if (tVal.Trim().Split(':')[0].Trim().ToLower() == "ctc")
                                        {
                                            tCTC = tVal.Trim().Split(':')[1].Trim();
                                            if (tCTC.Trim().Contains("-"))
                                            {
                                                tCTC = tCTC.Trim().Split('-')[1].Trim();
                                            }
                                            //  tCTC = tCTC.Trim().ToLower().Replace("yr", "").Trim().Replace("rs.", "").Trim().Replace("annually", "").Trim().Replace("years", "").Trim().Replace("year", "").Trim().Replace("per/annum", "").Trim().Replace("per", "").Trim().Replace("/", "").Trim().Replace("annum", "").Trim().Replace("month", "").Trim().Replace("k", "").Trim().Replace("rs", "").Trim().Replace("<", "").Trim().Replace("-", "").Trim().Replace(" lakh", "").Trim();
                                            tCTC = System.Text.RegularExpressions.Regex.Replace(tCTC, @"[^-?\d+\.]", "").Trim();
                                        }
                                        else if (tVal.Trim().Split(':')[0].Trim().ToLower() == "company")
                                            tPrsantCompany = tVal.Trim().Split(':')[1].Trim();
                                        else if (tVal.Trim().Split(':')[0].Trim().ToLower() == "skills")
                                            tSkills = tVal.Trim().Split(':')[1].Trim();
                                        else if (tVal.Trim().Split(':')[0].Trim().ToLower() == "desired job location")
                                            tPreferedLocation = tVal.Trim().Split(':')[1].Trim();

                                    }
                                }
                            }

                            if (CandInfo_Desig.Trim() != "")
                            {
                                if (CandInfo_Desig.Trim().StartsWith("^"))
                                {
                                    CandInfo_Desig = CandInfo_Desig.Remove(0).Trim();
                                }
                                else if (CandInfo_Desig.Trim().EndsWith("^"))
                                {
                                    CandInfo_Desig = CandInfo_Desig.Remove(CandInfo_Desig.Length - 1).Trim();
                                }
                                string[] tDetails1 = CandInfo_Desig.Split('^');
                                foreach (string tVal in tDetails1)
                                {
                                    if (tVal.Trim() != "")
                                    {
                                        if (tVal.Trim().Split(':')[0].Trim().ToLower() == "designation")
                                            tDesignation = tVal.Trim().Split(':')[1].Trim();
                                        else if (tVal.Trim().Split(':')[0].Trim().ToLower() == "ctc")
                                        {
                                            tCTC = tVal.Trim().Split(':')[1].Trim();
                                            if (tCTC.Trim().Contains("-"))
                                            {
                                                tCTC = tCTC.Trim().Split('-')[1].Trim();
                                            }
                                            // tCTC = tCTC.Trim().ToLower().Replace("yr", "").Trim().Replace("rs.", "").Trim().Replace("annually", "").Trim().Replace("years", "").Trim().Replace("year", "").Trim().Replace("per/annum", "").Trim().Replace("per", "").Trim().Replace("/", "").Trim().Replace("annum", "").Trim().Replace("month", "").Trim().Replace("k", "").Trim().Replace("rs", "").Trim().Replace("lakh", "").Trim().Replace("<", "").Trim().Replace("-", "").Trim().Replace(" lakh", "").Trim();

                                            tCTC = System.Text.RegularExpressions.Regex.Replace(tCTC, @"[^-?\d+\.]", "").Trim();

                                        }
                                        else if (tVal.Trim().Split(':')[0].Trim().ToLower() == "company")
                                            tPrsantCompany = tVal.Trim().Split(':')[1].Trim();
                                        else if (tVal.Trim().Split(':')[0].Trim().ToLower() == "location")
                                            tLocation = tVal.Trim().Split(':')[1].Trim();
                                        else if (tVal.Trim().Split(':')[0].Trim().ToLower() == "experience")
                                        {
                                            tExp = tVal.Trim().Split(':')[1].Trim();
                                            tExp = System.Text.RegularExpressions.Regex.Replace(tExp, @"[^-?\d+\.]", "").Trim();
                                        }

                                        else if (tVal.Trim().Split(':')[0].Trim().ToLower() == "skills")
                                            tSkills = tVal.Trim().Split(':')[1].Trim();
                                        else if (tVal.Trim().Split(':')[0].Trim().ToLower() == "desired job location")
                                            tPreferedLocation = tVal.Trim().Split(':')[1].Trim();
                                        else if (tVal.Trim().Split(':')[0].Trim().ToLower() == "education")
                                        {

                                            tEducation = StripHTML(tVal.Trim().Split(':')[1].Trim());
                                            if (tVal.Trim().Split(':')[1].Trim().Contains(","))
                                            {
                                                string tFTemVal = "";
                                                foreach (string tFVa in tVal.Trim().Split(':')[1].Trim().Split(','))
                                                {
                                                    if (tFTemVal.Trim() == "" && (!tFTemVal.Trim().ToLower().Contains("college") || !tFTemVal.Trim().ToLower().Contains("university")))
                                                        tFTemVal = tFVa;
                                                    else if (!tFTemVal.Trim().ToLower().Contains("college") || !tFTemVal.Trim().ToLower().Contains("university"))
                                                        tFTemVal = "," + tFVa;
                                                    else
                                                        break;
                                                }
                                                tEducation = tFTemVal.Trim();
                                            }
                                            else
                                                tEducation = tVal.Trim().Split(':')[1].Trim();
                                        }
                                    }
                                }
                            }
                        }
                        catch { }
                        objElSub = objXnm.CreateElement("CandidateLocation");
                        objElSub.InnerText = tLocation;
                        if (string.IsNullOrEmpty(tLocation) && objHTML1.DocumentNode.SelectNodes(@"//span[@class='anal bor_n dlc_l']").Count > 0)
                        {
                            tLocation = objHTML1.DocumentNode.SelectNodes(@"//span[@class='anal bor_n dlc_l']")[0].InnerText;
                            objElSub.InnerText = tLocation;
                        }
                        objEl.AppendChild(objElSub);

                        objElSub = objXnm.CreateElement("PhoneH");
                        objElSub.InnerText = "";
                        objEl.AppendChild(objElSub);

                        objElSub = objXnm.CreateElement("PresentCTC");
                        objElSub.InnerText = tCTC;
                        objEl.AppendChild(objElSub);

                        objElSub = objXnm.CreateElement("TotalExp");
                        objElSub.InnerText = tExp;
                        objEl.AppendChild(objElSub);

                        objElSub = objXnm.CreateElement("Skill");
                        objElSub.InnerText = StripHTML(tSkills.Trim());
                        objEl.AppendChild(objElSub);

                        objElSub = objXnm.CreateElement("PresentEmployer");
                        objElSub.InnerText = tPrsantCompany;
                        if (string.IsNullOrEmpty(tPrsantCompany) && objHTML1.DocumentNode.SelectNodes(@"//span[@class='anal dlc_c']") != null)
                        {
                            tPrsantCompany = objHTML1.DocumentNode.SelectNodes(@"//span[@class='anal dlc_c']")[0].InnerText;
                            objElSub.InnerText = tPrsantCompany;
                        }
                        objEl.AppendChild(objElSub);

                        string tDesignationIDs = "";
                        objElSub = objXnm.CreateElement("JobTitle");
                        objElSub.InnerText = tDesignation.Split(',')[tDesignation.Split(',').GetLowerBound(0)];
                        if (string.IsNullOrEmpty(tDesignation) && objHTML1.DocumentNode.SelectNodes(@"//span[@class='anal pad_lft0 dlc_d ']") != null)
                        {
                            tDesignation = objHTML1.DocumentNode.SelectNodes(@"//span[@class='anal pad_lft0 dlc_d ']")[0].InnerText;
                            objElSub.InnerText = tDesignation;
                        }
                        if (objElSub.InnerText.Trim() == "")
                            objElSub.InnerText = "<--None-->";
                        objEl.AppendChild(objElSub);
                         

                        objElSub = objXnm.CreateElement("Education"); 
                        objElSub.InnerText = tEducation.Replace("\n", "").Replace("\t\t\t\t\t", ",").Replace("\t", "").Replace("&nbsp;", "").Trim();
                        objEl.AppendChild(objElSub);
                         

                        objElSub = objXnm.CreateElement("URL");
                        objElSub.InnerText = tURL;
                        objEl.AppendChild(objElSub);

                        objElSub = objXnm.CreateElement("PreviousDesignation");
                        objElSub.InnerText = "";
                        objEl.AppendChild(objElSub);

                        objElSub = objXnm.CreateElement("PreviousEmployer");
                        objElSub.InnerText = "";
                        objEl.AppendChild(objElSub);

                        objElSub = objXnm.CreateElement("PrefLocationText");
                        objElSub.InnerText = tPreferedLocation.Trim();
                        objEl.AppendChild(objElSub);
                         
                        objElSub = objXnm.CreateElement("SiteResumeID");
                        objElSub.InnerText = "";
                        objEl.AppendChild(objElSub);

                        objElSub = objXnm.CreateElement("AutoResumeID");
                        objElSub.InnerText = "";
                        objEl.AppendChild(objElSub);

                        objElSub = objXnm.CreateElement("Indicator");
                        objElSub.InnerText = "";
                        objEl.AppendChild(objElSub);


                        objRoot.AppendChild(objEl);

                    }
                    catch { }
                }
            }
        }



        public static string GetGlobalCookies(string uri)
        {
            try
            {
                uint datasize = 1024;
                StringBuilder cookieData = new StringBuilder((int)datasize);
                if (InternetGetCookieEx(uri, null, cookieData, ref datasize, INTERNET_COOKIE_HTTPONLY, IntPtr.Zero) && cookieData.Length > 0)
                    return cookieData.ToString().Replace(';', ',');
                else
                    return null;
            }
            catch { return null; }
        }

        void opCreateMonsterNewVersionINT(string[] ArrSub, string IDs)
        {
            objEl = objXnm.CreateElement("Main");

            objElSub = objXnm.CreateElement("Check");
            objElSub.InnerText = true.ToString();
            objEl.AppendChild(objElSub);
            objElSub = objXnm.CreateElement("ResumeID");
            objElSub.InnerText = "0";
            objEl.AppendChild(objElSub);
            objElSub = objXnm.CreateElement("SavedType");
            objElSub.InnerText = "0";
            objEl.AppendChild(objElSub);
            objElSub = objXnm.CreateElement("IDs");
            objElSub.InnerText = IDs;
            objEl.AppendChild(objElSub);
            string[] tS = { "(M)", "(R)", ",", ":", "Phone", "Mobile", "Telephone" };
            objElSub = objXnm.CreateElement("CandidateName");
            objElSub.InnerText = ArrSub[0].ToString().Replace("\n", "").Replace("\t", "").Trim();
            objEl.AppendChild(objElSub);
            objElSub = objXnm.CreateElement("Mobile");
            objElSub.InnerText = ArrSub[2].ToString().Replace("\n", "").Replace("\t", "").Replace("Mobile:", "").Replace("Telephone:", "").Trim().Replace("&nbsp;", "").Trim();
            objEl.AppendChild(objElSub);

            objElSub = objXnm.CreateElement("PhoneH");
            objElSub.InnerText = ArrSub[1].ToString().Replace("\n", "").Replace("\t", "").Replace("Mobile:", "").Replace("Telephone:", "").Trim().Replace("&nbsp;", "").Trim();
            objEl.AppendChild(objElSub);


            objElSub = objXnm.CreateElement("CandidateLocation");
            objElSub.InnerText = ArrSub[3].ToString().Replace("\n", "").Replace("\t", "").Replace("Current Location:", "").Replace("Location:", "").Replace("Currently in:", "").Trim();
            if (objElSub.InnerText.Trim() == "")
                objElSub.InnerText = "<--None-->";
            objEl.AppendChild(objElSub);

            objElSub = objXnm.CreateElement("PresentEmployer");
            objElSub.InnerText = (ArrSub[4].ToString().Trim().IndexOf("year") >= 0 ? "" : ArrSub[4].ToString()).Replace("\n", "").Replace("\t", "").Replace("&nbsp;", "").Replace("FRESHER", "").Replace("Fresher", "").Replace("Fresher", "").Replace("NONE", "").Replace("None", "").Replace("none", "").Replace("NILL", "").Replace("Nill", "").Replace("nill", "").Replace("Current Employer:", "");
            if (objElSub.InnerText.Trim() == "")
                objElSub.InnerText = "<--None-->";
            objEl.AppendChild(objElSub);
            string tDesignation = "", tDesignationIDs = "";
            //opGetIDs(ArrSub[5].ToString().Replace("\n", "").Replace("\t", "").Replace("&nbsp;", "").Trim(), ref tDesignationIDs, ref tDesignation, HireCraft.ClsFcommonXML.objfXMLJobTitle, "JobTitle", "Includelist");
            if (tDesignation == "")
                tDesignation = ArrSub[5].ToString().Replace("\n", "").Replace("\t", "").Replace("&nbsp;", "").Trim();
            objElSub = objXnm.CreateElement("JobTitle");
            objElSub.InnerText = tDesignation.Split(',')[tDesignation.Split(',').GetLowerBound(0)];
            if (objElSub.InnerText.Trim() == "")
                objElSub.InnerText = "<--None-->";
            objEl.AppendChild(objElSub);
            //objElSub = objXnm.CreateElement("DesignationID");
            //objElSub.InnerText = tDesignationIDs.Split(',')[tDesignationIDs.Split(',').GetLowerBound(0)];
            //objEl.AppendChild(objElSub);
            objElSub = objXnm.CreateElement("Skill");
            objElSub.InnerText = ArrSub[9].ToString().Replace("\n", "").Replace("\t", "").Replace("Skills:", "").Replace("&nbsp;", "").Trim();
            objEl.AppendChild(objElSub);

            objElSub = objXnm.CreateElement("Education");
            string tEducationText = ArrSub[6].ToString().Replace("\n", "").Replace("\t\t\t\t\t", ",").Replace("\t", "").Replace("&nbsp;", "").Trim();
            //opGetIDs(, ref tEducationIDs, ref tEducationText, HireCraft.ClsFcommonXML.objfXMLEducationTypes, "EducationType", "EducationAlias");

            objElSub.InnerText = tEducationText;
            objEl.AppendChild(objElSub);

            //objElSub = objXnm.CreateElement("EducationIDs");
            //objElSub.InnerText = tEducationIDs;
            //objEl.AppendChild(objElSub);

            objElSub = objXnm.CreateElement("PresentCTC");
            objElSub.InnerText = getSalary(ArrSub[7].ToString().Replace("\n", "").Replace("\t", "").Replace("CTC:  USD", "").Replace("+", "").Replace("&nbsp;", "").Replace("CTC(p.a): INR", "").Replace("CTC:  INR", "").Replace("CTC:  INR", "").Replace("Lac(s)", "Lacs").Replace("CTC:", "").Replace("CTC", "").Replace("INR", "").Replace("USD", "").Trim());
            objEl.AppendChild(objElSub);

            objElSub = objXnm.CreateElement("TotalExp");
            objElSub.InnerText = opGetExperience(ArrSub[8].ToString().Replace("Months", "Month").Replace("Month(s)", "Month").Replace("Years", "Year").Replace("Year(s)", "Year").Replace("\n", "").Replace("\t", "").Replace("&nbsp;", "").Replace("Experience:", "").Trim().Replace("Confidential", "").Replace("Exp:", "").Trim()).ToString();
            objEl.AppendChild(objElSub);
            objElSub = objXnm.CreateElement("PreviousDesignation");
            objElSub.InnerText = "";
            objEl.AppendChild(objElSub);
            objElSub = objXnm.CreateElement("PreviousEmployer");
            objElSub.InnerText = "";
            objEl.AppendChild(objElSub);
            objElSub = objXnm.CreateElement("PrefLocationText");
            objElSub.InnerText = "";
            objEl.AppendChild(objElSub);

            //objElSub = objXnm.CreateElement("PrefLocationIDs");
            //objElSub.InnerText = "";
            //objEl.AppendChild(objElSub);
            objElSub = objXnm.CreateElement("SiteResumeID");
            objElSub.InnerText = "";
            objEl.AppendChild(objElSub);
            objElSub = objXnm.CreateElement("AutoResumeID");
            objElSub.InnerText = "";
            objEl.AppendChild(objElSub);
            objElSub = objXnm.CreateElement("Indicator");
            objElSub.InnerText = "";
            objEl.AppendChild(objElSub);
            objRoot.AppendChild(objEl);
        }

        private bool opValidJobSiteMonsterSingapore(string tURL)
        {
            if (System.Text.RegularExpressions.Regex.IsMatch(tURL, @"(recruiter\.monster\.com)&^(monster\.com\.my)", System.Text.RegularExpressions.RegexOptions.IgnoreCase) == true)
                return true;
            else
            {
                //sbar.Text = "Invalid Site...";
                return false;
            }
        }


        // Mohan G on 10-Sep-2014
        private string opGetCTC(string CTC)
        {
            try
            {
                // Spliting Values
                string[] tCTCValue = CTC.Split(' ');
                if (tCTCValue.Length == 1) return tCTCValue[0];


                string tCTC = "";
                if (tCTCValue.Length > 1)
                {
                     
                    decimal dFactor = 1.0M; 

                    if (  dFactor > 0)
                    {
                        tCTC = Convert.ToString(Convert.ToInt64((Convert.ToDecimal(tCTCValue[0].Trim()) * dFactor) * 12));
                    }
                }
                return tCTC;
            }
            catch
            {
                return "";
            }
        }

        void opCreateMonsterNewVersion(string[] ArrSub, string IDs)
        {
            objEl = objXnm.CreateElement("Main");

            objElSub = objXnm.CreateElement("Check");
            objElSub.InnerText = true.ToString();
            objEl.AppendChild(objElSub);
            objElSub = objXnm.CreateElement("ResumeID");
            objElSub.InnerText = "0";
            objEl.AppendChild(objElSub);
            objElSub = objXnm.CreateElement("SavedType");
            objElSub.InnerText = "0";
            objEl.AppendChild(objElSub);
            objElSub = objXnm.CreateElement("IDs");
            objElSub.InnerText = IDs;
            objEl.AppendChild(objElSub);
            string[] tS = { "(M)", "(R)", ",", ":", "Phone", "Mobile", "Telephone" };
            objElSub = objXnm.CreateElement("CandidateName");
            objElSub.InnerText = ArrSub[0].ToString().Replace("\n", "").Replace("\t", "").Trim();
            objEl.AppendChild(objElSub);


            string tPhone = "", tMobile = "";
            string tSearchText = ArrSub[1].ToString() + "," + ArrSub[2].ToString();
            string[] acontact = tSearchText.Replace("\n", "").Replace("\t", "").Replace("Currently in:", "").Trim().Split(tS, StringSplitOptions.RemoveEmptyEntries);
            for (int i = 0; i < acontact.Length; i++)
            {
                if (this.opIsMobile(opTrimString(acontact[i])))
                    tMobile += acontact[i].Trim() + ",";
                else if (this.opIsPhone(opTrimString(acontact[i])))
                    tPhone += acontact[i].Trim() + ",";
            }
            if (tMobile.EndsWith(",")) tMobile = tMobile.Substring(0, tMobile.Length - 1);
            if (tPhone.EndsWith(",")) tPhone = tPhone.Substring(0, tPhone.Length - 1);

            objElSub = objXnm.CreateElement("Mobile");
            objElSub.InnerText = tMobile;// ArrSub[2].ToString().Replace("\n", "").Replace("\t", "").Replace("Mobile:", "").Replace("Telephone:", "").Trim().Replace("&nbsp;", "").Trim();
            objEl.AppendChild(objElSub);

            objElSub = objXnm.CreateElement("PhoneH");
            objElSub.InnerText = tPhone;// ArrSub[2].ToString().Replace("\n", "").Replace("\t", "").Replace("Mobile:", "").Replace("Telephone:", "").Trim().Replace("&nbsp;", "").Trim();
            objEl.AppendChild(objElSub);


            objElSub = objXnm.CreateElement("CandidateLocation");
            objElSub.InnerText = ArrSub[3].ToString().Replace("\n", "").Replace("\t", "").Replace("Current Location:", "").Replace("Location:", "").Replace("Currently in:", "").Trim();
            if (objElSub.InnerText.Trim() == "")
                objElSub.InnerText = "<--None-->";
            objEl.AppendChild(objElSub);

            objElSub = objXnm.CreateElement("PresentEmployer");
            objElSub.InnerText = (ArrSub[4].ToString().Trim().IndexOf("year") >= 0 ? "" : ArrSub[4].ToString()).Replace("\n", "").Replace("\t", "").Replace("&nbsp;", "").Replace("FRESHER", "").Replace("Fresher", "").Replace("Fresher", "").Replace("NONE", "").Replace("None", "").Replace("none", "").Replace("NILL", "").Replace("Nill", "").Replace("nill", "").Replace("Current Employer:", "");
            if (objElSub.InnerText.Trim() == "")
                objElSub.InnerText = "<--None-->";
            objEl.AppendChild(objElSub);
            string tDesignation = "", tDesignationIDs = "";
            if (ArrSub.Length > 11)
                if (!string.IsNullOrEmpty(ArrSub[11]))
                    //opGetIDs(ArrSub[11].ToString().Replace("\n", "").Replace("\t", "").Replace("&nbsp;", "").Trim(), ref tDesignationIDs, ref tDesignation, HireCraft.ClsFcommonXML.objfXMLJobTitle, "JobTitle", "Includelist");

            objElSub = objXnm.CreateElement("JobTitle");
            objElSub.InnerText = tDesignation.Split(',')[tDesignation.Split(',').GetLowerBound(0)];
            if (objElSub.InnerText.Trim() == "")
                objElSub.InnerText = "<--None-->";
            objEl.AppendChild(objElSub);
            objElSub = objXnm.CreateElement("DesignationID");
            objElSub.InnerText = tDesignationIDs.Split(',')[tDesignationIDs.Split(',').GetLowerBound(0)];
            objEl.AppendChild(objElSub);
            objElSub = objXnm.CreateElement("Skill");
            objElSub.InnerText = ArrSub[5].ToString().Replace("\n", "").Replace("\t", "").Replace("Skills:", "").Replace("&nbsp;", "").Trim();
            objEl.AppendChild(objElSub);

            objElSub = objXnm.CreateElement("Education");
            string tEducationText = "", tEducationIDs = "";
            if (ArrSub.Length > 6)
                if (!string.IsNullOrEmpty(ArrSub[6]))
                    tEducationText = ArrSub[6].ToString().Replace("\n", "").Replace("\t\t\t\t\t", ",").Replace("\t", "").Replace("&nbsp;", "").Trim();  //opGetIDs(, ref tEducationIDs, ref tEducationText, HireCraft.ClsFcommonXML.objfXMLEducationTypes, "EducationType", "EducationAlias");

            objElSub.InnerText = tEducationText;
            objEl.AppendChild(objElSub);

            //objElSub = objXnm.CreateElement("EducationIDs");
            //objElSub.InnerText = tEducationIDs;
            //objEl.AppendChild(objElSub);

            objElSub = objXnm.CreateElement("PresentCTC");
            objElSub.InnerText = getSalary(ArrSub[7].ToString().Replace("\n", "").Replace("\t", "").Replace("CTC:  USD", "").Replace("+", "").Replace("&nbsp;", "").Replace("CTC(p.a): INR", "").Replace("CTC:  INR", "").Replace("CTC:  INR", "").Replace("Lac(s)", "Lacs").Replace("CTC:", "").Replace("CTC", "").Replace("INR", "").Replace("USD", "").Replace("SGD", "").Replace("MYR", "").Trim());
            objEl.AppendChild(objElSub);

            objElSub = objXnm.CreateElement("TotalExp");
            objElSub.InnerText = opGetExperience(ArrSub[8].ToString().Replace("Months", "Month").Replace("Month(s)", "Month").Replace("Years", "Year").Replace("Year(s)", "Year").Replace("\n", "").Replace("\t", "").Replace("&nbsp;", "").Replace("Experience:", "").Trim().Replace("Confidential", "").Replace("Exp:", "").Trim()).ToString();
            objEl.AppendChild(objElSub);
            objElSub = objXnm.CreateElement("PreviousDesignation");
            objElSub.InnerText = "";
            objEl.AppendChild(objElSub);
            objElSub = objXnm.CreateElement("PreviousEmployer");
            objElSub.InnerText = "";
            objEl.AppendChild(objElSub);
            string PrefLocationTex = "", PrefLocationIDs = "";
            if (ArrSub.Length > 9)
                if (!string.IsNullOrEmpty(ArrSub[9]))
                  PrefLocationTex= ArrSub[9]; // opGetIDs(ArrSub[9].ToString().Replace("\n", "").Replace("\t\t\t\t\t", ",").Replace("\t", "").Replace("&nbsp;", "").Trim(), ref PrefLocationIDs, ref PrefLocationTex, HireCraft.ClsFcommonXML.objfXMLResumeLocations, "LocationTitle", "LocationAlias");

            objElSub = objXnm.CreateElement("PrefLocationText");
            objElSub.InnerText = PrefLocationTex;
            objEl.AppendChild(objElSub);

            //objElSub = objXnm.CreateElement("PrefLocationIDs");
            //objElSub.InnerText = PrefLocationIDs;
            //objEl.AppendChild(objElSub);

            objElSub = objXnm.CreateElement("SiteResumeID");
            if (ArrSub.Length > 10)
                objElSub.InnerText = ArrSub[10];
            else
                objElSub.InnerText = "";
            objEl.AppendChild(objElSub);
            objElSub = objXnm.CreateElement("AutoResumeID");
            objElSub.InnerText = "";
            objEl.AppendChild(objElSub);
            objElSub = objXnm.CreateElement("Indicator");
            objElSub.InnerText = "";
            objEl.AppendChild(objElSub);
            objRoot.AppendChild(objEl);
        }

        void opCreateMonsterNewVersionMy(string[] ArrSub, string IDs)
        {
            objEl = objXnm.CreateElement("Main");

            objElSub = objXnm.CreateElement("Check");
            objElSub.InnerText = true.ToString();
            objEl.AppendChild(objElSub);
            objElSub = objXnm.CreateElement("ResumeID");
            objElSub.InnerText = "0";
            objEl.AppendChild(objElSub);
            objElSub = objXnm.CreateElement("SavedType");
            objElSub.InnerText = "0";
            objEl.AppendChild(objElSub);
            objElSub = objXnm.CreateElement("IDs");
            objElSub.InnerText = IDs;
            objEl.AppendChild(objElSub);
            string[] tS = { "(M)", "(R)", ",", ":", "Phone", "Mobile", "Telephone" };
            objElSub = objXnm.CreateElement("CandidateName");
            objElSub.InnerText = ArrSub[0].ToString().Replace("\n", "").Replace("\t", "").Trim();
            objEl.AppendChild(objElSub);


            //string tPhone = ArrSub[1].ToString(), tMobile = "";
            //string tSearchText = ArrSub[1].ToString() + "," + ArrSub[2].ToString();
            //string[] acontact = tSearchText.Replace("\n", "").Replace("\t", "").Replace("Currently in:", "").Trim().Split(tS, StringSplitOptions.RemoveEmptyEntries);
            //for (int i = 0; i < acontact.Length; i++)
            //{
            //    if (this.opIsMobile(opTrimString(acontact[i])))
            //        tMobile += acontact[i].Trim() + ",";
            //    else if (this.opIsPhone(opTrimString(acontact[i])))
            //        tPhone += acontact[i].Trim() + ",";
            //}
            //if (tMobile.EndsWith(",")) tMobile = tMobile.Substring(0, tMobile.Length - 1);
            //if (tPhone.EndsWith(",")) tPhone = tPhone.Substring(0, tPhone.Length - 1);
            objElSub = objXnm.CreateElement("Mobile");
            objElSub.InnerText = ArrSub[2].ToString().Replace("\n", "").Replace("\t", "").Replace("Mobile:", "").Replace("Telephone:", "").Trim().Replace("&nbsp;", "").Trim();
            objEl.AppendChild(objElSub);

            objElSub = objXnm.CreateElement("PhoneH");
            objElSub.InnerText = ArrSub[1].ToString().Replace("\n", "").Replace("\t", "").Replace("Mobile:", "").Replace("Telephone:", "").Trim().Replace("&nbsp;", "").Trim();
            objEl.AppendChild(objElSub);


            objElSub = objXnm.CreateElement("CandidateLocation");
            objElSub.InnerText = ArrSub[3].ToString().Replace("\n", "").Replace("\t", "").Replace("Current Location:", "").Replace("Location:", "").Replace("Currently in:", "").Trim();
            if (objElSub.InnerText.Trim() == "")
                objElSub.InnerText = "<--None-->";
            objEl.AppendChild(objElSub);

            objElSub = objXnm.CreateElement("PresentEmployer");
            objElSub.InnerText = (ArrSub[4].ToString().Trim().IndexOf("year") >= 0 ? "" : ArrSub[4].ToString()).Replace("\n", "").Replace("\t", "").Replace("&nbsp;", "").Replace("FRESHER", "").Replace("Fresher", "").Replace("Fresher", "").Replace("NONE", "").Replace("None", "").Replace("none", "").Replace("NILL", "").Replace("Nill", "").Replace("nill", "").Replace("Current Employer:", "");
            if (objElSub.InnerText.Trim() == "")
                objElSub.InnerText = "<--None-->";
            objEl.AppendChild(objElSub);
            string tDesignation = ArrSub[5].ToString().Replace("\n", "").Replace("\t", "").Replace("&nbsp;", "").Trim();
            //opGetIDs(, ref tDesignationIDs, ref tDesignation, HireCraft.ClsFcommonXML.objfXMLJobTitle, "JobTitle", "Includelist");

            objElSub = objXnm.CreateElement("JobTitle");
            objElSub.InnerText = tDesignation.Split(',')[tDesignation.Split(',').GetLowerBound(0)];
            if (objElSub.InnerText.Trim() == "")
                objElSub.InnerText = "<--None-->";
            objEl.AppendChild(objElSub);
            //objElSub = objXnm.CreateElement("DesignationID");
            //objElSub.InnerText = tDesignationIDs.Split(',')[tDesignationIDs.Split(',').GetLowerBound(0)];
            //objEl.AppendChild(objElSub);
            objElSub = objXnm.CreateElement("Skill");
            objElSub.InnerText = "";//ArrSub[5].ToString().Replace("\n", "").Replace("\t", "").Replace("Skills:", "").Replace("&nbsp;", "").Trim();
            objEl.AppendChild(objElSub);

            objElSub = objXnm.CreateElement("Education");
            string tEducationText = ArrSub[6].ToString().Replace("\n", "").Replace("\t\t\t\t\t", ",").Replace("\t", "").Replace("&nbsp;", "").Trim();
            //opGetIDs(, ref tEducationIDs, ref tEducationText, HireCraft.ClsFcommonXML.objfXMLEducationTypes, "EducationType", "EducationAlias");

            objElSub.InnerText = tEducationText;
            objEl.AppendChild(objElSub);

            //objElSub = objXnm.CreateElement("EducationIDs");
            //objElSub.InnerText = tEducationIDs;
            //objEl.AppendChild(objElSub);

            objElSub = objXnm.CreateElement("PresentCTC");
            objElSub.InnerText = getSalary(ArrSub[7].ToString().Replace("\n", "").Replace("\t", "").Replace("CTC:  USD", "").Replace("+", "").Replace("&nbsp;", "").Replace("CTC(p.a): INR", "").Replace("CTC:  INR", "").Replace("CTC:  INR", "").Replace("Lac(s)", "Lacs").Replace("CTC:", "").Replace("CTC", "").Replace("INR", "").Replace("USD", "").Trim());
            objEl.AppendChild(objElSub);

            objElSub = objXnm.CreateElement("TotalExp");
            objElSub.InnerText = opGetExperience(ArrSub[8].ToString().Replace("Months", "Month").Replace("Month(s)", "Month").Replace("Years", "Year").Replace("Year(s)", "Year").Replace("\n", "").Replace("\t", "").Replace("&nbsp;", "").Replace("Experience:", "").Trim().Replace("Confidential", "").Replace("Exp:", "").Trim()).ToString();
            objEl.AppendChild(objElSub);
            objElSub = objXnm.CreateElement("PreviousDesignation");
            objElSub.InnerText = "";
            objEl.AppendChild(objElSub);
            objElSub = objXnm.CreateElement("PreviousEmployer");
            objElSub.InnerText = "";
            objEl.AppendChild(objElSub);
            string PrefLocationTex = "", PrefLocationIDs = "";
            if (ArrSub.Length > 9)
                PrefLocationTex = ArrSub[9].ToString().Replace("\n", "").Replace("\t\t\t\t\t", ",").Replace("\t", "").Replace("&nbsp;", "").Trim();// opGetIDs(, ref PrefLocationIDs, ref PrefLocationTex, HireCraft.ClsFcommonXML.objfXMLResumeLocations, "LocationTitle", "LocationAlias");

            objElSub = objXnm.CreateElement("PrefLocationText");
            objElSub.InnerText = PrefLocationTex;
            objEl.AppendChild(objElSub);

            //objElSub = objXnm.CreateElement("PrefLocationIDs");
            //objElSub.InnerText = PrefLocationIDs;
            //objEl.AppendChild(objElSub);

            objElSub = objXnm.CreateElement("SiteResumeID");
            if (ArrSub.Length > 10)
                objElSub.InnerText = ArrSub[10];
            else
                objElSub.InnerText = "";
            objEl.AppendChild(objElSub);
            objElSub = objXnm.CreateElement("AutoResumeID");
            objElSub.InnerText = "";
            objEl.AppendChild(objElSub);
            objElSub = objXnm.CreateElement("Indicator");
            objElSub.InnerText = "";
            objEl.AppendChild(objElSub);
            objRoot.AppendChild(objEl);
        }

        private string RemoveHTMLNew(string strText)
        {
            string TAGLIST
                  = ";!--;!DOCTYPE;A;ACRONYM;ADDRESS;APPLET;AREA;B;BASE;BASEFONT;" +
                    "BGSOUND;BIG;BLOCKQUOTE;BODY;BR;BR/;BUTTON;CAPTION;CENTER;CITE;CODE;" +
                    "COL;COLGROUP;COMMENT;DD;DEL;DFN;DIR;DIV;DL;DT;EM;EMBED;FIELDSET;" +
                    "FONT;FORM;FRAME;FRAMESET;HEAD;H1;H2;H3;H4;H5;H6;HR;HTML;I;IFRAME;IMG;" +
                    "INPUT;INS;ISINDEX;KBD;LABEL;LAYER;LAGEND;LI;LINK;LISTING;MAP;MARQUEE;" +
                    "MENU;META;NOBR;NOFRAMES;NOSCRIPT;OBJECT;OL;OPTION;P;PARAM;PLAINTEXT;" +
                    "PRE;Q;S;SAMP;SCRIPT;SELECT;SMALL;SPAN;STRIKE;STRONG;STYLE;SUB;SUP;" +
                    "TABLE;TBODY;TD;TEXTAREA;TFOOT;TH;THEAD;TITLE;TR;TT;U;UL;VAR;WBR;XMP;RESUMETITLE;";
            const string BLOCKTAGLIST = ";APPLET;EMBED;FRAMESET;HEAD;NOFRAMES;NOSCRIPT;OBJECT;SCRIPT;STYLE;";
            int nPos1 = 0;
            int nPos2 = 0;
            int nPos3 = 0;
            string strResult = "";
            string strTagName = "";
            bool bRemove;
            bool bSearchForBlock;
            nPos1 = strText.IndexOf("<");
            while (nPos1 >= 0)
            {
                nPos2 = strText.IndexOf(">", nPos1 + 1);
                if (nPos2 >= 0)
                {
                    strTagName = strText.Substring(nPos1 + 1, nPos2 - nPos1 - 1);

                    strTagName = strTagName.Replace("\r", " ").Replace("\n", " ");

                    nPos3 = strTagName.IndexOf(" ");

                    if (nPos3 > 0) strTagName = strTagName.Substring(0, nPos3);

                    if (strTagName.Substring(0, 1) == "/")
                    {
                        strTagName = strTagName.Substring(1);
                        bSearchForBlock = false;
                    }
                    else bSearchForBlock = true;
                    if (TAGLIST.IndexOf(";" + strTagName.ToUpper() + ";", 0) >= 0)
                    {
                        bRemove = true;
                        if (bSearchForBlock)
                        {
                            if (BLOCKTAGLIST.IndexOf(";" + strTagName.ToUpper() + ";") >= 0)
                            {
                                nPos2 = strText.Length;
                                nPos3 = strText.IndexOf("</" + strTagName, nPos1 + 1);
                                if (nPos3 > 0) nPos3 = strText.IndexOf(">", nPos3 + 1);
                                if (nPos3 > 0) nPos2 = nPos3;
                            }
                        }
                    }
                    else bRemove = false;
                    if (string.Compare(strTagName, "BR", true) == 0 || string.Compare(strTagName, "BR/", true) == 0 || string.Compare(strTagName, "span", true) == 0 || string.Compare(strTagName, "div", true) == 0)
                        strResult = strResult + System.Environment.NewLine;
                    if (bRemove)
                    {
                        strResult = strResult + strText.Substring(0, nPos1).Trim();
                        strText = strText.Substring(nPos2 + 1).Trim();
                    }
                    else
                    {
                        strResult = strResult + strText.Substring(nPos1).Trim();
                        strText = strText.Substring(nPos1 + 1).Trim();
                    }
                }
                else
                {
                    strResult = strResult + strText;
                    strText = "";
                }
                nPos1 = strText.IndexOf("<");
            }
            strResult = strResult + strText;
            strResult = strResult.Replace("\r\n\r\n", "\r\n");
            return strResult;
        }

        void opCreateNodesTimesJob(string[] ArrSub, string IDs)
        {
            if (true)
            {
                objEl = objXnm.CreateElement("Main");
                objElSub = objXnm.CreateElement("Check");
                objElSub.InnerText = true.ToString();
                objEl.AppendChild(objElSub);
                objElSub = objXnm.CreateElement("ResumeID");
                objElSub.InnerText = "0";
                objEl.AppendChild(objElSub);
                objElSub = objXnm.CreateElement("SavedType");
                objElSub.InnerText = "0";
                objEl.AppendChild(objElSub);
                objElSub = objXnm.CreateElement("IDs");
                objElSub.InnerText = IDs;
                objEl.AppendChild(objElSub);
                objElSub = objXnm.CreateElement("CandidateName");
                objElSub.InnerText = ArrSub[1].ToString().Replace("\n", "").Replace("\t", "").Trim();
                objEl.AppendChild(objElSub);
                string[] tS = { "(M)", "(R)", ",", ":" };
                string tPhone = "", tMobile = "";
                string[] acontact = ArrSub[2].ToString().Replace("\n", "").Replace("\t", "").Replace("Currently in:", "").Trim().Split(tS, StringSplitOptions.RemoveEmptyEntries);
                for (int i = 0; i < acontact.Length; i++)
                {
                    if (this.opIsMobile(opTrimString(acontact[i])))
                        tMobile += acontact[i].Trim() + ",";
                    else if (this.opIsPhone(opTrimString(acontact[i])))
                        tPhone += acontact[i].Trim() + ",";
                }
                if (tMobile.EndsWith(",")) tMobile = tMobile.Substring(0, tMobile.Length - 1);
                if (tPhone.EndsWith(",")) tPhone = tPhone.Substring(0, tPhone.Length - 1);
                objElSub = objXnm.CreateElement("Mobile");
                objElSub.InnerText = tMobile.Replace("+", "");// ArrSub[2].ToString().Replace("\n", "").Replace("\t", "").Replace("Mobile:", "").Replace("Telephone:", "").Trim().Replace("&nbsp;", "").Trim();
                objEl.AppendChild(objElSub);
                objElSub = objXnm.CreateElement("PhoneH");
                objElSub.InnerText = tPhone.Replace("+", "");// ArrSub[2].ToString().Replace("\n", "").Replace("\t", "").Replace("Mobile:", "").Replace("Telephone:", "").Trim().Replace("&nbsp;", "").Trim();
                objEl.AppendChild(objElSub);
                objElSub = objXnm.CreateElement("CandidateLocation");
                objElSub.InnerText = ArrSub[3].ToString().Replace("Location", "").Replace("location", "").Replace(":", "").Replace("\n", "").Replace("\t", "").Replace("Mobile:", "").Replace("Telephone:", "").Trim(); ;
                if (objElSub.InnerText.Trim() == "")
                    objElSub.InnerText = "<--None-->";
                objEl.AppendChild(objElSub);
                if (ArrSub.Length > 3)
                {
                    objElSub = objXnm.CreateElement("PresentEmployer");
                    objElSub.InnerText = ArrSub[4].ToString().Replace("\n", "").Replace("\t", "").Replace("&nbsp;", "").Replace("FRESHER", "").Replace("Fresher", "").Replace("fresher", "").Replace("NONE", "").Replace("None", "").Replace("none", "").Replace("NILL", "").Replace("Nill", "").Replace("nill", "").Replace("Confidential", "").Replace("NA", "").Trim();
                    if (objElSub.InnerText.Trim() == "")
                        objElSub.InnerText = "<--None-->";
                    objEl.AppendChild(objElSub);
                }
                string tDesignation = "", tDesignationIDs = "";
                if (ArrSub.Length > 9)
                  tDesignation=ArrSub[9].ToString() ;// opGetIDs(ArrSub[9].ToString().Replace("Experience:", "").Replace("\n", "").Replace("\t", "").Replace("&nbsp;", "").Trim().Replace("Confidential", "").Trim().ToString(), ref tDesignationIDs, ref tDesignation, HireCraft.ClsFcommonXML.objfXMLJobTitle, "JobTitle", "Includelist");
                if (tDesignation == "")
                    if (ArrSub.Length > 9)
                        tDesignation = ArrSub[9].ToString().Replace("\n", "").Replace("\t", "").Replace("&nbsp;", "").Trim();
                objElSub = objXnm.CreateElement("JobTitle");
                objElSub.InnerText = tDesignation.Split(',')[tDesignation.Split(',').GetLowerBound(0)];
                if (objElSub.InnerText.Trim() == "")
                    objElSub.InnerText = "<--None-->";
                objEl.AppendChild(objElSub);
                objElSub = objXnm.CreateElement("DesignationID");
                objElSub.InnerText = tDesignationIDs.Split(',')[tDesignationIDs.Split(',').GetLowerBound(0)];
                objEl.AppendChild(objElSub);
                objElSub = objXnm.CreateElement("Skill");
                objElSub.InnerText = ArrSub[5].ToString().Replace("\n", "").Replace("\t", "").Replace("&nbsp;", "").Trim();
                objEl.AppendChild(objElSub);
                objElSub = objXnm.CreateElement("Education");
                string tEducationText = ArrSub[8].ToString().Replace("\n", "").Replace("\t\t\t\t\t", ",").Replace("from", ",").Replace("University", "University,").Replace("\t", "").Replace("&nbsp;", "").Trim();
                //opGetIDs(, ref tEducationIDs, ref tEducationText, HireCraft.ClsFcommonXML.objfXMLEducationTypes, "EducationType", "EducationAlias");
                objElSub.InnerText = tEducationText;
                objEl.AppendChild(objElSub);
                //objElSub = objXnm.CreateElement("EducationIDs");
                //objElSub.InnerText = tEducationIDs;
                //objEl.AppendChild(objElSub);
                objElSub = objXnm.CreateElement("PresentCTC");
                objElSub.InnerText = getSalary(ArrSub[6].ToString().Replace("£", "").Replace("\n", "").Replace("\t", "").Replace("&nbsp;", "").Replace("CTC(p.a): INR", "").Replace("Rs.", "").Replace("Rs", "").Replace("CTC:", "").Replace("CTC", "").Replace("INR", "").Replace("USD", "").Trim());
                objEl.AppendChild(objElSub);
                objElSub = objXnm.CreateElement("TotalExp");
                objElSub.InnerText = opGetExperience(ArrSub[7].ToString().Replace("Month(s)", "Month").Replace("Year(s)", "Year").Replace("\n", "").Replace("\t", "").Replace("&nbsp;", "").Trim().Replace("Confidential", "").Trim()).ToString();
                objEl.AppendChild(objElSub);
                objElSub = objXnm.CreateElement("PreviousDesignation");
                if (ArrSub.Length > 10)
                    objElSub.InnerText = ArrSub[10].ToString();
                else
                    objElSub.InnerText = "";

                objEl.AppendChild(objElSub);

                objElSub = objXnm.CreateElement("PreviousEmployer");
                if (ArrSub.Length > 11)
                    objElSub.InnerText = ArrSub[11].ToString();
                else
                    objElSub.InnerText = "";
                objEl.AppendChild(objElSub);
                objElSub = objXnm.CreateElement("PrefLocationText");
                objElSub.InnerText = "";
                objEl.AppendChild(objElSub);

                //objElSub = objXnm.CreateElement("PrefLocationIDs");
                //objElSub.InnerText = "";
                //objEl.AppendChild(objElSub);
                objElSub = objXnm.CreateElement("SiteResumeID");
                objElSub.InnerText = "";
                objEl.AppendChild(objElSub);
                objElSub = objXnm.CreateElement("AutoResumeID");
                objElSub.InnerText = "";
                objEl.AppendChild(objElSub);
                objElSub = objXnm.CreateElement("Indicator");
                objElSub.InnerText = "";
                objEl.AppendChild(objElSub);
                objRoot.AppendChild(objEl);
            }
        }

        void opCreateNodesCATS(string[] ArrSub, string IDs)
        {
            if (true)
            {
                objEl = objXnm.CreateElement("Main");
                objElSub = objXnm.CreateElement("Check");
                objElSub.InnerText = true.ToString();
                objEl.AppendChild(objElSub);
                objElSub = objXnm.CreateElement("ResumeID");
                objElSub.InnerText = "0";
                objEl.AppendChild(objElSub);
                objElSub = objXnm.CreateElement("SavedType");
                objElSub.InnerText = "0";
                objEl.AppendChild(objElSub);
                objElSub = objXnm.CreateElement("IDs");
                objElSub.InnerText = IDs;
                objEl.AppendChild(objElSub);
                objElSub = objXnm.CreateElement("CandidateName");
                objElSub.InnerText = ArrSub[1].ToString().Replace("\n", "").Replace("\t", "").Trim();
                objEl.AppendChild(objElSub);
                string[] tS = { "(M)", "(R)", ",", ":" };
                string tPhone = "", tMobile = "";
                string[] acontact = ArrSub[2].ToString().Replace("\n", "").Replace("\t", "").Replace("Currently in:", "").Trim().Split(tS, StringSplitOptions.RemoveEmptyEntries);
                for (int i = 0; i < acontact.Length; i++)
                {
                    if (this.opIsMobile(opTrimString(acontact[i])))
                        tMobile += acontact[i].Trim() + ",";
                    else if (this.opIsPhone(opTrimString(acontact[i])))
                        tPhone += acontact[i].Trim() + ",";
                }
                if (tMobile.EndsWith(",")) tMobile = tMobile.Substring(0, tMobile.Length - 1);
                if (tPhone.EndsWith(",")) tPhone = tPhone.Substring(0, tPhone.Length - 1);
                objElSub = objXnm.CreateElement("Mobile");
                objElSub.InnerText = tMobile.Replace("+", "");// ArrSub[2].ToString().Replace("\n", "").Replace("\t", "").Replace("Mobile:", "").Replace("Telephone:", "").Trim().Replace("&nbsp;", "").Trim();
                objEl.AppendChild(objElSub);
                objElSub = objXnm.CreateElement("PhoneH");
                objElSub.InnerText = tPhone.Replace("+", "");// ArrSub[2].ToString().Replace("\n", "").Replace("\t", "").Replace("Mobile:", "").Replace("Telephone:", "").Trim().Replace("&nbsp;", "").Trim();
                objEl.AppendChild(objElSub);
                objElSub = objXnm.CreateElement("CandidateLocation");
                objElSub.InnerText = ArrSub[3].ToString().Replace("Location", "").Replace("location", "").Replace(":", "").Replace("\n", "").Replace("\t", "").Replace("Mobile:", "").Replace("Telephone:", "").Trim(); ;
                if (objElSub.InnerText.Trim() == "")
                    objElSub.InnerText = "<--None-->";
                objEl.AppendChild(objElSub);
                if (ArrSub.Length > 3)
                {
                    objElSub = objXnm.CreateElement("PresentEmployer");
                    objElSub.InnerText = ArrSub[4].ToString().Replace("\n", "").Replace("\t", "").Replace("&nbsp;", "").Replace("FRESHER", "").Replace("Fresher", "").Replace("fresher", "").Replace("NONE", "").Replace("None", "").Replace("none", "").Replace("NILL", "").Replace("Nill", "").Replace("nill", "").Replace("Confidential", "").Replace("NA", "").Trim();
                    if (objElSub.InnerText.Trim() == "")
                        objElSub.InnerText = "<--None-->";
                    objEl.AppendChild(objElSub);
                }
                string tDesignation = "", tDesignationIDs = "";
                if (ArrSub.Length > 8)
                    tDesignation = ArrSub[8].ToString().Replace("Experience:", "").Replace("\n", "").Replace("\t", "").Replace("&nbsp;", "").Trim().Replace("Confidential", "").Trim().ToString(); 
                if (tDesignation == "")
                    if (ArrSub.Length > 8) tDesignation = ArrSub[8].ToString().Replace("Experience:", "").Replace("\n", "").Replace("\t", "").Replace("&nbsp;", "").Trim();

                objElSub = objXnm.CreateElement("JobTitle");
                objElSub.InnerText = tDesignation.Split(',')[tDesignation.Split(',').GetLowerBound(0)];
                if (objElSub.InnerText.Trim() == "")
                    objElSub.InnerText = "<--None-->";
                objEl.AppendChild(objElSub);
                //objElSub = objXnm.CreateElement("DesignationID");
                //objElSub.InnerText = tDesignationIDs.Split(',')[tDesignationIDs.Split(',').GetLowerBound(0)];
                //objEl.AppendChild(objElSub);
                objElSub = objXnm.CreateElement("Skill");
                objElSub.InnerText = ArrSub[5].ToString().Replace("\n", "").Replace("\t", "").Replace("&nbsp;", "").Trim();
                objEl.AppendChild(objElSub);
                objElSub = objXnm.CreateElement("Education");
                string tEducationText = ArrSub[8].ToString().Replace("\n", "").Replace("\t\t\t\t\t", ",").Replace("from", ",").Replace("University", "University,").Replace("\t", "").Replace("&nbsp;", "").Trim() ;
                objElSub.InnerText = tEducationText;
                objEl.AppendChild(objElSub);
                //objElSub = objXnm.CreateElement("EducationIDs");
                //objElSub.InnerText = "";
                //objEl.AppendChild(objElSub);
                objElSub = objXnm.CreateElement("PresentCTC");
                objElSub.InnerText = getSalaryCats(ArrSub[6].ToString().Replace("£", "").Replace("\n", "").Replace("\t", "").Replace("&nbsp;", "").Replace("CTC(p.a): INR", "").Replace("Rs", "").Replace("CTC:", "").Replace("CTC", "").Replace("INR", "").Replace("USD", "").Trim());
                objEl.AppendChild(objElSub);
                objElSub = objXnm.CreateElement("TotalExp");
                objElSub.InnerText = opGetExperience(ArrSub[7].ToString().Replace("Month(s)", "Month").Replace("Year(s)", "Year").Replace("\n", "").Replace("\t", "").Replace("&nbsp;", "").Trim().Replace("Confidential", "").Trim()).ToString();
                objEl.AppendChild(objElSub);
                objElSub = objXnm.CreateElement("PreviousDesignation");
                objElSub.InnerText = "";
                objEl.AppendChild(objElSub);
                objElSub = objXnm.CreateElement("PreviousEmployer");
                objElSub.InnerText = "";
                objEl.AppendChild(objElSub);

                objElSub = objXnm.CreateElement("PrefLocationText");
                objElSub.InnerText = "";
                objEl.AppendChild(objElSub);

                //objElSub = objXnm.CreateElement("PrefLocationIDs");
                //objElSub.InnerText = "";
                //objEl.AppendChild(objElSub);
                objElSub = objXnm.CreateElement("SiteResumeID");
                objElSub.InnerText = "";
                objEl.AppendChild(objElSub);

                objElSub = objXnm.CreateElement("AutoResumeID");
                objElSub.InnerText = "";
                objEl.AppendChild(objElSub);
                objElSub = objXnm.CreateElement("Indicator");
                objElSub.InnerText = "";
                objEl.AppendChild(objElSub);
                objRoot.AppendChild(objEl);
            }
        }


        private bool opValidURL(string tURL)
        {
            if (System.Text.RegularExpressions.Regex.IsMatch(tURL, @"(?<Protocol>\w+):\/\/(?<Domain>[\w@][\w.:@]+)\/?[\w\.?=%&=\-@/$,]*\/?"))
                return true;
            else
            {
                 opSetMessage("Invalid URL...");
                return false;
            }

        }
        private bool opValidJobSiteMonster(string tURL)
        {
            if (System.Text.RegularExpressions.Regex.IsMatch(tURL, @"(monsterindia\.com)", System.Text.RegularExpressions.RegexOptions.IgnoreCase) == true)
                return true;
            else
            {
                //sbar.Text = "Invalid Site...";
                return false;
            }
        }
        private bool opValidJobSiteMonsterMalaysia(string tURL)
        {
            if (System.Text.RegularExpressions.Regex.IsMatch(tURL, @"(monster\.com\.my)", System.Text.RegularExpressions.RegexOptions.IgnoreCase) == true)
                return true;
            else
            {
                //sbar.Text = "Invalid Site...";
                return false;
            }
        }
        private bool opValidJobSiteMonstergulf(string tURL)
        {
            if (System.Text.RegularExpressions.Regex.IsMatch(tURL, @"(monstergulf\.com)", System.Text.RegularExpressions.RegexOptions.IgnoreCase) == true)
                return true;
            else
            {
                //sbar.Text = "Invalid Site...";
                return false;
            }
        }
        private bool opValidJobSiteNaukri(string tURL)
        {
            if (System.Text.RegularExpressions.Regex.IsMatch(tURL, @"(resdex\.naukri\.com)", System.Text.RegularExpressions.RegexOptions.IgnoreCase) == true)
                return true;
            else
            {
                //sbar.Text = "Invalid Site...";
                return false;
            }
        }
        private bool opValidJobSiteResponseBRVNaukri(string tURL) //response
        {
            if (System.Text.RegularExpressions.Regex.IsMatch(tURL, @"(response\.naukri\.com/brv)", System.Text.RegularExpressions.RegexOptions.IgnoreCase) == true)
                return true;
            else
            {
                //sbar.Text = "Invalid Site...";
                return false;
            }
        }
        private bool opValidJobSiteResponseeAppNaukri(string tURL) //response
        {
            if (System.Text.RegularExpressions.Regex.IsMatch(tURL, @"(response\.naukri\.com/responsemanager/search)", System.Text.RegularExpressions.RegexOptions.IgnoreCase) == true)
                return true;
            else
            {
                //sbar.Text = "Invalid Site...";http://response.naukri.com/responsemanager/search/setSrchSess
                return false;
            }
        }
        private bool opValidCareerBuilder(string tURL)
        {
            if (System.Text.RegularExpressions.Regex.IsMatch(tURL, @"(careerbuilder\.com)", System.Text.RegularExpressions.RegexOptions.IgnoreCase) == true)
                return true;
            else
            {

                return false;
            }
        }
        private bool opValidDice(string tURL)
        {
            if (System.Text.RegularExpressions.Regex.IsMatch(tURL, @"(employer.dice\.com)", System.Text.RegularExpressions.RegexOptions.IgnoreCase) == true)
                return true;
            else
            {

                return false;
            }
        }
        private bool opValidJobSiteNaukrigulf(string tURL)
        {
            if (System.Text.RegularExpressions.Regex.IsMatch(tURL, @"(naukrigulf\.com)", System.Text.RegularExpressions.RegexOptions.IgnoreCase) == true)
                return true;
            else
                return false;
        }
        private bool opValidJobSiteResponseNaukriGulf(string tURL) //Naukri Gulf response
        {
            if (System.Text.RegularExpressions.Regex.IsMatch(tURL, @"(naukrigulf\.com/ng/rm/AdvancedSearch)", System.Text.RegularExpressions.RegexOptions.IgnoreCase) == true)
                return true;
            else if (System.Text.RegularExpressions.Regex.IsMatch(tURL, @"(naukrigulf\.com/ng/rm/CvPreview)", System.Text.RegularExpressions.RegexOptions.IgnoreCase) == true)
                return true;
            else
            {
                //sbar.Text = "Invalid Site...";
                return false;
            }
        }
        void opCreateNodesNaukri(string[] ArrSub, string IDs)
        {
            if (true)
            {


                objEl = objXnm.CreateElement("Main");

                objElSub = objXnm.CreateElement("Check");
                objElSub.InnerText = true.ToString();
                objEl.AppendChild(objElSub);
                objElSub = objXnm.CreateElement("ResumeID");
                objElSub.InnerText = "0";
                objEl.AppendChild(objElSub);
                objElSub = objXnm.CreateElement("SavedType");
                objElSub.InnerText = "0";
                objEl.AppendChild(objElSub);
                objElSub = objXnm.CreateElement("IDs");
                objElSub.InnerText = IDs;
                objEl.AppendChild(objElSub);

                objElSub = objXnm.CreateElement("CandidateName");
                objElSub.InnerText = ArrSub[1].ToString().Replace("\n", "").Replace("\t", "").Replace("featured", "").Replace("Featured", "").Replace("FEATURED", "").Trim();
                objEl.AppendChild(objElSub);

                string[] tS = { "(M)", "(R)", ",", ":", "Phone", "Mobile" };
                string tPhone = "", tMobile = "";
                string[] acontact = ArrSub[2].ToString().Replace("&nbsp;", ",").Replace("\n", "").Replace("\t", "").Replace("Currently in:", "").Replace("Verified", ",").Trim().Split(tS, StringSplitOptions.RemoveEmptyEntries);
                for (int i = 0; i < acontact.Length; i++)
                {
                    if (this.opIsMobile(opTrimString(acontact[i])))
                        tMobile += acontact[i].Trim() + ",";
                    else if (this.opIsPhone(opTrimString(acontact[i])))
                        tPhone += acontact[i].Trim() + ",";
                }
                if (tMobile.EndsWith(",")) tMobile = tMobile.Substring(0, tMobile.Length - 1);
                if (tPhone.EndsWith(",")) tPhone = tPhone.Substring(0, tPhone.Length - 1);
                objElSub = objXnm.CreateElement("Mobile");
                objElSub.InnerText = tMobile;// ArrSub[2].ToString().Replace("\n", "").Replace("\t", "").Replace("Mobile:", "").Replace("Telephone:", "").Trim().Replace("&nbsp;", "").Trim();
                objEl.AppendChild(objElSub);

                objElSub = objXnm.CreateElement("PhoneH");
                objElSub.InnerText = tPhone;// ArrSub[2].ToString().Replace("\n", "").Replace("\t", "").Replace("Mobile:", "").Replace("Telephone:", "").Trim().Replace("&nbsp;", "").Trim();
                objEl.AppendChild(objElSub);


                objElSub = objXnm.CreateElement("CandidateLocation");
                objElSub.InnerText = ArrSub[3].ToString().Replace("\n", "").Replace("\t", "").Replace("Location:", "").Replace("Currently in:", "").Replace("Current Location:", "").Replace("Current", "").Trim();
                if (objElSub.InnerText.Trim() == "")
                    objElSub.InnerText = "<--None-->";
                objEl.AppendChild(objElSub);

                objElSub = objXnm.CreateElement("PresentEmployer");
                objElSub.InnerText = ArrSub[4].ToString().Replace("\n", "").Replace("\t", "").Replace("&nbsp;", "").Replace("FRESHER", "").Replace("Fresher", "").Replace("Fresher", "").Replace("NONE", "").Replace("None", "").Replace("none", "").Replace("NILL", "").Replace("Nill", "").Replace("nill", "").Replace("Current Employer:", "").Trim();
                if (objElSub.InnerText.Trim() == "")
                    objElSub.InnerText = "<--None-->";
                objEl.AppendChild(objElSub);
                string tDesignation = ArrSub[5].ToString().Replace("\n", "").Replace("\t", "").Replace("&nbsp;", "").Trim(); 
                if (tDesignation == "")
                    tDesignation = ArrSub[5].ToString().Replace("\n", "").Replace("\t", "").Replace("&nbsp;", "").Trim();
                objElSub = objXnm.CreateElement("JobTitle");
                objElSub.InnerText = tDesignation.Split(',')[tDesignation.Split(',').GetLowerBound(0)];
                if (objElSub.InnerText.Trim() == "")
                    objElSub.InnerText = "<--None-->";
                objEl.AppendChild(objElSub);
                //objElSub = objXnm.CreateElement("DesignationID");
                //objElSub.InnerText = "";// tDesignationIDs.Split(',')[tDesignationIDs.Split(',').GetLowerBound(0)];
                //objEl.AppendChild(objElSub);
                objElSub = objXnm.CreateElement("Skill");
                objElSub.InnerText = ArrSub[7].ToString().Replace("\n", "").Replace("\t", "").Replace("Skills:", "").Replace("&nbsp;", "").Trim();
                objEl.AppendChild(objElSub);

                objElSub = objXnm.CreateElement("Education");
                string tEducationText = ArrSub[8].ToString().Replace("\n", "").Replace("\t\t\t\t\t", ",").Replace("\t", "").Replace("&nbsp;", "").Trim(); // tEducationIDs = "";
                //opGetIDs(, ref tEducationIDs, ref tEducationText, HireCraft.ClsFcommonXML.objfXMLEducationTypes, "EducationType", "EducationAlias");

                objElSub.InnerText = tEducationText;
                objEl.AppendChild(objElSub);

                //objElSub = objXnm.CreateElement("EducationIDs");
                //objElSub.InnerText = "";// tEducationIDs;
                //objEl.AppendChild(objElSub);

                objElSub = objXnm.CreateElement("PresentCTC");
                objElSub.InnerText = getSalary(ArrSub[9].ToString().Replace("\n", "").Replace("\t", "").Replace("CTC:  USD", "").Replace("+", "").Replace("&nbsp;", "").Replace("CTC(p.a): INR", "").Replace("CTC:  INR", "").Replace("CTC:  INR", "").Replace("Lac(s)", "Lacs").Replace("USD", "").Replace("CTC:", "").Replace("CTC", "").Replace("INR", "").Trim());
                objEl.AppendChild(objElSub);

                objElSub = objXnm.CreateElement("TotalExp");
                objElSub.InnerText = opGetExperience(ArrSub[6].ToString().Replace("Exp:", "").Replace("Month(s)", "Month").Replace("Year(s)", "Year").Replace("\n", "").Replace("\t", "").Replace("&nbsp;", "").Replace("Experience:", "").Trim().Replace("Confidential", "").Trim()).ToString();
                objEl.AppendChild(objElSub);

                objElSub = objXnm.CreateElement("PreviousDesignation");
                if (ArrSub.Length > 10)
                    objElSub.InnerText = ArrSub[10].ToString();
                else
                    objElSub.InnerText = "";

                objEl.AppendChild(objElSub);

                objElSub = objXnm.CreateElement("PreviousEmployer");
                if (ArrSub.Length > 11)
                    objElSub.InnerText = ArrSub[11].ToString();
                else
                    objElSub.InnerText = "";

                objEl.AppendChild(objElSub);
                string PrefLocationTex = "" ;
                if (ArrSub.Length > 12)
                    PrefLocationTex =ArrSub[12].ToString().Replace("\n", "").Replace("\t\t\t\t\t", ",").Replace("\t", "").Replace("&nbsp;", "").Trim(); 

                objElSub = objXnm.CreateElement("PrefLocationText");
                objElSub.InnerText = PrefLocationTex;
                objEl.AppendChild(objElSub);

                //objElSub = objXnm.CreateElement("PrefLocationIDs");
                //objElSub.InnerText = PrefLocationIDs;
                //objEl.AppendChild(objElSub);
                objElSub = objXnm.CreateElement("SiteResumeID");
                if (ArrSub.Length > 13)
                    objElSub.InnerText = ArrSub[13].ToString().Trim();
                else
                    objElSub.InnerText = "";
                objEl.AppendChild(objElSub);
                objElSub = objXnm.CreateElement("AutoResumeID");
                objElSub.InnerText = "";
                objEl.AppendChild(objElSub);
                objElSub = objXnm.CreateElement("Indicator");
                objElSub.InnerText = "";
                objEl.AppendChild(objElSub);
                objRoot.AppendChild(objEl);
            }
        }

        void opCreateNodesNaukriResponse(string tCandidateDataXML)
        {
            if (true)
            {
                System.Xml.XmlDocument objCandXml = new XmlDocument();
                objCandXml.LoadXml(tCandidateDataXML);

                objEl = objXnm.CreateElement("Main");

                objElSub = objXnm.CreateElement("Check");
                objElSub.InnerText = false.ToString();
                objEl.AppendChild(objElSub);

                objElSub = objXnm.CreateElement("ResumeID");
                objElSub.InnerText = "0";
                objEl.AppendChild(objElSub);

                objElSub = objXnm.CreateElement("SavedType");
                objElSub.InnerText = "0";
                objEl.AppendChild(objElSub);

                objElSub = objXnm.CreateElement("IDs");
                objElSub.InnerText = objCandXml.GetElementsByTagName("APPLY_ID").Item(0).InnerText;
                objEl.AppendChild(objElSub);

                objElSub = objXnm.CreateElement("CandidateName");
                objElSub.InnerText = objCandXml.GetElementsByTagName("NAME").Item(0).InnerText.Trim();
                objEl.AppendChild(objElSub);

                objElSub = objXnm.CreateElement("Mobile");
                objElSub.InnerText = objCandXml.GetElementsByTagName("MOBILE").Item(0).InnerText.Replace("(M)", "").Trim();
                objEl.AppendChild(objElSub);

                objElSub = objXnm.CreateElement("PhoneH");
                objElSub.InnerText = objCandXml.GetElementsByTagName("PHONE").Item(0).InnerText.Replace("(R)", "").Trim();

                if (objElSub.InnerText == "91 80" || objElSub.InnerText.Length < 6)
                    objElSub.InnerText = "";

                objEl.AppendChild(objElSub);

                objElSub = objXnm.CreateElement("CandidateLocation");
                objElSub.InnerText = objCandXml.GetElementsByTagName("CITY").Item(0).InnerText.Trim();
                if (objElSub.InnerText.Trim() == "")
                    objElSub.InnerText = "<--None-->";
                objEl.AppendChild(objElSub);

                objElSub = objXnm.CreateElement("PresentEmployer");
                objElSub.InnerText = objCandXml.GetElementsByTagName("CURR_ORGN").Item(0).InnerText.Trim();
                if (objElSub.InnerText.Trim() == "")
                    objElSub.InnerText = "<--None-->";
                objEl.AppendChild(objElSub);
                string tDesignation = "", tDesignationIDs = "";
                tDesignation = objCandXml.GetElementsByTagName("CURR_DESIG").Item(0).InnerText.Trim();
                if (tDesignation == "")
                    tDesignation = objCandXml.GetElementsByTagName("CURR_DESIG").Item(0).InnerText.Trim().Replace("\n", "").Replace("\t", "").Replace("&nbsp;", "").Trim();

                objElSub = objXnm.CreateElement("JobTitle");
                objElSub.InnerText = tDesignation.Split(',')[tDesignation.Split(',').GetLowerBound(0)];
                if (objElSub.InnerText.Trim() == "")
                    objElSub.InnerText = "<--None-->";
                objEl.AppendChild(objElSub);

                //objElSub = objXnm.CreateElement("DesignationID");
                //objElSub.InnerText = tDesignationIDs.Split(',')[tDesignationIDs.Split(',').GetLowerBound(0)];
                //objEl.AppendChild(objElSub);

                objElSub = objXnm.CreateElement("Skill");
                objElSub.InnerText = objCandXml.GetElementsByTagName("SKILLS").Item(0).InnerText.Trim();
                objEl.AppendChild(objElSub);

                objElSub = objXnm.CreateElement("Education");
                string tEduTemp = "", tEducationText = "", tEducationIDs = "";

                if (objCandXml.GetElementsByTagName("UG_COURSE").Item(0).InnerText.Trim() != "")
                    tEduTemp = objCandXml.GetElementsByTagName("UG_COURSE").Item(0).InnerText.Trim();
                if (objCandXml.GetElementsByTagName("PG_COURSE").Item(0).InnerText.Trim() != "")
                    tEduTemp = tEduTemp + "," + objCandXml.GetElementsByTagName("PG_COURSE").Item(0).InnerText.Trim();
                if (objCandXml.GetElementsByTagName("PPG_COURSE").Item(0).InnerText.Trim() != "")
                    tEduTemp = tEduTemp + "," + objCandXml.GetElementsByTagName("PPG_COURSE").Item(0).InnerText.Trim();
                 
                objElSub.InnerText = tEducationText;
                objEl.AppendChild(objElSub);

                //objElSub = objXnm.CreateElement("EducationIDs");
                //objElSub.InnerText = tEducationIDs;
                //objEl.AppendChild(objElSub);

                objElSub = objXnm.CreateElement("PresentCTC");
                objElSub.InnerText = getSalary(objCandXml.GetElementsByTagName("CTC").Item(0).InnerText.Trim().Replace("\n", "").Replace("\t", "").Replace("CTC:  USD", "").Replace("+", "").Replace("&nbsp;", "").Replace("CTC(p.a): INR", "").Replace("CTC:  INR", "").Replace("CTC:  INR", "").Replace("CTC: INR", "").Replace("Lac(s)", "Lacs").Replace("CTC:", "").Replace("CTC", "").Replace("INR", "").Replace("USD", "").Trim());
                objEl.AppendChild(objElSub);

                objElSub = objXnm.CreateElement("TotalExp");
                objElSub.InnerText = opGetExperience(objCandXml.GetElementsByTagName("TOTAL_EXP").Item(0).InnerText.Trim().Replace("Exp:", "").Replace("Month(s)", "Month").Replace("Year(s)", "Year").Replace("\n", "").Replace("\t", "").Replace("&nbsp;", "").Replace("Experience:", "").Trim().Replace("Confidential", "").Trim()).ToString();
                objEl.AppendChild(objElSub);

                objElSub = objXnm.CreateElement("EmailID");
                objElSub.InnerText = objCandXml.GetElementsByTagName("EMAIL").Item(0).InnerText.Trim();
                objEl.AppendChild(objElSub);
                objElSub = objXnm.CreateElement("PreviousDesignation");
                objElSub.InnerText = "";
                objEl.AppendChild(objElSub);
                objElSub = objXnm.CreateElement("PreviousEmployer");
                objElSub.InnerText = "";
                objEl.AppendChild(objElSub);
                objElSub = objXnm.CreateElement("PrefLocationText");
                objElSub.InnerText = "";
                objEl.AppendChild(objElSub);

                //objElSub = objXnm.CreateElement("PrefLocationIDs");
                //objElSub.InnerText = "";
                //objEl.AppendChild(objElSub);
                objElSub = objXnm.CreateElement("SiteResumeID");
                objElSub.InnerText = "";
                objEl.AppendChild(objElSub);
                objElSub = objXnm.CreateElement("AutoResumeID");
                objElSub.InnerText = "";
                objEl.AppendChild(objElSub);
                objElSub = objXnm.CreateElement("Indicator");
                objElSub.InnerText = "";
                objEl.AppendChild(objElSub);
                objRoot.AppendChild(objEl);
            }
        }

        private bool opIsPhone(string str)
        {
            try
            {
                str = str.Trim().Replace("+91", "").Replace("(", "").Replace(")", "");
                if (str.Trim().StartsWith("-") == true)
                    str = str.Trim().Substring(1, str.Length - 1);
                if (str.Trim().StartsWith("_") == true)
                    str = str.Trim().Substring(1, str.Length - 1);

                if (str.Trim().StartsWith("91") == true)
                    str = str.Trim().Substring(2, str.Length - 2);

                if (str.Trim().StartsWith("-") == true)
                    str = str.Trim().Substring(1, str.Length - 1);

                if (str.Trim().IndexOf("0") == 0 || str.Trim().IndexOf("1") == 0 || str.Trim().IndexOf("2") == 0 || str.Trim().IndexOf("3") == 0 || str.Trim().IndexOf("4") == 0 || str.Trim().IndexOf("5") == 0 || str.Trim().IndexOf("6") == 0 || str.Trim().IndexOf("7") == 0 || str.Trim().IndexOf("8") == 0 || str.Trim().IndexOf("9") == 0)
                    if (str.Trim().Length > 4)
                        return true;
            }
            catch { }
            return false;
        }
        /// <summary>
        /// Validate the Mobile
        /// </summary>
        /// <param name="str"></param>
        /// <returns></returns>
        private bool opIsMobile(string str)
        {
            try
            {
                str = str.Trim().Replace("+91", "").Replace("(", "").Replace(")", "");
                if (str.Trim().StartsWith("-") == true)
                    str = str.Trim().Substring(1, str.Length - 1);
                if (str.Trim().StartsWith("_") == true)
                    str = str.Trim().Substring(1, str.Length - 1);

                if (str.Trim().StartsWith("91") == true)
                    str = str.Trim().Substring(2, str.Length - 2);

                if (str.Trim().StartsWith("0091") == true)
                    str = str.Trim().Substring(4, str.Length - 4);
                if (str.Trim().StartsWith("9100") == true)
                    str = str.Trim().Substring(4, str.Length - 4);
                if (str.Trim().StartsWith("091") == true)
                    str = str.Trim().Substring(3, str.Length - 3);

                if (str.Trim().StartsWith("-") == true)
                    str = str.Trim().Substring(1, str.Length - 1);

                if (str.Trim().IndexOf("9") == 0)
                    if (str.Trim().Length == 10)
                        return true;
                if (str.Trim().IndexOf("8") == 0)
                    if (str.Trim().Length == 10)
                        return true;
                if (str.Trim().IndexOf("09") == 0)
                    if (str.Trim().Length == 11)
                        return true;
                if (str.Trim().StartsWith("0065") == true)
                    str = str.Trim().Substring(2, str.Length - 2);
                if (str.Trim().StartsWith("00639") == true)
                    str = str.Trim().Substring(2, str.Length - 2);
                if (str.Trim().IndexOf("659") == 0)
                    if (str.Trim().Length > 8 && str.Trim().Length <= 10)
                        return true;
                if (str.Trim().StartsWith("0097150") == true || str.Trim().StartsWith("00971050") == true || str.Trim().StartsWith("97150") == true || str.Trim().StartsWith("971050") == true || str.Trim().StartsWith("0097155") == true || str.Trim().StartsWith("00971055") == true || str.Trim().StartsWith("97155") == true || str.Trim().StartsWith("971055") == true || str.Trim().StartsWith("0097156") == true || str.Trim().StartsWith("00971056") == true || str.Trim().StartsWith("97156") == true || str.Trim().StartsWith("971056") == true)//UAE Mobile Code  00971 - 50 for etisalat mobile,00971- 55 for du mobile 
                {
                    if (str.Trim().Length <= 15)
                        return true;
                }
                if (str.Trim().StartsWith("050") == true || str.Trim().StartsWith("055") == true)
                {
                    if (str.Trim().Length == 10)
                        return true;
                }
                if (str.Trim().StartsWith("50") == true || str.Trim().StartsWith("55") == true)
                {
                    if (str.Trim().Length == 9)
                        return true;
                }
                if (str.Trim().StartsWith("63917") == true || str.Trim().StartsWith("63918") == true || str.Trim().StartsWith("63915") == true || str.Trim().StartsWith("63912") == true || str.Trim().StartsWith("6390") == true)//Philipians Mobile Code 63-917/90/918/912/915
                {
                    if (str.Trim().Length > 10 && str.Trim().Length <= 15)
                        return true;
                }
                if (str.Trim().StartsWith("+63917") == true || str.Trim().StartsWith("+63918") == true || str.Trim().StartsWith("+63915") == true || str.Trim().StartsWith("+63912") == true || str.Trim().StartsWith("+6390") == true)//Philipians Mobile Code 63-917/90/918/912/915
                {
                    if (str.Trim().Length > 10 && str.Trim().Length <= 15)
                        return true;
                }
            }
            catch
            {
            }
            return false;
        }
        void opCreateNodesRecruitGulf(string[] ArrSub, string IDs)
        {
            if (true)
            {
                objEl = objXnm.CreateElement("Main");

                objElSub = objXnm.CreateElement("Check");
                objElSub.InnerText = true.ToString();
                objEl.AppendChild(objElSub);
                objElSub = objXnm.CreateElement("ResumeID");
                objElSub.InnerText = "0";
                objEl.AppendChild(objElSub);
                objElSub = objXnm.CreateElement("SavedType");
                objElSub.InnerText = "0";
                objEl.AppendChild(objElSub);
                objElSub = objXnm.CreateElement("IDs");
                objElSub.InnerText = IDs;
                objEl.AppendChild(objElSub);

                objElSub = objXnm.CreateElement("CandidateName");
                objElSub.InnerText = ArrSub[1].ToString().Replace("\n", "").Replace("\t", "").Replace("featured", "").Replace("Featured", "").Replace("FEATURED", "").Trim();
                objEl.AppendChild(objElSub);

                string[] tS = { "(M)", "(R)", ",", ":", "Phone", "Mobile" };
                string tPhone = "", tMobile = "";
                string[] acontact = ArrSub[2].ToString().Replace("&nbsp;", ",").Replace("\n", "").Replace("\t", "").Replace("Currently in:", "").Replace("Verified", ",").Trim().Split(tS, StringSplitOptions.RemoveEmptyEntries);
                for (int i = 0; i < acontact.Length; i++)
                {
                    if (this.opIsMobile(opTrimString(acontact[i])))
                        tMobile += acontact[i].Trim() + ",";
                    else if (this.opIsPhone(opTrimString(acontact[i])))
                        tPhone += acontact[i].Trim() + ",";
                }
                if (tMobile.EndsWith(",")) tMobile = tMobile.Substring(0, tMobile.Length - 1);
                if (tPhone.EndsWith(",")) tPhone = tPhone.Substring(0, tPhone.Length - 1);
                objElSub = objXnm.CreateElement("Mobile");
                objElSub.InnerText = tMobile;// ArrSub[2].ToString().Replace("\n", "").Replace("\t", "").Replace("Mobile:", "").Replace("Telephone:", "").Trim().Replace("&nbsp;", "").Trim();
                objEl.AppendChild(objElSub);

                objElSub = objXnm.CreateElement("PhoneH");
                objElSub.InnerText = tPhone;// ArrSub[2].ToString().Replace("\n", "").Replace("\t", "").Replace("Mobile:", "").Replace("Telephone:", "").Trim().Replace("&nbsp;", "").Trim();
                objEl.AppendChild(objElSub);


                objElSub = objXnm.CreateElement("CandidateLocation");
                objElSub.InnerText = ArrSub[3].ToString().Replace("\n", "").Replace("\t", "").Replace("Location:", "").Replace("Currently in:", "").Replace("Current Location:", "").Replace("Current", "").Trim();
                if (objElSub.InnerText.Trim() == "")
                    objElSub.InnerText = "<--None-->";
                objEl.AppendChild(objElSub);

                objElSub = objXnm.CreateElement("PresentEmployer");
                objElSub.InnerText = ArrSub[4].ToString().Replace("\n", "").Replace("\t", "").Replace("&nbsp;", "").Replace("FRESHER", "").Replace("Fresher", "").Replace("Fresher", "").Replace("NONE", "").Replace("None", "").Replace("none", "").Replace("NILL", "").Replace("Nill", "").Replace("nill", "").Replace("Current Employer:", "").Trim();
                if (objElSub.InnerText.Trim() == "")
                    objElSub.InnerText = "<--None-->";
                objEl.AppendChild(objElSub);
                string tDesignation = ArrSub[5].ToString().Replace("\n", "").Replace("\t", "").Replace("&nbsp;", "").Trim(); 
                if (tDesignation == "")
                    tDesignation = ArrSub[5].ToString().Replace("\n", "").Replace("\t", "").Replace("&nbsp;", "").Trim();
                objElSub = objXnm.CreateElement("JobTitle");
                objElSub.InnerText = tDesignation.Split(',')[tDesignation.Split(',').GetLowerBound(0)];
                if (objElSub.InnerText.Trim() == "")
                    objElSub.InnerText = "<--None-->";
                objEl.AppendChild(objElSub);
                //objElSub = objXnm.CreateElement("DesignationID");
                //objElSub.InnerText = tDesignationIDs.Split(',')[tDesignationIDs.Split(',').GetLowerBound(0)];
                //objEl.AppendChild(objElSub);
                objElSub = objXnm.CreateElement("Skill");
                objElSub.InnerText = ArrSub[7].ToString().Replace("\n", "").Replace("\t", "").Replace("Skills:", "").Replace("&nbsp;", "").Trim();
                objEl.AppendChild(objElSub);

                objElSub = objXnm.CreateElement("Education");
                string tEducationText = ArrSub[8].ToString().Replace("\n", "").Replace("\t\t\t\t\t", ",").Replace("\t", "").Replace("&nbsp;", "").Trim();
                     
                objElSub.InnerText = tEducationText;
                objEl.AppendChild(objElSub);

                //objElSub = objXnm.CreateElement("EducationIDs");
                //objElSub.InnerText = "";
                //objEl.AppendChild(objElSub);

                objElSub = objXnm.CreateElement("PresentCTC");
                objElSub.InnerText = ArrSub[9].ToString().Replace("\n", "").Replace("\t", "").Replace("CTC:  USD", "").Replace("+", "").Replace("&nbsp;", "").Replace("CTC(p.a): INR", "").Replace("CTC:  INR", "").Replace("CTC:  INR", "").Replace("Lac(s)", "Lacs").Replace("USD", "").Replace("CTC:", "").Replace("CTC", "").Replace("INR", "").Trim();
                objEl.AppendChild(objElSub);

                objElSub = objXnm.CreateElement("TotalExp");
                objElSub.InnerText = opGetExperience(ArrSub[6].ToString().Replace("Exp:", "").Replace("Month(s)", "Month").Replace("Year(s)", "Year").Replace("\n", "").Replace("\t", "").Replace("&nbsp;", "").Replace("Experience:", "").Trim().Replace("Confidential", "").Trim()).ToString();
                objEl.AppendChild(objElSub);
                objElSub = objXnm.CreateElement("PreviousDesignation");
                objElSub.InnerText = "";
                objEl.AppendChild(objElSub);
                objElSub = objXnm.CreateElement("PreviousEmployer");
                objElSub.InnerText = "";
                objEl.AppendChild(objElSub);
                objElSub = objXnm.CreateElement("PrefLocationText");
                objElSub.InnerText = "";
                objEl.AppendChild(objElSub);

                //objElSub = objXnm.CreateElement("PrefLocationIDs");
                //objElSub.InnerText = "";
                //objEl.AppendChild(objElSub);
                objElSub = objXnm.CreateElement("SiteResumeID");
                objElSub.InnerText = "";
                objEl.AppendChild(objElSub);
                objElSub = objXnm.CreateElement("AutoResumeID");
                objElSub.InnerText = "";
                objEl.AppendChild(objElSub);
                objElSub = objXnm.CreateElement("Indicator");
                objElSub.InnerText = "";
                objEl.AppendChild(objElSub);
                objRoot.AppendChild(objEl);
            }
        }

        private string RemoveHTML(string strText)
        {
            string TAGLIST
                  = ";!--;!DOCTYPE;A;ACRONYM;ADDRESS;APPLET;AREA;B;BASE;BASEFONT;" +
                    "BGSOUND;BIG;BLOCKQUOTE;BODY;BR;BUTTON;CAPTION;CENTER;CITE;CODE;" +
                    "COL;COLGROUP;COMMENT;DD;DEL;DFN;DIR;DIV;DL;DT;EM;EMBED;FIELDSET;" +
                    "FONT;FORM;FRAME;FRAMESET;HEAD;H1;H2;H3;H4;H5;H6;HR;HTML;I;IFRAME;IMG;" +
                    "INPUT;INS;ISINDEX;KBD;LABEL;LAYER;LAGEND;LI;LINK;LISTING;MAP;MARQUEE;" +
                    "MENU;META;NOBR;NOFRAMES;NOSCRIPT;OBJECT;OL;OPTION;P;PARAM;PLAINTEXT;" +
                    "PRE;Q;S;SAMP;SCRIPT;SELECT;SMALL;SPAN;STRIKE;STRONG;STYLE;SUB;SUP;" +
                    "TABLE;TBODY;TD;TEXTAREA;TFOOT;TH;THEAD;TITLE;TR;TT;U;UL;VAR;WBR;XMP;RESUMETITLE;";

            const string BLOCKTAGLIST = ";APPLET;EMBED;FRAMESET;HEAD;NOFRAMES;NOSCRIPT;OBJECT;SCRIPT;STYLE;";

            int nPos1 = 0;
            int nPos2 = 0;
            int nPos3 = 0;
            string strResult = "";
            string strTagName = "";
            bool bRemove;
            bool bSearchForBlock;

            nPos1 = strText.IndexOf("<");
            while (nPos1 >= 0)
            {
                nPos2 = strText.IndexOf(">", nPos1 + 1);
                if (nPos2 >= 0)
                {
                    strTagName = strText.Substring(nPos1 + 1, nPos2 - nPos1 - 1);

                    strTagName = strTagName.Replace("\r", " ").Replace("\n", " ");

                    nPos3 = strTagName.IndexOf(" ");

                    if (nPos3 > 0) strTagName = strTagName.Substring(0, nPos3);

                    if (strTagName.Substring(0, 1) == "/")
                    {
                        strTagName = strTagName.Substring(1);
                        bSearchForBlock = false;
                    }
                    else bSearchForBlock = true;

                    if (TAGLIST.IndexOf(";" + strTagName.ToUpper() + ";", 0) >= 0)
                    {
                        bRemove = true;
                        if (bSearchForBlock)
                        {
                            if (BLOCKTAGLIST.IndexOf(";" + strTagName.ToUpper() + ";") >= 0)
                            {
                                nPos2 = strText.Length;
                                nPos3 = strText.IndexOf("</" + strTagName, nPos1 + 1);
                                if (nPos3 > 0) nPos3 = strText.IndexOf(">", nPos3 + 1);
                                if (nPos3 > 0) nPos2 = nPos3;
                            }
                        }
                    }
                    else bRemove = false;
                    if (bFlagNaukri == 21)
                    {
                        if (string.Compare(strTagName, "li", true) == 0 || string.Compare(strTagName, "BR", true) == 0 || string.Compare(strTagName, "BR/", true) == 0 || string.Compare(strTagName, "span", true) == 0 || string.Compare(strTagName, "div", true) == 0 || string.Compare(strTagName, "A", true) == 0)
                            strResult = strResult + System.Environment.NewLine;
                    }
                    else
                    {
                        if (string.Compare(strTagName, "li", true) == 0 || string.Compare(strTagName, "BR", true) == 0 || string.Compare(strTagName, "BR/", true) == 0 || string.Compare(strTagName, "span", true) == 0 || string.Compare(strTagName, "div", true) == 0)
                            strResult = strResult + System.Environment.NewLine;
                    }
                    if (bRemove)
                    {
                        strResult = strResult + strText.Substring(0, nPos1);
                        strText = strText.Substring(nPos2 + 1);
                    }
                    else
                    {
                        strResult = strResult + strText.Substring(nPos1);
                        strText = strText.Substring(nPos1 + 1);
                    }
                }
                else
                {
                    strResult = strResult + strText;
                    strText = "";
                }

                nPos1 = strText.IndexOf("<");
            }
            strResult = strResult + strText;

            strResult = strResult.Replace("\r\n\r\n", "\r\n");

            return strResult;
        }

        private string RemoveHTMLTimeSheet(string strText)
        {
            string TAGLIST
                  = ";!--;!DOCTYPE;A;ACRONYM;ADDRESS;APPLET;AREA;B;BASE;BASEFONT;" +
                    "BGSOUND;BIG;BLOCKQUOTE;BODY;BR;BUTTON;CAPTION;CENTER;CITE;CODE;" +
                    "COL;COLGROUP;COMMENT;DD;DEL;DFN;DIR;DIV;DL;DT;EM;EMBED;FIELDSET;" +
                    "FONT;FORM;FRAME;FRAMESET;HEAD;H1;H2;H3;H4;H5;H6;HR;HTML;I;IFRAME;IMG;" +
                    "INPUT;INS;ISINDEX;KBD;LABEL;LAYER;LAGEND;LI;LINK;LISTING;MAP;MARQUEE;" +
                    "MENU;META;NOBR;NOFRAMES;NOSCRIPT;OBJECT;OL;OPTION;P;PARAM;PLAINTEXT;" +
                    "PRE;Q;S;SAMP;SCRIPT;SELECT;SMALL;SPAN;STRIKE;STRONG;STYLE;SUB;SUP;" +
                    "TABLE;TBODY;TD;TEXTAREA;TFOOT;TH;THEAD;TITLE;TR;TT;U;UL;VAR;WBR;XMP;RESUMETITLE;";

            const string BLOCKTAGLIST = ";APPLET;EMBED;FRAMESET;HEAD;NOFRAMES;NOSCRIPT;OBJECT;SCRIPT;STYLE;";

            int nPos1 = 0;
            int nPos2 = 0;
            int nPos3 = 0;
            string strResult = "";
            string strTagName = "";
            bool bRemove;
            bool bSearchForBlock;

            nPos1 = strText.IndexOf("<");
            while (nPos1 >= 0)
            {
                nPos2 = strText.IndexOf(">", nPos1 + 1);
                if (nPos2 >= 0)
                {
                    strTagName = strText.Substring(nPos1 + 1, nPos2 - nPos1 - 1);

                    strTagName = strTagName.Replace("\r", " ").Replace("\n", " ");

                    nPos3 = strTagName.IndexOf(" ");

                    if (nPos3 > 0) strTagName = strTagName.Substring(0, nPos3);

                    if (strTagName.Substring(0, 1) == "/")
                    {
                        strTagName = strTagName.Substring(1);
                        bSearchForBlock = false;
                    }
                    else bSearchForBlock = true;

                    if (TAGLIST.IndexOf(";" + strTagName.ToUpper() + ";", 0) >= 0)
                    {
                        bRemove = true;
                        if (bSearchForBlock)
                        {
                            if (BLOCKTAGLIST.IndexOf(";" + strTagName.ToUpper() + ";") >= 0)
                            {
                                nPos2 = strText.Length;
                                nPos3 = strText.IndexOf("</" + strTagName, nPos1 + 1);
                                if (nPos3 > 0) nPos3 = strText.IndexOf(">", nPos3 + 1);
                                if (nPos3 > 0) nPos2 = nPos3;
                            }
                        }
                    }
                    else bRemove = false;
                    if (bRemove)
                    {
                        strResult = strResult + strText.Substring(0, nPos1);
                        strText = strText.Substring(nPos2 + 1);
                    }
                    else
                    {
                        strResult = strResult + strText.Substring(nPos1);
                        strText = strText.Substring(nPos1 + 1);
                    }
                }
                else
                {
                    strResult = strResult + strText;
                    strText = "";
                }

                nPos1 = strText.IndexOf("<");
            }
            strResult = strResult + strText;

            strResult = strResult.Replace("\r\n\r\n", "\r\n");

            return strResult;
        }

        private bool opValidJobSitetimesjobs(string tURL)
        {
            if (System.Text.RegularExpressions.Regex.IsMatch(tURL, @"(timesjobs\.com)", System.Text.RegularExpressions.RegexOptions.IgnoreCase) == true)
                return true;
            else
            {
                //sbar.Text = "Invalid Site...";
                return false;
            }
        }

        void opCreateNodes(string[] ArrSub, string IDs)
        {
            try
            {

                objEl = objXnm.CreateElement("Main");
                objElSub = objXnm.CreateElement("Check");
                objElSub.InnerText = true.ToString();
                objEl.AppendChild(objElSub);
                objElSub = objXnm.CreateElement("ResumeID");
                objElSub.InnerText = "0";
                objEl.AppendChild(objElSub);
                objElSub = objXnm.CreateElement("SavedType");
                objElSub.InnerText = "0";
                objEl.AppendChild(objElSub);
                objElSub = objXnm.CreateElement("IDs");
                objElSub.InnerText = IDs;
                objEl.AppendChild(objElSub);

                objElSub = objXnm.CreateElement("CandidateName");
                objElSub.InnerText = ArrSub[2].ToString().Replace("\n", "").Replace("\t", "").Trim();
                objEl.AppendChild(objElSub);

                objElSub = objXnm.CreateElement("Mobile");
                if (ArrSub.GetUpperBound(0) > 2)
                    objElSub.InnerText = ArrSub[3].ToString().Replace("\n", "").Replace("\t", "").Replace("Mobile:", "").Replace("+", "").Replace("Telephone:", "").Trim();
                else
                    objElSub.InnerText = "";
                objEl.AppendChild(objElSub);

                string[] st1235 = { "Nationality" };
                objElSub = objXnm.CreateElement("CandidateLocation");
                if (ArrSub.GetUpperBound(0) > 4)
                    objElSub.InnerText = ArrSub[5].Split(st1235, StringSplitOptions.RemoveEmptyEntries)[0];
                else if (ArrSub.GetUpperBound(0) == 4)
                    objElSub.InnerText = ArrSub[4].Split(st1235, StringSplitOptions.RemoveEmptyEntries)[0];
                else
                    objElSub.InnerText = "";
                objEl.AppendChild(objElSub);

                objElSub = objXnm.CreateElement("PhoneH");
                if (ArrSub.GetUpperBound(0) > 4 && ArrSub[4].ToLower().IndexOf("telephone") >= 0)
                    objElSub.InnerText = ArrSub[4].ToString().Replace("\n", "").Replace("\t", "").Replace("Mobile:", "").Replace("Telephone:", "").Replace("+", "").Trim();
                else if (ArrSub.GetUpperBound(0) == 4)
                    objElSub.InnerText = "";
                objEl.AppendChild(objElSub);
                string[] st1234 = { "\n" };
                string[] aPEmp = ArrSub[1].Split(st1234, StringSplitOptions.RemoveEmptyEntries);
                objElSub = objXnm.CreateElement("PresentEmployer");
                if (aPEmp[1].ToLower().IndexOf("annual salary:") < 0 && aPEmp[1].ToLower().IndexOf("experience:") < 0 && aPEmp[1].ToLower().IndexOf("salary:") < 0)
                    objElSub.InnerText = aPEmp[1].ToString().Replace("\n", "").Replace("\t", "").Replace("&nbsp;", "").Trim().Replace("Confidential", "").Replace("FRESHER", "").Replace("Fresher", "").Replace("Fresher", "").Replace("NONE", "").Replace("None", "").Replace("none", "").Replace("NILL", "").Replace("Nill", "").Replace("nill", "").Trim();
                else
                    objElSub.InnerText = "";
                if (objElSub.InnerText.Trim() == "")
                    objElSub.InnerText = "<--None-->";
                objEl.AppendChild(objElSub);

                string tPresentCTc = "", tExp = "";
                for (int i = 0; i < aPEmp.Length; i++)
                {

                    if (aPEmp[i].ToLower().IndexOf("annual salary:") >= 0 || aPEmp[i].ToLower().IndexOf("salary:") >= 0)
                        tPresentCTc = getSalary(aPEmp[i].ToString().Replace("Annual Salary:", "").Replace("Salary:", "").Replace("Indian Rupees", "").Replace("per annum", "").Replace("Dirhams", "").Replace("\n", "").Replace("\t", "").Replace("&nbsp;", "").Trim().Replace("Confidential", "").Replace(":", "").Replace("INR", "").Replace("INR", "").Replace("CTC:", "").Replace("CTC", "").Replace("INR", "").Replace("USD", "").Trim());
                    if (aPEmp[i].ToLower().IndexOf("experience:") >= 0)
                        tExp = opGetExperience(aPEmp[i].ToString().Replace("Experience:", "").Replace("\n", "").Replace("\t", "").Replace("&nbsp;", "").Trim().Replace("Confidential", "").Trim()).ToString();
                }
                objElSub = objXnm.CreateElement("PresentCTC");
                objElSub.InnerText = tPresentCTc;
                objEl.AppendChild(objElSub);

                objElSub = objXnm.CreateElement("TotalExp");
                objElSub.InnerText = tExp;
                objEl.AppendChild(objElSub);
                string[] st123 = { "\n\t" };

                aPEmp = ArrSub[0].Split(st123, StringSplitOptions.RemoveEmptyEntries);
                string tDesignation = aPEmp[0].ToString().Replace("Experience:", "").Replace("\n", "").Replace("\t", "").Replace("&nbsp;", "").Trim().Replace("Confidential", "").Trim().ToString();
                if (tDesignation == "")
                    tDesignation = aPEmp[0].ToString().Replace("Experience:", "").Replace("\n", "").Replace("\t", "").Replace("&nbsp;", "").Trim();

                objElSub = objXnm.CreateElement("JobTitle");
                objElSub.InnerText = tDesignation.Split(',')[tDesignation.Split(',').GetLowerBound(0)];
                if (objElSub.InnerText.Trim() == "")
                    objElSub.InnerText = "<--None-->";
                objEl.AppendChild(objElSub);

                //objElSub = objXnm.CreateElement("DesignationID");
                
                //    objElSub.InnerText = "";
                //objEl.AppendChild(objElSub);

                aPEmp = aPEmp[1].Split('\n');

                objElSub = objXnm.CreateElement("Skill");
                objElSub.InnerText = aPEmp[0].ToString().Replace("Experience:", "").Replace("\n", "").Replace("\t", "").Replace("&nbsp;", "").Trim().Replace("Confidential", "").Trim().ToString();
                objEl.AppendChild(objElSub);

                objElSub = objXnm.CreateElement("Education");
                string tEducationText = "", tEducationIDs = "";
                if (aPEmp.Length > 1)
                  tEducationText =aPEmp[1].ToString().Replace("\n", "").Replace("\t\t\t\t\t", ",").Replace("\t", "").Replace("&nbsp;", "").Trim(); 
                objElSub.InnerText = tEducationText;
                objEl.AppendChild(objElSub);

                //objElSub = objXnm.CreateElement("EducationIDs");
                //objElSub.InnerText = tEducationIDs;
                //objEl.AppendChild(objElSub);
                objElSub = objXnm.CreateElement("PreviousDesignation");
                objElSub.InnerText = "";
                objEl.AppendChild(objElSub);
                objElSub = objXnm.CreateElement("PreviousEmployer");
                objElSub.InnerText = "";
                objEl.AppendChild(objElSub);

                objElSub = objXnm.CreateElement("PrefLocationText");
                objElSub.InnerText = "";
                objEl.AppendChild(objElSub);

                //objElSub = objXnm.CreateElement("PrefLocationIDs");
                //objElSub.InnerText = "";
                //objEl.AppendChild(objElSub);
                objElSub = objXnm.CreateElement("SiteResumeID");
                objElSub.InnerText = "";
                objEl.AppendChild(objElSub);
                objElSub = objXnm.CreateElement("AutoResumeID");
                objElSub.InnerText = "";
                objEl.AppendChild(objElSub);
                objElSub = objXnm.CreateElement("Indicator");
                objElSub.InnerText = "";
                objEl.AppendChild(objElSub);
                objRoot.AppendChild(objEl);
            }
            catch { }
        }

        private string opGetExperience(string strResuemtext)
        {
            string tExp = "0";
            decimal Exp = 0;
            try
            {
                if (strResuemtext.ToLower().IndexOf("year") >= 0 && strResuemtext.ToLower().IndexOf("month") >= 0)
                    strResuemtext = strResuemtext.ToLower().Replace("year", ".").Replace("month", "").Replace(" ", "").Trim();
                else if (strResuemtext.ToLower().IndexOf("year") > 0 && strResuemtext.ToLower().IndexOf("month") < 0)
                    strResuemtext = strResuemtext.ToLower().Replace("year", ".00");
                else if (strResuemtext.ToLower().IndexOf("yrs") > 0 && strResuemtext.ToLower().IndexOf("month") < 0)
                    strResuemtext = strResuemtext.ToLower().Replace("yrs", ".00");
                else if (strResuemtext.ToLower().IndexOf("year") < 0 && strResuemtext.ToLower().IndexOf("month") >= 0)
                    strResuemtext = "0." + strResuemtext.ToLower().Replace("months", "").Replace("month", "");
                else if (strResuemtext.ToLower().IndexOf("-") >= 0)
                    strResuemtext = strResuemtext.Split('-')[strResuemtext.Split('-').GetUpperBound(0)].ToLower().Replace("yrs", "");
                else if (System.Text.RegularExpressions.Regex.IsMatch(strResuemtext, @"\d{1,2}yr[\s]\d{1,2}m"))
                    strResuemtext = strResuemtext.ToLower().Replace("yr", ".").Replace("m", "").Replace(" ", "").Trim();
                string[] str = strResuemtext.Split('.');
                if (str.Length > 1)
                {
                    strResuemtext = str[0] + ".0" + Convert.ToString(str[1]);
                }
                str = null;
                Exp = Convert.ToDecimal(opTrimString(strResuemtext.Replace("+", "")));
                tExp = Exp.ToString("##.##");
            }
            catch
            {
                tExp = "0";
            }
            return tExp;
        }

        private string StripHTML(string str)
        {
            //variable to hold the returned value
            string strippedString;
            try
            {
                //variable to hold our RegularExpression pattern
                string pattern = "<.*?>";
                //replace all HTML tags
                strippedString = System.Text.RegularExpressions.Regex.Replace(str, pattern, string.Empty);
            }
            catch
            {
                strippedString = string.Empty;
            }
            return strippedString;
        }


        void opCreateMonsterGulf(string[] ArrSub, string IDs)
        {
            objEl = objXnm.CreateElement("Main");

            objElSub = objXnm.CreateElement("Check");
            objElSub.InnerText = true.ToString();
            objEl.AppendChild(objElSub);
            objElSub = objXnm.CreateElement("ResumeID");
            objElSub.InnerText = "0";
            objEl.AppendChild(objElSub);
            objElSub = objXnm.CreateElement("SavedType");
            objElSub.InnerText = "0";
            objEl.AppendChild(objElSub);
            objElSub = objXnm.CreateElement("IDs");
            objElSub.InnerText = IDs;
            objEl.AppendChild(objElSub);
            string[] tS = { "(M)", "(R)", ",", ":", "Phone", "Mobile", "Telephone" };
            objElSub = objXnm.CreateElement("CandidateName");
            objElSub.InnerText = ArrSub[0].ToString().Replace("\n", "").Replace("\t", "").Trim();
            objEl.AppendChild(objElSub);


            string tPhone = "", tMobile = "";
            string tSearchText = ArrSub[1].ToString() + "," + ArrSub[2].ToString();
            string[] acontact = tSearchText.Replace("\n", "").Replace("\t", "").Replace("Currently in:", "").Trim().Split(tS, StringSplitOptions.RemoveEmptyEntries);
            for (int i = 0; i < acontact.Length; i++)
            {
                if (this.opIsMobile(opTrimString(acontact[i].Replace("-", ""))))
                    tMobile += acontact[i].Trim() + ",";
                else if (this.opIsPhone(opTrimString(acontact[i].Replace("-", ""))))
                    tPhone += acontact[i].Trim() + ",";
            }
            if (tMobile.EndsWith(",")) tMobile = tMobile.Substring(0, tMobile.Length - 1);
            if (tPhone.EndsWith(",")) tPhone = tPhone.Substring(0, tPhone.Length - 1);
            objElSub = objXnm.CreateElement("Mobile");
            objElSub.InnerText = tMobile;// ArrSub[2].ToString().Replace("\n", "").Replace("\t", "").Replace("Mobile:", "").Replace("Telephone:", "").Trim().Replace("&nbsp;", "").Trim();
            objEl.AppendChild(objElSub);

            objElSub = objXnm.CreateElement("PhoneH");
            objElSub.InnerText = tPhone;// ArrSub[2].ToString().Replace("\n", "").Replace("\t", "").Replace("Mobile:", "").Replace("Telephone:", "").Trim().Replace("&nbsp;", "").Trim();
            objEl.AppendChild(objElSub);


            objElSub = objXnm.CreateElement("CandidateLocation");
            objElSub.InnerText = ArrSub[3].ToString().Replace("\n", "").Replace("\t", "").Replace("Current Location:", "").Replace("Location:", "").Replace("Currently in:", "").Trim();
            if (objElSub.InnerText.Trim() == "")
                objElSub.InnerText = "<--None-->";
            objEl.AppendChild(objElSub);

            objElSub = objXnm.CreateElement("PresentEmployer");
            objElSub.InnerText = (ArrSub[4].ToString().Trim().IndexOf("year") >= 0 ? "" : ArrSub[4].ToString()).Replace("\n", "").Replace("\t", "").Replace("&nbsp;", "").Replace("FRESHER", "").Replace("Fresher", "").Replace("Fresher", "").Replace("NONE", "").Replace("None", "").Replace("none", "").Replace("NILL", "").Replace("Nill", "").Replace("nill", "").Replace("Current Employer:", "");
            if (objElSub.InnerText.Trim() == "")
                objElSub.InnerText = "<--None-->";
            objEl.AppendChild(objElSub);
            string tDesignation = "", tDesignationIDs = "";
            if (string.IsNullOrEmpty(ArrSub[5]) == false)
               tDesignation =ArrSub[5].ToString().Replace("\n", "").Replace("\t", "").Replace("&nbsp;", "").Trim();//, ref tDesignationIDs, ref tDesignation, HireCraft.ClsFcommonXML.objfXMLJobTitle, "JobTitle", "Includelist");
            if (tDesignation == "")
                if (string.IsNullOrEmpty(ArrSub[5]) == false)
                    tDesignation = ArrSub[5].ToString().Replace("\n", "").Replace("\t", "").Replace("&nbsp;", "").Trim();
            objElSub = objXnm.CreateElement("JobTitle");
            objElSub.InnerText = tDesignation.Split(',')[tDesignation.Split(',').GetLowerBound(0)];
            if (objElSub.InnerText.Trim() == "")
                objElSub.InnerText = "<--None-->";
            objEl.AppendChild(objElSub);
            //objElSub = objXnm.CreateElement("DesignationID");
            //objElSub.InnerText = tDesignationIDs.Split(',')[tDesignationIDs.Split(',').GetLowerBound(0)];
            //objEl.AppendChild(objElSub);
            objElSub = objXnm.CreateElement("Skill");
            objElSub.InnerText = ArrSub[5].ToString().Replace("\n", "").Replace("\t", "").Replace("Skills:", "").Replace("&nbsp;", "").Trim();
            objEl.AppendChild(objElSub);

            objElSub = objXnm.CreateElement("Education");
            string tEducationText = "", tEducationIDs = "";
            tEducationText = ArrSub[6].ToString().Replace("\n", "").Replace("\t\t\t\t\t", ",").Replace("\t", "").Replace("&nbsp;", "").Trim();

            objElSub.InnerText = tEducationText;
            objEl.AppendChild(objElSub);

            //objElSub = objXnm.CreateElement("EducationIDs");
            //objElSub.InnerText = tEducationIDs;
            //objEl.AppendChild(objElSub);

            objElSub = objXnm.CreateElement("PresentCTC");
            objElSub.InnerText = getSalary(ArrSub[7].ToString().Replace("\n", "").Replace("\t", "").Replace("INR per annum", "").Replace("CTC:  USD", "").Replace("+", "").Replace("&nbsp;", "").Replace("CTC(p.a): INR", "").Replace("CTC:  INR", "").Replace("CTC:  INR", "").Replace("Lac(s)", "Lacs").Replace("CTC:", "").Replace("CTC", "").Replace("INR", "").Replace("USD", "").Replace("per annum", "").Trim());
            objEl.AppendChild(objElSub);

            objElSub = objXnm.CreateElement("TotalExp");
            objElSub.InnerText = opGetExperience(ArrSub[8].ToString().Replace("Months", "Month").Replace("Month(s)", "Month").Replace("Years", "Year").Replace("Year(s)", "Year").Replace("\n", "").Replace("\t", "").Replace("&nbsp;", "").Replace("Experience:", "").Trim().Replace("Confidential", "").Replace("Exp:", "").Trim()).ToString();
            objEl.AppendChild(objElSub);
            objElSub = objXnm.CreateElement("PreviousDesignation");
            objElSub.InnerText = "";
            objEl.AppendChild(objElSub);
            objElSub = objXnm.CreateElement("PreviousEmployer");
            objElSub.InnerText = "";
            objEl.AppendChild(objElSub);
            string PrefLocationTex = "", PrefLocationIDs = "";
            if (ArrSub.Length > 9)
             PrefLocationTex =ArrSub[9].ToString().Replace("\n", "").Replace("\t\t\t\t\t", ",").Replace("\t", "").Replace("&nbsp;", "").Trim(); 

            objElSub = objXnm.CreateElement("PrefLocationText");
            objElSub.InnerText = PrefLocationTex;
            objEl.AppendChild(objElSub);

            //objElSub = objXnm.CreateElement("PrefLocationIDs");
            //objElSub.InnerText = PrefLocationIDs;
            //objEl.AppendChild(objElSub);

            objElSub = objXnm.CreateElement("SiteResumeID");
            if (ArrSub.Length > 10)
                objElSub.InnerText = ArrSub[10];
            else
                objElSub.InnerText = "";
            objElSub = objXnm.CreateElement("AutoResumeID");
            objElSub.InnerText = "";
            objEl.AppendChild(objElSub);
            objElSub = objXnm.CreateElement("Indicator");
            objElSub.InnerText = "";
            objEl.AppendChild(objElSub);
            objRoot.AppendChild(objEl);
        }

        private string opTrimString(string str1)
        {
            while (str1.IndexOf(" ") >= 0)
            {
                str1 = str1.Replace(" ", "");
            }
            return str1;
        }

        private string getSalaryCats(string tSalary)
        {
            try
            {
                try
                {
                    decimal d = Convert.ToDecimal(tSalary);
                }
                catch
                {
                    tSalary = "0";
                }
                return tSalary;
            }
            catch
            {
                return "";
            }

        }

        private string getSalary(string tSalary)
        {
            string tReturn = "";
            tSalary = tSalary.ToLower();
            try
            {
                if (tSalary.Trim().IndexOf("per month") >= 0 || tSalary.Trim().IndexOf(" pm") >= 0 || tSalary.Trim().IndexOf("/pm") >= 0 || tSalary.Trim().IndexOf("/-pm") >= 0 || tSalary.Trim().IndexOf("/month") >= 0)
                {
                    string strPMonth = "";
                    try
                    {
                        strPMonth = tSalary.Trim().Trim().Replace("=", "").Replace("k", "000").Replace("+", "").Replace("per month.", "").Replace("per month", "").Replace("pm", "").Replace("/ month", "(").Replace("/month", "(").Replace("/", "").Replace("-", "").Replace("inr", "");
                        decimal d = Convert.ToDecimal(opTrimString(strPMonth));
                        tSalary = Convert.ToString(d * 12);
                    }
                    catch
                    {
                        try
                        {
                            string[] aMonth = strPMonth.Split('(', ')');
                            for (int i = 0; i < aMonth.GetUpperBound(0); i++)
                            {
                                decimal d = Convert.ToDecimal(aMonth[i]);
                                tSalary = Convert.ToString(d * 12);
                            }

                        }
                        catch { }
                    }
                }
                if (tSalary.Trim().IndexOf("/-") >= 0)
                {
                    string[] strSplit = tSalary.Trim().Split('/', '-');
                    for (int i = 0; i <= strSplit.GetUpperBound(0); i++)
                    {
                        if (strSplit[i].Trim().Length > 0)
                        {
                            tSalary = strSplit[i].Trim();
                            break;
                        }
                    }
                }
                //if (CheckNumeric(tSalary.Replace(", ", "").Replace(",", "").Replace("p.a.", "").Replace("p.a", "").Replace("per annum.", "").Replace("per annum", "").Replace("=", "").Trim().ToCharArray(), "") == true)
                //    tSalary = opGetNumberWLakhs(tSalary.Trim().Replace("l", " l")).Trim().Replace("/annum", "");
                //else
                //    tSalary = tSalary.Replace(", ", "").Replace(",", "").Replace("p.a.", "").Replace("p.a", "").Replace("per annum.", "").Replace("per annum", "").Replace("=", "").Trim();

                if (tSalary.Trim().Length != 0)
                {
                    if (tSalary.Trim().IndexOf("lacs") == 0)
                    {
                        tSalary = tSalary.Replace("lacs", "");
                    }
                    if ((tSalary.Trim().IndexOf("lacs") >= 0 || tSalary.Trim().IndexOf("lac(s)") >= 0) && tSalary.Trim().IndexOf("thousand") < 0)
                        tSalary = tSalary.Trim().Replace("lacs", ".");//.Replace("lac(s)",".").Replace("lack",".").Replace("lakhs",".").Replace("lakh(s)",".").Replace("lakh",".");
                    else if ((tSalary.Trim().IndexOf("lacs") >= 0 || tSalary.Trim().IndexOf("lac(s)") >= 0) && tSalary.Trim().IndexOf("thousand") >= 0)
                        tSalary = ConvertStringDigit(tSalary);

                    tSalary = tSalary.Replace(" ", "").Trim();
                    if (tSalary.Trim().EndsWith(".")) tSalary = tSalary.Substring(0, tSalary.Length - 1);
                    if (tSalary.Trim().Length != 0)
                    {
                        if (tSalary.Trim().Length > 4 && tSalary.Trim().IndexOf(".") < 0)
                        {
                            try
                            {
                                decimal d = Convert.ToDecimal(tSalary) / 100000;
                                tSalary = Convert.ToString(d);
                            }
                            catch
                            {
                                tSalary = "0";
                            }
                        }
                        if (CheckNumeric(tSalary.Trim().ToCharArray(), "CTC") == false)
                        {
                            tReturn = tSalary;
                        }
                    }
                }
            }
            catch
            {
                tReturn = "";
            }
            return tReturn;

        }

        /// <summary>
        /// Number exits in the character Array
        /// If strMsg is CTC count the .
        /// </summary>
        /// <param name="c_array"></param>
        /// <param name="strMsg"></param>
        /// <returns></returns>
        private bool CheckNumeric(char[] c_array, string strMsg)
        {
            int nCount = 0;
            for (int i = 0; i < c_array.Length; i++)
            {
                for (int j = 48; j <= 57; j++)
                {
                    if (c_array[i].ToString() == Convert.ToChar(j).ToString()) nCount++;
                    if (strMsg == "CTC")
                    {
                        if (c_array[i].ToString() == Convert.ToChar(46).ToString()) { nCount++; break; }
                    }
                }
            }
            if (nCount == c_array.Length)//|| nCount==c_array.Length+1)
                return false;
            else
                return true;
        } 

        /// <summary>
        /// Converting Character to Digits 
        /// eg:- 1 lacs 20 thousand convert it 120000
        /// </summary>
        /// <param name="strToConvert"></param>
        /// <returns></returns>
        private string ConvertStringDigit(string strToConvert)
        {
            string temp = "";
            string val = "";
            string word = strToConvert;
            string strDigit = "";
            int flag = 0;
            word = word.ToLower();
            string[] newword = word.Split(new char[] { ' ' });
            for (int i = 0; i < newword.Length; i++)
            {
                if ((newword[i] == "lac(s)") | (newword[i] == "lack") | (newword[i] == "lacs") | (newword[i] == "lakh") | (newword[i] == "lakhs") | (newword[i] == "lakh(s)"))
                {
                    i--;
                    val = newword[i];
                    break;
                }
            }

            for (int i = 0; i < newword.Length; i++)
            {
                if ((newword[i] == "thousand"))
                {
                    i--;
                    temp = newword[i];
                    if (temp.Length == 1)
                    {
                        val += 0;
                        val += newword[i];
                        flag = 1;
                        break;
                    }
                    else
                    {
                        val += newword[i];
                        flag = 1;
                        break;
                    }
                }
            }
            if (flag == 0)
            {
                strDigit = val + "00000";
            }
            if (flag == 1)
            {
                strDigit = val + "000";

            }
            return strDigit;
        }
        public string GetLocalTempPath()
        {
            string str = System.IO.Path.GetTempPath() + @"HireLookImportPortalResume\";
            if (System.IO.Directory.Exists(str) == false)
                System.IO.Directory.CreateDirectory(str);
            return str;
        }
        private void opStartDownloading()
        {
            try
            {
                System.Windows.Forms.Control.CheckForIllegalCrossThreadCalls = true;
                tsDownload.Enabled = false;
                btnMinanMax.Focus();
                if (true) 
                {
                    opSetCursorBusy();
                    int i = 0;
                    byte[] by = null;
                    object objNull = null; 
                    int iFlagCompleted = 0; 
                    System.Windows.Forms.Application.DoEvents();
                    
                    int iRowCount = 0;
                    for (i = 0; i < grdCandidate.RowCount; i++)
                        if (grdCandidate.Rows[i].Cells[ "Check"].Value.ToString() == true.ToString())
                            iRowCount++;
                    tspgrs.Minimum = 0;
                    tspgrs.Maximum = 100;
                    tspgrs.Value = 0;
                    if (iRowCount > 0)
                    {
                        tspgrs.Step = 100 / iRowCount;
                    tspgrs.Visible = true;
                        bStopped = false;
                        tsStop.Visible = true;
                        tsStop.Enabled = true;
                        tsSummary.Visible = true;
                    }

                    System.Windows.Forms.Application.DoEvents(); 
                    for (i = 0; i < grdCandidate.RowCount; i++)
                    {
                        System.Windows.Forms.Application.DoEvents();
                        if (bStopped == true)
                        {
                            System.Windows.Forms.Application.DoEvents();
                            opSetMessage("Downloading Stopped...");
                            break;
                        }
                        by = null;
                        if (grdCandidate.Rows[i].Cells[  "Check"].Value.ToString() == true.ToString())
                        {
                            if ((i % 5) == 0)// After 5 rows 
                            {
                                for (int ikj = 0; ikj <= 5000; ikj++)
                                {
                                    System.Windows.Forms.Application.DoEvents();
                                    int kk = ikj;
                                }
                            }
                            if ((i % 3) == 0)// After 3 rows 
                            {
                                for (int ikj = 0; ikj <= 10000; ikj++)
                                {
                                    System.Windows.Forms.Application.DoEvents();
                                    int kk = ikj;
                                }
                            }


                            string FileIDs = "";
                            string strUrl = "";
                            if (iFlagCompleted == 0) opSetMessage("Downloading Started...");
                            System.Windows.Forms.Application.DoEvents();
                            iFlagCompleted++;
                            by = null;

                            string tMobileNo = grdCandidate.Rows[i].Cells[  "Mobile"].Value.ToString().Replace("-", "").Replace("+", "").Replace(":", "");

                            string[] tSplit = { "Tel:", "(M)", "(R)", "Ph", ":", "ph", "PH", ",", ";" };
                            string[] aMobileNo = tMobileNo.Split(tSplit, StringSplitOptions.RemoveEmptyEntries);
                            tSplit = null;
                            tMobileNo = "";
                            for (int mCnt = 0; mCnt <= aMobileNo.GetUpperBound(0); mCnt++)
                            {
                                if (aMobileNo[mCnt].Replace(" ", "").Trim().Length > 15) continue;
                                if (tMobileNo != "")
                                    tMobileNo += "," + aMobileNo[mCnt];
                                else
                                    tMobileNo = aMobileNo[mCnt];
                            }
                            string tCandidateName = grdCandidate.Rows[i].Cells[  "CandidateName"].Value.ToString().Replace("Name", "").Replace("name", "").Replace("NAME", "");
                            if (tCandidateName.Trim().ToLower().IndexOf("year") >= 0 || tCandidateName.Trim().ToLower().IndexOf("month") >= 0 || tCandidateName.Trim().ToLower().IndexOf("masked") >= 0 || tCandidateName.Trim().ToLower().IndexOf("null") >= 0 || tCandidateName.Trim().ToLower().IndexOf("confidential") >= 0)
                                tCandidateName = "";

                            //if (opCheckDuplication("<root><UserName>" + HireCraft.FCommon.UName + "</UserName><CreatedUserID>" + HireCraft.FCommon.UID.ToString() + "</CreatedUserID><Name>" + tCandidateName + "</Name><Mobile>" + tMobileNo + "</Mobile><CRITERIA>" + tCRITERIA + "</CRITERIA><COOLINGPERIOD>" + tCOOLINGPERIOD + "</COOLINGPERIOD><FINALWEIGHTAGE>" + tFINALWEIGHTAGE + "</FINALWEIGHTAGE><PhoneH>" + grdCandidate.Rows[i].Cells[  "PhoneH").ToString() + "</PhoneH></root>", grdCandidate.Rows[i].Cells[  "IDs").ToString()) == false)
                            { 
                                string tFileName = grdCandidate.Rows[i].Cells[  "CandidateName"].Value.ToString();
                                string tFileExtension = ".doc";
                                if (bFlagNaukri == 1)
                                {
                                     #region "recruiter.monsterindia.com"

                                    FileIDs = grdCandidate.Rows[i].Cells["IDs"].Value.ToString().Replace("&amp;", "&").Replace(";", "&").Replace("&&", "&");
                                    strUrl = "http://recruiter.monsterindia.com/resumedatabase/resume.html?" + FileIDs + "&type=doc";
                                    MSXML2.XMLHTTP xmlHttpMain = new MSXML2.XMLHTTP();
                                    xmlHttpMain.open("GET", strUrl, false, null, null);
                                    xmlHttpMain.setRequestHeader("Content-Type", "text/urlencoded");
                                    xmlHttpMain.send(objNull); 
                                    if (xmlHttpMain.statusText == "OK")
                                    {
                                        strUrl = "";
                                        string tResponseText = (string)xmlHttpMain.responseText;
                                        try
                                        {

                                            if (tResponseText.IndexOf("Create a Personal Folder") >= 0 || xmlHttpMain.responseText.IndexOf("Insufficient Resume Inventory") >= 0)
                                            {

                                                this.Invoke(new CreateAuthorizePopup(opAuthorizePopup), strUrl);
                                                by = null;
                                                strUrl = null;
                                                xmlHttpMain = null;
                                                opSetMessage("Communication from the site has interrupted. Please relogin...");
                                                break;
                                            }
                                            else if (xmlHttpMain.responseText.IndexOf("Search results shall show resumes within 3 months") >= 0)
                                            {
                                                this.Invoke(new CreateAuthorizePopup(opAuthorizePopup), strUrl);
                                                by = null;
                                                strUrl = null;
                                                xmlHttpMain = null;
                                                opSetMessage("Communication from the site has interrupted. Please relogin...");
                                                break;
                                            }
                                            else if (xmlHttpMain.responseText.IndexOf("Please authenticate yourself by typing the code that you see below.") >= 0)
                                            {
                                                this.Invoke(new CreateAuthorizePopup(opAuthorizePopup), strUrl);
                                                by = null;
                                                strUrl = null;
                                                xmlHttpMain = null;
                                                opSetMessage("Communication from the site has interrupted. Please relogin...");
                                                break;
                                            }
                                        }
                                        catch { }
                                        #region "fetching detail information"

                                        HtmlAgilityPack.HtmlDocument objHTML1 = null;
                                        objHTML1 = new HtmlAgilityPack.HtmlDocument();
                                        objHTML1.LoadHtml(tResponseText);
                                      
                                       
                                        #endregion
                                        //.Replace("<script type=\"text/javascript\">", "<!-- <script type=\"text/javascript\">").Replace("</script>", "</script> -->");
                                        string[] tsp = { "url = '/resumedatabase/resume_process_request.html?", "url += '" };
                                        string[] tsp1 = { "';\n" };
                                        string[] tspdata = tResponseText.Split(tsp, StringSplitOptions.RemoveEmptyEntries);

                                        // string strUrl2 = tspdata[2].Split(tsp1, StringSplitOptions.RemoveEmptyEntries)[0].Trim().Replace("'+summaryFlag+'", "1");
                                        if (tspdata.Length > 1)
                                        {
                                            strUrl = "http://recruiter.monsterindia.com/resumedatabase/resume_process_request.html?" + tspdata[1].Replace("';\n", "").Trim();
                                            //strUrl += strUrl2;
                                            xmlHttpMain = null;
                                            xmlHttpMain = new MSXML2.XMLHTTP();
                                            xmlHttpMain.open("GET", strUrl, false, null, null);
                                            xmlHttpMain.setRequestHeader("Content-Type", "text/urlencoded");
                                            xmlHttpMain.send(objNull);

                                            if (xmlHttpMain.statusText == "OK")
                                            {
                                                by = (byte[])xmlHttpMain.responseBody;
                                                try
                                                {

                                                    if (xmlHttpMain.responseText.IndexOf("Create a Personal Folder") >= 0 || xmlHttpMain.responseText.IndexOf("Insufficient Resume Inventory") >= 0)
                                                    {

                                                        this.Invoke(new CreateAuthorizePopup(opAuthorizePopup), strUrl);
                                                        by = null;
                                                        strUrl = null;
                                                        xmlHttpMain = null;
                                                        opSetMessage("Communication from the site has interrupted. Please relogin...");
                                                        break;
                                                    }
                                                    else if (xmlHttpMain.responseText.IndexOf("Search results shall show resumes within 3 months") >= 0)
                                                    {

                                                        this.Invoke(new CreateAuthorizePopup(opAuthorizePopup), strUrl);
                                                        by = null;
                                                        strUrl = null;
                                                        xmlHttpMain = null;
                                                        opSetMessage("Communication from the site has interrupted. Please relogin...");
                                                        break;
                                                    }
                                                    else if (xmlHttpMain.responseText.IndexOf("Please authenticate yourself by typing the code that you see below.") >= 0)
                                                    {
                                                        this.Invoke(new CreateAuthorizePopup(opAuthorizePopup), strUrl);
                                                        by = null;
                                                        strUrl = null;
                                                        xmlHttpMain = null;
                                                        opSetMessage("Communication from the site has interrupted. Please relogin...");
                                                        break;
                                                    }
                                                }
                                                catch { }
                                                try
                                                {
                                                    string[] tSpli = { "attachment; filename=", "Pragma: public", "Set-Cookie:", "Vary:User-Agent", "Keep-Alive" };
                                                    string tFileName1 = xmlHttpMain.getAllResponseHeaders().Split(tSpli, StringSplitOptions.RemoveEmptyEntries)[1].Replace("\r\n", "").Replace(Convert.ToChar(34).ToString(), "").Replace("/", "");
                                                    tFileExtension = System.IO.Path.GetExtension(tFileName1);
                                                    if (tFileExtension == "") tFileExtension = ".doc";
                                                }
                                                catch { }
                                            }
                                            else
                                            {
                                                opSetMessage("Communication from the site has interrupted. Please relogin...");

                                                this.Invoke(new CreateAuthorizePopup(opAuthorizePopup), strUrl);
                                                break;
                                            }
                                        }
                                    }
                                    else
                                    {
                                        opSetMessage("Communication from the site has interrupted. Please relogin...");

                                        this.Invoke(new CreateAuthorizePopup(opAuthorizePopup), strUrl);
                                        break;
                                    }
                                     #endregion
                                }
                                else if (bFlagNaukri == 2)//resdex.
                                {
                                    #region "resdex w24.naukri.com"


                                    FileIDs = grdCandidate.Rows[i].Cells[  "IDs"].Value.ToString().Replace(";", "&").Replace("value=", "");
                                    strUrl = "http://resdex.naukri.com/preview/preview?" + FileIDs.Trim();//.Replace("%3D", "=").Replace("'", "").Trim();
                                     
                                    MSXML2.XMLHTTP xmlHttpMain = new MSXML2.XMLHTTP();
                                    xmlHttpMain.open("GET", strUrl, false, null, null);
                                    xmlHttpMain.setRequestHeader("Content-Type", "text/urlencoded");
                                    xmlHttpMain.send(objNull);

                                    if (xmlHttpMain.statusText == "OK")
                                    {
                                        try
                                        {
                                            if (xmlHttpMain.responseText.IndexOf("In order to prevent misuse of your account.") >= 0 || xmlHttpMain.responseText.IndexOf("You have either exceeding or completely utilized the maximum limit of CV views available for this week") >= 0 || xmlHttpMain.responseText.IndexOf("Someone is already logged into Resdex with this username. Please log-in using one of the available subuser accounts. You can also reset the subuser who is currently accessing Resdex with this username.") >= 0 || xmlHttpMain.responseText.IndexOf("Resetting will logout the user who is currently logged into Resdex with this username") >= 0 || (xmlHttpMain.responseText.IndexOf("Can't read the words below?") >= 0 && xmlHttpMain.responseText.IndexOf("Try different words") >= 0 && xmlHttpMain.responseText.IndexOf("an audio captcha") >= 0))
                                            {

                                                this.Invoke(new CreateAuthorizePopup(opAuthorizePopup), strUrl);
                                                opSetMessage("Communication from the site has interrupted. Please relogin...");
                                                by = null;
                                                break;
                                            }
                                        }
                                        catch { }

                                        strUrl = "";
                                        HtmlDocument objHTML = null; ;
                                        objHTML = this.Invoke(new CreateBrowseronThread(opCreateBrowser), true) as HtmlDocument;
                                        string tResponseText = (string)xmlHttpMain.responseText;
                                        objHTML.Write(tResponseText);
                                        HtmlElement htmlEle1 = objHTML.GetElementById("scroll");
                                        if (htmlEle1 != null)
                                        {
                                            string[] tSp = { "preview/downloadResume?", ">" };

                                            if (htmlEle1.InnerHtml.IndexOf("/preview/downloadResume?") > 0)
                                            {
                                                string[] tData = htmlEle1.InnerHtml.Split(tSp, StringSplitOptions.RemoveEmptyEntries);
                                                if (tData.Length > 2 && tData[2].IndexOf("uname") >= 0)
                                                {
                                                    strUrl = "http://resdex.naukri.com/preview/downloadResume?" + tData[2].Replace("&amp;", "&").Replace(@"""", "").Trim();
                                                }
                                            }
                                        }
                                        else
                                        {

                                            HtmlElementCollection col1 = objHTML.GetElementsByTagName("a");
                                            foreach (HtmlElement htmlEle in col1)
                                            {
                                                if (htmlEle.GetAttribute("href").ToString().Replace("about:", "").Contains("/v2/preview/downloadResume?uname="))
                                                {
                                                    strUrl = "http://resdex.naukri.com" + htmlEle.GetAttribute("href").ToString().Replace("about:", "");
                                                    break;
                                                }
                                            }
                                            col1 = null;

                                        }
                                        htmlEle1 = null;  
                                        string tContactDetails = "";
                                        
                                        if (strUrl != "")
                                        {
                                            xmlHttpMain = null;
                                            xmlHttpMain = new MSXML2.XMLHTTP();
                                            xmlHttpMain.open("GET", strUrl, false, null, null);
                                            xmlHttpMain.setRequestHeader("Content-Type", "text/urlencoded");
                                            xmlHttpMain.send(objNull);
                                             
                                            if  (xmlHttpMain.statusText == "OK")
                                            {
                                                by = (byte[])xmlHttpMain.responseBody;
                                                try
                                                {
                                                    if (xmlHttpMain.responseText.IndexOf("In order to prevent misuse of your account.") >= 0 || xmlHttpMain.responseText.IndexOf("You have either exceeding or completely utilized the maximum limit of CV views available for this week") >= 0 || xmlHttpMain.responseText.IndexOf("Someone is already logged into Resdex with this username. Please log-in using one of the available subuser accounts. You can also reset the subuser who is currently accessing Resdex with this username.") >= 0 || xmlHttpMain.responseText.IndexOf("Resetting will logout the user who is currently logged into Resdex with this username") >= 0 || (xmlHttpMain.responseText.IndexOf("Can't read the words below?") >= 0 && xmlHttpMain.responseText.IndexOf("Try different words") >= 0 && xmlHttpMain.responseText.IndexOf("an audio captcha") >= 0))
                                                    {

                                                        this.Invoke(new CreateAuthorizePopup(opAuthorizePopup), strUrl);
                                                        opSetMessage("Communication from the site has interrupted. Please relogin...");
                                                        by = null;
                                                        break;
                                                    }
                                                }
                                                catch { }
                                                try
                                                {
                                                    string[] tSpli = { "attachment; filename=", "Pragma:", "Pragma: public", "Set-Cookie:", "Vary:User-Agent", "Keep-Alive" };
                                                    string tFileName1 = xmlHttpMain.getAllResponseHeaders().Split(tSpli, StringSplitOptions.RemoveEmptyEntries)[1].Replace("\r\n", "").Replace(Convert.ToChar(34).ToString(), "").Replace("/", "");

                                                    tFileExtension = System.IO.Path.GetExtension(tFileName1);
                                                    if (tFileExtension == "") tFileExtension = ".doc";
                                                }
                                                catch { }
                                            }
                                            else
                                            {

                                                this.Invoke(new CreateAuthorizePopup(opAuthorizePopup), strUrl);
                                                opSetMessage("Communication from the site has interrupted. Please relogin...");
                                                break;
                                            }
                                            xmlHttpMain = null;
                                        }
                                        else
                                        {
                                            iUnKnownFormatResumes++;
                                            bUpdateGridInfoUnknown delObj = new bUpdateGridInfoUnknown(opUpdateGridInfoUnknown);
                                            delObj.Invoke(grdCandidate.Rows[i].Cells[  "IDs"].Value.ToString());
                                            System.Windows.Forms.Application.DoEvents();
                                            delObj = null;
                                            lblUnknownFormatR.Text = iUnKnownFormatResumes.ToString();
                                            System.Windows.Forms.Application.DoEvents();

                                            this.Invoke(new CreateAuthorizePopup(opAuthorizePopup), "http://resdex.naukri.com/preview/preview?" + grdCandidate.Rows[i].Cells[  "IDs"].Value.ToString().Replace(";", "&").Replace("value=", "").Trim());
                                            opSetMessage("Communication from the site has interrupted....");
                                            break;
                                        }
                                    }
                                    else
                                    {

                                        this.Invoke(new CreateAuthorizePopup(opAuthorizePopup), strUrl);
                                        opSetMessage("Communication from the site has interrupted. Please relogin...");
                                        break;
                                    }
                                    #endregion
                                }
                                else if (bFlagNaukri == 211)//response.
                                {
                                    #region "response w24.naukri.com"

                                    tFileExtension = ".doc";
                                    FileIDs = grdCandidate.Rows[i].Cells["IDs"].Value.ToString().Replace(";", "&").Replace("value=", "");

                                    if (tCookies != null && tCookies.IndexOf("ACCESS") >= 0)
                                    {
                                        byte[] barr = System.Text.Encoding.UTF8.GetBytes("aid=" + FileIDs + "&view=new&source=preview");

                                        System.Net.HttpWebRequest wbReq = (System.Net.HttpWebRequest)System.Net.WebRequest.Create("http://response.naukri.com/brv/download/single");
                                        wbReq.Method = "POST";
                                        wbReq.ContentType = "application/x-www-form-urlencoded";
                                        wbReq.ContentLength = barr.Length;

                                        System.Net.CookieContainer chkCook = new System.Net.CookieContainer();
                                        chkCook.Add(new System.Net.Cookie("ACCESS", tNaukriCoockiesACCESS, "/", ".naukri.com"));
                                        chkCook.Add(new System.Net.Cookie("test", tNaukriCoockiesTest, "/", ".naukri.com"));
                                        chkCook.Add(new System.Net.Cookie("UNID", tNaukriCoockiesUNID, "/", ".naukri.com"));

                                        wbReq.CookieContainer = chkCook;

                                        using (System.IO.Stream str = wbReq.GetRequestStream())
                                        {
                                            str.Write(barr, 0, barr.Length);
                                            str.Close();
                                        }

                                        using (System.Net.WebResponse wbRes = wbReq.GetResponse())
                                        {
                                            byte[] buffer = new byte[4096];
                                            System.IO.Stream responseStream = wbRes.GetResponseStream();
                                            System.IO.MemoryStream memStr = new System.IO.MemoryStream();

                                            int count = 0;
                                            bool bLoop = true;
                                            do
                                            {
                                                count = responseStream.Read(buffer, 0, buffer.Length);
                                                memStr.Write(buffer, 0, count);

                                                if (count == 0)
                                                    bLoop = false;

                                            } while (bLoop);

                                            by = memStr.ToArray();

                                            try
                                            {
                                                tFileExtension = System.IO.Path.GetExtension(System.IO.Path.GetTempPath() + wbRes.Headers.GetValues(0)[0].Split('=')[1].Trim());
                                            }
                                            catch { }

                                            memStr.Close();
                                            memStr = null;
                                            responseStream.Close();
                                            responseStream = null;
                                            buffer = null;
                                            wbRes.Close();
                                        }

                                        barr = null;
                                        chkCook = null;
                                        wbReq = null;
                                    }
                                    else
                                    {
                                        strUrl = "http://response.naukri.com/brv/preview/show?aid=" + FileIDs.Trim() + "&view=new#";
                                        MSXML2.XMLHTTP xmlHttpMain = new MSXML2.XMLHTTP();
                                        xmlHttpMain.open("GET", strUrl, false, null, null);
                                        xmlHttpMain.setRequestHeader("Content-Type", "text/urlencoded");
                                        xmlHttpMain.send(objNull);
                                        tFileExtension = ".doc";

                                        if (xmlHttpMain.statusText == "OK")
                                        {
                                            try
                                            {
                                                if (xmlHttpMain.responseText.IndexOf("In order to prevent misuse of your account.") >= 0 || xmlHttpMain.responseText.IndexOf("You have either exceeding or completely utilized the maximum limit of CV views available for this week") >= 0 || xmlHttpMain.responseText.IndexOf("Someone is already logged into Resdex with this username. Please log-in using one of the available subuser accounts. You can also reset the subuser who is currently accessing Resdex with this username.") >= 0 || xmlHttpMain.responseText.IndexOf("Resetting will logout the user who is currently logged into Resdex with this username") >= 0 || (xmlHttpMain.responseText.IndexOf("Can't read the words below?") >= 0 && xmlHttpMain.responseText.IndexOf("Try different words") >= 0 && xmlHttpMain.responseText.IndexOf("an audio captcha") >= 0))
                                                {

                                                    this.Invoke(new CreateAuthorizePopup(opAuthorizePopup), strUrl);
                                                    opSetMessage("Communication from the site has interrupted. Please relogin...");
                                                    by = null;
                                                    break;
                                                }
                                            }
                                            catch { }

                                            string[] st = { "<h3 class=\"rphead\">Candidate Text Resume</h3>", "<div style=\"margin-top: 20px;\" class=\"topButBG\">" };
                                            string tResponseText = (string)xmlHttpMain.responseText;
                                            tResponseText = tResponseText.Split(st, StringSplitOptions.RemoveEmptyEntries)[1].Trim();
                                            tResponseText = tResponseText.Replace("<br />", System.Environment.NewLine).Replace("<div class=\"mainPadLR1 mainPadtop2 lH18\">", "").Replace("</div>", "").Trim();
                                            by = System.Text.Encoding.UTF8.GetBytes(tResponseText);

                                        }
                                        else
                                        {

                                            this.Invoke(new CreateAuthorizePopup(opAuthorizePopup), strUrl);
                                            opSetMessage("Communication from the site has interrupted. Please relogin...");
                                            break;
                                        }
                                        xmlHttpMain = null;
                                    }
                                    #endregion
                                }
                                else if (bFlagNaukri == 221)//response.eapp
                                {
                                    #region "w24.naukri.com"

                                    tFileExtension = ".doc";
                                    FileIDs = grdCandidate.Rows[i].Cells["IDs"].Value.ToString().Replace(";", "&").Replace("value=", "");
                                    strUrl = "http://response.naukri.com/responsemanager/download/DownloadSingle?applyId=" + FileIDs.Replace("\"", "").Trim();

                                    if (strUrl != "")
                                    {
                                        MSXML2.XMLHTTP xmlHttpMain = new MSXML2.XMLHTTP();
                                        xmlHttpMain.open("GET", strUrl, false, null, null);
                                        xmlHttpMain.setRequestHeader("Content-Type", "text/urlencoded");
                                        xmlHttpMain.send(objNull);
                                        tFileExtension = ".doc";
                                        if (xmlHttpMain.statusText == "OK")
                                        {
                                            by = (byte[])xmlHttpMain.responseBody;
                                            try
                                            {
                                                if (xmlHttpMain.responseText.IndexOf("In order to prevent misuse of your account.") >= 0 || xmlHttpMain.responseText.IndexOf("You have either exceeding or completely utilized the maximum limit of CV views available for this week") >= 0 || xmlHttpMain.responseText.IndexOf("Someone is already logged into Resdex with this username. Please log-in using one of the available subuser accounts. You can also reset the subuser who is currently accessing Resdex with this username.") >= 0 || xmlHttpMain.responseText.IndexOf("Resetting will logout the user who is currently logged into Resdex with this username") >= 0 || (xmlHttpMain.responseText.IndexOf("Can't read the words below?") >= 0 && xmlHttpMain.responseText.IndexOf("Try different words") >= 0 && xmlHttpMain.responseText.IndexOf("an audio captcha") >= 0))
                                                {

                                                    this.Invoke(new CreateAuthorizePopup(opAuthorizePopup), strUrl);
                                                    opSetMessage("Communication from the site has interrupted. Please relogin...");
                                                    by = null;
                                                    break;
                                                }
                                            }
                                            catch { }
                                            try
                                            {
                                                string[] tSpli = { "attachment; filename=", "Vary:User-Agent" };
                                                string tFileName1 = xmlHttpMain.getAllResponseHeaders().Split(tSpli, StringSplitOptions.RemoveEmptyEntries)[1].Replace("\r\n", "").Replace(Convert.ToChar(34).ToString(), "").Replace("/", "");

                                                tFileExtension = System.IO.Path.GetExtension(tFileName1);
                                                if (tFileExtension == "") tFileExtension = ".doc";
                                                try
                                                {
                                                    if (xmlHttpMain.responseText.StartsWith("<html>"))
                                                        tFileExtension = ".htm";
                                                }
                                                catch { }
                                            }
                                            catch { }
                                        }
                                        else
                                        {

                                            this.Invoke(new CreateAuthorizePopup(opAuthorizePopup), strUrl);
                                            opSetMessage("Communication from the site has interrupted. Please relogin...");
                                            break;
                                        }
                                        xmlHttpMain = null;
                                    }
                                    else
                                    {
                                        iUnKnownFormatResumes++;
                                        bUpdateGridInfoUnknown delObj = new bUpdateGridInfoUnknown(opUpdateGridInfoUnknown);
                                        delObj.Invoke(grdCandidate.Rows[i].Cells["IDs"].Value.ToString());
                                        System.Windows.Forms.Application.DoEvents();
                                        delObj = null;
                                        System.Windows.Forms.Application.DoEvents();
                                        lblUnknownFormatR.Text = iUnKnownFormatResumes.ToString();
                                        System.Windows.Forms.Application.DoEvents();
                                        continue;
                                    }

                                    #endregion
                                }
                                else if (bFlagNaukri == 3)
                                {
                                    #region "hire.timesjobs.com"
                                    string strUrl1 = "";
                                    tFileExtension = ".doc";
                                    FileIDs = grdCandidate.Rows[i].Cells["IDs"].Value.ToString().ToString().Replace("&amp;", "&").Replace("value=", "");
                                    strUrl = FileIDs;
                                    strUrl1 = FileIDs;
                                    MSXML2.XMLHTTP xmlHttpMain = new MSXML2.XMLHTTP();
                                    xmlHttpMain.open("GET", strUrl, false, null, null);
                                    xmlHttpMain.setRequestHeader("Content-Type", "text/urlencoded");
                                    xmlHttpMain.send(objNull);
                                    if (xmlHttpMain.statusText == "OK")
                                    {
                                        strUrl = "";
                                        string tResponseText = (string)xmlHttpMain.responseText;
                                        tResponseText = tResponseText.Replace("var pageTracker = _gat._getTracker(\"UA-1688637-4\");", "<!-- var pageTracker = _gat._getTracker(\"UA-1688637-4\"); -->");
                                        tResponseText = tResponseText.Replace("pageTracker._initData();", "<!-- pageTracker._initData(); -->");
                                        tResponseText = tResponseText.Replace("pageTracker._trackPageview();", "<!-- pageTracker._trackPageview(); -->");

                                        HtmlDocument objHTML = null; ;
                                        objHTML = this.Invoke(new CreateBrowseronThread(opCreateBrowser), true) as HtmlDocument;
                                        objHTML.Write(tResponseText);

                                        HtmlElementCollection col1 = objHTML.GetElementsByTagName("a");

                                        foreach (HtmlElement htmlEle in col1)
                                        {
                                            if (htmlEle.InnerText == null) continue;
                                            if (htmlEle.InnerText.Contains("Download Resume") && string.IsNullOrEmpty(strUrl))
                                            {
                                                strUrl = "http://hire.timesjobs.com/employer/viewWordResume.html?_q=" + htmlEle.OuterHtml.Split(new string[] { "_q=", "');" }, StringSplitOptions.RemoveEmptyEntries)[2];
                                                break;
                                            }
                                        }

                                        if (strUrl != "")
                                        {
                                            System.Net.WebClient sbC = new System.Net.WebClient();
                                            sbC.Headers.Set("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8");
                                            sbC.Headers.Set("Connection", "keep - alive");
                                            sbC.Headers.Set("Host", "hire.timesjobs.com");

                                            sbC.Headers.Set("Referer", strUrl1);
                                            sbC.Headers.Set("Cookie", tTimesJobCookies);
                                            by = sbC.DownloadData(strUrl);

                                            if (by != null)
                                            {

                                                try
                                                {
                                                    string[] tSpli = { "attachment; filename=", "Pragma: public", "Set-Cookie:", "Vary:User-Agent", "Keep-Alive" };
                                                    string tFileName1 = sbC.ResponseHeaders.Get(0).Split(tSpli, StringSplitOptions.RemoveEmptyEntries)[0].Replace("\r\n", "").Replace(Convert.ToChar(34).ToString(), "").Replace("/", ""); ;
                                                    tFileExtension = System.IO.Path.GetExtension(tFileName1);
                                                    if (tFileExtension == "") tFileExtension = ".doc";
                                                }
                                                catch { }
                                            }
                                            sbC = null;
                                        }
                                        else
                                        {
                                            by = (byte[])xmlHttpMain.responseBody;
                                        }
                                    }

                                    #endregion
                                }
                                else if (bFlagNaukri == 4)
                                {
                                    #region "recruiter.monstergulf.com"

                                    tFileExtension = ".doc";
                                    FileIDs = grdCandidate.Rows[i].Cells["IDs"].Value.ToString().Replace(";", "&");
                                    strUrl = "http://recruiter.monstergulf.com/resumedatabase/resume.html?" + FileIDs;
                                    MSXML2.XMLHTTP xmlHttpMain = new MSXML2.XMLHTTP();
                                    xmlHttpMain.open("GET", strUrl, false, null, null);
                                    xmlHttpMain.setRequestHeader("Content-Type", "text/urlencoded");
                                    xmlHttpMain.send(objNull);
                                    if (xmlHttpMain.statusText == "OK")
                                    {
                                        strUrl = "";
                                        string tResponseText = (string)xmlHttpMain.responseText;//.Replace("<script type=\"text/javascript\">", "<!-- <script type=\"text/javascript\">").Replace("</script>", "</script> -->");
                                        try
                                        {
                                            if (xmlHttpMain.responseText.IndexOf("Create a Personal Folder") >= 0 || xmlHttpMain.responseText.IndexOf("Insufficient Resume Inventory") >= 0)
                                            {

                                                this.Invoke(new CreateAuthorizePopup(opAuthorizePopup), strUrl);
                                                by = null;
                                                strUrl = null;
                                                xmlHttpMain = null;
                                                opSetMessage("Communication from the site has interrupted. Please relogin...");
                                                break;
                                            }
                                            else if (xmlHttpMain.responseText.IndexOf("Search results shall show resumes within 3 months") >= 0)
                                            {

                                                this.Invoke(new CreateAuthorizePopup(opAuthorizePopup), strUrl);
                                                by = null;
                                                strUrl = null;
                                                xmlHttpMain = null;
                                                opSetMessage("Communication from the site has interrupted. Please relogin...");
                                                break;
                                            }
                                            else if (xmlHttpMain.responseText.IndexOf("Please authenticate yourself by typing the code that you see below.") >= 0)
                                            {

                                                this.Invoke(new CreateAuthorizePopup(opAuthorizePopup), strUrl);
                                                by = null;
                                                strUrl = null;
                                                xmlHttpMain = null;
                                                opSetMessage("Communication from the site has interrupted. Please relogin...");
                                                break;
                                            }
                                        }
                                        catch { }
                                        string[] tsp = { "url = '/resumedatabase/resume_process_request.html?", "url += '" };
                                        string[] tsp1 = { "';\n" };
                                        string[] tspdata = tResponseText.Split(tsp, StringSplitOptions.RemoveEmptyEntries);
                                        if (tspdata.Length > 1)
                                        {

                                            strUrl = "http://recruiter.monstergulf.com/resumedatabase/resume_process_request.html?" + tspdata[1].Replace("';\n", "").Trim();
                                            //strUrl += strUrl2;
                                            xmlHttpMain = null;
                                            xmlHttpMain = new MSXML2.XMLHTTP();
                                            xmlHttpMain.open("GET", strUrl, false, null, null);
                                            xmlHttpMain.setRequestHeader("Content-Type", "text/urlencoded");
                                            xmlHttpMain.send(objNull);
                                            if (xmlHttpMain.statusText == "OK")
                                            {

                                                by = (byte[])xmlHttpMain.responseBody;
                                                try
                                                {

                                                    if (xmlHttpMain.responseText.IndexOf("Create a Personal Folder") >= 0 || xmlHttpMain.responseText.IndexOf("Insufficient Resume Inventory") >= 0)
                                                    {

                                                        this.Invoke(new CreateAuthorizePopup(opAuthorizePopup), strUrl);
                                                        by = null;
                                                        strUrl = null;
                                                        xmlHttpMain = null;
                                                        opSetMessage("Communication from the site has interrupted. Please relogin...");
                                                        break;
                                                    }
                                                    else if (xmlHttpMain.responseText.IndexOf("Search results shall show resumes within 3 months") >= 0)
                                                    {

                                                        this.Invoke(new CreateAuthorizePopup(opAuthorizePopup), strUrl);
                                                        by = null;
                                                        strUrl = null;
                                                        xmlHttpMain = null;
                                                        opSetMessage("Communication from the site has interrupted. Please relogin...");
                                                        break;
                                                    }
                                                    else if (xmlHttpMain.responseText.IndexOf("Please authenticate yourself by typing the code that you see below.") >= 0)
                                                    {

                                                        this.Invoke(new CreateAuthorizePopup(opAuthorizePopup), strUrl);
                                                        by = null;
                                                        strUrl = null;
                                                        xmlHttpMain = null;
                                                        opSetMessage("Communication from the site has interrupted. Please relogin...");
                                                        break;
                                                    }
                                                    string[] tSpli = { "attachment; filename=", "Pragma: public", "Set-Cookie:", "Vary:User-Agent", "Keep-Alive" };
                                                    string tFileName1 = xmlHttpMain.getAllResponseHeaders().Split(tSpli, StringSplitOptions.RemoveEmptyEntries)[1].Replace("\r\n", "").Replace(Convert.ToChar(34).ToString(), "").Replace("/", "");
                                                    tFileExtension = System.IO.Path.GetExtension(tFileName1);
                                                    if (tFileExtension == "") tFileExtension = ".doc";

                                                }
                                                catch { }
                                            }
                                            else
                                            {

                                                this.Invoke(new CreateAuthorizePopup(opAuthorizePopup), strUrl);
                                                opSetMessage("Communication from the site has interrupted. Please relogin...");
                                                break;
                                            }
                                        }
                                    }
                                    else
                                    {

                                        this.Invoke(new CreateAuthorizePopup(opAuthorizePopup), strUrl);
                                        opSetMessage("Communication from the site has interrupted. Please relogin...");
                                        break;
                                    }
                                    #endregion
                                }
                                else if (bFlagNaukri == 5)
                                {
                                    #region "recruiter.CAREERBUILDER.com"

                                    tFileExtension = ".doc";
                                    FileIDs = grdCandidate.Rows[i].Cells["IDs"].Value.ToString().Replace(";", "&").Replace("value=", "");
                                    strUrl = "http://www.careerbuilder.com/JobPoster/Resumes/ResumeDetails.aspx?Resume_DID=" + FileIDs;

                                    MSXML2.XMLHTTP xmlHttpMain = new MSXML2.XMLHTTP();
                                    xmlHttpMain.open("GET", strUrl, false, null, null);
                                    xmlHttpMain.setRequestHeader("Content-Type", "text/urlencoded");
                                    xmlHttpMain.send(objNull);
                                    if (xmlHttpMain.statusText == "OK")
                                    {
                                        strUrl = "";
                                        string tResponseText = (string)xmlHttpMain.responseText.Replace("<script type=\"text/javascript\">", "<!-- <script type=\"text/javascript\">").Replace("</script>", "</script> -->");
                                        tResponseText = tResponseText.Replace("s_cb.pageName='JP_SearchResumes - Resume Details';", "<!-- s_cb.pageName='JP_SearchResumes - Resume Details'; -->");
                                        tResponseText = tResponseText.Replace("s_cb.eVar15='NO_Registered_Employer';", "<!-- s_cb.eVar15='NO_Registered_Employer'; -->");
                                        tResponseText = tResponseText.Replace("s_cb.server='www';", "<!-- s_cb.server='www'; -->");
                                        tResponseText = tResponseText.Replace("s_cb.channel='JP_SearchResumes';", "<!-- s_cb.channel='JP_SearchResumes'; -->");
                                        tResponseText = tResponseText.Replace("s_cb.prop1='Resume Details';", "<!-- s_cb.prop1='Resume Details'; -->");
                                        tResponseText = tResponseText.Replace("s_cb.eVar11='Registered_Employer';", "<!-- s_cb.eVar11='Registered_Employer'; -->");
                                        tResponseText = tResponseText.Replace("var s_code=s_cb.t();if(s_code)document.write(s_code)", "<!-- var s_code=s_cb.t();if(s_code)document.write(s_code) -->");

                                        HtmlDocument objHTML = null; ;
                                        objHTML = this.Invoke(new CreateBrowseronThread(opCreateBrowser), true) as HtmlDocument;
                                        objHTML.Write(tResponseText);
                                        HtmlElementCollection col1 = objHTML.GetElementsByTagName("a");
                                        HtmlElement col = objHTML.GetElementById("ucResumeDetails_ucAffordanceTray_cbhlResumeWordDocSave");

                                        if (col != null) strUrl = col.GetAttribute("href");

                                        if (strUrl != "")
                                        {
                                            xmlHttpMain = new MSXML2.XMLHTTP();
                                            xmlHttpMain.open("GET", strUrl, false, null, null);
                                            xmlHttpMain.setRequestHeader("Content-Type", "text/urlencoded");
                                            xmlHttpMain.send(objNull);
                                            if (xmlHttpMain.statusText == "OK")
                                            {
                                                by = (byte[])xmlHttpMain.responseBody;
                                                try
                                                {
                                                    string[] tSpli = { "attachment; filename=", "X-AspNet-Version: ", "attachment;filename", "Pragma:", "Pragma: public", "Set-Cookie:", "Vary:User-Agent", "Keep-Alive" };
                                                    string tFileName1 = xmlHttpMain.getAllResponseHeaders().Split(tSpli, StringSplitOptions.RemoveEmptyEntries)[1].Replace("\r\n", "").Replace(Convert.ToChar(34).ToString(), "").Replace("/", "");
                                                    tFileExtension = System.IO.Path.GetExtension(tFileName1);
                                                    if (tFileExtension == "") tFileExtension = ".doc";
                                                }
                                                catch { }
                                            }
                                        }
                                        else
                                        {
                                            by = (byte[])xmlHttpMain.responseBody;
                                        }
                                    }
                                    #endregion
                                }
                                else if (bFlagNaukri == 6)
                                {
                                    #region "employer.dice.com"

                                    FileIDs = grdCandidate.Rows[i].Cells["IDs"].Value.ToString().Replace(";", "&").Replace("value=", "");
                                    strUrl = "https://employer.dice.com/talentmatch/servlet/TalentmatchSearch?op=7200&dockey=" + FileIDs;
                                    MSXML2.XMLHTTP xmlHttpMain = new MSXML2.XMLHTTP();
                                    xmlHttpMain.open("POST", strUrl, false, null, null);
                                    xmlHttpMain.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
                                    xmlHttpMain.send(objNull);
                                    tFileExtension = ".doc";
                                    if (xmlHttpMain.statusText == "OK")
                                    {
                                        by = (byte[])xmlHttpMain.responseBody;
                                        try
                                        {
                                            string[] tSpli = { "attachment; filename=", "X-Powered-By:", "filename=", "Pragma:", "Pragma: public", "Set-Cookie:", "Vary:User-Agent", "Connection: Keep-Alive" };
                                            string tFileName1 = xmlHttpMain.getAllResponseHeaders().Split(tSpli, StringSplitOptions.RemoveEmptyEntries)[1].Replace("\r\n", "").Replace(Convert.ToChar(34).ToString(), "").Replace("/", "");
                                            tFileExtension = System.IO.Path.GetExtension(tFileName1);
                                            if (tFileExtension == "") tFileExtension = ".doc";
                                        }
                                        catch { }
                                    }
                                    #endregion
                                }
                                else if (bFlagNaukri == 7)
                                {
                                    #region "w24.naukrigulf.com"

                                    tFileExtension = ".doc";
                                    FileIDs = grdCandidate.Rows[i].Cells["IDs"].Value.ToString().Replace("&amp;", "&").Replace("value=", "");
                                    strUrl = "http://www.naukrigulf.com/ni/niresdex/rdx_preview.php?" + FileIDs.Trim();//.Replace("%3D", "=").Replace("'", "").Trim();
                                    MSXML2.XMLHTTP xmlHttpMain = new MSXML2.XMLHTTP();
                                    xmlHttpMain.open("GET", strUrl, false, null, null);
                                    xmlHttpMain.setRequestHeader("Content-Type", "text/urlencoded");
                                    xmlHttpMain.send(objNull);

                                    if (xmlHttpMain.statusText == "OK")
                                    {
                                        strUrl = "";
                                        HtmlDocument objHTML = null; ;
                                        objHTML = this.Invoke(new CreateBrowseronThread(opCreateBrowser), true) as HtmlDocument;
                                        string tResponseText = (string)xmlHttpMain.responseText;
                                        objHTML.Write(tResponseText);
                                        HtmlElementCollection col1 = objHTML.GetElementsByTagName("A");
                                        foreach (HtmlElement htmlEle in col1)
                                        {
                                            if (htmlEle.InnerText == null) continue;
                                            if (htmlEle.InnerText == "Original CV")
                                            {
                                                string[] reg = System.Text.RegularExpressions.Regex.Split(htmlEle.OuterHtml, "(location.href='|';|return false)", System.Text.RegularExpressions.RegexOptions.IgnoreCase);
                                                if (reg.Length > 2) strUrl = reg[2];
                                                break;
                                            }
                                            else if (htmlEle.InnerText == "Naukrigulf Word")
                                            {
                                                string[] reg = System.Text.RegularExpressions.Regex.Split(htmlEle.OuterHtml, "(location.href='|';|return false)", System.Text.RegularExpressions.RegexOptions.IgnoreCase);
                                                if (reg.Length > 2) strUrl = reg[2];
                                                break;
                                            }
                                            else if (htmlEle.InnerText == "Naukrigulf PDF")
                                            {
                                                string[] reg = System.Text.RegularExpressions.Regex.Split(htmlEle.OuterHtml, "(location.href='|';|return false)", System.Text.RegularExpressions.RegexOptions.IgnoreCase);
                                                if (reg.Length > 2) strUrl = reg[2];
                                                break;
                                            }
                                        }
                                        xmlHttpMain = null;
                                        strUrl = strUrl.Replace("&amp;", "&");// +"&type=ndoc";
                                        xmlHttpMain = new MSXML2.XMLHTTP();
                                        xmlHttpMain.open("GET", strUrl, false, null, null);
                                        xmlHttpMain.setRequestHeader("Content-Type", "application/download");
                                        xmlHttpMain.send(objNull);

                                        if (xmlHttpMain.statusText == "OK")
                                        {
                                            try
                                            {
                                                string[] tSpli = { "Pragma:", "filename*=UTF-8''" };
                                                //string[] tData = xmlHttpMain.getAllResponseHeaders().Split(tSpli, StringSplitOptions.RemoveEmptyEntries);
                                                tFileName = xmlHttpMain.getAllResponseHeaders().Split(tSpli, StringSplitOptions.RemoveEmptyEntries)[1].Replace("\r\n", "").Replace(Convert.ToChar(34).ToString(), "").Replace("/", "").Replace("+", " ");

                                                tFileExtension = System.IO.Path.GetExtension(tFileName);
                                                tFileName = System.IO.Path.GetFileNameWithoutExtension(tFileName);
                                                if (tFileExtension == "") tFileExtension = ".doc";
                                                if (tFileName == "") tFileName = "Resume";
                                            }
                                            catch { }
                                            by = (byte[])xmlHttpMain.responseBody;
                                        }
                                        xmlHttpMain = null;

                                    }

                                    #endregion
                                }
                                else if (bFlagNaukri == 8)
                                {
                                    #region "recruiter.monsterindia.com"
                                    FileIDs = grdCandidate.Rows[i].Cells["IDs"].Value.ToString().Replace("&amp;", "&").Replace(";", "&").Replace("&&", "&");

                                    strUrl = "http://recruiter.monster.com.sg/v2/resumedatabase/resume.html?" + FileIDs;//&sum=0&logo=0&xcode=xyscplinx&serve_txt=0";
                                    tFileExtension = ".doc";
                                    MSXML2.XMLHTTP xmlHttpMain = new MSXML2.XMLHTTP();
                                    xmlHttpMain.open("GET", strUrl, false, null, null);
                                    xmlHttpMain.setRequestHeader("Content-Type", "text/urlencoded");
                                    xmlHttpMain.send(objNull);
                                    if (xmlHttpMain.statusText == "OK")
                                    {
                                        strUrl = "";
                                        string tResponseText = (string)xmlHttpMain.responseText;//.Replace("<script type=\"text/javascript\">", "<!-- <script type=\"text/javascript\">").Replace("</script>", "</script> -->");
                                        try
                                        {
                                            if (xmlHttpMain.responseText.IndexOf("Create a Personal Folder") >= 0 || xmlHttpMain.responseText.IndexOf("Insufficient Resume Inventory") >= 0)
                                            {

                                                this.Invoke(new CreateAuthorizePopup(opAuthorizePopup), strUrl);
                                                by = null;
                                                strUrl = null;
                                                xmlHttpMain = null;
                                                opSetMessage("Communication from the site has interrupted. Please relogin...");
                                                break;
                                            }
                                            else if (xmlHttpMain.responseText.IndexOf("Search results shall show resumes within 3 months") >= 0)
                                            {

                                                this.Invoke(new CreateAuthorizePopup(opAuthorizePopup), strUrl);
                                                by = null;
                                                strUrl = null;
                                                xmlHttpMain = null;
                                                opSetMessage("Communication from the site has interrupted. Please relogin...");
                                                break;
                                            }
                                            else if (xmlHttpMain.responseText.IndexOf("Please authenticate yourself by typing the code that you see below.") >= 0)
                                            {

                                                this.Invoke(new CreateAuthorizePopup(opAuthorizePopup), strUrl);
                                                by = null;
                                                strUrl = null;
                                                xmlHttpMain = null;
                                                opSetMessage("Communication from the site has interrupted. Please relogin...");
                                                break;
                                            }
                                        }
                                        catch { }
                                        string[] tsp = { "url = '/resumedatabase/resume_process_request.html?", "url += '" };
                                        string[] tsp1 = { "';\n" };
                                        string[] tspdata = tResponseText.Split(tsp, StringSplitOptions.RemoveEmptyEntries);

                                        if (tspdata.Length > 1)
                                        {
                                            strUrl = "http://recruiter.monster.com.sg/resumedatabase/resume_process_request.html?" + tspdata[1].Replace("';\n", "").Trim();
                                            //strUrl += strUrl2;
                                            xmlHttpMain = null;
                                            xmlHttpMain = new MSXML2.XMLHTTP();
                                            xmlHttpMain.open("GET", strUrl, false, null, null);
                                            xmlHttpMain.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
                                            xmlHttpMain.send(objNull);

                                            if (xmlHttpMain.statusText == "OK")
                                            {
                                                by = (byte[])xmlHttpMain.responseBody;
                                                try
                                                {
                                                    if (xmlHttpMain.responseText.IndexOf("Create a Personal Folder") >= 0 || xmlHttpMain.responseText.IndexOf("Insufficient Resume Inventory") >= 0)
                                                    {

                                                        this.Invoke(new CreateAuthorizePopup(opAuthorizePopup), strUrl);
                                                        by = null;
                                                        strUrl = null;
                                                        xmlHttpMain = null;
                                                        opSetMessage("Communication from the site has interrupted. Please relogin...");
                                                        break;
                                                    }
                                                    else if (xmlHttpMain.responseText.IndexOf("Search results shall show resumes within 3 months") >= 0)
                                                    {

                                                        this.Invoke(new CreateAuthorizePopup(opAuthorizePopup), strUrl);
                                                        by = null;
                                                        strUrl = null;
                                                        xmlHttpMain = null;
                                                        opSetMessage("Communication from the site has interrupted. Please relogin...");
                                                        break;
                                                    }
                                                    else if (xmlHttpMain.responseText.IndexOf("Please authenticate yourself by typing the code that you see below.") >= 0)
                                                    {

                                                        this.Invoke(new CreateAuthorizePopup(opAuthorizePopup), strUrl);
                                                        by = null;
                                                        strUrl = null;
                                                        xmlHttpMain = null;
                                                        opSetMessage("Communication from the site has interrupted. Please relogin...");
                                                        break;
                                                    }
                                                    string[] tSpli = { "attachment; filename=", "Pragma: public", "Set-Cookie:", "Vary:User-Agent", "Keep-Alive" };
                                                    string tFileName1 = xmlHttpMain.getAllResponseHeaders().Split(tSpli, StringSplitOptions.RemoveEmptyEntries)[1].Replace("\r\n", "").Replace(Convert.ToChar(34).ToString(), "").Replace("/", "");
                                                    tFileExtension = System.IO.Path.GetExtension(tFileName1);
                                                    if (tFileExtension == "") tFileExtension = ".doc";

                                                }
                                                catch { }
                                            }
                                            else
                                            {

                                                this.Invoke(new CreateAuthorizePopup(opAuthorizePopup), strUrl);
                                                opSetMessage("Communication from the site has interrupted. Please relogin...");
                                            }
                                        }
                                    }
                                    else
                                    {
                                        opSetMessage("Communication from the site has interrupted. Please relogin...");

                                        this.Invoke(new CreateAuthorizePopup(opAuthorizePopup), strUrl);
                                        break;
                                    }
                                    #endregion

                                }
                                else if (bFlagNaukri == 9)
                                {
                                    #region "recruiter.monster.com.my"

                                    //FileIDs = grdCandidate.Rows[i].Cells[  "IDs").ToString().Replace(";", "&");
                                    //strUrl = "http://recruiter.monster.com.my/resumedatabase/resume_process_request.html?" + FileIDs + "&type=doc";//&sum=0&logo=0&xcode=xyscplinx&serve_txt=0";
                                    //MSXML2.XMLHTTP xmlHttpMain = new MSXML2.XMLHTTP();
                                    //xmlHttpMain.open("GET", strUrl, false, null, null);
                                    //xmlHttpMain.setRequestHeader("Content-Type", "text/urlencoded");
                                    //xmlHttpMain.send(objNull);
                                    //if (xmlHttpMain.statusText == "OK")
                                    //    by = (byte[])xmlHttpMain.responseBody;

                                    FileIDs = grdCandidate.Rows[i].Cells["IDs"].Value.ToString().Replace("&amp;", "&").Replace(";", "&").Replace("&&", "&");
                                    strUrl = "http://recruiter.monster.com.my/resumedatabase/resume.html?" + FileIDs + "&type=doc";
                                    MSXML2.XMLHTTP xmlHttpMain = new MSXML2.XMLHTTP();
                                    xmlHttpMain.open("GET", strUrl, false, null, null);
                                    xmlHttpMain.setRequestHeader("Content-Type", "text/urlencoded");
                                    xmlHttpMain.send(objNull);
                                    if (xmlHttpMain.statusText == "OK")
                                    {
                                        strUrl = "";
                                        string tResponseText = (string)xmlHttpMain.responseText;
                                        try
                                        {

                                            if (xmlHttpMain.responseText.IndexOf("Create a Personal Folder") >= 0 || xmlHttpMain.responseText.IndexOf("Insufficient Resume Inventory") >= 0)
                                            {
                                                this.Invoke(new CreateAuthorizePopup(opAuthorizePopup), strUrl);
                                                by = null;
                                                strUrl = null;
                                                xmlHttpMain = null;
                                                opSetMessage("Communication from the site has interrupted. Please relogin...");
                                                break;
                                            }
                                            else if (xmlHttpMain.responseText.IndexOf("Search results shall show resumes within 3 months") >= 0)
                                            {
                                                this.Invoke(new CreateAuthorizePopup(opAuthorizePopup), strUrl);
                                                by = null;
                                                strUrl = null;
                                                xmlHttpMain = null;
                                                opSetMessage("Communication from the site has interrupted. Please relogin...");
                                                break;
                                            }
                                            else if (xmlHttpMain.responseText.IndexOf("Please authenticate yourself by typing the code that you see below.") >= 0)
                                            {
                                                this.Invoke(new CreateAuthorizePopup(opAuthorizePopup), strUrl);
                                                by = null;
                                                strUrl = null;
                                                xmlHttpMain = null;
                                                opSetMessage("Communication from the site has interrupted. Please relogin...");
                                                break;
                                            }
                                        }
                                        catch { }
                                        #region "fetching detail information"

                                        HtmlAgilityPack.HtmlDocument objHTML1 = null;
                                        objHTML1 = new HtmlAgilityPack.HtmlDocument();
                                        objHTML1.LoadHtml(tResponseText);
                                       
                                        #endregion
                                        //.Replace("<script type=\"text/javascript\">", "<!-- <script type=\"text/javascript\">").Replace("</script>", "</script> -->");
                                        string[] tsp = { "url = '/resumedatabase/resume_process_request.html?", "url += '" };
                                        string[] tsp1 = { "';\n" };
                                        string[] tspdata = tResponseText.Split(tsp, StringSplitOptions.RemoveEmptyEntries);

                                        // string strUrl2 = tspdata[2].Split(tsp1, StringSplitOptions.RemoveEmptyEntries)[0].Trim().Replace("'+summaryFlag+'", "1");
                                        if (tspdata.Length > 1)
                                        {
                                            strUrl = "http://recruiter.monster.com.my/resumedatabase/resume_process_request.html?" + tspdata[1].Replace("';\n", "").Trim();
                                            //strUrl += strUrl2;
                                            xmlHttpMain = null;
                                            xmlHttpMain = new MSXML2.XMLHTTP();
                                            xmlHttpMain.open("GET", strUrl, false, null, null);
                                            xmlHttpMain.setRequestHeader("Content-Type", "text/urlencoded");
                                            xmlHttpMain.send(objNull);

                                            if (xmlHttpMain.statusText == "OK")
                                            {
                                                by = (byte[])xmlHttpMain.responseBody;
                                                try
                                                {

                                                    if (xmlHttpMain.responseText.IndexOf("Create a Personal Folder") >= 0 || xmlHttpMain.responseText.IndexOf("Insufficient Resume Inventory") >= 0)
                                                    {
                                                        this.Invoke(new CreateAuthorizePopup(opAuthorizePopup), strUrl);
                                                        by = null;
                                                        strUrl = null;
                                                        xmlHttpMain = null;
                                                        opSetMessage("Communication from the site has interrupted. Please relogin...");
                                                        break;
                                                    }
                                                    else if (xmlHttpMain.responseText.IndexOf("Search results shall show resumes within 3 months") >= 0)
                                                    {
                                                        this.Invoke(new CreateAuthorizePopup(opAuthorizePopup), strUrl);
                                                        by = null;
                                                        strUrl = null;
                                                        xmlHttpMain = null;
                                                        opSetMessage("Communication from the site has interrupted. Please relogin...");
                                                        break;
                                                    }
                                                    else if (xmlHttpMain.responseText.IndexOf("Please authenticate yourself by typing the code that you see below.") >= 0)
                                                    {
                                                        this.Invoke(new CreateAuthorizePopup(opAuthorizePopup), strUrl);
                                                        by = null;
                                                        strUrl = null;
                                                        xmlHttpMain = null;
                                                        opSetMessage("Communication from the site has interrupted. Please relogin...");
                                                        break;
                                                    }
                                                }
                                                catch { }
                                                try
                                                {
                                                    string[] tSpli = { "attachment; filename=", "Pragma: public", "Set-Cookie:", "Vary:User-Agent", "Keep-Alive" };
                                                    string tFileName1 = xmlHttpMain.getAllResponseHeaders().Split(tSpli, StringSplitOptions.RemoveEmptyEntries)[1].Replace("\r\n", "").Replace(Convert.ToChar(34).ToString(), "").Replace("/", "");
                                                    tFileExtension = System.IO.Path.GetExtension(tFileName1);
                                                    if (tFileExtension == "") tFileExtension = ".doc";
                                                }
                                                catch { }
                                            }
                                            else
                                            {
                                                opSetMessage("Communication from the site has interrupted. Please relogin...");
                                                this.Invoke(new CreateAuthorizePopup(opAuthorizePopup), strUrl);
                                                break;
                                            }
                                        }
                                    }
                                    else
                                    {
                                        opSetMessage("Communication from the site has interrupted. Please relogin...");
                                        this.Invoke(new CreateAuthorizePopup(opAuthorizePopup), strUrl);
                                        break;
                                    }

                                    #endregion
                                }
                                else if (bFlagNaukri == 10)
                                {
                                    #region "recruiter.monster.com.sg"

                                    FileIDs = grdCandidate.Rows[i].Cells["IDs"].Value.ToString().Replace(";", "&");
                                    strUrl = "http://recruiter.monster.com.sg/resumedatabase/resume_process_request.html?" + FileIDs + "&type=doc";//&sum=0&logo=0&xcode=xyscplinx&serve_txt=0";
                                    MSXML2.XMLHTTP xmlHttpMain = new MSXML2.XMLHTTP();
                                    xmlHttpMain.open("GET", strUrl, false, null, null);
                                    xmlHttpMain.setRequestHeader("Content-Type", "text/urlencoded");
                                    xmlHttpMain.send(objNull);
                                    if (xmlHttpMain.statusText == "OK")
                                        by = (byte[])xmlHttpMain.responseBody;

                                    #endregion
                                }
                                else if (bFlagNaukri == 11)
                                {
                                    #region "recruiter.monster.com.sg"

                                    by = null;
                                    FileIDs = grdCandidate.Rows[i].Cells["IDs"].Value.ToString().Replace(";", "&");
                                    strUrl = "http://hiring.monster.com/jcm/candidates/downloadSeekerDocument.aspx?sPath=private_0/resumes/" + FileIDs;
                                    tFileExtension = ".doc";
                                    MSXML2.XMLHTTP xmlHttpMain = new MSXML2.XMLHTTP();
                                    xmlHttpMain.open("POST", strUrl, false, null, null);
                                    xmlHttpMain.setRequestHeader("Content-Type", "text/urlencoded");
                                    xmlHttpMain.send(objNull);
                                    if (xmlHttpMain.statusText == "OK" && xmlHttpMain.getAllResponseHeaders().IndexOf("filename") >= 0)
                                    {
                                        by = (byte[])xmlHttpMain.responseBody;
                                        try
                                        {
                                            string[] tSpli = { "attachment; filename=", "Pragma:", "Pragma: public", "Set-Cookie:", "Vary:User-Agent", "Keep-Alive", "X-ORIG-COOKIE:" };
                                            string tFileName1 = xmlHttpMain.getAllResponseHeaders().Split(tSpli, StringSplitOptions.RemoveEmptyEntries)[1].Replace("\r\n", "").Replace(Convert.ToChar(34).ToString(), "").Replace("/", "");
                                            tFileExtension = System.IO.Path.GetExtension(tFileName1);
                                            tFileName = System.IO.Path.GetFileNameWithoutExtension(tFileName1);
                                            if (tFileExtension == "") tFileExtension = ".doc";
                                        }
                                        catch { }
                                    }

                                    #endregion
                                }
                                else if (bFlagNaukri == 12)
                                {
                                    #region "ats.mcbarronwood.com"

                                    FileIDs = grdCandidate.Rows[i].Cells["IDs"].Value.ToString().Replace(";", "&").Replace("value=", "");
                                    strUrl = FileIDs;
                                    MSXML2.XMLHTTP xmlHttpMain = new MSXML2.XMLHTTP();
                                    xmlHttpMain.open("GET", strUrl, false, null, null);
                                    xmlHttpMain.setRequestHeader("Content-Type", "text/urlencoded");
                                    xmlHttpMain.send(objNull);
                                    if (xmlHttpMain.statusText == "OK")
                                    {
                                        strUrl = "";
                                        HtmlDocument objHTML = null;
                                        objHTML = this.Invoke(new CreateBrowseronThread(opCreateBrowser), false) as HtmlDocument;
                                        string tResponseText = (string)xmlHttpMain.responseText;
                                        objHTML.Write(tResponseText);
                                        HtmlElementCollection col1 = objHTML.GetElementsByTagName("a");
                                        foreach (HtmlElement htmlEle in col1)
                                        {
                                            if (htmlEle.GetAttribute("href").IndexOf("attachments/") > 0)
                                            {
                                                strUrl = "http://ats.mcbarronwood.com/" + htmlEle.GetAttribute("href").Replace("about:blank", "").Replace("about:", "").Replace("blank", "").Trim();// +"&resumeindex=0&resumeboardid=1&qryMode=true&folderID=0&folderApplicantID=&encrb=" + tEncID;
                                                break;
                                            }
                                        }
                                        if (strUrl != "")
                                        {
                                            xmlHttpMain = new MSXML2.XMLHTTP();
                                            xmlHttpMain.open("GET", strUrl, false, null, null);
                                            xmlHttpMain.setRequestHeader("Content-Type", "text/urlencoded");
                                            xmlHttpMain.send(objNull);
                                            if (xmlHttpMain.statusText == "OK")
                                                by = (byte[])xmlHttpMain.responseBody;
                                        }
                                        else
                                            by = (byte[])xmlHttpMain.responseBody;
                                    }

                                    #endregion
                                }
                                else if (bFlagNaukri == 13)
                                {
                                    #region "www.oilcareers.com"
                                    int iStopreatdownloading = 0;
                                    tFileExtension = ".doc";
                                downloadDocument:
                                    FileIDs = grdCandidate.Rows[i].Cells["IDs"].Value.ToString();
                                    strUrl = "http://www.oilcareers.com/content/recruiters/cvdatabase/cv_detail.asp?download=1&id=" + FileIDs + "&JobTerms=";
                                    MSXML2.XMLHTTP xmlHttpMain = new MSXML2.XMLHTTP();
                                    xmlHttpMain.open("GET", strUrl, false, null, null);
                                    xmlHttpMain.setRequestHeader("Content-Type", "text/urlencoded");
                                    xmlHttpMain.send(objNull);
                                    if (xmlHttpMain.responseText.IndexOf("OilCareers - Operational Error") >= 0 && iStopreatdownloading == 0)
                                    {

                                        FileIDs = grdCandidate.Rows[i].Cells["IDs"].Value.ToString();
                                        string strUrl1 = "http://www.oilcareers.com/content/recruiters/cvdatabase/cv_detail.asp?id=" + FileIDs + "&JobTerms=";
                                        MSXML2.XMLHTTP xmlHttpMain1 = new MSXML2.XMLHTTP();
                                        xmlHttpMain1.open("GET", strUrl1, false, null, null);
                                        xmlHttpMain1.setRequestHeader("Content-Type", "text/urlencoded");
                                        xmlHttpMain1.send(objNull);
                                        if (xmlHttpMain1.statusText == "OK")
                                        {
                                            xmlHttpMain1 = null;
                                            iStopreatdownloading += 1;
                                            goto downloadDocument;
                                        }
                                    }
                                    else
                                    {
                                        by = (byte[])xmlHttpMain.responseBody;
                                        try
                                        {
                                            string[] tSpli = { "Content-Disposition: attachment; filename=", "Connection: Keep-Alive", "Content-Length: 69120" };
                                            tFileName = xmlHttpMain.getAllResponseHeaders().Split(tSpli, StringSplitOptions.RemoveEmptyEntries)[1].Replace("\r\n", "").Replace(Convert.ToChar(34).ToString(), "").Replace("/", "").Replace("+", " ");
                                            tFileExtension = System.IO.Path.GetExtension(tFileName);
                                            tFileName = System.IO.Path.GetFileNameWithoutExtension(tFileName);
                                            if (tFileExtension == "") tFileExtension = ".doc";
                                            if (tFileName == "") tFileName = "Resume";
                                        }
                                        catch { }
                                    }
                                    xmlHttpMain = null;

                                    #endregion
                                }
                                else if (bFlagNaukri == 14)
                                {
                                    #region "www.recruitgulf.com"
                                    FileIDs = grdCandidate.Rows[i].Cells["IDs"].Value.ToString();
                                    strUrl = FileIDs;
                                    MSXML2.XMLHTTP xmlHttpMain = new MSXML2.XMLHTTP();
                                    xmlHttpMain.open("GET", strUrl, false, null, null);
                                    xmlHttpMain.setRequestHeader("Content-Type", "text/urlencoded");
                                    xmlHttpMain.send(objNull);
                                    if (xmlHttpMain.statusText == "OK")
                                        by = (byte[])xmlHttpMain.responseBody;
                                    try
                                    {
                                        string[] tSpli = { "Content-Disposition: attachment; filename=", "Cache-Control: private" };
                                        //string[] tData = xmlHttpMain.getAllResponseHeaders().Split(tSpli, StringSplitOptions.RemoveEmptyEntries);
                                        tFileName = xmlHttpMain.getAllResponseHeaders().Split(tSpli, StringSplitOptions.RemoveEmptyEntries)[1].Replace("\r\n", "").Replace(Convert.ToChar(34).ToString(), "").Replace("/", "").Replace("+", " ");
                                        tFileExtension = System.IO.Path.GetExtension(tFileName);
                                        tFileName = System.IO.Path.GetFileNameWithoutExtension(tFileName);
                                        if (tFileExtension == "") tFileExtension = ".doc";
                                        if (tFileName == "") tFileName = "Resume";
                                    }
                                    catch { }
                                    #endregion
                                }
                                else if (bFlagNaukri == 15)
                                {
                                    #region "www.oilandgasjobsearch.com"

                                    FileIDs = grdCandidate.Rows[i].Cells["IDs"].Value.ToString();
                                    strUrl = "https://ae.oilandgasjobsearch.com" + FileIDs;
                                    MSXML2.XMLHTTP xmlHttpMain = new MSXML2.XMLHTTP();
                                    xmlHttpMain.open("GET", strUrl, false, null, null);
                                    xmlHttpMain.setRequestHeader("Content-Type", "text/urlencoded");
                                    xmlHttpMain.send(objNull);
                                    if (xmlHttpMain.statusText == "OK")
                                    {
                                        by = (byte[])xmlHttpMain.responseBody;

                                        try
                                        {
                                            string[] tSpli = { "Content-Disposition: attachment; filename=", "X-AspNet-Version:" };
                                            //string[] tData = xmlHttpMain.getAllResponseHeaders().Split(tSpli, StringSplitOptions.RemoveEmptyEntries);
                                            tFileName = xmlHttpMain.getAllResponseHeaders().Split(tSpli, StringSplitOptions.RemoveEmptyEntries)[1].Replace("\r\n", "").Replace(Convert.ToChar(34).ToString(), "").Replace("/", "").Replace("+", " ");
                                            tFileExtension = System.IO.Path.GetExtension(tFileName);
                                            tFileName = System.IO.Path.GetFileNameWithoutExtension(tFileName);
                                            if (tFileExtension == "") tFileExtension = ".doc";
                                            if (tFileName == "") tFileName = "Resume";
                                        }
                                        catch { }
                                    }
                                    #endregion
                                }
                                else if (bFlagNaukri == 16)
                                {
                                    #region "www.corp-corp.com"
                                    tFileExtension = ".htm";
                                    strUrl = grdCandidate.Rows[i].Cells["IDs"].Value.ToString();

                                    MSXML2.XMLHTTP xmlHttpMain = new MSXML2.XMLHTTP();
                                    xmlHttpMain.open("POST", strUrl, false, null, null);
                                    xmlHttpMain.setRequestHeader("Content-Type", "text/urlencoded");
                                    xmlHttpMain.send(objNull);
                                    if (xmlHttpMain.statusText == "OK")
                                    {
                                        HtmlAgilityPack.HtmlDocument objDocument = new HtmlAgilityPack.HtmlDocument();
                                        objDocument.LoadHtml(xmlHttpMain.responseText);
                                        //Read only the Resume Converted Text part.
                                        try
                                        {
                                            by = Encoding.UTF8.GetBytes(objDocument.GetElementbyId("txtResumeText").InnerHtml);
                                        }
                                        catch
                                        {
                                            by = (byte[])xmlHttpMain.responseBody;
                                        }
                                    }
                                    #endregion
                                }
                                else if (bFlagNaukri == 17)
                                {
                                    #region "monster.com.ph"

                                    FileIDs = grdCandidate.Rows[i].Cells["IDs"].Value.ToString().Replace("&amp;", "&").Replace(";", "&").Replace("&&", "&");

                                    strUrl = "http://recruiter.monster.com.ph/v2/resumedatabase/resume.html?" + FileIDs;//&sum=0&logo=0&xcode=xyscplinx&serve_txt=0";
                                    tFileExtension = ".doc";
                                    MSXML2.XMLHTTP xmlHttpMain = new MSXML2.XMLHTTP();
                                    xmlHttpMain.open("GET", strUrl, false, null, null);
                                    xmlHttpMain.setRequestHeader("Content-Type", "text/urlencoded");
                                    xmlHttpMain.send(objNull);
                                    if (xmlHttpMain.statusText == "OK")
                                    {
                                        strUrl = "";
                                        string tResponseText = (string)xmlHttpMain.responseText;//.Replace("<script type=\"text/javascript\">", "<!-- <script type=\"text/javascript\">").Replace("</script>", "</script> -->");
                                        string[] tsp = { "url = '/resumedatabase/resume_process_request.html?", "url += '" };
                                        string[] tsp1 = { "';\n" };
                                        string[] tspdata = tResponseText.Split(tsp, StringSplitOptions.RemoveEmptyEntries);

                                        if (tspdata.Length > 1)
                                        {
                                            strUrl = "http://recruiter.monster.com.ph/resumedatabase/resume_process_request.html?" + tspdata[1].Replace("';\n", "").Trim();
                                            //strUrl += strUrl2;
                                            xmlHttpMain = null;
                                            xmlHttpMain = new MSXML2.XMLHTTP();
                                            xmlHttpMain.open("GET", strUrl, false, null, null);
                                            xmlHttpMain.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
                                            xmlHttpMain.send(objNull);

                                            if (xmlHttpMain.statusText == "OK")
                                            {
                                                by = (byte[])xmlHttpMain.responseBody;
                                                try
                                                {
                                                    if (xmlHttpMain.responseText.IndexOf("Create a Personal Folder") >= 0 || xmlHttpMain.responseText.IndexOf("Insufficient Resume Inventory") >= 0)
                                                    {
                                                        this.Invoke(new CreateAuthorizePopup(opAuthorizePopup), strUrl);
                                                        by = null;
                                                        strUrl = null;
                                                        xmlHttpMain = null;
                                                        opSetMessage("Communication from the site has interrupted. Please relogin...");
                                                        break;
                                                    }
                                                    else if (xmlHttpMain.responseText.IndexOf("Search results shall show resumes within 3 months") >= 0)
                                                    {
                                                        this.Invoke(new CreateAuthorizePopup(opAuthorizePopup), strUrl);
                                                        by = null;
                                                        strUrl = null;
                                                        xmlHttpMain = null;
                                                        opSetMessage("Communication from the site has interrupted. Please relogin...");
                                                        break;
                                                    }
                                                    else if (xmlHttpMain.responseText.IndexOf("Please authenticate yourself by typing the code that you see below.") >= 0)
                                                    {
                                                        this.Invoke(new CreateAuthorizePopup(opAuthorizePopup), strUrl);
                                                        by = null;
                                                        strUrl = null;
                                                        xmlHttpMain = null;
                                                        opSetMessage("Communication from the site has interrupted. Please relogin...");
                                                        break;
                                                    }
                                                    string[] tSpli = { "attachment; filename=", "Pragma: public", "Set-Cookie:", "Vary:User-Agent", "Keep-Alive" };
                                                    string tFileName1 = xmlHttpMain.getAllResponseHeaders().Split(tSpli, StringSplitOptions.RemoveEmptyEntries)[1].Replace("\r\n", "").Replace(Convert.ToChar(34).ToString(), "").Replace("/", "");
                                                    tFileExtension = System.IO.Path.GetExtension(tFileName);
                                                    if (tFileExtension == "") tFileExtension = ".doc";

                                                }
                                                catch { }
                                            }
                                            else
                                            {
                                                this.Invoke(new CreateAuthorizePopup(opAuthorizePopup), strUrl);
                                                opSetMessage("Communication from the site has interrupted. Please relogin...");
                                            }
                                        }
                                    }
                                    else
                                    {
                                        opSetMessage("Communication from the site has interrupted. Please relogin...");
                                        this.Invoke(new CreateAuthorizePopup(opAuthorizePopup), strUrl);
                                        break;
                                    }
                                    #endregion

                                }
                                else if (bFlagNaukri == 18)
                                {
                                    #region "rms.jobsdb.com"
                                    string[] sp = { ":PDF" };
                                    bool pdf = false;
                                    string[] spData = grdCandidate.Rows[i].Cells["IDs"].Value.ToString().Split(sp, StringSplitOptions.None);
                                    if (spData.Length > 1)
                                    {
                                        tFileExtension = ".pdf"; pdf = true;
                                        strUrl = "http://rms.jobsdb.com/PH/en/CandidateManagement/GetResumeAsPdf?id=" + spData[0] + "&candidateType=1";

                                    }
                                    else
                                    {
                                        tFileExtension = ".doc";
                                        strUrl = "http://rms.jobsdb.com/PH/en/CandidateManagement/DownloadResumeAttachment?candidateId=" + spData[0] + "&candidateType=1";
                                    }
                                    sp = null; spData = null;
                                    MSXML2.XMLHTTP xmlHttpMain = new MSXML2.XMLHTTP();
                                    xmlHttpMain.open("POST", strUrl, false, null, null);
                                    xmlHttpMain.setRequestHeader("Content-Type", "*/*");
                                    xmlHttpMain.send(objNull);
                                    if (xmlHttpMain.statusText == "OK")
                                    {
                                        by = (byte[])xmlHttpMain.responseBody;
                                        try
                                        {
                                            string[] tSpli = { "attachment; filename=", "Pragma: public", "Set-Cookie:", "Vary:User-Agent", "Keep-Alive", "Date:" };
                                            string tFileName1 = xmlHttpMain.getAllResponseHeaders().Split(tSpli, StringSplitOptions.RemoveEmptyEntries)[1].Replace("\r\n", "").Replace(Convert.ToChar(34).ToString(), "").Replace("/", "");
                                            tFileExtension = System.IO.Path.GetExtension(tFileName1);
                                            if (tFileExtension == "") tFileExtension = (pdf ? ".pdf" : ".doc");
                                        }
                                        catch { }
                                    }
                                    #endregion
                                }
                                else if (bFlagNaukri == 19)
                                {
                                    #region "www.oilandgasjobsearch.com"

                                    FileIDs = grdCandidate.Rows[i].Cells["IDs"].Value.ToString();
                                    strUrl = "https://ae.oilandgasjobsearch.com" + FileIDs;
                                    MSXML2.XMLHTTP xmlHttpMain = new MSXML2.XMLHTTP();
                                    xmlHttpMain.open("GET", strUrl, false, null, null);
                                    xmlHttpMain.setRequestHeader("Content-Type", "text/urlencoded");
                                    xmlHttpMain.send(objNull);
                                    if (xmlHttpMain.statusText == "OK")
                                    {
                                        by = (byte[])xmlHttpMain.responseBody;
                                        try
                                        {
                                            string[] tSpli = { "Content-Disposition: attachment; filename=", "X-AspNet-Version" };
                                            tFileName = xmlHttpMain.getAllResponseHeaders().Split(tSpli, StringSplitOptions.RemoveEmptyEntries)[1].Replace("\r\n", "").Replace(Convert.ToChar(34).ToString(), "").Replace("/", "").Replace("+", " ");
                                            tFileExtension = System.IO.Path.GetExtension(tFileName);
                                            tFileName = System.IO.Path.GetFileNameWithoutExtension(tFileName);
                                            if (tFileExtension == "") tFileExtension = ".doc";
                                            if (tFileName == "") tFileName = "Resume";
                                        }
                                        catch { }
                                    }
                                    #endregion
                                }
                                else if (bFlagNaukri == 20)
                                {
                                    #region "recruter.shine.com"

                                    FileIDs = "http://recruiter.shine.com/" + grdCandidate.Rows[i].Cells["IDs"].Value.ToString().Replace(";", "&").Replace("value=", "");
                                    strUrl = FileIDs;
                                    MSXML2.XMLHTTP xmlHttpMain = new MSXML2.XMLHTTP();
                                    xmlHttpMain.open("GET", strUrl, false, null, null);
                                    xmlHttpMain.setRequestHeader("Content-Type", "text/urlencoded");
                                    xmlHttpMain.send(objNull);
                                    if (xmlHttpMain.statusText == "OK")
                                    {
                                        strUrl = "";
                                        HtmlDocument objHTML = null;
                                        objHTML = this.Invoke(new CreateBrowseronThread(opCreateBrowser), false) as HtmlDocument;
                                        string tResponseText = (string)xmlHttpMain.responseText;
                                        objHTML.Write(tResponseText);
                                        HtmlElementCollection col1 = objHTML.GetElementsByTagName("a");
                                        foreach (HtmlElement htmlEle in col1)
                                        {
                                            if (htmlEle.GetAttribute("href").IndexOf("resume/download/?resume") > 0)
                                            {
                                                strUrl = "http://recruiter.shine.com/" + htmlEle.GetAttribute("href").Replace("about:blank", "").Replace("about:", "").Replace("blank", "").Trim();// +"&resumeindex=0&resumeboardid=1&qryMode=true&folderID=0&folderApplicantID=&encrb=" + tEncID;
                                                break;
                                            }
                                        }
                                        if (strUrl != "")
                                        {
                                            xmlHttpMain = new MSXML2.XMLHTTP();
                                            xmlHttpMain.open("GET", strUrl, false, null, null);
                                            xmlHttpMain.setRequestHeader("Content-Type", "text/urlencoded");
                                            xmlHttpMain.send(objNull);
                                            if (xmlHttpMain.statusText == "OK")
                                                by = (byte[])xmlHttpMain.responseBody;
                                        }
                                        else
                                            by = (byte[])xmlHttpMain.responseBody;
                                    }

                                    #endregion
                                }
                                else if (bFlagNaukri == 21)
                                {
                                    #region "www.rigzone.com"

                                    FileIDs = "http://www.rigzone.com/jobs/resume_download.asp?r_id=" + grdCandidate.Rows[i].Cells["IDs"].Value.ToString().Replace(";", "&").Replace("value=", "");
                                    strUrl = FileIDs;
                                    MSXML2.XMLHTTP xmlHttpMain = new MSXML2.XMLHTTP();
                                    xmlHttpMain.open("GET", strUrl, false, null, null);
                                    xmlHttpMain.setRequestHeader("Content-Type", "text/urlencoded");
                                    xmlHttpMain.send(objNull);
                                    if (xmlHttpMain.statusText == "OK")
                                    {
                                        by = (byte[])xmlHttpMain.responseBody;
                                    }
                                    try
                                    {
                                        //This resume is currently unavailable
                                        string[] tSpli = { "Content-Disposition: inline; filename=", "Connection: Keep-Alive", "Set-Cookie:" };
                                        string tFileName1 = xmlHttpMain.getAllResponseHeaders().Split(tSpli, StringSplitOptions.RemoveEmptyEntries)[1].Replace("\r\n", "").Replace(Convert.ToChar(34).ToString(), "").Replace("/", "").Replace("+", " ");

                                        tFileExtension = System.IO.Path.GetExtension(tFileName1);
                                        if (tFileExtension == "") tFileExtension = ".doc";
                                        tFileName1 = null; tSpli = null;
                                    }
                                    catch { }
                                    xmlHttpMain = null;
                                    #endregion
                                }
                                else if (bFlagNaukri == 231)
                                {
                                    #region "www.naukrigulf.com -- Response"

                                    FileIDs = grdCandidate.Rows[i].Cells["IDs"].Value.ToString().Replace(";", "&").Replace("value=", "");
                                    strUrl = "http://www.naukrigulf.com/ng/rm/ResponseActions/downloadCV?" + FileIDs + ",&downloadType=orig&sid=[object%20Object]";

                                    if (strUrl != "")
                                    {
                                        MSXML2.XMLHTTP xmlHttpMain = new MSXML2.XMLHTTP();
                                        xmlHttpMain.open("GET", strUrl, false, null, null);
                                        xmlHttpMain.setRequestHeader("Content-Type", "text/urlencoded");
                                        xmlHttpMain.send(objNull);
                                        tFileExtension = ".doc";
                                        if (xmlHttpMain.statusText == "OK")
                                        {
                                            by = (byte[])xmlHttpMain.responseBody;
                                            try
                                            {
                                                if (xmlHttpMain.responseText.IndexOf("In order to prevent misuse of your account.") >= 0 || xmlHttpMain.responseText.IndexOf("You have either exceeding or completely utilized the maximum limit of CV views available for this week") >= 0 || xmlHttpMain.responseText.IndexOf("Someone is already logged into Resdex with this username. Please log-in using one of the available subuser accounts. You can also reset the subuser who is currently accessing Resdex with this username.") >= 0 || xmlHttpMain.responseText.IndexOf("Resetting will logout the user who is currently logged into Resdex with this username") >= 0 || (xmlHttpMain.responseText.IndexOf("Can't read the words below?") >= 0 && xmlHttpMain.responseText.IndexOf("Try different words") >= 0 && xmlHttpMain.responseText.IndexOf("an audio captcha") >= 0))
                                                {
                                                    this.Invoke(new CreateAuthorizePopup(opAuthorizePopup), strUrl);
                                                    opSetMessage("Communication from the site has interrupted. Please relogin...");
                                                    by = null;
                                                }
                                            }
                                            catch { }
                                            try
                                            {
                                                string[] tSpli = { "attachment; filename=", "Vary:User-Agent" };
                                                tFileName = xmlHttpMain.getAllResponseHeaders().Split(tSpli, StringSplitOptions.RemoveEmptyEntries)[1].Replace("\r\n", "").Replace(Convert.ToChar(34).ToString(), "").Replace("/", "");
                                                tFileExtension = System.IO.Path.GetExtension(tFileName);
                                                if (tFileExtension == "") tFileExtension = ".doc";
                                            }
                                            catch { }
                                        }
                                    }

                                    #endregion
                                }
                                if (by != null)
                                {
                                    #region "downloading"

                                    System.IO.FileStream nw = new System.IO.FileStream( GetLocalTempPath() + grdCandidate.Rows[i].Cells[  "CandidateName"].Value.ToString().Replace("|", "").Replace(Convert.ToChar(34).ToString(), "").Replace(">", "").Replace("<", "").Replace("*", "").Replace("?", "").Replace(@"\", "").Replace(@"/", "").Replace(":", "") + tFileExtension, System.IO.FileMode.OpenOrCreate, System.IO.FileAccess.ReadWrite);
                                    nw.Write(by, 0, by.Length);
                                    nw.Flush();
                                    nw.Close();
                                    nw.Dispose();
                                    System.IO.FileInfo info = new System.IO.FileInfo(GetLocalTempPath() + grdCandidate.Rows[i].Cells["CandidateName"].Value.ToString().Replace("|", "").Replace(Convert.ToChar(34).ToString(), "").Replace(">", "").Replace("<", "").Replace("*", "").Replace("?", "").Replace(@"\", "").Replace(@"/", "").Replace(":", "") + tFileExtension);

                                    
                                    
                                    try
                                    {
                                        System.IO.File.SetAttributes(info.FullName, System.IO.FileAttributes.Normal);
                                    }
                                    catch { } 
                                    string tREturnData = "-4";

                                    try{
                                    
                                        System.Net. WebClient webClient = new System.Net. WebClient();
                                        string boundary = "------------------------" + DateTime.Now.Ticks.ToString("x");
                                        webClient.Headers.Add("Authorization: bearer " + Configuration.access_token);
                                        webClient.Headers.Add("Content-Type", "multipart/form-data; boundary=" + boundary);
                                        var fileData = webClient.Encoding.GetString(by);
                                        var package = string.Format("--{0}\r\nContent-Disposition: form-data; name=\"file\"; filename=\"{1}\"\r\nContent-Type: {2}\r\n\r\n{3}\r\n--{0}--\r\n", boundary, info.Name, "application/octet-stream", fileData);

                                        var nfile = webClient.Encoding.GetBytes(package);
                                        byte[] resp = webClient.UploadData(Configuration.ApplicationAPI + "resume/bulkparsing", "POST", nfile);

                                        ResposeData _responseData = new ResposeData();
                                        _responseData = Newtonsoft.Json.JsonConvert.DeserializeObject<ResposeData>(System.Text.Encoding.UTF8.GetString(resp));
                                        //Constants.ResumeId = _responseData.RID; 
                                        if (_responseData.Code == "SUCCESS0001")
                                        {
                                            tREturnData = _responseData.RID.ToString();
                                        }
                                        else if (_responseData.Code == "DUPLICATE001")
                                        {
                                            tREturnData = "-1000:0";
                                        }
                                        else if (_responseData.Code == "ERR0001" || _responseData.Code == "FAIL0001")
                                        {
                                            tREturnData = "-4";
                                        }
                                        else
                                        { 
                                        }
                                    }
                                    catch (System.Net.WebException ex)
                                    {
                                        var responseString = new System.IO.StreamReader(ex.Response.GetResponseStream()).ReadToEnd();
                                        HCResponse _hcresponse = Newtonsoft.Json.JsonConvert.DeserializeObject<HCResponse>(responseString);
                                        if (_hcresponse.Code == "VALD0001" || _hcresponse.Code == "ERR0007")
                                        {

                                            tREturnData = "-22";
                                        }
                                        else if (_hcresponse.Code == "DUPLICATE001")
                                        {
                                        
                                            tREturnData = "-1000:0";
                                        }
                                        else if (_hcresponse.Code == "FAIL0001" || _hcresponse.Code == "ERR0001")
                                        {

                                            tREturnData = "-4";
                                        } 
                                        Log.LogData(info.Name + System.Environment.NewLine + _hcresponse.Message + ex.Message + System.Environment.NewLine + ex.StackTrace, Log.Status.Error);
                                        _hcresponse = null; responseString = null; 
                                    }
                                    catch (Exception ex)
                                    {
                                        Log.LogData("Error on Parsing : " + ex.Message + ex.StackTrace, Log.Status.Error);
                                    }// objfeResumebank.fParseResumeImportPortal(objclsPortalData, info.Name, true);
                                    bUpdateGridInfoAfterDownload delObj = new bUpdateGridInfoAfterDownload(opUpdateColumnInfoAfterDownload);
                                    delObj.Invoke(tREturnData, "", info.Name, grdCandidate.Rows[i].Cells[  "IDs"].Value.ToString());
                                    System.Windows.Forms.Application.DoEvents();
                                    delObj = null;

                                    #endregion
                                }
                                else
                                {
                                    iUnKnownFormatResumes++;
                                    bUpdateGridInfoUnknown delObj = new bUpdateGridInfoUnknown(opUpdateGridInfoUnknown);
                                    delObj.Invoke(grdCandidate.Rows[i].Cells[  "IDs"].Value.ToString());
                                    System.Windows.Forms.Application.DoEvents();
                                    delObj = null;
                                    lblUnknownFormatR.Text = iUnKnownFormatResumes.ToString();
                                    System.Windows.Forms.Application.DoEvents();
                                } 
                            }
                            System.Windows.Forms.Application.DoEvents();
                            System.Windows.Forms.Application.DoEvents();
                            tspgrs.PerformStep();
                            System.Windows.Forms.Application.DoEvents();
                            System.Windows.Forms.Application.DoEvents();
                        }
                    }

                    if (iFlagCompleted > 0)
                    {
                        System.Windows.Forms.Application.DoEvents();
                        if (bStopped == false) opSetMessage("Downloading Completed...");
                        //tspgrs.Value = 100;
                        bStopped = false;
                        tsStop.Visible = false;
                    }
                    else
                        opSetMessage("No Candidate Selected...");
                }
            }
            catch (Exception ex)
            {

                Log.LogData("Error on Parsing : " + ex.Message + ex.StackTrace, Log.Status.Error);
            }
            finally
            {
                tspgrs.Visible = false;
                tsDownload.Enabled = true;
                opSetCursorNormal();
            }
        }
        #endregion

        private void tsDownload_Click(object sender, EventArgs e)
        {
            try {
                //System.Threading.Thread objThread = new System.Threading.Thread(opStartDownloading);
                //objThread.SetApartmentState(System.Threading.ApartmentState.MTA);
                //objThread.Start();
                //objThread = null;
                opStartDownloading();
            }
            catch { }
        }
    }

 
}
