﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net;
using System.IO;
using Newtonsoft.Json;
using HCUserControls;
using HireLook;
using System.Dynamic;
namespace HireLook
{
    public partial class FrmResumeManagers : Form
    {
        #region Declaration
        string ResumeKey = string.Empty;
        CtrlFooter footer = new CtrlFooter();
        ResposeData _responseData = new ResposeData();
        public Boolean DuplicateRsmStatus = false;
        List<CtrlTextBox> textboxlist = new List<CtrlTextBox>();
        List<SectionControls> sections = new List<SectionControls>();

        List<FormDesignLayout> SectionDesignDetails = new List<FormDesignLayout>();
        List<TabPage> TabPageList = new List<TabPage>();

        Int32 iSelTPInd = 0;
        Int32 iBtnTP = 0;
        public Button btn = new Button();
        #endregion

        public FrmResumeManagers(List<FormDesignLayout> SectionDesignDetails, string ResumeKey)
        {
            InitializeComponent();
            this.ResumeKey = ResumeKey;
            this.AutoSize = true;
            //this.Padding = new Padding(0, 0, 20, 20);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.SectionDesignDetails = SectionDesignDetails;
            LoadTabs();

            this.footer.Location = new System.Drawing.Point(0, 190);
            footer.Dock = DockStyle.Bottom;
            this.footer.BringToFront();
            this.Controls.Add(footer);
        }

        #region TabLoading

        void LoadTabs()
        {

            foreach (FormDesignLayout designLayout in SectionDesignDetails)
            {
                designLayout.ControlDetails = designLayout.ControlDetails.OrderBy(o => o.Sequence).ToList();
                AddTabControl(designLayout);
            }


            btn.Name = "btnButton";
            btn.Text = "Next";
            btn.Click += new System.EventHandler(this.btn_Click);
            btn.BringToFront();

            btn.FlatStyle = FlatStyle.Popup;
            btn.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.tableLayoutPanel1.Controls.Add(btn);
            this.tableLayoutPanel1.Dock = DockStyle.Fill;
            loadSectionResumeData();
        }

        void AddTabControl(FormDesignLayout designLayout)
        {
            try
            {
                SectionControls section = new SectionControls();
                TabPage dynamicTab = new TabPage();
                FlowLayoutPanel pnl = new FlowLayoutPanel();
                int TotalControl = 0;
                dynamicTab.Name = "tab" + designLayout.Sequence.ToString();
                dynamicTab.Text = designLayout.SectionTitle;
                dynamicTab.Tag = designLayout.Sequence;
                pnl.Dock = DockStyle.Fill;
                pnl.BringToFront();
                pnl.FlowDirection = System.Windows.Forms.FlowDirection.TopDown;
                //if (designLayout.SectionTitle == "Resume Document")
                //    return;
                foreach (ControlDetail controls in designLayout.ControlDetails)
                {
                    switch (controls.ControlType)
                    {
                        case "dropdown":  //done
                            // AddDropDown(controls, ref pnl, TotalControl);
                            section.DrpDown.Add(AddDropDown(controls, ref pnl, TotalControl));
                            break;
                        case "text":  //done
                            section.TextBox.Add(AddTextBox(controls, ref pnl, TotalControl));
                            break;
                        case "dob":  //done
                            section.DOB.Add(AddDateBox(controls, ref pnl, TotalControl));
                            break;
                        case "textarea":  //done
                            section.TextArea.Add(AddTextArea(controls, ref pnl, TotalControl));
                            break;
                        case "number":   //done
                            section.Number.Add(AddNumberBox(controls, ref pnl, TotalControl));
                            break;
                        case "employment-grid-list":
                            AddEmployment(controls, ref pnl, TotalControl);
                            break;
                        case "functionsSubfunctions":
                            section.CtrlFunctionSubFunction.Add(AddCtrlFunctionSubFunctionControls(controls, ref pnl, TotalControl));
                            break;
                        case "hcCTC":
                            section.CtrlCTC.Add(ADDCTC(controls, ref pnl, TotalControl));
                            break;
                        case "hcEmail":
                            section.TextBox.Add(AddTextBox(controls, ref pnl, TotalControl));
                            break;
                        case "hcExpSelector":
                            section.ExperienceSelector.Add(AddExpSelector(controls, ref pnl, TotalControl));
                            break;
                        case "hcPhone":
                            section.TextBox.Add(AddTextBox(controls, ref pnl, TotalControl));
                            break;
                        case "hcResumeSkills":
                            AddCtrlResumeSkillControls(controls, ref pnl, TotalControl);
                            break;
                        case "resume-education":
                            AddResumeEducation(controls, ref pnl, TotalControl);
                            break;
                        case "resumeSource":
                            section.ctrlResumeSource.Add(AddCtrlResumeSourceControls(controls, ref pnl, TotalControl));
                            break;
                        case "user-edit-address":
                            AddAddress(controls, ref pnl, TotalControl);
                            break;
                        case "documentViewer":
                            AddDocument(controls, ref pnl, TotalControl, designLayout.SectionId);
                            break;
                        default:
                            break;
                    }

                    // AddTextBox(controls, ref pnl, TotalControl);
                    TotalControl = TotalControl + 1;
                }
                //dynamicTab.BackColor = Color.SkyBlue;
                //   Create Button
                sections.Add(section);
                dynamicTab.Controls.Add(pnl);

                TabPageList.Add(dynamicTab);

                this.ResumeTabControl.TabPages.Add(dynamicTab);
            }
            catch (Exception ex)
            {
                Log.LogData("Error in AddTabControls: " + ex.Message + ex.StackTrace, Log.Status.Error);
            }

        }


        #endregion

        #region Save ResumeManager

        void btn_Click(object sender, EventArgs e)
        {
            int seqNo = Convert.ToInt32(ResumeTabControl.SelectedTab.Tag);
            SectionControls sectionCtrl = new SectionControls();
            sectionCtrl = sections[seqNo - 1];
            SectionSave sectionSave = new SectionSave();
            sectionSave.SectionId = SectionDesignDetails[seqNo - 1].SectionId;
            object ModuleValue = PrepareSaveData(sectionCtrl);
            if (ModuleValue != string.Empty)
            {
                sectionSave.Values = ModuleValue;
                opSectionSaveData(sectionSave, seqNo);
            }
        }

        object PrepareSaveData(SectionControls sectionCtrl)
        {
            string ModuleSaveDataInString = string.Empty;
            try
            {
                IDictionary<string, object> dictionarys = new Dictionary<string, object>();

                foreach (CtrlTextBox textbox in sectionCtrl.TextBox)
                {
                    try
                    {
                        if (textbox.opValidate())
                            dictionarys.Add(textbox.controls.NGModelName, textbox.getTextBoxValue());
                        else
                        {
                            footer.ShowMessage("Please Enter " + textbox.controls.FieldName);
                            return string.Empty;
                        }
                    }
                    catch (Exception ex)
                    {
                        Log.LogData("Error in Preparing TextBox Data: " + ex.Message + ex.StackTrace, Log.Status.Error);
                    }
                }

                foreach (CtrlDropdown drpdown in sectionCtrl.DrpDown)
                {
                    try
                    {
                        if (drpdown.opValidate())
                            dictionarys.Add(drpdown.controls.NGModelName, drpdown.getDropDownValue());
                        else
                        {
                            footer.ShowMessage("Please Enter " + drpdown.controls.FieldName);
                            return string.Empty;
                        }

                    }
                    catch (Exception ex)
                    {
                        Log.LogData("Error in Preparing Dropdown Data: " + ex.Message + ex.StackTrace, Log.Status.Error);
                    }
                }

                foreach (CtrlTextArea TextArea in sectionCtrl.TextArea)
                {
                    try
                    {
                        if (TextArea.opValidate())
                            dictionarys.Add(TextArea.controls.NGModelName, TextArea.getTextArea());
                        else
                        {
                            footer.ShowMessage("Please Enter " + TextArea.controls.FieldName);
                            return string.Empty;
                        }

                    }
                    catch (Exception ex)
                    {
                        Log.LogData("Error in Preparing TextArea Data: " + ex.Message + ex.StackTrace, Log.Status.Error);
                    }
                }

                foreach (CtrlDOB DOB in sectionCtrl.DOB)
                {
                    try
                    {
                        dictionarys.Add(DOB.controls.NGModelName, DOB.getDOB());
                    }
                    catch (Exception ex)
                    {
                        Log.LogData("Error in Preparing DOB Data: " + ex.Message + ex.StackTrace, Log.Status.Error);
                    }
                }

                foreach (CtrlNumber Number in sectionCtrl.Number)
                {
                    try
                    {
                        if (Number.opValidate())
                            dictionarys.Add(Number.controls.NGModelName, Number.getNumbers());
                        else
                        {
                            footer.ShowMessage("Please Enter " + Number.controls.FieldName);
                            return string.Empty;
                        }

                    }
                    catch (Exception ex)
                    {
                        Log.LogData("Error in Preparing Number Data: " + ex.Message + ex.StackTrace, Log.Status.Error);
                    }
                }

                foreach (CtrlCTC ctrlCTC in sectionCtrl.CtrlCTC)
                {
                    try
                    {
                        dictionarys.Add(ctrlCTC.controls.NGModelName, ctrlCTC.getCTC());
                    }
                    catch (Exception ex)
                    {
                        Log.LogData("Error in Preparing CtrlCTC Data: " + ex.Message + ex.StackTrace, Log.Status.Error);
                    }
                }

                foreach (CtrlExperienceSelector ctrlExpSelector in sectionCtrl.ExperienceSelector)
                {
                    try
                    {
                        dictionarys.Add(ctrlExpSelector.controls.NGModelName, ctrlExpSelector.getExperience());
                    }
                    catch (Exception ex)
                    {
                        Log.LogData("Error in Preparing CtrlCTC Data: " + ex.Message + ex.StackTrace, Log.Status.Error);
                    }
                }
                foreach (CtrlFuncSubFunction ctrlFuncSubFunction in sectionCtrl.CtrlFunctionSubFunction)
                {
                    try
                    {
                        dictionarys.Add(ctrlFuncSubFunction.controls.NGModelName, ctrlFuncSubFunction.getFunctionSubfunctionData());
                    }
                    catch (Exception ex)
                    {
                        Log.LogData("Error in Preparing CtrlCTC Data: " + ex.Message + ex.StackTrace, Log.Status.Error);
                    }
                }

                foreach (CtrlResumeSource CtrlResumeSource in sectionCtrl.ctrlResumeSource)
                {
                    try
                    {
                        if (CtrlResumeSource.opValidate())
                            dictionarys.Add(CtrlResumeSource.controls.NGModelName, CtrlResumeSource.getResumeCtrlValue());
                        else
                        {
                            footer.ShowMessage("Please Enter " + CtrlResumeSource.controls.FieldName);
                            return string.Empty;
                        }
                    }
                    catch (Exception ex)
                    {
                        Log.LogData("Error in Preparing CtrlCTC Data: " + ex.Message + ex.StackTrace, Log.Status.Error);
                    }
                }

                try
                {
                    ModuleSaveDataInString = JsonConvert.SerializeObject(dictionarys);
                    return dictionarys;
                }
                catch (Exception ex)
                {
                    Log.LogData("Error in Saving Resume Data: " + ex.Message + ex.StackTrace, Log.Status.Error);
                    return ModuleSaveDataInString;
                }
            }
            catch (Exception ex)
            {
                Log.LogData("Error in Preparing PrepareSaveData method: " + ex.Message + ex.StackTrace, Log.Status.Error);
                return ModuleSaveDataInString;
            }

        }

        void opSectionSaveData(SectionSave sectionSave, Int32 seqNo)
        {
            string url = string.Empty;
            url = Configuration.ApplicationAPI + "resume";
            if (seqNo > 1)
                url = Configuration.ApplicationAPI + "resume/" + _responseData.RID + "?novalidate=false";

            var request = (HttpWebRequest)WebRequest.Create(url);
            //var postData = "SectionId=" + sectionSave.SectionId + "&Values=" + sectionSave.Value;
            var data = Encoding.ASCII.GetBytes(JsonConvert.SerializeObject(sectionSave, Formatting.None));
            if (seqNo > 1)
                request.Method = "PUT";
            else
                request.Method = "POST";
            request.Headers.Add("Authorization: Bearer " + HireLook.Configuration.access_token);
            request.ContentType = "application/json";
            request.ContentLength = data.Length;

            using (var stream = request.GetRequestStream())
            {
                stream.Write(data, 0, data.Length);
            }

            try
            {
                HttpWebResponse response = (HttpWebResponse)request.GetResponse();
                var responseString = new StreamReader(response.GetResponseStream()).ReadToEnd();
                try
                {
                    _responseData = JsonConvert.DeserializeObject<ResposeData>(responseString);
                    Constants.ResumeId = _responseData.RID;
                    footer.ShowMessage("Saved ...");
                    Application.DoEvents();
                    iBtnTP = iBtnTP + 1;
                    if (ResumeTabControl.TabPages.Count != seqNo)
                        ResumeTabControl.SelectTab(iBtnTP - 1);
                    if (ResumeTabControl.TabPages.Count - 1 == seqNo)
                    {
                        btn.Text = "Finish";
                    }
                    if (ResumeTabControl.TabPages.Count == seqNo)
                        this.Close();
                }
                catch (Exception ex)
                {
                    Log.LogData("Error in frmLogin: Registry value: " + ex.Message + ex.StackTrace, Log.Status.Error);
                }
            }
            catch (WebException ex)
            {
                var responseString = new StreamReader(ex.Response.GetResponseStream()).ReadToEnd();
                HCResponse _hcresponse = JsonConvert.DeserializeObject<HCResponse>(responseString);
                if (_hcresponse.Code == "DUPLICATE001")
                {
                    DuplicateRsmStatus = true;
                    MessageBox.Show("Current candidate resume is duplicate");
                    this.Close();
                }
                else
                {
                    MessageBox.Show(_hcresponse.MessageDetails[0].Message);
                }
                Log.LogData("Invalid In Saving Resume Manager: " + ex.Message + ex.StackTrace, Log.Status.Error);
            }
        }

        #endregion

        #region Controls Description



        CtrlTextBox AddTextBox(ControlDetail controls, ref FlowLayoutPanel pnl, int TotalControl)
        {
            CtrlTextBox textboxs = new CtrlTextBox(controls);
            pnl.Controls.Add(textboxs);
            return textboxs;
        }

        CtrlExperienceSelector AddExpSelector(ControlDetail controls, ref FlowLayoutPanel pnl, int TotalControl)
        {
            CtrlExperienceSelector ExperienceSelector = new CtrlExperienceSelector(controls);
            pnl.Controls.Add(ExperienceSelector);
            return ExperienceSelector;
        }

        CtrlNumber AddNumberBox(ControlDetail controls, ref FlowLayoutPanel pnl, int TotalControl)
        {
            CtrlNumber nbr = new CtrlNumber(controls);
            pnl.Controls.Add(nbr);
            return nbr;
        }

        CtrlDOB AddDateBox(ControlDetail controls, ref FlowLayoutPanel pnl, int TotalControl)
        {
            CtrlDOB textCtrlDOB = new CtrlDOB(controls);
            pnl.Controls.Add(textCtrlDOB);
            return textCtrlDOB;
        }

        CtrlTextArea AddTextArea(ControlDetail controls, ref FlowLayoutPanel pnl, int TotalControl)
        {

            CtrlTextArea TextArea = new CtrlTextArea(controls);
            //textbox.Location = new Point(100, 10 + (TotalControl * 30) + lastControlHeight);
            //lastControlHeight = textbox.Height;
            pnl.Controls.Add(TextArea);
            return TextArea;

        }

        #region DropDown

        CtrlDropdown AddDropDown(ControlDetail controls, ref FlowLayoutPanel pnl, int TotalControl)
        {

            CtrlDropdown CtrlDropdown = new CtrlDropdown(controls);
            pnl.Controls.Add(CtrlDropdown);
            return CtrlDropdown;
        }

        #endregion

        #region CTC

        CtrlCTC ADDCTC(ControlDetail controls, ref FlowLayoutPanel pnl, int TotalControl)
        {
            CtrlCTC ctrlCTC = new CtrlCTC(controls);
            pnl.Controls.Add(ctrlCTC);
            return ctrlCTC;
        }

        #endregion

        void AddCtrlResumeSkillControls(ControlDetail controls, ref FlowLayoutPanel pnl, int TotalControl)
        {
            CtrlResumeSkill ResumeSkill = new CtrlResumeSkill(controls);
            pnl.Controls.Add(ResumeSkill);
            //CtrlRequirementSkills reqskill = new CtrlRequirementSkills();
            //pnl.Controls.Add(reqskill);
            //pnl.Controls.Add(textBoxNewInput);
        }

        CtrlResumeSource AddCtrlResumeSourceControls(ControlDetail controls, ref FlowLayoutPanel pnl, int TotalControl)
        {
            CtrlResumeSource ResumeSource = new CtrlResumeSource(controls);
            pnl.Controls.Add(ResumeSource);
            return ResumeSource;
        }

        void AddCtrlReqSkillControls(ControlDetail controls, ref FlowLayoutPanel pnl, int TotalControl)
        {
            CtrlRequirementSkills reqskill = new CtrlRequirementSkills();
            pnl.Controls.Add(reqskill);
        }

        CtrlFuncSubFunction AddCtrlFunctionSubFunctionControls(ControlDetail controls, ref FlowLayoutPanel pnl, int TotalControl)
        {
            CtrlFuncSubFunction funSubFunc = new CtrlFuncSubFunction(controls);
            pnl.Controls.Add(funSubFunc);
            return funSubFunc;
        }

        void AddAddress(ControlDetail controls, ref FlowLayoutPanel pnl, int TotalControl)
        {
            CtrlAddress ctrlAddress = new CtrlAddress(controls);
            pnl.Controls.Add(ctrlAddress);
        }

        void AddResumeEducation(ControlDetail controls, ref FlowLayoutPanel pnl, int TotalControl)
        {
            CtrlEducation ctrlEducation = new CtrlEducation(controls);
            pnl.Controls.Add(ctrlEducation);
        }

        void AddEmployment(ControlDetail controls, ref FlowLayoutPanel pnl, int TotalControl)
        {
            CtrlEmployment ctrlEmployment = new CtrlEmployment(controls);
            pnl.Controls.Add(ctrlEmployment);
        }

        void AddDocument(ControlDetail controls, ref FlowLayoutPanel pnl, int TotalControl, Int64 sectionId)
        {
            CtrlTxtControls doc = new CtrlTxtControls(controls, ResumeKey, sectionId);
            pnl.Controls.Add(doc);
        }
        #endregion

        void loadSectionResumeData()
        {
            Resumes res = new Resumes();
            int sectionNO = Convert.ToInt32(ResumeTabControl.SelectedTab.Tag);
            dynamic Data = Configuration.parseResumeData(ResumeKey, sectionNO);

            int seqNo = Convert.ToInt32(ResumeTabControl.SelectedTab.Tag);
            SectionControls sectionCtrl = new SectionControls();
            sectionCtrl = sections[seqNo - 1];
            SectionSave sectionSave = new SectionSave();
            sectionSave.SectionId = SectionDesignDetails[seqNo - 1].SectionId;
            prepareLoadDefault(sectionCtrl, Data);
        }

        void prepareLoadDefault(SectionControls sectionCtrl, dynamic Data)
        {
            foreach (CtrlTextBox textbox in sectionCtrl.TextBox)
            {
                try
                {

                    foreach (var Val in Data)
                    {
                        if (Val.Key == textbox.controls.NGModelName)
                        {
                            string KeyData = Val.Key;
                            textbox.setTextBoxValue(Val.Value);
                        }

                    }

                }
                catch (Exception ex)
                {
                    Log.LogData("Error in Preparing TextBox Data: " + ex.Message + ex.StackTrace, Log.Status.Error);
                }
            }

            //foreach (CtrlDropdown drpdown in sectionCtrl.DrpDown)
            //{
            //    try
            //    {
            //        foreach (var Val in Data)
            //        {
            //            if (Val.Key == drpdown.controls.NGModelName)
            //              //  System.Diagnostics.Debug.WriteLine(Val.Value);
            //        }

            //    }
            //    catch (Exception ex)
            //    {
            //        Log.LogData("Error in Preparing Dropdown Data: " + ex.Message + ex.StackTrace, Log.Status.Error);
            //    }
            //}

            foreach (CtrlTextArea TextArea in sectionCtrl.TextArea)
            {
                try
                {
                    foreach (var Val in Data)
                    {
                        if (Val.Key == TextArea.controls.NGModelName)
                            TextArea.setTextArea(Val.Value);
                    }
                }
                catch (Exception ex)
                {
                    Log.LogData("Error in Preparing TextArea Data: " + ex.Message + ex.StackTrace, Log.Status.Error);
                }
            }

            foreach (CtrlDOB DOB in sectionCtrl.DOB)
            {
                try
                {
                    foreach (var Val in Data)
                    {
                        if (Val.Key == DOB.controls.NGModelName)
                            if (Val.Value != null || Val.Value != string.Empty)
                            {
                                DateTime DOBValue = Convert.ToDateTime(Val.Value);
                                DOB.setDoB(Val.Value);
                            }
                    }
                }
                catch (Exception ex)
                {
                    Log.LogData("Error in Preparing DOB Data: " + ex.Message + ex.StackTrace, Log.Status.Error);
                }
            }

            //foreach (CtrlNumber Number in sectionCtrl.Number)
            //{
            //    try
            //    {
            //        dictionarys.Add(Number.controls.NGModelName, Number.getNumbers());
            //    }
            //    catch (Exception ex)
            //    {
            //        Log.LogData("Error in Preparing Number Data: " + ex.Message + ex.StackTrace, Log.Status.Error);
            //    }
            //}

            //foreach (CtrlCTC ctrlCTC in sectionCtrl.CtrlCTC)
            //{
            //    try
            //    {
            //        dictionarys.Add(ctrlCTC.controls.NGModelName, ctrlCTC.getCTC());
            //    }
            //    catch (Exception ex)
            //    {
            //        Log.LogData("Error in Preparing CtrlCTC Data: " + ex.Message + ex.StackTrace, Log.Status.Error);
            //    }
            //}

            //foreach (CtrlExperienceSelector ctrlExpSelector in sectionCtrl.ExperienceSelector)
            //{
            //    try
            //    {
            //        dictionarys.Add(ctrlExpSelector.controls.NGModelName, ctrlExpSelector.getExperience());
            //    }
            //    catch (Exception ex)
            //    {
            //        Log.LogData("Error in Preparing CtrlCTC Data: " + ex.Message + ex.StackTrace, Log.Status.Error);
            //    }
            //}
            //foreach (CtrlFuncSubFunction ctrlFuncSubFunction in sectionCtrl.CtrlFunctionSubFunction)
            //{
            //    try
            //    {
            //        dictionarys.Add(ctrlFuncSubFunction.controls.NGModelName, ctrlFuncSubFunction.getFunctionSubfunctionData());
            //    }
            //    catch (Exception ex)
            //    {
            //        Log.LogData("Error in Preparing CtrlCTC Data: " + ex.Message + ex.StackTrace, Log.Status.Error);
            //    }
            //}

        }

        private void ResumeTabControl_Click(object sender, EventArgs e)
        {
            try
            {
                if (Convert.ToInt32(ResumeTabControl.SelectedTab.Tag) > iBtnTP)
                {
                    ResumeTabControl.SelectTab(iSelTPInd - 1);
                }
                else
                {
                    iSelTPInd = Convert.ToInt32(ResumeTabControl.SelectedTab.Tag);
                }
            }
            catch (Exception ex)
            {
                Log.LogData("Error in ResumeTAbClick" + ex.Message + ex.StackTrace, Log.Status.Error);
            }
        }

        private void FrmResumeManagers_Load(object sender, EventArgs e)
        {
            iSelTPInd = Convert.ToInt32(ResumeTabControl.SelectedTab.Tag);
            iBtnTP = Convert.ToInt32(ResumeTabControl.SelectedTab.Tag);
        }


    }
}
