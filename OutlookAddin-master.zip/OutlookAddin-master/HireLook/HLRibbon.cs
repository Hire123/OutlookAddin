﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Office.Tools.Ribbon;
using System.Windows.Forms;
namespace HireLook
{
    public partial class HLRibbon
    {
        private void HLRibbon_Load(object sender, RibbonUIEventArgs e)
        {
           
        }

        private void btnLogin_Click(object sender, RibbonControlEventArgs e)
        {
           
        }
      

        private void btnLogout_Click(object sender, RibbonControlEventArgs e)
        {
           
        }

       
    }
}
