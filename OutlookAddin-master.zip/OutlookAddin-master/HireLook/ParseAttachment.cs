﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Outlook = Microsoft.Office.Interop.Outlook;
using Office = Microsoft.Office.Core;
using System.Runtime.InteropServices;
using System.Net;
using Microsoft.Office.Interop.Outlook;
using System.IO;
using System.Text.RegularExpressions;
using Newtonsoft.Json;
using HireLook;
using System.Windows.Forms;
namespace HireLook
{
    class ParseAttachment 
    {
        Outlook.Selection mySelection;
        Outlook.MailItem mailitem = null;
        frmProgressBar prgBar;
        Attachment attach;
        public void getAttachment()
        {
            try
            {
                mySelection = Globals.ThisAddIn.Application.ActiveExplorer().Selection;
                //Outlook.MAPIFolder inBox = (Outlook.MAPIFolder)Globals.ThisAddIn.Application.
                // ActiveExplorer().Session.GetDefaultFolder
                // (Outlook.OlDefaultFolders.olFolderInbox);

                foreach (Object obj in mySelection)
                {
                    if (obj is Outlook.MailItem)
                    {
                        mailitem = (Outlook.MailItem)obj;
                        // mailitem.Move(ThisAddIn.HireCraftOtherFolder);
                        //Outlook.MAPIFolder destFolder = inBox.Folders["In Process"];
                        //mailitem.Move(destFolder);
                        
                        if (mailitem.Attachments.Count > 0)
                        {
                            foreach (Attachment attachment in mailitem.Attachments)
                            {
                       

                                //prgBar.Dispose();
                                if (Configuration.Allowed_Doc_Extention.FindAll(item => item.ToLower() == System.IO.Path.GetExtension(attachment.FileName).ToLower()).Count > 0)
                                {
                                    prgBar = new frmProgressBar(attachment);
                                    prgBar.loadProgress();
                                    ////prgBar.opCallEventMethod += uploadAttachment;
                                    prgBar.ShowDialog();
                                    if (prgBar.reqParseStatus)
                                        movemail(true);
                                    else
                                        movemail(false);
                                    prgBar.Dispose(); prgBar = null;
                                }
                            }
                        } 
                        else
                            System.Windows.Forms.MessageBox.Show("No attachment available");
                    }
                }
            }
            catch (System.Exception ex)
            {

                Log.LogData("Error in get Attachment: " + ex.Message + ex.StackTrace, Log.Status.Error);
            }
        }

        public void uploadAttachment()
        {

            string currentPath = System.IO.Path.GetTempPath();
            string filepath = @"Attachments\" + attach.FileName;
            if (!Directory.Exists(currentPath + "Attachments"))
            {
                Directory.CreateDirectory(Path.Combine(currentPath, "Attachments"));
            }
            filepath = currentPath + filepath;
            Constants.FilePath = filepath;
            attach.SaveAsFile(filepath);
            //prgBar.prgBar.Increment(50);
            //prgBar.prgBar.Refresh();
            System.Windows.Forms.Application.DoEvents();
            byte[] bytes = File.ReadAllBytes(filepath);
            string UploadResult = UploadMultipart(bytes, attach.FileName, "application/octet-stream", Configuration.ApplicationAPI + "resume/documentupload");
            if (!System.String.IsNullOrWhiteSpace(UploadResult))
            {

                //sssConfiguration.parseResumeData(UploadResult);
                //System.Diagnostics.Process.Start(Configuration.ApplicatonResumeURL + UploadResult);
                //prgBar.prgBar.Increment(70);
                //prgBar.prgBar.Refresh();
                System.Windows.Forms.Application.DoEvents();
                loadSelections(UploadResult);

            }
            else
            {
                System.Windows.Forms.MessageBox.Show("Unable to parse attachment");
                //prgBar.Close();
            }
            //if (!String.IsNullOrEmpty(UploadResult))
            //    parseResumeData(UploadResult);
            //Read mail item 
        }

        public string UploadMultipart(byte[] file, string filename, string contentType, string url)
        {
            string ResposeResult = string.Empty;
            try
            {
                var webClient = new WebClient();
                string boundary = "------------------------" + DateTime.Now.Ticks.ToString("x");
                webClient.Headers.Add("Authorization: bearer " + Configuration.access_token);
                webClient.Headers.Add("Content-Type", "multipart/form-data; boundary=" + boundary);
                var fileData = webClient.Encoding.GetString(file);
                var package = string.Format("--{0}\r\nContent-Disposition: form-data; name=\"file\"; filename=\"{1}\"\r\nContent-Type: {2}\r\n\r\n{3}\r\n--{0}--\r\n", boundary, filename, "application/octet-stream", fileData);

                var nfile = webClient.Encoding.GetBytes(package);
                byte[] resp = webClient.UploadData(url, "POST", nfile);
                ResposeResult = System.Text.Encoding.UTF8.GetString(resp);
                Regex rgx = new Regex("[^a-zA-Z0-9 -]");
                ResposeResult = rgx.Replace(ResposeResult, "");

            }
            catch (System.Exception ex)
            {
                Log.LogData("Error in upload attachmnt" + ex.Message + ex.StackTrace, Log.Status.Error);
                return "";
            }
            return ResposeResult;
        }

        public void loadSelections(string resumeUploadKey)
        {
            var request = (HttpWebRequest)WebRequest.Create(Configuration.ApplicationAPI + "user/design?module=resume&style=form&designtype=create");

            request.Method = "GET";
            request.ContentType = "application/x-www-form-urlencoded";
            request.Headers.Add("Authorization: bearer " + Configuration.access_token);

            try
            {
                HttpWebResponse response = (HttpWebResponse)request.GetResponse();
                var responseString = new StreamReader(response.GetResponseStream()).ReadToEnd();
                try
                {
                    List<FormDesignLayout> designlayout = JsonConvert.DeserializeObject<List<FormDesignLayout>>(responseString);
                    if (designlayout.Count > 0)
                    {
                        //prgBar.prgBar.Increment(100);
                        //prgBar.prgBar.Refresh();
                        //System.Windows.Forms.Application.DoEvents();
                        //prgBar.Close();
                        //prgBar.Dispose();

                        FrmResumeManagers resumeMgr = new FrmResumeManagers(designlayout, resumeUploadKey);
                        resumeMgr.ShowDialog();
                        if (resumeMgr.DuplicateRsmStatus)
                            movemail(true);
                        else
                            movemail(false);

                        resumeMgr.Dispose();
                    }

                }
                catch (System.Exception ex)
                {
                    Log.LogData("Error in frmLogin: Registry value: " + ex.Message + ex.StackTrace, Log.Status.Error);
                }
            }
            catch (WebException ex)
            {
                Log.LogData("Error in Load Selection: " + ex.Message + ex.StackTrace, Log.Status.Error);
            }
        }

        void movemail(Boolean ResumeStatus)
        {
            try
            {
                if (ResumeStatus)
                    mailitem.Move(ThisAddIn.HireCraftDuplicateFolder);
                else
                    mailitem.Move(ThisAddIn.HireCraftParseFolder);
            }
            catch (System.Exception ex)
            {
                Log.LogData("Error in moveMail method: " + ex.Message + ex.StackTrace, Log.Status.Error);
            }

        }
    }
}
