﻿namespace HireLook
{
    partial class frmImportResume
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmImportResume));
            this.GroupBox1 = new System.Windows.Forms.GroupBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.lnklblDuplicate = new System.Windows.Forms.LinkLabel();
            this.llinkParsed = new System.Windows.Forms.LinkLabel();
            this.llblDupOverwrite = new System.Windows.Forms.LinkLabel();
            this.lblParsed = new System.Windows.Forms.Label();
            this.lblDuplicateDoc = new System.Windows.Forms.Label();
            this.lblUnknownFormatR = new System.Windows.Forms.Label();
            this.lblFailedSave = new System.Windows.Forms.Label();
            this.lblDuplicateOverwrite = new System.Windows.Forms.Label();
            this.Label7 = new System.Windows.Forms.Label();
            this.Label6 = new System.Windows.Forms.Label();
            this.pnlbtm = new System.Windows.Forms.Panel();
            this.prgBar = new System.Windows.Forms.ProgressBar();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.tsbar = new System.Windows.Forms.ToolStripStatusLabel();
            this.gBCurrent = new System.Windows.Forms.GroupBox();
            this.lblFileName = new System.Windows.Forms.Label();
            this.Label12 = new System.Windows.Forms.Label();
            this.lblFolderName = new System.Windows.Forms.Label();
            this.Label10 = new System.Windows.Forms.Label();
            this.pnlTop = new System.Windows.Forms.Panel();
            this.btnBrowse = new System.Windows.Forms.Button();
            this.txtPath = new System.Windows.Forms.TextBox();
            this.Label14 = new System.Windows.Forms.Label();
            this.Label2 = new System.Windows.Forms.Label();
            this.lblTotalFiles = new System.Windows.Forms.Label();
            this.lblStatus = new System.Windows.Forms.Label();
            this.labCount = new System.Windows.Forms.Label();
            this.Label11 = new System.Windows.Forms.Label();
            this.Label1 = new System.Windows.Forms.Label();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.tsBtnStart = new System.Windows.Forms.ToolStripButton();
            this.tsBtnStop = new System.Windows.Forms.ToolStripButton();
            this.tsExits = new System.Windows.Forms.ToolStripButton();
            this.brWorkerProgressbar = new System.ComponentModel.BackgroundWorker();
            this.GroupBox1.SuspendLayout();
            this.pnlbtm.SuspendLayout();
            this.statusStrip1.SuspendLayout();
            this.gBCurrent.SuspendLayout();
            this.pnlTop.SuspendLayout();
            this.toolStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // GroupBox1
            // 
            this.GroupBox1.Controls.Add(this.label5);
            this.GroupBox1.Controls.Add(this.label4);
            this.GroupBox1.Controls.Add(this.label3);
            this.GroupBox1.Controls.Add(this.lnklblDuplicate);
            this.GroupBox1.Controls.Add(this.llinkParsed);
            this.GroupBox1.Controls.Add(this.llblDupOverwrite);
            this.GroupBox1.Controls.Add(this.lblParsed);
            this.GroupBox1.Controls.Add(this.lblDuplicateDoc);
            this.GroupBox1.Controls.Add(this.lblUnknownFormatR);
            this.GroupBox1.Controls.Add(this.lblFailedSave);
            this.GroupBox1.Controls.Add(this.lblDuplicateOverwrite);
            this.GroupBox1.Controls.Add(this.Label7);
            this.GroupBox1.Controls.Add(this.Label6);
            this.GroupBox1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.GroupBox1.Location = new System.Drawing.Point(0, 125);
            this.GroupBox1.Name = "GroupBox1";
            this.GroupBox1.Size = new System.Drawing.Size(620, 100);
            this.GroupBox1.TabIndex = 5;
            this.GroupBox1.TabStop = false;
            this.GroupBox1.Text = "Number of Resumes";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(11, 22);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(115, 13);
            this.label5.TabIndex = 19;
            this.label5.Text = "Duplicate (Overwritten)";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(311, 22);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(100, 13);
            this.label4.TabIndex = 18;
            this.label4.Text = "Duplicate (Skipped)";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(311, 53);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(149, 13);
            this.label3.TabIndex = 17;
            this.label3.Text = "Successfully Parsed Resumes";
            // 
            // lnklblDuplicate
            // 
            this.lnklblDuplicate.AutoSize = true;
            this.lnklblDuplicate.Location = new System.Drawing.Point(311, 22);
            this.lnklblDuplicate.Name = "lnklblDuplicate";
            this.lnklblDuplicate.Size = new System.Drawing.Size(100, 13);
            this.lnklblDuplicate.TabIndex = 15;
            this.lnklblDuplicate.TabStop = true;
            this.lnklblDuplicate.Text = "Duplicate (Skipped)";
            // 
            // llinkParsed
            // 
            this.llinkParsed.AutoSize = true;
            this.llinkParsed.Location = new System.Drawing.Point(311, 53);
            this.llinkParsed.Name = "llinkParsed";
            this.llinkParsed.Size = new System.Drawing.Size(149, 13);
            this.llinkParsed.TabIndex = 16;
            this.llinkParsed.TabStop = true;
            this.llinkParsed.Text = "Successfully Parsed Resumes";
            // 
            // llblDupOverwrite
            // 
            this.llblDupOverwrite.AutoSize = true;
            this.llblDupOverwrite.Location = new System.Drawing.Point(11, 22);
            this.llblDupOverwrite.Name = "llblDupOverwrite";
            this.llblDupOverwrite.Size = new System.Drawing.Size(115, 13);
            this.llblDupOverwrite.TabIndex = 14;
            this.llblDupOverwrite.TabStop = true;
            this.llblDupOverwrite.Text = "Duplicate (Overwritten)";
            // 
            // lblParsed
            // 
            this.lblParsed.AutoSize = true;
            this.lblParsed.Location = new System.Drawing.Point(539, 53);
            this.lblParsed.Name = "lblParsed";
            this.lblParsed.Size = new System.Drawing.Size(13, 13);
            this.lblParsed.TabIndex = 13;
            this.lblParsed.Text = "0";
            // 
            // lblDuplicateDoc
            // 
            this.lblDuplicateDoc.AutoSize = true;
            this.lblDuplicateDoc.Location = new System.Drawing.Point(539, 22);
            this.lblDuplicateDoc.Name = "lblDuplicateDoc";
            this.lblDuplicateDoc.Size = new System.Drawing.Size(13, 13);
            this.lblDuplicateDoc.TabIndex = 12;
            this.lblDuplicateDoc.Text = "0";
            // 
            // lblUnknownFormatR
            // 
            this.lblUnknownFormatR.AutoSize = true;
            this.lblUnknownFormatR.Location = new System.Drawing.Point(223, 83);
            this.lblUnknownFormatR.Name = "lblUnknownFormatR";
            this.lblUnknownFormatR.Size = new System.Drawing.Size(13, 13);
            this.lblUnknownFormatR.TabIndex = 11;
            this.lblUnknownFormatR.Text = "0";
            // 
            // lblFailedSave
            // 
            this.lblFailedSave.AutoSize = true;
            this.lblFailedSave.Location = new System.Drawing.Point(223, 53);
            this.lblFailedSave.Name = "lblFailedSave";
            this.lblFailedSave.Size = new System.Drawing.Size(13, 13);
            this.lblFailedSave.TabIndex = 10;
            this.lblFailedSave.Text = "0";
            // 
            // lblDuplicateOverwrite
            // 
            this.lblDuplicateOverwrite.AutoSize = true;
            this.lblDuplicateOverwrite.Location = new System.Drawing.Point(223, 22);
            this.lblDuplicateOverwrite.Name = "lblDuplicateOverwrite";
            this.lblDuplicateOverwrite.Size = new System.Drawing.Size(13, 13);
            this.lblDuplicateOverwrite.TabIndex = 9;
            this.lblDuplicateOverwrite.Text = "0";
            // 
            // Label7
            // 
            this.Label7.AutoSize = true;
            this.Label7.Location = new System.Drawing.Point(11, 83);
            this.Label7.Name = "Label7";
            this.Label7.Size = new System.Drawing.Size(146, 13);
            this.Label7.TabIndex = 6;
            this.Label7.Text = "Resumes in Unknown Format";
            // 
            // Label6
            // 
            this.Label6.AutoSize = true;
            this.Label6.Location = new System.Drawing.Point(11, 53);
            this.Label6.Name = "Label6";
            this.Label6.Size = new System.Drawing.Size(170, 13);
            this.Label6.TabIndex = 5;
            this.Label6.Text = "Failed to Save (Invalid documents)";
            // 
            // pnlbtm
            // 
            this.pnlbtm.Controls.Add(this.prgBar);
            this.pnlbtm.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.pnlbtm.Location = new System.Drawing.Point(0, 225);
            this.pnlbtm.Name = "pnlbtm";
            this.pnlbtm.Size = new System.Drawing.Size(620, 22);
            this.pnlbtm.TabIndex = 6;
            // 
            // prgBar
            // 
            this.prgBar.Dock = System.Windows.Forms.DockStyle.Fill;
            this.prgBar.Location = new System.Drawing.Point(0, 0);
            this.prgBar.Name = "prgBar";
            this.prgBar.Size = new System.Drawing.Size(620, 22);
            this.prgBar.TabIndex = 0;
            // 
            // statusStrip1
            // 
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsbar});
            this.statusStrip1.Location = new System.Drawing.Point(0, 247);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(620, 22);
            this.statusStrip1.TabIndex = 7;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // tsbar
            // 
            this.tsbar.Name = "tsbar";
            this.tsbar.Size = new System.Drawing.Size(48, 17);
            this.tsbar.Text = "Ready...";
            // 
            // gBCurrent
            // 
            this.gBCurrent.Controls.Add(this.lblFileName);
            this.gBCurrent.Controls.Add(this.Label12);
            this.gBCurrent.Controls.Add(this.lblFolderName);
            this.gBCurrent.Controls.Add(this.Label10);
            this.gBCurrent.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.gBCurrent.Location = new System.Drawing.Point(0, 79);
            this.gBCurrent.Name = "gBCurrent";
            this.gBCurrent.Size = new System.Drawing.Size(620, 46);
            this.gBCurrent.TabIndex = 8;
            this.gBCurrent.TabStop = false;
            this.gBCurrent.Text = "Document being processed";
            // 
            // lblFileName
            // 
            this.lblFileName.AutoSize = true;
            this.lblFileName.Location = new System.Drawing.Point(298, 21);
            this.lblFileName.Name = "lblFileName";
            this.lblFileName.Size = new System.Drawing.Size(0, 13);
            this.lblFileName.TabIndex = 7;
            // 
            // Label12
            // 
            this.Label12.AutoSize = true;
            this.Label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label12.Location = new System.Drawing.Point(265, 21);
            this.Label12.Name = "Label12";
            this.Label12.Size = new System.Drawing.Size(27, 13);
            this.Label12.TabIndex = 6;
            this.Label12.Text = "File";
            // 
            // lblFolderName
            // 
            this.lblFolderName.AutoSize = true;
            this.lblFolderName.Location = new System.Drawing.Point(53, 21);
            this.lblFolderName.Name = "lblFolderName";
            this.lblFolderName.Size = new System.Drawing.Size(0, 13);
            this.lblFolderName.TabIndex = 5;
            // 
            // Label10
            // 
            this.Label10.AutoSize = true;
            this.Label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label10.Location = new System.Drawing.Point(11, 21);
            this.Label10.Name = "Label10";
            this.Label10.Size = new System.Drawing.Size(42, 13);
            this.Label10.TabIndex = 4;
            this.Label10.Text = "Folder";
            // 
            // pnlTop
            // 
            this.pnlTop.BackColor = System.Drawing.Color.Transparent;
            this.pnlTop.Controls.Add(this.btnBrowse);
            this.pnlTop.Controls.Add(this.txtPath);
            this.pnlTop.Controls.Add(this.Label14);
            this.pnlTop.Controls.Add(this.Label2);
            this.pnlTop.Controls.Add(this.lblTotalFiles);
            this.pnlTop.Controls.Add(this.lblStatus);
            this.pnlTop.Controls.Add(this.labCount);
            this.pnlTop.Controls.Add(this.Label11);
            this.pnlTop.Controls.Add(this.Label1);
            this.pnlTop.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pnlTop.Location = new System.Drawing.Point(0, 25);
            this.pnlTop.Name = "pnlTop";
            this.pnlTop.Padding = new System.Windows.Forms.Padding(10, 0, 10, 0);
            this.pnlTop.Size = new System.Drawing.Size(620, 54);
            this.pnlTop.TabIndex = 9;
            // 
            // btnBrowse
            // 
            this.btnBrowse.Location = new System.Drawing.Point(541, 8);
            this.btnBrowse.Name = "btnBrowse";
            this.btnBrowse.Size = new System.Drawing.Size(75, 20);
            this.btnBrowse.TabIndex = 17;
            this.btnBrowse.Text = "Browse";
            this.btnBrowse.UseVisualStyleBackColor = true;
            this.btnBrowse.Click += new System.EventHandler(this.btnBrowse_Click);
            // 
            // txtPath
            // 
            this.txtPath.BackColor = System.Drawing.SystemColors.Info;
            this.txtPath.Location = new System.Drawing.Point(85, 8);
            this.txtPath.Name = "txtPath";
            this.txtPath.ReadOnly = true;
            this.txtPath.Size = new System.Drawing.Size(455, 20);
            this.txtPath.TabIndex = 16;
            // 
            // Label14
            // 
            this.Label14.AutoSize = true;
            this.Label14.Location = new System.Drawing.Point(7, 37);
            this.Label14.Name = "Label14";
            this.Label14.Size = new System.Drawing.Size(82, 13);
            this.Label14.TabIndex = 10;
            this.Label14.Text = "Total files found";
            // 
            // Label2
            // 
            this.Label2.AutoSize = true;
            this.Label2.Location = new System.Drawing.Point(150, 37);
            this.Label2.Name = "Label2";
            this.Label2.Size = new System.Drawing.Size(149, 13);
            this.Label2.TabIndex = 11;
            this.Label2.Text = "Number of Resumes imported ";
            // 
            // lblTotalFiles
            // 
            this.lblTotalFiles.AutoSize = true;
            this.lblTotalFiles.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTotalFiles.Location = new System.Drawing.Point(98, 37);
            this.lblTotalFiles.Name = "lblTotalFiles";
            this.lblTotalFiles.Size = new System.Drawing.Size(14, 13);
            this.lblTotalFiles.TabIndex = 12;
            this.lblTotalFiles.Text = "0";
            // 
            // lblStatus
            // 
            this.lblStatus.AutoSize = true;
            this.lblStatus.Location = new System.Drawing.Point(488, 37);
            this.lblStatus.Name = "lblStatus";
            this.lblStatus.Size = new System.Drawing.Size(0, 13);
            this.lblStatus.TabIndex = 15;
            // 
            // labCount
            // 
            this.labCount.AutoSize = true;
            this.labCount.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labCount.Location = new System.Drawing.Point(305, 37);
            this.labCount.Name = "labCount";
            this.labCount.Size = new System.Drawing.Size(14, 13);
            this.labCount.TabIndex = 13;
            this.labCount.Text = "0";
            // 
            // Label11
            // 
            this.Label11.AutoSize = true;
            this.Label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label11.Location = new System.Drawing.Point(362, 37);
            this.Label11.Name = "Label11";
            this.Label11.Size = new System.Drawing.Size(122, 13);
            this.Label11.TabIndex = 14;
            this.Label11.Text = "Bulk Importer Status";
            // 
            // Label1
            // 
            this.Label1.Location = new System.Drawing.Point(4, 10);
            this.Label1.Name = "Label1";
            this.Label1.Size = new System.Drawing.Size(78, 13);
            this.Label1.TabIndex = 5;
            this.Label1.Text = "Resume Folder";
            this.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // toolStrip1
            // 
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsBtnStart,
            this.tsBtnStop,
            this.tsExits});
            this.toolStrip1.Location = new System.Drawing.Point(0, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(620, 25);
            this.toolStrip1.TabIndex = 10;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // tsBtnStart
            // 
            this.tsBtnStart.Image = ((System.Drawing.Image)(resources.GetObject("tsBtnStart.Image")));
            this.tsBtnStart.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsBtnStart.Name = "tsBtnStart";
            this.tsBtnStart.Size = new System.Drawing.Size(51, 22);
            this.tsBtnStart.Text = "Start";
            this.tsBtnStart.Click += new System.EventHandler(this.tsBtnStart_Click);
            // 
            // tsBtnStop
            // 
            this.tsBtnStop.Image = ((System.Drawing.Image)(resources.GetObject("tsBtnStop.Image")));
            this.tsBtnStop.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsBtnStop.Name = "tsBtnStop";
            this.tsBtnStop.Size = new System.Drawing.Size(51, 22);
            this.tsBtnStop.Text = "Stop";
            this.tsBtnStop.Click += new System.EventHandler(this.tsBtnStop_Click);
            // 
            // tsExits
            // 
            this.tsExits.Image = ((System.Drawing.Image)(resources.GetObject("tsExits.Image")));
            this.tsExits.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.tsExits.Name = "tsExits";
            this.tsExits.Size = new System.Drawing.Size(45, 22);
            this.tsExits.Text = "Exit";
            this.tsExits.Click += new System.EventHandler(this.tsExits_Click);
            // 
            // frmImportResume
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(620, 269);
            this.Controls.Add(this.pnlTop);
            this.Controls.Add(this.toolStrip1);
            this.Controls.Add(this.gBCurrent);
            this.Controls.Add(this.GroupBox1);
            this.Controls.Add(this.pnlbtm);
            this.Controls.Add(this.statusStrip1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "frmImportResume";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Import Resume";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmImportResume_FormClosing);
            this.GroupBox1.ResumeLayout(false);
            this.GroupBox1.PerformLayout();
            this.pnlbtm.ResumeLayout(false);
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.gBCurrent.ResumeLayout(false);
            this.gBCurrent.PerformLayout();
            this.pnlTop.ResumeLayout(false);
            this.pnlTop.PerformLayout();
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        internal System.Windows.Forms.GroupBox GroupBox1;
        internal System.Windows.Forms.LinkLabel lnklblDuplicate;
        internal System.Windows.Forms.LinkLabel llinkParsed;
        internal System.Windows.Forms.LinkLabel llblDupOverwrite;
        internal System.Windows.Forms.Label lblParsed;
        internal System.Windows.Forms.Label lblDuplicateDoc;
        internal System.Windows.Forms.Label lblUnknownFormatR;
        internal System.Windows.Forms.Label lblFailedSave;
        internal System.Windows.Forms.Label lblDuplicateOverwrite;
        internal System.Windows.Forms.Label Label7;
        internal System.Windows.Forms.Label Label6;
        private System.Windows.Forms.Panel pnlbtm;
        private System.Windows.Forms.ProgressBar prgBar;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel tsbar;
        internal System.Windows.Forms.GroupBox gBCurrent;
        internal System.Windows.Forms.Label lblFileName;
        internal System.Windows.Forms.Label Label12;
        internal System.Windows.Forms.Label lblFolderName;
        internal System.Windows.Forms.Label Label10;
        internal System.Windows.Forms.Panel pnlTop;
        private System.Windows.Forms.Button btnBrowse;
        private System.Windows.Forms.TextBox txtPath;
        internal System.Windows.Forms.Label Label14;
        internal System.Windows.Forms.Label Label2;
        internal System.Windows.Forms.Label lblTotalFiles;
        internal System.Windows.Forms.Label lblStatus;
        internal System.Windows.Forms.Label labCount;
        internal System.Windows.Forms.Label Label11;
        internal System.Windows.Forms.Label Label1;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripButton tsBtnStart;
        private System.Windows.Forms.ToolStripButton tsBtnStop;
        private System.Windows.Forms.ToolStripButton tsExits;
        private System.ComponentModel.BackgroundWorker brWorkerProgressbar;
        internal System.Windows.Forms.Label label5;
        internal System.Windows.Forms.Label label4;
        internal System.Windows.Forms.Label label3;
    }
}