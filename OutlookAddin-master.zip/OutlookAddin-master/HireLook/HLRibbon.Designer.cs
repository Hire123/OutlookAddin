﻿namespace HireLook
{
    partial class HLRibbon : Microsoft.Office.Tools.Ribbon.RibbonBase
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        public HLRibbon()
            : base(Globals.Factory.GetRibbonFactory())
        {
            InitializeComponent();
        }

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabHireLook = this.Factory.CreateRibbonTab();
            this.grpHireLook = this.Factory.CreateRibbonGroup();
            this.btnLogin = this.Factory.CreateRibbonButton();
            this.btnLogout = this.Factory.CreateRibbonButton();
            this.tabHireLook.SuspendLayout();
            this.grpHireLook.SuspendLayout();
            // 
            // tabHireLook
            // 
            this.tabHireLook.Groups.Add(this.grpHireLook);
            this.tabHireLook.Label = "HireLook";
            this.tabHireLook.Name = "tabHireLook";
            // 
            // grpHireLook
            // 
            this.grpHireLook.Items.Add(this.btnLogin);
            this.grpHireLook.Items.Add(this.btnLogout);
            this.grpHireLook.Label = "HireLook";
            this.grpHireLook.Name = "grpHireLook";
            // 
            // btnLogin
            // 
            this.btnLogin.Label = "Parse";
            this.btnLogin.Name = "btnLogin";
            this.btnLogin.Click += new Microsoft.Office.Tools.Ribbon.RibbonControlEventHandler(this.btnLogin_Click);
            // 
            // btnLogout
            // 
            this.btnLogout.Label = "Logout";
            this.btnLogout.Name = "btnLogout";
            this.btnLogout.Click += new Microsoft.Office.Tools.Ribbon.RibbonControlEventHandler(this.btnLogout_Click);
            // 
            // HLRibbon
            // 
            this.Name = "HLRibbon";
            this.RibbonType = "Microsoft.Outlook.Mail.Read";
            this.Tabs.Add(this.tabHireLook);
            this.Load += new Microsoft.Office.Tools.Ribbon.RibbonUIEventHandler(this.HLRibbon_Load);
            this.tabHireLook.ResumeLayout(false);
            this.tabHireLook.PerformLayout();
            this.grpHireLook.ResumeLayout(false);
            this.grpHireLook.PerformLayout();

        }

        #endregion

        internal Microsoft.Office.Tools.Ribbon.RibbonTab tabHireLook;
        internal Microsoft.Office.Tools.Ribbon.RibbonGroup grpHireLook;
        internal Microsoft.Office.Tools.Ribbon.RibbonButton btnLogin;
        internal Microsoft.Office.Tools.Ribbon.RibbonButton btnLogout;
    }

    partial class ThisRibbonCollection
    {
        internal HLRibbon HLRibbon
        {
            get { return this.GetRibbon<HLRibbon>(); }
        }
    }
}
