﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HCUserControls;
namespace HireLook
{
    class SectionControls
    {
        public List<CtrlTextBox> TextBox = new List<CtrlTextBox>();
        public List<CtrlDropdown> DrpDown = new List<CtrlDropdown>();
        public List<CtrlDOB> DOB = new List<CtrlDOB>();
        public List<CtrlTextArea> TextArea = new List<CtrlTextArea>();
        public List<CtrlNumber> Number = new List<CtrlNumber>();
        public List<CtrlExperienceSelector> ExperienceSelector = new List<CtrlExperienceSelector>();
        public List<CtrlCTC> CtrlCTC = new List<CtrlCTC>();
        public List<CtrlFuncSubFunction> CtrlFunctionSubFunction = new List<CtrlFuncSubFunction>();
        public List<CtrlResumeSource> ctrlResumeSource = new List<CtrlResumeSource>();
    }

    class SectionSave
    {
        public Int64 SectionId { get; set; }
        public object Values { get; set; }
    }

    public class FormDesignLayout
    {
        public List<ControlDetail> ControlDetails { get; set; }
        public long SectionId { get; set; }
        public string SectionTitle { get; set; }
        public short Sequence { get; set; }
    }
}
