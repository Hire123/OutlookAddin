﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Net; 

namespace HireLook
{
    public partial class frmImportResume : Form
    {
        public frmImportResume()
        {
            InitializeComponent();
        }

        bool bParseStart, bEnd;
        bool bstop, bFlagStarted;
        long tUnKnownFormatResumes;
        long tFailed2Save;
        long tDuplicateDocument;
        long tDuplicateOverwriteDocument;
        long tParsedResume, ITotalFiles;
        int iGlobalCount;
        int iGlobalTotalCount;
        private void tsExits_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void tsBtnStop_Click(object sender, EventArgs e)
        {
            try
            {
                if (!string.IsNullOrEmpty(txtPath.Text.Trim()))
                {
                    bstop = true;
                    bFlagStarted = false;
                    tsBtnStart.Visible = true;
                    bEnd = true;
                    ITotalFiles = 0;
                    opSetMessage("Parsing stopped...");
                    lblStatus.Text = "Stopped";
                }
            }
            catch (Exception ex)
            {
                Log.LogData("Error on Parsing : " + ex.Message + ex.StackTrace, Log.Status.Error);
            }
        }

        private void frmImportResume_FormClosing(object sender, FormClosingEventArgs e)
        {
            try
            {
                if (bFlagStarted == true)
                {
                    opSetMessage("Parsing under process, Unable to exit...");
                    e.Cancel = true;
                }
            }
            catch (Exception ex)
            {
                Log.LogData("Error on Parsing : " + ex.Message + ex.StackTrace, Log.Status.Error);
            }
        }
        private void btnBrowse_Click(object sender, EventArgs e)
        {
            try {

                System.Windows.Forms.FolderBrowserDialog FolderBrowserDialog1 = new System.Windows.Forms.FolderBrowserDialog();
                if (FolderBrowserDialog1.ShowDialog() == System.Windows.Forms.DialogResult.OK)
                {
                    txtPath.Text = FolderBrowserDialog1.SelectedPath;
                }
                FolderBrowserDialog1.Dispose(); FolderBrowserDialog1 = null;
            }
            catch(Exception ex)
            {
                Log.LogData("Error on Parsing : " + ex.Message + ex.StackTrace, Log.Status.Error);
            }
        }

        private void tsBtnStart_Click(object sender, EventArgs e)
        {
            try
            {
                if (string.IsNullOrEmpty(txtPath.Text.Trim()))
                {
                    opSetMessage("Select a Resume Folder ...");
                    bFlagStarted = false; 
                }
                else if (System.IO.Directory.Exists(txtPath.Text) == false)
                {
                    opSetMessage("Selected Resume Folder is not exists ...");
                    bFlagStarted = false; 
                }
                else
                { 
                    if (bstop == true)
                    {
                        if (System.Windows.Forms.MessageBox.Show("Bulk Resume Importer Stopped. Do you want to Restart?", "HireCraft", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == System.Windows.Forms.DialogResult.Yes)
                        {
                            bstop = false;
                            opSetMessage("Bulk Parsing process is started...");
                            lblStatus.Text = "Started...";
                            ParseResume();
                        }
                        else
                        {
                            bFlagStarted = false;  
                        }
                    }
                    ParseResume();
                }
            }
            catch (Exception ex)
            {
                Log.LogData("Error on Parsing : " + ex.Message + ex.StackTrace, Log.Status.Error);
            }
            finally
            { 
            }
        }
        #region "User Defined Functions" 
        /// <summary>
        ///  Fetch the Temp folder
        /// </summary>
        /// 
        public string GetLocalTempPath()
        { 
                string str = System.IO.Path.GetTempPath() + @"HireLookImportResume\";
                if (System.IO.Directory.Exists(str) == false)
                    System.IO.Directory.CreateDirectory(str);
                return str; 
        } 
        
        /// <summary>
        /// set message in status bar
        /// </summary>
        /// <param name="tMessage"></param>
        private void opSetMessage(string tMessage)
        {
            tsbar.Text = tMessage;
        }

        private void ParseResume()
        {
            try
            {
                tsBtnStop.Visible = true;
                tsBtnStart.Visible = false;

                try
                {
                    string str = "\"" + txtPath.Text + "\\*.*\" -A -R -H /S /D";
                    System.Diagnostics.Process.Start(System.Environment.SystemDirectory + "\\attrib.exe", str);
                }
                catch (Exception ex)
                {
                    Log.LogData("Error on Parsing : " + ex.Message + ex.StackTrace, Log.Status.Error);
                }
                Application.DoEvents();
                opParse();
            }
            catch (Exception ex)
            {
                Log.LogData("Error on Parsing : " + ex.Message + ex.StackTrace, Log.Status.Error);
            }
        }
        private void opSetProgressBar()
        {
            ITotalFiles = 0;
            loopNodesForTotalFiles(txtPath.Text);
            lblTotalFiles.Text = ITotalFiles.ToString(); 
            prgBar.Maximum = Convert.ToInt32(ITotalFiles);
        }
        private void InitializeBackgroundWorker()
        {
            brWorkerProgressbar.DoWork += new DoWorkEventHandler(backgroundWorker1_DoWork);
            brWorkerProgressbar.RunWorkerCompleted += new RunWorkerCompletedEventHandler(backgroundWorker1_RunWorkerCompleted);
            brWorkerProgressbar.ProgressChanged += new ProgressChangedEventHandler(backgroundWorker1_ProgressChanged);
            brWorkerProgressbar.WorkerReportsProgress = true;
            brWorkerProgressbar.WorkerSupportsCancellation = true;
        }

        private void backgroundWorker1_DoWork(object sender, DoWorkEventArgs e)
        {
            loopNodes(txtPath.Text);

        }

        // This event handler deals with the results of the 
        // background operation. 
        private void backgroundWorker1_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            // First, handle the case where an exception was thrown. 
            if (e.Error != null)
            {
                MessageBox.Show(e.Error.Message);
            }
            else if (e.Cancelled)
            { 
                this.Close();
                this.Dispose();
            }
            else
            { 

            }

        }

        private void backgroundWorker1_ProgressChanged(object sender, ProgressChangedEventArgs e)
        {
            this.prgBar.Value = e.ProgressPercentage;
            System.Windows.Forms.Application.DoEvents();
        }

        private void opParse()
        {
            try
            {
                if (bParseStart == false)
                {
                    bParseStart = true;
                    try
                    {
                        string strPath = txtPath.Text;
                        opSetProgressBar();
                        opSetMessage("Bulk Parsing process is started...");
                        lblStatus.Text = "Started..."; 
                        loopNodes(strPath);
                        strPath = null;
                    }
                    catch (Exception ex)
                    {

                        Log.LogData("Error on Parsing : " + ex.Message + ex.StackTrace, Log.Status.Error);
                    } 
                    opSetMessage("Bulk Parsing completed Successfully...");
                    prgBar.Value = prgBar.Maximum;
                    if (bstop == false)
                        lblStatus.Text = "Completed Successfully...";
                    Application.DoEvents();
                    bParseStart = false;
                    bFlagStarted = false;
                    tsBtnStop.Visible = false;
                    tsBtnStart.Visible = true;
                }
            }
            catch (Exception ex)
            {
                Log.LogData("Error on Parsing : " + ex.Message + ex.StackTrace, Log.Status.Error);
                bParseStart = false;
            }
            finally
            {
            }

        }
        private bool loopNodesForTotalFiles(string strPath)
        {
            System.IO.DirectoryInfo ofs = null;
            try
            {
                ofs = new System.IO.DirectoryInfo(strPath + "\\"); 
                System.IO.DirectoryInfo d = null;
                //Folders Loop ----------------------------------------------------
                foreach (System.IO.DirectoryInfo d_loopVariable in ofs.GetDirectories())
                {
                    d = d_loopVariable;
                    try
                    {
                        loopNodesForTotalFiles(strPath + "\\" + d.Name);
                        //Recursive call

                    }
                    catch (Exception ex)
                    {
                    }
                }
                //Files Loop ------------------------------------------------------

                if (!(ofs.Name == "Successfully Parsed Resumes" | ofs.Name == "Resumes in Unknown Format" | ofs.Name == "Duplicate (Skipped)" | ofs.Name == "Failed to Save (Invalid documents)" | ofs.Name == "Duplicate (Overwritten)"))
                {
                    // Application.DoEvents()
                    foreach (System.IO.FileInfo oFile in ofs.GetFiles())
                    {
                        long l = oFile.Length;
                        if (!(l < 100 | l == 13312))
                        {
                            string tFileName = "";
                            tFileName = oFile.Name;
                            // Application.DoEvents()
                            if (tFileName.Trim().ToLower().EndsWith(".zip") == true)
                            {
                                //Zip file parse logic
                                if (opGetExpandZippedFolder(strPath + "\\" + oFile.Name))
                                {
                                    System.IO.DirectoryInfo ofsZip = new System.IO.DirectoryInfo( GetLocalTempPath() + "HireCraftZip\\");
                                    System.IO.FileInfo oFileZip = null;
                                    foreach (System.IO.FileInfo oFileZip_loopVariable in ofsZip.GetFiles())
                                    {
                                        oFileZip = oFileZip_loopVariable;
                                        ITotalFiles = ITotalFiles + 1;
                                    }
                                }
                                
                            }
                            else
                            {
                                ITotalFiles = ITotalFiles + 1;
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Log.LogData("Error on Parsing : " + ex.Message + ex.StackTrace, Log.Status.Error);
            }
            return false;
        }

        public  bool opGetExpandZippedFolder(string tLocalPath)
        {
            try
            {
                string tFileName = GetLocalTempPath() + @"HireCraftZip\";

                if (System.IO.Directory.Exists(tFileName) == false)
                {
                    System.IO.Directory.CreateDirectory(tFileName);
                }
                else
                {
                    ClearSelectedFolderFiles(tFileName);
                }

                C1.C1Zip.C1ZipFile objZipFile = new C1.C1Zip.C1ZipFile();

                if (System.IO.File.Exists(tLocalPath))
                {
                    if (C1.C1Zip.C1ZipFile.IsZipFile(tLocalPath))
                    {
                        objZipFile.Open(tLocalPath);
                        C1.C1Zip.C1ZipEntryCollection zec = objZipFile.Entries;
                        foreach (C1.C1Zip.C1ZipEntry ze in zec)
                        {
                            string dstFileName = tFileName + System.IO.Path.GetFileName(ze.FileName);
                            objZipFile.Entries.Extract(ze.FileName, dstFileName);
                            try
                            {
                                if (dstFileName.EndsWith(".Zip") || dstFileName.EndsWith(".zip") || dstFileName.EndsWith(".ZIP"))
                                {
                                    ExtractSelectedFolderFiles(dstFileName);
                                    try
                                    {
                                        if (System.IO.File.Exists(dstFileName) == true)
                                            System.IO.File.Delete(dstFileName);
                                    }
                                    catch { }
                                }
                            }
                            catch { }
                        }
                        return true;
                    }
                    else
                        return false;
                }
                else
                    return false;
            }
            catch {
                return false;
            }
        }

        /// <summary>
        /// Pass the folder path
        /// it clears the files in that folder
        /// returns True / False
        /// </summary>
        /// <param name="strPath"></param>
        /// <returns></returns>

        public static bool ClearSelectedFolderFiles(string strPath)
        {
            try
            {
                System.IO.DirectoryInfo ofs = new System.IO.DirectoryInfo(strPath + @"\");

                //Folders Loop ----------------------------------------------------
                foreach (System.IO.DirectoryInfo d in ofs.GetDirectories())
                {
                    try
                    {
                        ClearSelectedFolderFiles(strPath + @"\" + d.Name);  //Recursive call
                        Application.DoEvents();
                        if (System.IO.Directory.Exists(strPath + @"\" + d.Name))
                        {
                            try
                            {
                                System.IO.Directory.Delete(strPath + @"\" + d.Name);
                                Application.DoEvents();
                            }
                            catch { }
                        }
                    }
                    catch { }
                }
                //Files Loop ------------------------------------------------------
                foreach (System.IO.FileInfo oFile in ofs.GetFiles())
                {
                    try
                    {
                        if (System.IO.File.Exists(strPath + @"\" + oFile.Name) == true)
                        {
                            try
                            {
                                System.IO.File.Delete(strPath + @"\" + oFile.Name);
                            }
                            catch { }
                        }
                        Application.DoEvents();
                    }
                    catch { }
                }
            }
            catch { }
            return true;
        }
        private bool ExtractSelectedFolderFiles(string strPath)
        {
            try
            {
                string tFileName = GetLocalTempPath() + @"HireCraftZip\";
                C1.C1Zip.C1ZipFile objZipFile = new C1.C1Zip.C1ZipFile();
                objZipFile.Open(strPath);
                C1.C1Zip.C1ZipEntryCollection zec = objZipFile.Entries;
                foreach (C1.C1Zip.C1ZipEntry ze in zec)
                {
                    try
                    {
                        string dstFileName = tFileName + System.IO.Path.GetFileName(ze.FileName);
                        objZipFile.Entries.Extract(ze.FileName, dstFileName);
                        try
                        {
                            if (dstFileName.EndsWith(".Zip") || dstFileName.EndsWith(".zip") || dstFileName.EndsWith(".ZIP"))
                            {
                                ExtractSelectedFolderFiles(dstFileName);
                            }
                        }
                        catch { }
                    }
                    catch
                    {
                    }
                }
                objZipFile.Close();
            }
            catch
            {
            }
            return true;
        }
        private void loopNodes(string strPath)
        { 
            System.IO.DirectoryInfo ofs = null;
            try
            {
                ofs = new System.IO.DirectoryInfo(strPath + "\\"); 
                System.IO.DirectoryInfo d = null; 
                foreach (System.IO.DirectoryInfo d_loopVariable in ofs.GetDirectories())
                {
                    d = d_loopVariable;
                    try
                    {
                        loopNodes(strPath + "\\" + d.Name); 
                        if (bstop == true)
                        {
                            bParseStart = false;
                            break;
                        } 
                    }
                    catch (Exception ex)
                    {

                        Log.LogData("Error on Parsing : " + ex.Message + ex.StackTrace, Log.Status.Error);
                    }
                }
                if (bstop == true)
                {
                    bParseStart = false; 
                  
                } 
                if (bstop == false && (!(ofs.Name == "Successfully Parsed Resumes" | ofs.Name == "Resumes in Unknown Format" | ofs.Name == "Duplicate (Skipped)" | ofs.Name == "Failed to Save (Invalid documents)" | ofs.Name == "Duplicate (Overwritten)")))
                {
                    lblFolderName.Text = ofs.Name;
                    Application.DoEvents();
                    foreach (System.IO.FileInfo oFile in ofs.GetFiles())
                    {
                        try
                        {
                            if (bstop == true)
                            {
                                break;
                            }
                            long l = oFile.Length;
                            if (!(l < 100 | l == 13312))
                            {

                                if (oFile.Name.ToLower().EndsWith(".zip"))
                                {

                                    if (opGetExpandZippedFolder(strPath + "\\" + oFile.Name))
                                    {
                                        System.IO.DirectoryInfo ofsZip = new System.IO.DirectoryInfo(GetLocalTempPath() + "HireCraftZip\\"); 
                                        foreach (System.IO.FileInfo oFileZip_loopVariable in ofsZip.GetFiles())
                                        {
                                            opUploadFile(GetLocalTempPath() + "HireCraftZip\\", strPath, oFileZip_loopVariable);
                                        }
                                    }
                                    if (System.IO.Directory.Exists(strPath + "\\Successfully Parsed Resumes") == false)
                                    {
                                        System.IO.Directory.CreateDirectory(strPath + "\\Successfully Parsed Resumes");
                                    }
                                    System.IO.File.Move(strPath + "\\" + oFile.Name, strPath + "\\Successfully Parsed Resumes\\" + oFile.Name);
                                }
                                else
                                    opUploadFile(strPath, strPath, oFile);
                            }

                        }
                        catch (Exception ex)
                        {
                        }
                    } 
                }
            }
            catch (Exception ex)
            {
                Log.LogData("Error on Parsing : " + ex.Message + ex.StackTrace, Log.Status.Error);
                bParseStart = false;
            }
            finally
            {
                ofs = null;
            } 
        }
        private void opUploadFile(string strPath1, string strPath, System.IO.FileInfo oFile)
        {
            try
            {


                lblFileName.Text = oFile.Name;
                Application.DoEvents();
                if (Configuration.Allowed_Doc_Extention.FindAll(item => item.ToLower() == oFile.Extension.ToLower()).Count > 0)
                {
                    byte[] bytes = System.IO.File.ReadAllBytes(oFile.FullName);

                    var webClient = new WebClient();
                    string boundary = "------------------------" + DateTime.Now.Ticks.ToString("x");
                    webClient.Headers.Add("Authorization: bearer " + Configuration.access_token);
                    webClient.Headers.Add("Content-Type", "multipart/form-data; boundary=" + boundary);
                    var fileData = webClient.Encoding.GetString(bytes);
                    var package = string.Format("--{0}\r\nContent-Disposition: form-data; name=\"file\"; filename=\"{1}\"\r\nContent-Type: {2}\r\n\r\n{3}\r\n--{0}--\r\n", boundary, oFile.Name, "application/octet-stream", fileData);

                    var nfile = webClient.Encoding.GetBytes(package);
                    byte[] resp = webClient.UploadData(Configuration.ApplicationAPI + "resume/bulkparsing", "POST", nfile);

                    ResposeData _responseData = new ResposeData();
                    _responseData = Newtonsoft.Json.JsonConvert.DeserializeObject<ResposeData>(System.Text.Encoding.UTF8.GetString(resp));
                    //Constants.ResumeId = _responseData.RID; 
                    if (_responseData.Code == "SUCCESS0001")
                    {
                        tParsedResume = tParsedResume + 1;
                        if (System.IO.Directory.Exists(strPath + "\\Successfully Parsed Resumes") == false)
                        {
                            System.IO.Directory.CreateDirectory(strPath + "\\Successfully Parsed Resumes");
                        }
                        System.IO.File.Move(strPath + "\\" + oFile.Name, strPath + "\\Successfully Parsed Resumes\\" + oFile.Name);
                        //duplicate case need to move- Duplicate (Skipped)                tDuplicateDocument = tDuplicateDocument + 1;
                        //duplicate overwrite case-Duplicate (Overwritten)tDuplicateOverwriteDocument = tDuplicateOverwriteDocument + 1;
                    }
                    else if (_responseData.Code == "DUPLICATE001")
                    {
                        tDuplicateDocument = tDuplicateDocument + 1;
                        if (System.IO.Directory.Exists(strPath + "\\Duplicate (Skipped)") == false)
                        {
                            System.IO.Directory.CreateDirectory(strPath + "\\Duplicate (Skipped)");
                        }
                        System.IO.File.Move(strPath1 + "\\" + oFile.Name, strPath + "\\Duplicate (Skipped)\\" + oFile.Name);
                    }
                    else if (_responseData.Code == "ERR0001" || _responseData.Code == "FAIL0001")
                    {
                        tFailed2Save = tFailed2Save + 1;
                        if (System.IO.Directory.Exists(strPath + "\\Failed to Save (Invalid documents)") == false)
                        {
                            System.IO.Directory.CreateDirectory(strPath + "\\Failed to Save (Invalid documents)");
                        }
                        System.IO.File.Move(strPath1 + "\\" + oFile.Name, strPath + "\\Failed to Save (Invalid documents)\\" + oFile.Name);
                    }
                    else
                    {
                        tParsedResume = tParsedResume + 1;
                        if (System.IO.Directory.Exists(strPath + "\\Successfully Parsed Resumes") == false)
                        {
                            System.IO.Directory.CreateDirectory(strPath + "\\Successfully Parsed Resumes");
                        }
                        System.IO.File.Move(strPath1 + "\\" + oFile.Name, strPath + "\\Successfully Parsed Resumes\\" + oFile.Name);
                        //duplicate case need to move- Duplicate (Skipped)                tDuplicateDocument = tDuplicateDocument + 1;
                        //duplicate overwrite case-Duplicate (Overwritten)tDuplicateOverwriteDocument = tDuplicateOverwriteDocument + 1;
                    }
                    Log.LogData(oFile.Name + System.Environment.NewLine + _responseData.Message, Log.Status.Info);
                    _responseData = null; _responseData = null;
                    bytes = null;
                }
                else
                {
                    tUnKnownFormatResumes = tUnKnownFormatResumes + 1;
                    if (System.IO.Directory.Exists(strPath + "\\Resumes in Unknown Format") == false)
                    {
                        System.IO.Directory.CreateDirectory(strPath + "\\Resumes in Unknown Format");
                    }
                    System.IO.File.Move(strPath1 + "\\" + oFile.Name, strPath + "\\Resumes in Unknown Format\\" + oFile.Name);
                    //failed to save case-Failed to Save (Invalid documents)tFailed2Save = tFailed2Save + 1;
                }
                iGlobalTotalCount = iGlobalTotalCount + 1;
                labCount.Text = Convert.ToString(iGlobalTotalCount);
                lblDuplicateDoc.Text = tDuplicateDocument.ToString();
                lblDuplicateOverwrite.Text = tDuplicateOverwriteDocument.ToString();
                lblFailedSave.Text = tFailed2Save.ToString();
                lblUnknownFormatR.Text = tUnKnownFormatResumes.ToString();
                lblParsed.Text = tParsedResume.ToString();
                prgBar.Value = iGlobalTotalCount;
                Application.DoEvents();
            }
            catch (WebException ex)
            {
                var responseString = new System.IO.StreamReader(ex.Response.GetResponseStream()).ReadToEnd();
                HCResponse _hcresponse = Newtonsoft.Json.JsonConvert.DeserializeObject<HCResponse>(responseString);
                if (_hcresponse.Code == "VALD0001" || _hcresponse.Code == "ERR0007")
                {
                    tUnKnownFormatResumes = tUnKnownFormatResumes + 1;
                    if (System.IO.Directory.Exists(strPath + "\\Resumes in Unknown Format") == false)
                    {
                        System.IO.Directory.CreateDirectory(strPath + "\\Resumes in Unknown Format");
                    }
                    System.IO.File.Move(strPath1 + "\\" + oFile.Name, strPath + "\\Resumes in Unknown Format\\" + oFile.Name);
                }
                else if (_hcresponse.Code == "DUPLICATE001")
                {
                    tDuplicateDocument = tDuplicateDocument + 1;
                    if (System.IO.Directory.Exists(strPath + "\\Duplicate (Skipped)") == false)
                    {
                        System.IO.Directory.CreateDirectory(strPath + "\\Duplicate (Skipped)");
                    }
                    System.IO.File.Move(strPath1 + "\\" + oFile.Name, strPath + "\\Duplicate (Skipped)\\" + oFile.Name);
                }
                else if (_hcresponse.Code == "FAIL0001" || _hcresponse.Code == "ERR0001")
                {
                    tFailed2Save = tFailed2Save + 1;
                    if (System.IO.Directory.Exists(strPath + "\\Failed to Save (Invalid documents)") == false)
                    {
                        System.IO.Directory.CreateDirectory(strPath + "\\Failed to Save (Invalid documents)");
                    }
                    System.IO.File.Move(strPath1 + "\\" + oFile.Name, strPath + "\\Failed to Save (Invalid documents)\\" + oFile.Name);
                }
                else
                {
                    tUnKnownFormatResumes = tUnKnownFormatResumes + 1;
                    if (System.IO.Directory.Exists(strPath + "\\Resumes in Unknown Format") == false)
                    {
                        System.IO.Directory.CreateDirectory(strPath + "\\Resumes in Unknown Format");
                    }
                    System.IO.File.Move(strPath1 + "\\" + oFile.Name, strPath + "\\Resumes in Unknown Format\\" + oFile.Name);
                }
                Log.LogData(oFile.Name + System.Environment.NewLine + _hcresponse.Message + ex.Message + System.Environment.NewLine + ex.StackTrace, Log.Status.Error);
                _hcresponse = null; responseString = null;

                iGlobalTotalCount = iGlobalTotalCount + 1;
                labCount.Text = Convert.ToString(iGlobalTotalCount);
                lblDuplicateDoc.Text = tDuplicateDocument.ToString();
                lblDuplicateOverwrite.Text = tDuplicateOverwriteDocument.ToString();
                lblFailedSave.Text = tFailed2Save.ToString();
                lblUnknownFormatR.Text = tUnKnownFormatResumes.ToString();
                lblParsed.Text = tParsedResume.ToString();
                prgBar.Value = iGlobalTotalCount;
                Application.DoEvents();
            }
            catch (Exception ex)
            {
                Log.LogData("Error on Parsing : " + ex.Message + ex.StackTrace, Log.Status.Error);
            }
        }

        public string UploadMultipart(byte[] file, string filename, string contentType, string url)
        {
            string ResposeResult = string.Empty;
            try
            {
                var webClient = new WebClient();
                string boundary = "------------------------" + DateTime.Now.Ticks.ToString("x");
                webClient.Headers.Add("Authorization: bearer " + Configuration.access_token);
                webClient.Headers.Add("Content-Type", "multipart/form-data; boundary=" + boundary);
                var fileData = webClient.Encoding.GetString(file);
                var package = string.Format("--{0}\r\nContent-Disposition: form-data; name=\"file\"; filename=\"{1}\"\r\nContent-Type: {2}\r\n\r\n{3}\r\n--{0}--\r\n", boundary, filename, "application/octet-stream", fileData);

                var nfile = webClient.Encoding.GetBytes(package);
                byte[] resp = webClient.UploadData(url, "POST", nfile);
                ResposeResult = System.Text.Encoding.UTF8.GetString(resp);
                System.Text.RegularExpressions.Regex rgx = new System.Text.RegularExpressions.Regex("[^a-zA-Z0-9 -]");
                ResposeResult = rgx.Replace(ResposeResult, "");

            }
            catch (System.Exception ex)
            {
                Log.LogData("Error in upload attachmnt" + ex.Message + ex.StackTrace, Log.Status.Error);
                return "";
            }
            return ResposeResult;
        }

        #endregion


       
    }
}
