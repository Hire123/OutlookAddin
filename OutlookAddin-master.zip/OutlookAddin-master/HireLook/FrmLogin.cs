﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net;
using System.IO;
using Newtonsoft.Json;
using Microsoft.Win32;
using HireLook;
using HCUserControls;
namespace HireLook
{
    public partial class FrmLogin : Form
    {
        CtrlFooter footer = new CtrlFooter();
        public FrmLogin()
        {
            InitializeComponent();
            this.footer.Location = new System.Drawing.Point(0, 190);
            footer.Dock = DockStyle.Bottom;
            this.footer.BringToFront();
            this.Controls.Add(footer);
        }
        private void FrmLogin_Load(object sender, EventArgs e)
        {
            this.UseWaitCursor = true;
            Configuration.isLogin = false;
            this.UseWaitCursor = false;
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            this.UseWaitCursor = true;
            if (txtUsername.Text.Trim() == string.Empty)
            {
                footer.ShowMessage("Enter Username.");
                txtUsername.Focus();
            }
            else if (txtPassword.Text.Trim().ToString() == string.Empty)
            {
                footer.ShowMessage("Enter Password.");
                txtPassword.Focus();
            }
            else
                opLogin(txtUsername.Text.Trim().ToString(), txtPassword.Text.Trim().ToString());
            this.UseWaitCursor = false;
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        void opLogin(string Username, string Password)
        {
            var request = (HttpWebRequest)WebRequest.Create(Configuration.ApplicationAPI + "token");
            var postData = "Username=" + Username + "&Password=" + Password + "&grant_type=password&Client_Id=hMTc57B";
            var data = Encoding.ASCII.GetBytes(postData);
            request.Method = "POST";
            request.ContentType = "application/x-www-form-urlencoded";
            request.ContentLength = data.Length;
            try
            {
                using (var stream = request.GetRequestStream())
                {
                    stream.Write(data, 0, data.Length);
                }
                try
                {
                    HttpWebResponse response = (HttpWebResponse)request.GetResponse();
                    var responseString = new StreamReader(response.GetResponseStream()).ReadToEnd();

                    var values = JsonConvert.DeserializeObject<Dictionary<string, string>>(responseString);

                    try
                    {

                        foreach (var value in values)
                        {
                            RegistryKey key = Registry.CurrentUser.CreateSubKey(Configuration.registryName);
                            if (value.Key == "RID" || value.Key == "access_token" || value.Key == "token_type" || value.Key == "refresh_token" || value.Key == "as:client_id" || value.Key == "userName")
                                key.SetValue(value.Key, value.Value);
                            key.Close();
                        }
                        Configuration.LoadRegValues();
                        // Configuration.LoadRegValues();
                    }
                    catch (Exception ex)
                    {
                        Log.LogData("Error in frmLogin: Registry value: " + ex.Message + ex.StackTrace, Log.Status.Error);
                    }
                    this.Close();
                }
                catch (WebException ex)
                {
                    Configuration.isLogin = false;
                    footer.ShowMessage("Invalid Username/Password.");
                    Log.LogData("Invalid Username/Password: " + txtUsername.Text, Log.Status.Error);
                }
            }
            catch (Exception ex)
            {
                Log.LogData("Server Error " + ex.Message + ex.StackTrace, Log.Status.Error);
            }
        }

    }
}
