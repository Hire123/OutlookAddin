﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Linq;
using Outlook = Microsoft.Office.Interop.Outlook;
using Office = Microsoft.Office.Core;
using Microsoft.Win32;
using Microsoft.Office.Interop.Outlook;
using System.Runtime.InteropServices;
namespace HireLook
{
    public partial class ThisAddIn
    {

        public static Outlook.MAPIFolder inBox = null;
        public static Outlook.MAPIFolder HireCraftProcessFolder = null;
        public static Outlook.MAPIFolder HireCraftParseFolder = null;
        public static Outlook.MAPIFolder HireCraftOtherFolder = null;
        public static Outlook.MAPIFolder HireCraftDuplicateFolder = null;
        public static Outlook.MAPIFolder HireCraftOverwriteFolder = null;

        private void ThisAddIn_Startup(object sender, System.EventArgs e)
        {

            CreateHireLookFolder(this.Application);
        }

        private void CreateHireLookFolder(Outlook._Application OutlookApp)
        {
            bool FolderFlag = false;
            bool parseFlag = false;
           // Outlook.MAPIFolder Hirefolder = null;
            inBox = (Outlook.MAPIFolder)Globals.ThisAddIn.Application.ActiveExplorer().Session.GetDefaultFolder
         (Outlook.OlDefaultFolders.olFolderInbox);
            //code the get the inbox folder details
            for (int i = 1; inBox.Folders.Count >= i; i++)
            {
                //code the check the hirecraft processed folder available or not inside inbox
                FolderFlag = false;
                if (inBox.Folders[i].Name == "HireCraft Processed")
                {
                    HireCraftProcessFolder = inBox.Folders[i] as Outlook.MAPIFolder;
                    FolderFlag = true;
                    //code the check HireCraft processed folder contains parse duplicate and override duplicate override folder available or not
                    if (HireCraftProcessFolder.Folders.Count > 0)
                    {
                        for (int j = 1; HireCraftProcessFolder.Folders.Count >= j; j++)
                        {
                            HireCraftParseFolder = HireCraftProcessFolder.Folders[j] as Outlook.MAPIFolder;
                            if (HireCraftProcessFolder.Folders[j].Name == "Parsed Resume")
                            {
                                parseFlag = true;
                                break;
                            }
                            else
                            {
                                parseFlag = false;
                                Marshal.ReleaseComObject(HireCraftParseFolder);
                            }

                        }
                        if (parseFlag == false)
                        {
                            HireCraftParseFolder = (Outlook.MAPIFolder)HireCraftProcessFolder.Folders.Add("Parsed Resume");
                        }

                        //below code to check folder exists or not if not exist then creating the folder inside inbox
                        parseFlag = false;
                        for (int j = 1; HireCraftProcessFolder.Folders.Count >= j; j++)
                        {
                            HireCraftOtherFolder = HireCraftProcessFolder.Folders[j] as Outlook.MAPIFolder;
                            if (HireCraftProcessFolder.Folders[j].Name == "Others")
                            {
                                parseFlag = true;
                                break;
                            }
                            else
                            {
                                parseFlag = false;
                                Marshal.ReleaseComObject(HireCraftOtherFolder);
                            }

                        }
                        if (parseFlag == false)
                        {
                            HireCraftOtherFolder = (Outlook.MAPIFolder)HireCraftProcessFolder.Folders.Add("Others");
                        }

                        //below code to check folder exists or not if not exist then creating the folder inside inbox
                        parseFlag = false;
                        for (int j = 1; HireCraftProcessFolder.Folders.Count >= j; j++)
                        {
                            HireCraftDuplicateFolder = HireCraftProcessFolder.Folders[j] as Outlook.MAPIFolder;
                            if (HireCraftProcessFolder.Folders[j].Name == "Duplicate Resume")
                            {
                                parseFlag = true;
                                break;
                            }
                            else
                            {
                                parseFlag = false;
                                Marshal.ReleaseComObject(HireCraftDuplicateFolder);
                            }

                        }
                        if (parseFlag == false)
                        {
                            HireCraftDuplicateFolder = (Outlook.MAPIFolder)HireCraftProcessFolder.Folders.Add("Duplicate Resume");
                        }

                        //below code to check folder exists or not if not exist then creating the folder inside inbox
                        parseFlag = false;
                        for (int j = 1; HireCraftProcessFolder.Folders.Count >= j; j++)
                        {
                            HireCraftOverwriteFolder = HireCraftProcessFolder.Folders[j] as Outlook.MAPIFolder;
                            if (HireCraftProcessFolder.Folders[j].Name == "Duplicate Overwrite Resume")
                            {
                                parseFlag = true;
                                break;
                            }
                            else
                            {
                                parseFlag = false;
                                Marshal.ReleaseComObject(HireCraftOverwriteFolder);
                            }

                        }
                        if (parseFlag == false)
                        {
                            HireCraftOverwriteFolder = (Outlook.MAPIFolder)HireCraftProcessFolder.Folders.Add("Duplicate Overwrite Resume");
                        }

                    }
                    else
                    {
                        //creating below folder inside hirecraft processed folder
                        HireCraftParseFolder = (Outlook.MAPIFolder)HireCraftProcessFolder.Folders.Add("Parsed Resume");
                        HireCraftOtherFolder = (Outlook.MAPIFolder)HireCraftProcessFolder.Folders.Add("Others");
                        HireCraftDuplicateFolder = (Outlook.MAPIFolder)HireCraftProcessFolder.Folders.Add("Duplicate Resume");
                        HireCraftOverwriteFolder = (Outlook.MAPIFolder)HireCraftProcessFolder.Folders.Add("Duplicate Overwrite Resume");
                    }
                    break;
                }

            }

            if (FolderFlag == false)
            {
                //if Hirecraft processed folder not avablable then creating HireCraft Processed folder and their child folder
                HireCraftProcessFolder = (Outlook.MAPIFolder)inBox.Folders.Add("HireCraft Processed");

                HireCraftParseFolder = (Outlook.MAPIFolder)HireCraftProcessFolder.Folders.Add("Parsed Resume");
                HireCraftOtherFolder = (Outlook.MAPIFolder)HireCraftProcessFolder.Folders.Add("Others");
                HireCraftDuplicateFolder = (Outlook.MAPIFolder)HireCraftProcessFolder.Folders.Add("Duplicate Resume");
                HireCraftOverwriteFolder = (Outlook.MAPIFolder)HireCraftProcessFolder.Folders.Add("Duplicate Overwrite Resume");
            }

        }

        private void SetUpFolder(Outlook._Application OutlookApp)
        {
            CreateHireLookFolder(OutlookApp);
            Outlook.NameSpace ns = null;
            Outlook.MAPIFolder folderInbox = null;
            Outlook.MAPIFolder parent = null;
            Outlook.Folders rootFolders = null;
            Outlook.MAPIFolder smileFolder = null;

            try
            {
                ns = OutlookApp.GetNamespace("MAPI");
                folderInbox = ns.GetDefaultFolder(Outlook.OlDefaultFolders.olFolderInbox);
                parent = folderInbox.Parent as Outlook.MAPIFolder;
                rootFolders = parent.Folders;
                for (int i = 1; rootFolders.Count >= i; i++)
                {
                    smileFolder = rootFolders[i];
                    if (smileFolder.Name == "In Process")
                    {
                        break;
                    }
                    else
                    {
                        Marshal.ReleaseComObject(smileFolder);
                        smileFolder = null;
                    }
                }
                if (smileFolder == null)
                {
                    smileFolder = rootFolders.Add("In Process");
                }
            }
            catch (System.Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.Message,
                              "An exception was thrown in the code...");
            }
            finally
            {
                if (smileFolder != null) Marshal.ReleaseComObject(smileFolder);
                if (rootFolders != null) Marshal.ReleaseComObject(rootFolders);
                if (folderInbox != null) Marshal.ReleaseComObject(folderInbox);
                if (ns != null) Marshal.ReleaseComObject(ns);
            }
        }

        private void ThisAddIn_Shutdown(object sender, System.EventArgs e)
        {
        }

        #region VSTO generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InternalStartup()
        {
            this.Startup += new System.EventHandler(ThisAddIn_Startup);
            this.Shutdown += new System.EventHandler(ThisAddIn_Shutdown);
        }

        #endregion

        protected override Microsoft.Office.Core.IRibbonExtensibility CreateRibbonExtensibilityObject()
        {
            return new Ribbon();
        }



    }
}
