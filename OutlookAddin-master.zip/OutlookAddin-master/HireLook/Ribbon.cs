﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Text;
using Office = Microsoft.Office.Core;
using Microsoft.Win32;
using System.Security.AccessControl;
using Microsoft.Office.Interop.Outlook;
using Outlook = Microsoft.Office.Interop.Outlook;
using System.Net;
using Newtonsoft.Json;
using System.Text.RegularExpressions;
using HireLook;

// TODO:  Follow these steps to enable the Ribbon (XML) item:

// 1: Copy the following code block into the ThisAddin, ThisWorkbook, or ThisDocument class.

//  protected override Microsoft.Office.Core.IRibbonExtensibility CreateRibbonExtensibilityObject()
//  {
//      return new Ribbon();
//  }

// 2. Create callback methods in the "Ribbon Callbacks" region of this class to handle user
//    actions, such as clicking a button. Note: if you have exported this Ribbon from the Ribbon designer,
//    move your code from the event handlers to the callback methods and modify the code to work with the
//    Ribbon extensibility (RibbonX) programming model.

// 3. Assign attributes to the control tags in the Ribbon XML file to identify the appropriate callback methods in your code.  

// For more information, see the Ribbon XML documentation in the Visual Studio Tools for Office Help.


namespace HireLook
{
    [ComVisible(true)]
    public class Ribbon : Office.IRibbonExtensibility
    {
        private Office.IRibbonUI ribbon;
        bool _hideLogin = true;
        bool _hideParse = false;
        bool _hideImportResume = false;
        bool _hidebtnImportResumePortal = false;
        bool _hideLogout = false;
        bool callback { get; set; }

        public Ribbon()
        {

        }

        #region IRibbonExtensibility Members

        public string GetCustomUI(string ribbonID)
        {
            return GetResourceText("HireLook.Ribbon3.xml");
        }

        #endregion

        #region Ribbon Callbacks
        //Create callback methods here. For more information about adding callback methods, visit http://go.microsoft.com/fwlink/?LinkID=271226

        public void Ribbon_Load(Office.IRibbonUI ribbonUI)
        {
            this.ribbon = ribbonUI;
            RegistryKey myregistry = Registry.CurrentUser.OpenSubKey(Configuration.registryName);
            if (myregistry != null)
            {
                Configuration.LoadRegValues();
                if (Configuration.isLogin == false)
                {
                    //FrmLogin frmLogin = new FrmLogin();
                    //frmLogin.ShowDialog();
                    //if (Configuration.isLogin)
                    //{
                    //    _hideLogin = false;
                    //    _hideParse = true;
                    //    _hideImportResume = true;
                    //    _hidebtnImportResumePortal = true;
                    //    _hideLogout = true;
                    //    ribbon.Invalidate();
                    //}
                    //else
                    //{
                    _hideLogin = true;
                    _hideParse = false;
                    _hideImportResume = false;
                    _hidebtnImportResumePortal = false;
                    _hideLogout = false;
                    ribbon.Invalidate();
                    //}
                }
                else
                {
                    if (Configuration.OPRefreshToken())
                    {
                        _hideLogin = false;
                        _hideParse = true;
                        _hideImportResume = true;
                        _hidebtnImportResumePortal = true;
                        _hideLogout = true;
                        ribbon.Invalidate();
                    }
                    else
                    {
                        //FrmLogin frmLogin = new FrmLogin();
                        //frmLogin.ShowDialog();
                        //if (Configuration.isLogin)
                        //{
                        //    _hideLogin = false;
                        //    _hideParse = true;
                        //    _hideImportResume = true;
                        //    _hidebtnImportResumePortal = true;
                        //    _hideLogout = true;
                        //    ribbon.Invalidate();
                        //}
                        //else
                        //{
                        _hideLogin = true;
                        _hideParse = false;
                        _hideImportResume = false;
                        _hidebtnImportResumePortal = false;
                        _hideLogout = false;
                        ribbon.Invalidate();
                        //}
                    }

                }
            }
            else
            {
                //FrmLogin frmLogin = new FrmLogin();
                //frmLogin.ShowDialog();
                //if (Configuration.isLogin)
                //{
                //    _hideLogin = false;
                //    _hideParse = true;
                //    _hideImportResume = true;
                //    _hidebtnImportResumePortal = true;
                //    _hideLogout = true;
                //    ribbon.Invalidate();
                //}
                //else
                //{
                _hideLogin = true;
                _hideParse = false;
                _hideImportResume = false;
                _hidebtnImportResumePortal = false;
                _hideLogout = false;
                ribbon.Invalidate();
                //}
            }
        }

        #endregion

        #region Helpers

        private static string GetResourceText(string resourceName)
        {
            Assembly asm = Assembly.GetExecutingAssembly();
            string[] resourceNames = asm.GetManifestResourceNames();
            for (int i = 0; i < resourceNames.Length; ++i)
            {
                if (string.Compare(resourceName, resourceNames[i], StringComparison.OrdinalIgnoreCase) == 0)
                {
                    using (StreamReader resourceReader = new StreamReader(asm.GetManifestResourceStream(resourceNames[i])))
                    {
                        if (resourceReader != null)
                        {
                            return resourceReader.ReadToEnd();
                        }
                    }
                }
            }
            return null;
        }

        #endregion

        #region Login functionality

        public void btnLogin_Click(Microsoft.Office.Core.IRibbonControl control)
        {
            FrmLogin frmLogin = new FrmLogin();
            frmLogin.ShowDialog();
            if (Configuration.isLogin)
            {
                _hideLogin = false;
                _hideParse = true;
                _hideLogout = true;
                _hideImportResume = true;
                _hidebtnImportResumePortal = true;
                ribbon.Invalidate();
            }
        }

        public bool HideLogin(Office.IRibbonControl control)
        {
            return _hideLogin;
        }

        public string getlabel(Office.IRibbonControl control)
        {
            string returnString = string.Empty;
            switch (control.Id)
            {
                case "grpHireLook":

                    if (callback == true)
                    {
                        callback = false;
                        returnString = Configuration.userName;
                    }
                    else
                    {
                        callback = true;
                        returnString = Configuration.userName;
                    }
                    break;
            }

            return returnString;
        }
        #endregion

        #region Parse functionality

        public bool HideParse(Office.IRibbonControl control)
        {
            return _hideParse;
        }

        public void LoadImage(Office.IRibbonControl control)
        {

        }
        public void btnParse_Click(Microsoft.Office.Core.IRibbonControl control)
        {
            try
            {
                if (Configuration.isLogin)
                {
                    //string currentPath = AppDomain.CurrentDomain.BaseDirectory;
                    //string FilePath = @"Attachments\" + "RESUME(shikha).pdf";
                    //Constants.FilePath = currentPath + FilePath;
                    ParseAttachment parseAttach = new ParseAttachment();
                    parseAttach.getAttachment();
                    // parseAttach.loadSelections("Resume672");

                    //TxtCtrl ctrl = new TxtCtrl();
                    //ctrl.ShowDialog();

                }
            }
            catch (System.Exception ex)
            {
                Log.LogData("Error on Parsing : " + ex.Message + ex.StackTrace, Log.Status.Error);
            }
        }

        #endregion

        public void btnParseSilent_Click(Office.IRibbonControl control)
        {

        }

        #region Logout functionality

        public void btnLogout_Click(Office.IRibbonControl control)
        {
            bool removeResult = Configuration.RemoveRegValues();
            if (removeResult)
            {
                _hideLogout = false;
                _hideParse = false;
                _hideImportResume = false;
                _hidebtnImportResumePortal = false;
                _hideLogin = true;
                ribbon.Invalidate();
            }
        }

        public bool hideLogout(Office.IRibbonControl control)
        {
            return _hideLogout;
        }

        #endregion

        #region "Import Resumes"

        public void btnFolderParse_Click(Office.IRibbonControl control)
        {
            try
            {
                if (Configuration.isLogin)
                {
                    frmImportResume objimportresume = new frmImportResume();
                    objimportresume.ShowDialog();
                    objimportresume.Dispose();
                    objimportresume = null;

                }
            }
            catch (System.Exception ex)
            {
                Log.LogData("Error on Parsing : " + ex.Message + ex.StackTrace, Log.Status.Error);
            }
        }
        public bool HideImportResume(Office.IRibbonControl control)
        {
            return _hideImportResume;
        }
        #endregion

        #region "Import Resumes from portal"

        public void btnImportResumePortal_Click(Office.IRibbonControl control)
        {
            try
            {
                if (Configuration.isLogin)
                {
                    try
                    {
                        frmImportfromPortals objimportresume = new frmImportfromPortals();
                        objimportresume.ShowDialog();
                        objimportresume.Dispose();
                        objimportresume = null;
                    }
                    catch (System.Exception ex)
                    {
                        Log.LogData("Error on Parsing : Error in opening ImportResumePortal : " + ex.Message + ex.StackTrace, Log.Status.Error);
                    }
                }
            }
            catch (System.Exception ex)
            {
                Log.LogData("Error on Parsing : " + ex.Message + ex.StackTrace, Log.Status.Error);
            }
        }
        public bool HidebtnImportResumePortal(Office.IRibbonControl control)
        {
            return _hidebtnImportResumePortal;
        }
        #endregion
    }


}
