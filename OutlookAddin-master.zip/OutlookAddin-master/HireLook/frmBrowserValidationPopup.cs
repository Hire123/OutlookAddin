﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace HireLook
{
    public partial class frmBrowserValidationPopup : Form
    {
        public frmBrowserValidationPopup()
        {
            InitializeComponent();
        }

        public string tAuthURL = "";

        private void frmBrowserValidationPopup_Load(object sender, EventArgs e)
        {

            try
            {

                wbAuth.ScriptErrorsSuppressed = true;
                if (tAuthURL.Trim() != "")
                {
                    wbAuth.Navigate(tAuthURL);
                }
            }
            catch (Exception ex)
            {
                Log.LogData("Error on Parsing : " + ex.Message + ex.StackTrace, Log.Status.Error);
            }
        }

        private void wbAuth_DocumentCompleted(object sender, WebBrowserDocumentCompletedEventArgs e)
        {
            try
            {
                if (((System.Windows.Forms.WebBrowser)(sender)).DocumentTitle != "")
                    this.Text = ((System.Windows.Forms.WebBrowser)(sender)).DocumentTitle;
                else if (((System.Windows.Forms.WebBrowser)(sender)) != null && ((System.Windows.Forms.WebBrowser)(sender)).Document != null && string.IsNullOrEmpty(((System.Windows.Forms.WebBrowser)(sender)).DocumentText) == false && ((System.Windows.Forms.WebBrowser)(sender)).DocumentTitle == "")
                {
                    string[] arr = ((System.Windows.Forms.WebBrowser)(sender)).DocumentText.Split(new string[] { "<title>", "</title>" }, StringSplitOptions.RemoveEmptyEntries);
                    if (arr != null && arr.Length > 1)
                        this.Text = arr[1];
                }
            }
            catch (Exception ex)
            {
                Log.LogData("Error on Parsing : " + ex.Message + ex.StackTrace, Log.Status.Error);
            }
        }
    }
}
