﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Net;
using System.IO;
using System.Text.RegularExpressions;
using Microsoft.Office.Interop.Outlook;
using Newtonsoft.Json;
namespace HireLook
{
    public partial class frmProgressBar : Form
    {
        public delegate void opSetEventHandler();
        public event opSetEventHandler opCallEventMethod;
        Boolean bflg;
        Attachment attach;
        List<FormDesignLayout> designlayout = new List<FormDesignLayout>();
        string UploadResult = string.Empty;
        public bool reqParseStatus = false;
        public frmProgressBar()
        {
            InitializeComponent();
            InitializeBackgroundWorker();
        }
        public frmProgressBar(Attachment attachment)
        {
            this.attach = attachment;
            InitializeComponent();

        }
        public void loadProgress()
        {
            InitializeBackgroundWorker();
            if (brWorkerProgressbar.IsBusy != true)
                brWorkerProgressbar.RunWorkerAsync();
        }
        private void InitializeBackgroundWorker()
        {
            brWorkerProgressbar.DoWork += new DoWorkEventHandler(backgroundWorker1_DoWork);
            brWorkerProgressbar.RunWorkerCompleted += new RunWorkerCompletedEventHandler(backgroundWorker1_RunWorkerCompleted);
            brWorkerProgressbar.ProgressChanged += new ProgressChangedEventHandler(backgroundWorker1_ProgressChanged);
            brWorkerProgressbar.WorkerReportsProgress = true;
            brWorkerProgressbar.WorkerSupportsCancellation = true;
        }

        private void backgroundWorker1_DoWork(object sender, DoWorkEventArgs e)
        {
            // Get the BackgroundWorker that raised this event.
            BackgroundWorker worker = sender as BackgroundWorker;
            uploadAttachment(ref worker, e);
            // Assign the result of the computation 
            // to the Result property of the DoWorkEventArgs 
            // object. This is will be available to the  
            // RunWorkerCompleted eventhandler.

        }

        // This event handler deals with the results of the 
        // background operation. 
        private void backgroundWorker1_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            // First, handle the case where an exception was thrown. 
            if (e.Error != null)
            {
                MessageBox.Show(e.Error.Message);
            }
            else if (e.Cancelled)
            {
                // Next, handle the case where the user canceled  
                // the operation. 
                // Note that due to a race condition in  
                // the DoWork event handler, the Cancelled 
                // flag may not have been set, even though 
                // CancelAsync was called.
                // resultLabel.Text = "Canceled";
                reqParseStatus = false;
                this.Close();
                this.Dispose();
            }
            else
            {

                this.Close();
                this.Dispose();
                FrmResumeManagers resumeMgr = new FrmResumeManagers(designlayout, UploadResult);
                resumeMgr.ShowDialog(); resumeMgr.Dispose();

                if (resumeMgr.DuplicateRsmStatus)
                    reqParseStatus = true;
                else
                    reqParseStatus = false;

            }

        }

        private void backgroundWorker1_ProgressChanged(object sender, ProgressChangedEventArgs e)
        {
            this.prgBar.Value = e.ProgressPercentage;
            System.Windows.Forms.Application.DoEvents();
        }

        public void uploadAttachment(ref BackgroundWorker worker, DoWorkEventArgs e)
        {
            brWorkerProgressbar.ReportProgress(25);
            string currentPath = System.IO.Path.GetTempPath();
            string filepath = @"Attachments\" + attach.FileName;
            if (!Directory.Exists(currentPath + "Attachments"))
            {
                Directory.CreateDirectory(Path.Combine(currentPath, "Attachments"));
            }
            filepath = currentPath + filepath;
            Constants.FilePath = filepath;
            attach.SaveAsFile(filepath);
            brWorkerProgressbar.ReportProgress(50);
            System.Windows.Forms.Application.DoEvents();
            byte[] bytes = File.ReadAllBytes(filepath);
            brWorkerProgressbar.ReportProgress(60);
            UploadResult = UploadMultipart(bytes, attach.FileName, "application/octet-stream", Configuration.ApplicationAPI + "resume/documentupload");

            if (!System.String.IsNullOrWhiteSpace(UploadResult))
            {

                //Configuration.parseResumeData(UploadResult);
                //System.Diagnostics.Process.Start(Configuration.ApplicatonResumeURL + UploadResult);
                brWorkerProgressbar.ReportProgress(70);
                System.Windows.Forms.Application.DoEvents();
                brWorkerProgressbar.ReportProgress(75);
                loadSelections(UploadResult,ref worker, e);

            }
            else
            {
                brWorkerProgressbar.ReportProgress(100);
                System.Windows.Forms.MessageBox.Show("Unable to parse attachment");
                //this.Close(); this.Dispose();
                e.Cancel = true;

            } 
        }

        public string UploadMultipart(byte[] file, string filename, string contentType, string url)
        {
            string ResposeResult = string.Empty;
            try
            {
                var webClient = new WebClient();
                string boundary = "------------------------" + DateTime.Now.Ticks.ToString("x");
                webClient.Headers.Add("Authorization: bearer " + Configuration.access_token);
                webClient.Headers.Add("Content-Type", "multipart/form-data; boundary=" + boundary);
                var fileData = webClient.Encoding.GetString(file);
                var package = string.Format("--{0}\r\nContent-Disposition: form-data; name=\"file\"; filename=\"{1}\"\r\nContent-Type: {2}\r\n\r\n{3}\r\n--{0}--\r\n", boundary, filename, "application/octet-stream", fileData);

                var nfile = webClient.Encoding.GetBytes(package);
                byte[] resp = webClient.UploadData(url, "POST", nfile);
                ResposeResult = System.Text.Encoding.UTF8.GetString(resp);
                Regex rgx = new Regex("[^a-zA-Z0-9 -]");
                ResposeResult = rgx.Replace(ResposeResult, "");
                brWorkerProgressbar.ReportProgress(65);

            }
            catch (System.Exception ex)
            {
                Log.LogData("Error in upload attachmnt" + ex.Message + ex.StackTrace, Log.Status.Error);
                return "";
            }
            return ResposeResult;
        }

        public void loadSelections(string resumeUploadKey,ref BackgroundWorker worker, DoWorkEventArgs e)
        {

            brWorkerProgressbar.ReportProgress(80);
            var request = (HttpWebRequest)WebRequest.Create(Configuration.ApplicationAPI + "user/design?module=resume&style=form&designtype=create");

            request.Method = "GET";
            request.ContentType = "application/x-www-form-urlencoded";
            request.Headers.Add("Authorization: bearer " + Configuration.access_token);

            brWorkerProgressbar.ReportProgress(85); 
            try
            {
                HttpWebResponse response = (HttpWebResponse)request.GetResponse();
                var responseString = new StreamReader(response.GetResponseStream()).ReadToEnd();

                brWorkerProgressbar.ReportProgress(90); 
                try
                {
                    designlayout = JsonConvert.DeserializeObject<List<FormDesignLayout>>(responseString);
                    if (designlayout.Count > 0)
                    {
                        brWorkerProgressbar.ReportProgress(100);
                        System.Windows.Forms.Application.DoEvents();
                    }

                }
                catch (System.Exception ex)
                {
                    Log.LogData("Error in frmLogin: Registry value: " + ex.Message + ex.StackTrace, Log.Status.Error);
                }
            }
            catch (WebException ex)
            {
                Log.LogData("Error in Load Selection: " + ex.Message + ex.StackTrace, Log.Status.Error);
            }
        }

        private void opSetProgressBar(object sender, EventArgs e)
        {
            if (bflg == false)
            {
                bflg = true;
                opCallEventMethod.Invoke();
            }
        }

        private void frmProgressBar_Load(object sender, EventArgs e)
        {
            //prgBar.Minimum = 0;
            //Timer t = new Timer();
            //t.Interval = 1000;
            //t.Enabled = true;
            //t.Tick += new System.EventHandler(this.opSetProgressBar);
        }
    }
}
