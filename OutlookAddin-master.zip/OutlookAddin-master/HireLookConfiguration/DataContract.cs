﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace HireLook
{
    public class ResposeData
    {
        public Int64 RID { get; set; }
        public string Code { get; set; }
        public string Message { get; set; }
        public string MessageDetails { get; set; }
    }

    public sealed class HCResponse
    {
        public Int64 Id { get; set; }
        public Int64 RID { get; set; }
        public string Code { get; set; }
        public string Message { get; set; }
        public List<MessageDetail> MessageDetails { get; set; }
    }

    public sealed class MessageDetail
    {
        public string Field { get; set; }
        public string Message { get; set; }
    }

}
