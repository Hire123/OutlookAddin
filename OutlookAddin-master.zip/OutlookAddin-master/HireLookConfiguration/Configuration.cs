﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using Microsoft.Win32;
using System.IO;
using System.Net;
using Newtonsoft.Json;
using System.Text.RegularExpressions;
using Newtonsoft.Json.Linq;
namespace HireLook
{
    public static class Configuration
    {
        public static Boolean isLogin = false;
        public static string access_token = string.Empty;
        public static string client_id = string.Empty;
        public static string refresh_token = string.Empty;
        public static string token_type = string.Empty;
        public static string userName = string.Empty;
        public static string RID = "0";
        public static string registryName = @"SOFTWARE\HireLook\HireLookConfig";
        public static string ApplicatonResumeURL = Convert.ToString(ConfigurationManager.AppSettings["ApplicationResumeURL"]);
        public static string ApplicationAPI = Convert.ToString(ConfigurationManager.AppSettings["ApplicatonAPI"]);
        public static List<string> Allowed_Doc_Extention = null;
        
        public static void LoadRegValues()
        {
            RegistryKey myregistry = Registry.CurrentUser.OpenSubKey(registryName);
            if (myregistry != null)
            {
                try
                {
                    //Constants.ApplicatonResumeURL = Convert.ToString(ConfigurationManager.AppSettings["ApplicationResumeURL"]);
                    //Constants.ApplicationAPI = Convert.ToString(ConfigurationManager.AppSettings["ApplicatonAPI"]);
                    if (!System.String.IsNullOrWhiteSpace((string)(myregistry.GetValue("access_token"))) && !System.String.IsNullOrWhiteSpace((string)(myregistry.GetValue("refresh_token"))) && !System.String.IsNullOrWhiteSpace((string)(myregistry.GetValue("RID"))) && !System.String.IsNullOrWhiteSpace((string)(myregistry.GetValue("token_type"))) && !System.String.IsNullOrWhiteSpace((string)(myregistry.GetValue("userName"))))
                    {
                        Configuration.isLogin = true;
                        Configuration.access_token = (string)myregistry.GetValue("access_token");
                        Configuration.client_id = (string)myregistry.GetValue("client_id");
                        Configuration.refresh_token = (string)myregistry.GetValue("refresh_token");
                        Configuration.RID = (string)myregistry.GetValue("RID");
                        Configuration.token_type = (string)myregistry.GetValue("token_type");
                        Configuration.userName = (string)myregistry.GetValue("userName");

                    }
                    else
                        Configuration.isLogin = false;
                }
                catch (Exception ex)
                {
                    Configuration.isLogin = false;
                    Log.LogData("Error in LoadRegValues: " + ex.Message + ex.StackTrace, Log.Status.Error);
                }
            }
            try
            {
                if (!string.IsNullOrWhiteSpace(Convert.ToString(ConfigurationManager.AppSettings["Allowed_Doc_Extention"])))
                {
                    //Chetan C17Sep13:Allowed extentions to be parsed as Resume Document.
                    Allowed_Doc_Extention = new List<string>(Convert.ToString(ConfigurationManager.AppSettings["Allowed_Doc_Extention"]).Split(new string[] { "," }, StringSplitOptions.RemoveEmptyEntries));

                    //Chetan C17Sep13:Need to prefix all list items with dot and trim and to lower case.
                    Allowed_Doc_Extention = Allowed_Doc_Extention.Select(item => { item = "." + item.Trim().ToLower(); return item; }).ToList();
                }
                else
                {
                    Allowed_Doc_Extention = new List<string>();
                    Allowed_Doc_Extention.Add(".doc");
                    Allowed_Doc_Extention.Add(".docx");
                    Allowed_Doc_Extention.Add(".txt");
                    Allowed_Doc_Extention.Add(".rtf");
                    Allowed_Doc_Extention.Add(".htm");
                    Allowed_Doc_Extention.Add(".html");
                    Allowed_Doc_Extention.Add(".pdf");
                }
            
            
            }
            catch { }
        }

        public static bool RemoveRegValues()
        {
            using (RegistryKey key = Registry.CurrentUser.OpenSubKey(registryName, true))
            {
                if (key != null)
                {
                    try
                    {
                        Configuration.isLogin = false;
                        key.SetValue("access_token", string.Empty);
                        key.SetValue("refresh_token", string.Empty);
                        key.SetValue("RID", string.Empty);
                        key.SetValue("token_type", string.Empty);
                        key.SetValue("userName", string.Empty);
                        Configuration.access_token = string.Empty;
                        Configuration.client_id = string.Empty;
                        Configuration.refresh_token = string.Empty;
                        Configuration.RID = string.Empty;
                        Configuration.token_type = string.Empty;
                        Configuration.userName = string.Empty;
                        return true;
                    }
                    catch (Exception ex)
                    {
                        Configuration.isLogin = true;
                        Log.LogData("Error in RemoveRegValues: " + ex.Message + ex.StackTrace, Log.Status.Error);
                        return false;
                    }

                }
                else
                    return false;
            }

        }

        public static bool OPRefreshToken()
        {
            var request = (HttpWebRequest)WebRequest.Create(Configuration.ApplicationAPI + "token");
            var postData = "refresh_token=" + Configuration.refresh_token + "&grant_type=refresh_token&Client_id=hMTc57B";
            var data = Encoding.ASCII.GetBytes(postData);
            request.Method = "POST";
            request.ContentType = "application/x-www-form-urlencoded";
            request.ContentLength = data.Length;
            request.Headers.Add("Authorization: Bearer " + Configuration.access_token);
            try
            {
                using (var stream = request.GetRequestStream())
                {
                    stream.Write(data, 0, data.Length);
                }

                try
                {
                    HttpWebResponse response = (HttpWebResponse)request.GetResponse();
                    var responseString = new StreamReader(response.GetResponseStream()).ReadToEnd();
                    var values = JsonConvert.DeserializeObject<Dictionary<string, string>>(responseString);

                    try
                    {
                        foreach (var value in values)
                        {
                            RegistryKey key = Registry.CurrentUser.CreateSubKey(Configuration.registryName);
                            if (value.Key == "RID" || value.Key == "access_token" || value.Key == "token_type" || value.Key == "refresh_token" || value.Key == "as:client_id" || value.Key == "userName")
                                key.SetValue(value.Key, value.Value);
                            key.Close();
                        }
                        Configuration.LoadRegValues();
                        return true;
                    }
                    catch (Exception ex)
                    {
                        Log.LogData("Error in frmLogin: Registry value: " + ex.Message + ex.StackTrace, Log.Status.Error);
                        return false;
                    }

                }
                catch (WebException ex)
                {
                    Log.LogData("Error in Refresh token respose: " + ex.Message + ex.StackTrace, Log.Status.Error);
                    return false;
                }
            }
            catch (Exception ex)
            {
                Log.LogData("Error in Refresh Method Connection" + ex.Message + ex.StackTrace, Log.Status.Error);
                return false;
            }

        }

        public static dynamic parseResumeData(String resumeId, int sectionNO)
        {
            dynamic data = null;
            IDictionary<string, object> ResumeDictionary = new Dictionary<string, object>();
            resumeId = Regex.Replace(resumeId, @"\\", "");
            var request = (HttpWebRequest)WebRequest.Create(Configuration.ApplicationAPI + "resume/parsing?key=" + resumeId + "&SectionId=" + sectionNO);
            request.Method = "GET";
            request.ContentType = "application/x-www-form-urlencoded";
            request.Headers.Add("Authorization: bearer " + Configuration.access_token);
            // webClient.Headers.Add("Content-Type", "application/json");

            try
            {
                List<KeyValuePair<string, object>> ResumeData1 = new List<KeyValuePair<string, object>>();

                HttpWebResponse response = (HttpWebResponse)request.GetResponse();
                var responseString = new StreamReader(response.GetResponseStream()).ReadToEnd();
                try
                {
                    if (!string.IsNullOrWhiteSpace(responseString))
                    {
                        JObject httpResponseData = JObject.Parse(responseString);

                        var secValue = httpResponseData["Resume"].ToString();
                        data = JsonConvert.DeserializeObject(secValue.ToString(), typeof(Dictionary<string, object>));
                        // ResumeDictionary = secValue.Select(result => JsonConvert.DeserializeObject<Dictionary<string, object>>(result.ToString())).ToList();
                    }
                }
                catch (System.Exception ex)
                {
                    Log.LogData("Error in parsing ResumeData" + ex.Message, Log.Status.Error);
                }
            }
            catch (WebException ex)
            {
                Log.LogData("Invalid Username/Password: " + ex.Message + ex.StackTrace, Log.Status.Error); 
            }
            return data;
        }
    }
}
