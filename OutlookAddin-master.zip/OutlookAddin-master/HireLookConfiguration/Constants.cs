﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HireLook
{
    public static class Constants
    {
        public static string ResumeKey;
        public static Int64 ResumeId;
        public static string FilePath = string.Empty;
    }
}
