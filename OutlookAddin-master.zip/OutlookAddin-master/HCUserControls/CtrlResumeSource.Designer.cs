﻿namespace HCUserControls
{
    partial class CtrlResumeSource
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.cmbSourceName = new System.Windows.Forms.ComboBox();
            this.lblsrcName = new System.Windows.Forms.Label();
            this.lblSrcGroup = new System.Windows.Forms.Label();
            this.cmbSrcUser = new System.Windows.Forms.ComboBox();
            this.lblSrcUser = new System.Windows.Forms.Label();
            this.txtSrcGroup = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // cmbSourceName
            // 
            this.cmbSourceName.FormattingEnabled = true;
            this.cmbSourceName.Location = new System.Drawing.Point(96, 3);
            this.cmbSourceName.Margin = new System.Windows.Forms.Padding(2);
            this.cmbSourceName.Name = "cmbSourceName";
            this.cmbSourceName.Size = new System.Drawing.Size(147, 21);
            this.cmbSourceName.TabIndex = 38;
            this.cmbSourceName.TextUpdate += new System.EventHandler(this.cmbSourceName_TextUpdate);
            this.cmbSourceName.DropDownClosed += new System.EventHandler(this.cmbSourceName_DropDownClosed);
            // 
            // lblsrcName
            // 
            this.lblsrcName.AutoSize = true;
            this.lblsrcName.Location = new System.Drawing.Point(9, 5);
            this.lblsrcName.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblsrcName.Name = "lblsrcName";
            this.lblsrcName.Size = new System.Drawing.Size(83, 15);
            this.lblsrcName.TabIndex = 37;
            this.lblsrcName.Text = "Source Name";
            // 
            // lblSrcGroup
            // 
            this.lblSrcGroup.AutoSize = true;
            this.lblSrcGroup.Location = new System.Drawing.Point(9, 29);
            this.lblSrcGroup.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblSrcGroup.Name = "lblSrcGroup";
            this.lblSrcGroup.Size = new System.Drawing.Size(83, 15);
            this.lblSrcGroup.TabIndex = 39;
            this.lblSrcGroup.Text = "Source Group";
            // 
            // cmbSrcUser
            // 
            this.cmbSrcUser.FormattingEnabled = true;
            this.cmbSrcUser.Location = new System.Drawing.Point(96, 52);
            this.cmbSrcUser.Margin = new System.Windows.Forms.Padding(2);
            this.cmbSrcUser.Name = "cmbSrcUser";
            this.cmbSrcUser.Size = new System.Drawing.Size(147, 21);
            this.cmbSrcUser.TabIndex = 42;
            this.cmbSrcUser.TextUpdate += new System.EventHandler(this.cmbSrcUser_TextUpdate);
            // 
            // lblSrcUser
            // 
            this.lblSrcUser.AutoSize = true;
            this.lblSrcUser.Location = new System.Drawing.Point(17, 54);
            this.lblSrcUser.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblSrcUser.Name = "lblSrcUser";
            this.lblSrcUser.Size = new System.Drawing.Size(75, 15);
            this.lblSrcUser.TabIndex = 41;
            this.lblSrcUser.Text = "Source User";
            // 
            // txtSrcGroup
            // 
            this.txtSrcGroup.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.txtSrcGroup.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txtSrcGroup.Location = new System.Drawing.Point(96, 29);
            this.txtSrcGroup.Margin = new System.Windows.Forms.Padding(2);
            this.txtSrcGroup.Name = "txtSrcGroup";
            this.txtSrcGroup.Size = new System.Drawing.Size(147, 20);
            this.txtSrcGroup.TabIndex = 49;
            // 
            // CtrlResumeSource
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.txtSrcGroup);
            this.Controls.Add(this.cmbSrcUser);
            this.Controls.Add(this.lblSrcUser);
            this.Controls.Add(this.lblSrcGroup);
            this.Controls.Add(this.cmbSourceName);
            this.Controls.Add(this.lblsrcName);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "CtrlResumeSource";
            this.Size = new System.Drawing.Size(254, 76);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox cmbSourceName;
        private System.Windows.Forms.Label lblsrcName;
        private System.Windows.Forms.Label lblSrcGroup;
        private System.Windows.Forms.ComboBox cmbSrcUser;
        private System.Windows.Forms.Label lblSrcUser;
        private System.Windows.Forms.TextBox txtSrcGroup;
    }
}
