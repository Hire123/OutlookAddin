﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using HireLook;
using System.Drawing.Text;
using System.Text.RegularExpressions;
using System.Globalization;
namespace HCUserControls
{
    public partial class CtrlTextBox : UserControl
    {
        public ControlDetail controls = new ControlDetail();
        public Color DefaultBorderColor { get; set; }
        public Color FocusedBorderColor { get; set; }

        public CtrlTextBox()
        {
            InitializeComponent();
        }

        public CtrlTextBox(ControlDetail controls)
        {
            InitializeComponent();
            this.controls = controls;
            if (controls.Mandatory)
            {
                lblName.Text = "*" + this.controls.DisplayName;
                opSetMandatory();
            }
            else
                lblName.Text = this.controls.DisplayName;
        }

        public String getTextBoxValue()
        {
            return txtTextBox.Text;
        }

        public void setTextBoxValue(string text)
        {
            txtTextBox.Text = text;
        }

        public Boolean opValidate()
        {
            if (controls.Mandatory)
            {
                if (txtTextBox.Text.Trim() == string.Empty)
                {
                    txtTextBox.Focus();
                    //txtTextBox.Border
                    return false;
                }
                else if (controls.ControlType.ToLower() == "hcemail")
                {
                    if (!opValidateEmail(txtTextBox.Text.Trim())){
                        txtTextBox.Focus();
                        return false;
                    }
                    else
                        return true;
                }
                else
                    return true;
            }
            else
                return true;
        }

        void opSetMandatory()
        {
            lblName.ForeColor = System.Drawing.Color.Red;
        }
        bool opValidateEmail(string email)
        {
            bool isEmail = Regex.IsMatch(email, @"\A(?:[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?)\Z", RegexOptions.IgnoreCase);
            return isEmail;
        }
    }
}
