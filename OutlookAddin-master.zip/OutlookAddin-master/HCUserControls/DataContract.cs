﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace HCUserControls
{

    public class Resumes
    {
        public ResumeBank Resume { get; set; }
    }

    public class ResumeBank
    {
        public string CurrentCompany { get; set; }
        public string Designation { get; set; }
        public string DOB { get; set; }
        public string EmailID { get; set; }
        public decimal ExpectedCTC { get; set; }
        public string ExpectedCurrency { get; set; }
        public long ExpectedCurrencyID { get; set; }
        public decimal ExpectedHike { get; set; }
        public string ExpectedScale { get; set; }
        public long ExpectedScaleID { get; set; }
        public string ExpLevel { get; set; }
        public string FirstName { get; set; }
        public string Functions { get; set; }
        public string HotNotes { get; set; }
        public bool IsFresher { get; set; }
        public string LastName { get; set; }
        public string Location { get; set; }
        public string MiddleName { get; set; }
        public string MobileNo { get; set; }
        public string Name { get; set; }
        public string Notes { get; set; }
        public short NoticePeriod { get; set; }
        public string Photo { get; set; }
        public decimal PresentCTC { get; set; }
        public string PresentCurrency { get; set; }
        public long PresentCurrencyID { get; set; }
        public string PresentScale { get; set; }
        public long PresentScaleID { get; set; }
        public decimal RelevantExp { get; set; }
        public string ResStatus { get; set; }
        public short ResStatusID { get; set; }
        public string ResSummary { get; set; }
        public string ResType { get; set; }
        public short ResTypeID { get; set; }
        public long RID { get; set; }
        public string Salutation { get; set; }
        public long SalutationId { get; set; }
        public string Skills { get; set; }
        public string Source { get; set; }
        public string SourceEmailId { get; set; }
        public string SourceGroup { get; set; }
        public long SourceGroupID { get; set; }
        public long SourceID { get; set; }
        public string SourceUser { get; set; }
        public long SourceUserID { get; set; }
        public bool Status { get; set; }
        public string SubFunctions { get; set; }
        public long TID { get; set; }
        public decimal TotalExp { get; set; }
    }

    public class ControlDetail
    {
        public long ControlID { get; set; }
        public string ControlType { get; set; }
        public string DataField { get; set; }
        public string DataToLoad { get; set; }
        public bool DefaultValue { get; set; }
        public string DisplayName { get; set; }
        public string ErrorMessage { get; set; }
        public string FieldName { get; set; }
        public bool IsReadOnly { get; set; }
        public bool Mandatory { get; set; }
        public short MaxLength { get; set; }
        public short MinLength { get; set; }
        public string NGModelName { get; set; }
        public string PlaceholderText { get; set; }
        public string SelectMode { get; set; }
        public short Sequence { get; set; }
    }

    public class TemplateAttachment
    {
        public long AttachmentID { get; set; }
        public byte[] FileDa { get; set; }
        public string FileData { get; set; }
        public string FileName { get; set; }
        public long FileSize { get; set; }
        public short FileType { get; set; }
        public long TemplateId { get; set; }
    }

    public class StateNameSearch
    {
        public string Country { get; set; }
        public long CountryID { get; set; }
        public long RID { get; set; }
        public string Title { get; set; }
    }
    public class UserAddress
    {
        public string Addressline1 { get; set; }
        public string Addressline2 { get; set; }
        public string AddressType { get; set; }
        public long AddressTypeID { get; set; }
        public string City { get; set; }
        public string Country { get; set; }
        public long CountryID { get; set; }
        public string District { get; set; }
        public decimal Latitude { get; set; }
        public decimal Longitude { get; set; }
        public int Pincode { get; set; }
        public long RID { get; set; }
        public string State { get; set; }
        public long StateID { get; set; }
        public long UserID { get; set; }
        public string UserName { get; set; }
    }

    public class NameSearch
    {
        public long RID { get; set; }
        public string Title { get; set; }
    }
    public class Resume
    {
        public string FileName { get; set; }
        public string FileType { get; set; }
    }


    public class ResumeEducation
    {
        public string Education { get; set; }
        public long EducationID { get; set; }
        public string FromDate { get; set; }
        public bool GapInEdu { get; set; }
        public string Grade { get; set; }
        public string Institute { get; set; }
        public long InstituteID { get; set; }
        public string InstituteName { get; set; }
        public string Notes { get; set; }
        public long ResumeID { get; set; }
        public string Specialization { get; set; }
        public long SpecializationID { get; set; }
        public string ToDate { get; set; }
        public long UniversityID { get; set; }
        public string UniversityName { get; set; }
        public int Year { get; set; }
    }

    public class ResumeEmployerDetails
    {
        public bool CurrentEmpStatus { get; set; }
        public long DesignationID { get; set; }
        public string DesignationText { get; set; }
        public string Employer { get; set; }
        public long EmployerID { get; set; }
        public string Enddate { get; set; }
        public string Notes { get; set; }
        public long ResumeID { get; set; }
        public short SequenceNo { get; set; }
        public string StartDate { get; set; }
    }

    public class ResumeSkills
    {
        public bool Active { get; set; }
        public decimal Experience { get; set; }
        public int LastUsedYear { get; set; }
        public short NoofAssignment { get; set; }
        public string Proficiency { get; set; }
        public long ProficiencyId { get; set; }
        public long ResId { get; set; }
        public long RID { get; set; }
        public string Skill { get; set; }
        public long SkillId { get; set; }
    }

    public class ResumeSourceNameSearch
    {
        public long RID { get; set; }
        public string SourceGroup { get; set; }
        public long SourceGroupID { get; set; }
        public string Title { get; set; }
    }

    public class GetUserName
    {
        public string Name { get; set; }
        public long RID { get; set; }
    }
}
