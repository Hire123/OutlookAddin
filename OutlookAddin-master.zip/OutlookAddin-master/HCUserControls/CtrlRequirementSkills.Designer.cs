﻿namespace HCUserControls
{
    partial class CtrlRequirementSkills
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.ReqCrtlPanel = new System.Windows.Forms.Panel();
            this.cmbSkill = new System.Windows.Forms.ComboBox();
            this.btnADDSkill = new System.Windows.Forms.Button();
            this.txtNoOfAssignment = new System.Windows.Forms.TextBox();
            this.cmbLastUserYear = new System.Windows.Forms.ComboBox();
            this.chkCurrentStatus = new System.Windows.Forms.CheckBox();
            this.nmbToExperience = new System.Windows.Forms.NumericUpDown();
            this.nmbFromExperience = new System.Windows.Forms.NumericUpDown();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.cmbToProficiency = new System.Windows.Forms.ComboBox();
            this.cmbFromProficiency = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.lblSkills = new System.Windows.Forms.Label();
            this.ReqCrtlPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nmbToExperience)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nmbFromExperience)).BeginInit();
            this.SuspendLayout();
            // 
            // ReqCrtlPanel
            // 
            this.ReqCrtlPanel.Controls.Add(this.cmbSkill);
            this.ReqCrtlPanel.Controls.Add(this.btnADDSkill);
            this.ReqCrtlPanel.Controls.Add(this.txtNoOfAssignment);
            this.ReqCrtlPanel.Controls.Add(this.cmbLastUserYear);
            this.ReqCrtlPanel.Controls.Add(this.chkCurrentStatus);
            this.ReqCrtlPanel.Controls.Add(this.nmbToExperience);
            this.ReqCrtlPanel.Controls.Add(this.nmbFromExperience);
            this.ReqCrtlPanel.Controls.Add(this.label9);
            this.ReqCrtlPanel.Controls.Add(this.label8);
            this.ReqCrtlPanel.Controls.Add(this.label7);
            this.ReqCrtlPanel.Controls.Add(this.cmbToProficiency);
            this.ReqCrtlPanel.Controls.Add(this.cmbFromProficiency);
            this.ReqCrtlPanel.Controls.Add(this.label6);
            this.ReqCrtlPanel.Controls.Add(this.label5);
            this.ReqCrtlPanel.Controls.Add(this.label4);
            this.ReqCrtlPanel.Controls.Add(this.label3);
            this.ReqCrtlPanel.Controls.Add(this.label2);
            this.ReqCrtlPanel.Controls.Add(this.label1);
            this.ReqCrtlPanel.Controls.Add(this.lblSkills);
            this.ReqCrtlPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.ReqCrtlPanel.Location = new System.Drawing.Point(0, 0);
            this.ReqCrtlPanel.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.ReqCrtlPanel.Name = "ReqCrtlPanel";
            this.ReqCrtlPanel.Size = new System.Drawing.Size(537, 270);
            this.ReqCrtlPanel.TabIndex = 0;
            // 
            // cmbSkill
            // 
            this.cmbSkill.FormattingEnabled = true;
            this.cmbSkill.Location = new System.Drawing.Point(164, 9);
            this.cmbSkill.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.cmbSkill.Name = "cmbSkill";
            this.cmbSkill.Size = new System.Drawing.Size(195, 24);
            this.cmbSkill.TabIndex = 38;
            // 
            // btnADDSkill
            // 
            this.btnADDSkill.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnADDSkill.Location = new System.Drawing.Point(164, 210);
            this.btnADDSkill.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnADDSkill.Name = "btnADDSkill";
            this.btnADDSkill.Size = new System.Drawing.Size(97, 31);
            this.btnADDSkill.TabIndex = 18;
            this.btnADDSkill.Text = "Add Skills";
            this.btnADDSkill.UseVisualStyleBackColor = true;
            this.btnADDSkill.Click += new System.EventHandler(this.btnADDSkill_Click);
            // 
            // txtNoOfAssignment
            // 
            this.txtNoOfAssignment.Location = new System.Drawing.Point(164, 143);
            this.txtNoOfAssignment.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtNoOfAssignment.Name = "txtNoOfAssignment";
            this.txtNoOfAssignment.Size = new System.Drawing.Size(195, 22);
            this.txtNoOfAssignment.TabIndex = 17;
            // 
            // cmbLastUserYear
            // 
            this.cmbLastUserYear.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbLastUserYear.FormattingEnabled = true;
            this.cmbLastUserYear.Location = new System.Drawing.Point(164, 176);
            this.cmbLastUserYear.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.cmbLastUserYear.Name = "cmbLastUserYear";
            this.cmbLastUserYear.Size = new System.Drawing.Size(195, 24);
            this.cmbLastUserYear.TabIndex = 16;
            // 
            // chkCurrentStatus
            // 
            this.chkCurrentStatus.AutoSize = true;
            this.chkCurrentStatus.Location = new System.Drawing.Point(164, 113);
            this.chkCurrentStatus.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.chkCurrentStatus.Name = "chkCurrentStatus";
            this.chkCurrentStatus.Size = new System.Drawing.Size(18, 17);
            this.chkCurrentStatus.TabIndex = 15;
            this.chkCurrentStatus.UseVisualStyleBackColor = true;
            // 
            // nmbToExperience
            // 
            this.nmbToExperience.Location = new System.Drawing.Point(373, 78);
            this.nmbToExperience.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.nmbToExperience.Name = "nmbToExperience";
            this.nmbToExperience.Size = new System.Drawing.Size(120, 22);
            this.nmbToExperience.TabIndex = 14;
            // 
            // nmbFromExperience
            // 
            this.nmbFromExperience.Location = new System.Drawing.Point(215, 78);
            this.nmbFromExperience.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.nmbFromExperience.Name = "nmbFromExperience";
            this.nmbFromExperience.Size = new System.Drawing.Size(120, 22);
            this.nmbFromExperience.TabIndex = 13;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(339, 78);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(25, 17);
            this.label9.TabIndex = 12;
            this.label9.Text = "To";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(164, 78);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(40, 17);
            this.label8.TabIndex = 11;
            this.label8.Text = "From";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(339, 47);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(25, 17);
            this.label7.TabIndex = 10;
            this.label7.Text = "To";
            // 
            // cmbToProficiency
            // 
            this.cmbToProficiency.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbToProficiency.FormattingEnabled = true;
            this.cmbToProficiency.Location = new System.Drawing.Point(373, 44);
            this.cmbToProficiency.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.cmbToProficiency.Name = "cmbToProficiency";
            this.cmbToProficiency.Size = new System.Drawing.Size(121, 24);
            this.cmbToProficiency.TabIndex = 9;
            // 
            // cmbFromProficiency
            // 
            this.cmbFromProficiency.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbFromProficiency.FormattingEnabled = true;
            this.cmbFromProficiency.Location = new System.Drawing.Point(215, 44);
            this.cmbFromProficiency.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.cmbFromProficiency.Name = "cmbFromProficiency";
            this.cmbFromProficiency.Size = new System.Drawing.Size(121, 24);
            this.cmbFromProficiency.TabIndex = 8;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(31, 176);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(102, 17);
            this.label6.TabIndex = 7;
            this.label6.Text = "Last used year";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(4, 146);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(122, 17);
            this.label5.TabIndex = 6;
            this.label5.Text = "No. of assignment";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(33, 112);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(99, 17);
            this.label4.TabIndex = 5;
            this.label4.Text = "Current Status";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(53, 78);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(78, 17);
            this.label3.TabIndex = 4;
            this.label3.Text = "Experience";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(164, 44);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(40, 17);
            this.label2.TabIndex = 3;
            this.label2.Text = "From";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(57, 44);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(77, 17);
            this.label1.TabIndex = 2;
            this.label1.Text = "Proficiency";
            // 
            // lblSkills
            // 
            this.lblSkills.AutoSize = true;
            this.lblSkills.Location = new System.Drawing.Point(97, 16);
            this.lblSkills.Name = "lblSkills";
            this.lblSkills.Size = new System.Drawing.Size(40, 17);
            this.lblSkills.TabIndex = 0;
            this.lblSkills.Text = "Skills";
            // 
            // CtrlRequirementSkills
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.ReqCrtlPanel);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "CtrlRequirementSkills";
            this.Size = new System.Drawing.Size(537, 270);
            this.ReqCrtlPanel.ResumeLayout(false);
            this.ReqCrtlPanel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nmbToExperience)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nmbFromExperience)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel ReqCrtlPanel;
        private System.Windows.Forms.Label lblSkills;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.ComboBox cmbToProficiency;
        private System.Windows.Forms.ComboBox cmbFromProficiency;
        private System.Windows.Forms.NumericUpDown nmbToExperience;
        private System.Windows.Forms.NumericUpDown nmbFromExperience;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.CheckBox chkCurrentStatus;
        private System.Windows.Forms.ComboBox cmbLastUserYear;
        private System.Windows.Forms.TextBox txtNoOfAssignment;
        private System.Windows.Forms.Button btnADDSkill;
        private System.Windows.Forms.ComboBox cmbSkill;
    }
}
