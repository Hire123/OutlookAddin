﻿namespace HCUserControls
{
    partial class CtrlExperienceSelector
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.nbrYear = new System.Windows.Forms.NumericUpDown();
            this.lblTotalExperience = new System.Windows.Forms.Label();
            this.nbrMonth = new System.Windows.Forms.NumericUpDown();
            this.lblMonth = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.nbrYear)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nbrMonth)).BeginInit();
            this.SuspendLayout();
            // 
            // nbrYear
            // 
            this.nbrYear.Location = new System.Drawing.Point(103, 2);
            this.nbrYear.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.nbrYear.Name = "nbrYear";
            this.nbrYear.Size = new System.Drawing.Size(74, 20);
            this.nbrYear.TabIndex = 5;
            // 
            // lblTotalExperience
            // 
            this.lblTotalExperience.AutoSize = true;
            this.lblTotalExperience.Location = new System.Drawing.Point(2, 4);
            this.lblTotalExperience.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblTotalExperience.Name = "lblTotalExperience";
            this.lblTotalExperience.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.lblTotalExperience.Size = new System.Drawing.Size(99, 15);
            this.lblTotalExperience.TabIndex = 4;
            this.lblTotalExperience.Text = "Total Experience";
            this.lblTotalExperience.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // nbrMonth
            // 
            this.nbrMonth.Location = new System.Drawing.Point(214, 2);
            this.nbrMonth.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.nbrMonth.Name = "nbrMonth";
            this.nbrMonth.Size = new System.Drawing.Size(74, 20);
            this.nbrMonth.TabIndex = 7;
            // 
            // lblMonth
            // 
            this.lblMonth.AutoSize = true;
            this.lblMonth.Location = new System.Drawing.Point(290, 4);
            this.lblMonth.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lblMonth.Name = "lblMonth";
            this.lblMonth.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.lblMonth.Size = new System.Drawing.Size(42, 15);
            this.lblMonth.TabIndex = 6;
            this.lblMonth.Text = "Month";
            this.lblMonth.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(180, 4);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.label2.Size = new System.Drawing.Size(32, 15);
            this.label2.TabIndex = 8;
            this.label2.Text = "Year";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // CtrlExperienceSelector
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.label2);
            this.Controls.Add(this.nbrMonth);
            this.Controls.Add(this.lblMonth);
            this.Controls.Add(this.nbrYear);
            this.Controls.Add(this.lblTotalExperience);
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "CtrlExperienceSelector";
            this.Size = new System.Drawing.Size(340, 26);
            ((System.ComponentModel.ISupportInitialize)(this.nbrYear)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nbrMonth)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.NumericUpDown nbrYear;
        private System.Windows.Forms.Label lblTotalExperience;
        private System.Windows.Forms.NumericUpDown nbrMonth;
        private System.Windows.Forms.Label lblMonth;
        private System.Windows.Forms.Label label2;
    }
}
