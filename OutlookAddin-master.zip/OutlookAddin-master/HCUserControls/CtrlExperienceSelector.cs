﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using HireLook;
namespace HCUserControls
{
    public partial class CtrlExperienceSelector : UserControl
    {
        public ControlDetail controls = new ControlDetail();
        public CtrlExperienceSelector()
        {
            InitializeComponent();
        }
        public CtrlExperienceSelector(ControlDetail controls)
        {
            InitializeComponent();
            this.controls = controls;
            if (this.controls.Mandatory)
            {
                lblTotalExperience.Text = "*" + controls.DisplayName;
                opSetMandatory();
            }
            else
            {
                lblTotalExperience.Text = controls.DisplayName;
            }

        }

        public decimal getExperience()
        {
            decimal exp = nbrYear.Value + (nbrMonth.Value / 10);
            return exp;
        }

        void opSetMandatory()
        {
            lblTotalExperience.ForeColor = System.Drawing.Color.Red;
            lblTotalExperience.Text = lblTotalExperience.Text + "*";
        }

        Boolean opValidate()
        {
            if (Convert.ToString(nbrMonth.Value) == "")
            {
                nbrMonth.Focus();
                return false;
            }
            else if (Convert.ToString(nbrYear.Value) == "")
            {
                nbrYear.Focus();
                return false;
            }

            return true;
        }

    }
}
