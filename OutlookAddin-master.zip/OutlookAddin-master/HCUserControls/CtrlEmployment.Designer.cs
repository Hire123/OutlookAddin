﻿namespace HCUserControls
{
    partial class CtrlEmployment
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.cmbEmployeStatus = new System.Windows.Forms.ComboBox();
            this.lblEmploymentStatus = new System.Windows.Forms.Label();
            this.txtEmployeeName = new System.Windows.Forms.TextBox();
            this.lblEmployeeName = new System.Windows.Forms.Label();
            this.dtStartDate = new System.Windows.Forms.DateTimePicker();
            this.lblName = new System.Windows.Forms.Label();
            this.dtEndDate = new System.Windows.Forms.DateTimePicker();
            this.label1 = new System.Windows.Forms.Label();
            this.cmbRole = new System.Windows.Forms.ComboBox();
            this.lblRole = new System.Windows.Forms.Label();
            this.txtNotes = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.btnADDSkill = new System.Windows.Forms.Button();
            this.gridEmployment = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.gridEmployment)).BeginInit();
            this.SuspendLayout();
            // 
            // cmbEmployeStatus
            // 
            this.cmbEmployeStatus.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbEmployeStatus.FormattingEnabled = true;
            this.cmbEmployeStatus.Location = new System.Drawing.Point(171, 9);
            this.cmbEmployeStatus.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.cmbEmployeStatus.Name = "cmbEmployeStatus";
            this.cmbEmployeStatus.Size = new System.Drawing.Size(200, 24);
            this.cmbEmployeStatus.TabIndex = 13;
            // 
            // lblEmploymentStatus
            // 
            this.lblEmploymentStatus.AutoSize = true;
            this.lblEmploymentStatus.Location = new System.Drawing.Point(15, 12);
            this.lblEmploymentStatus.Name = "lblEmploymentStatus";
            this.lblEmploymentStatus.Size = new System.Drawing.Size(127, 17);
            this.lblEmploymentStatus.TabIndex = 12;
            this.lblEmploymentStatus.Text = "Employment status";
            // 
            // txtEmployeeName
            // 
            this.txtEmployeeName.Location = new System.Drawing.Point(171, 39);
            this.txtEmployeeName.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtEmployeeName.Name = "txtEmployeeName";
            this.txtEmployeeName.Size = new System.Drawing.Size(200, 22);
            this.txtEmployeeName.TabIndex = 15;
            // 
            // lblEmployeeName
            // 
            this.lblEmployeeName.AutoSize = true;
            this.lblEmployeeName.Location = new System.Drawing.Point(35, 39);
            this.lblEmployeeName.Name = "lblEmployeeName";
            this.lblEmployeeName.Size = new System.Drawing.Size(108, 17);
            this.lblEmployeeName.TabIndex = 14;
            this.lblEmployeeName.Text = "Employer Name";
            // 
            // dtStartDate
            // 
            this.dtStartDate.Location = new System.Drawing.Point(171, 66);
            this.dtStartDate.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.dtStartDate.Name = "dtStartDate";
            this.dtStartDate.Size = new System.Drawing.Size(200, 22);
            this.dtStartDate.TabIndex = 17;
            this.dtStartDate.ValueChanged += new System.EventHandler(this.dtStartDate_ValueChanged);
            // 
            // lblName
            // 
            this.lblName.AutoSize = true;
            this.lblName.Location = new System.Drawing.Point(81, 66);
            this.lblName.Name = "lblName";
            this.lblName.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.lblName.Size = new System.Drawing.Size(72, 17);
            this.lblName.TabIndex = 16;
            this.lblName.Text = "Start Date";
            this.lblName.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // dtEndDate
            // 
            this.dtEndDate.Location = new System.Drawing.Point(171, 95);
            this.dtEndDate.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.dtEndDate.Name = "dtEndDate";
            this.dtEndDate.Size = new System.Drawing.Size(200, 22);
            this.dtEndDate.TabIndex = 19;
            this.dtEndDate.ValueChanged += new System.EventHandler(this.dtEndDate_ValueChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(85, 95);
            this.label1.Name = "label1";
            this.label1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.label1.Size = new System.Drawing.Size(67, 17);
            this.label1.TabIndex = 18;
            this.label1.Text = "End Date";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // cmbRole
            // 
            this.cmbRole.FormattingEnabled = true;
            this.cmbRole.Location = new System.Drawing.Point(171, 123);
            this.cmbRole.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.cmbRole.Name = "cmbRole";
            this.cmbRole.Size = new System.Drawing.Size(195, 24);
            this.cmbRole.TabIndex = 39;
            this.cmbRole.TextUpdate += new System.EventHandler(this.cmbRole_TextUpdate);
            // 
            // lblRole
            // 
            this.lblRole.AutoSize = true;
            this.lblRole.Location = new System.Drawing.Point(119, 126);
            this.lblRole.Name = "lblRole";
            this.lblRole.Size = new System.Drawing.Size(37, 17);
            this.lblRole.TabIndex = 38;
            this.lblRole.Text = "Role";
            // 
            // txtNotes
            // 
            this.txtNotes.Location = new System.Drawing.Point(171, 153);
            this.txtNotes.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtNotes.Multiline = true;
            this.txtNotes.Name = "txtNotes";
            this.txtNotes.Size = new System.Drawing.Size(200, 77);
            this.txtNotes.TabIndex = 41;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(111, 178);
            this.label2.Name = "label2";
            this.label2.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.label2.Size = new System.Drawing.Size(45, 17);
            this.label2.TabIndex = 40;
            this.label2.Text = "Notes";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // btnADDSkill
            // 
            this.btnADDSkill.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnADDSkill.Location = new System.Drawing.Point(171, 239);
            this.btnADDSkill.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnADDSkill.Name = "btnADDSkill";
            this.btnADDSkill.Size = new System.Drawing.Size(75, 30);
            this.btnADDSkill.TabIndex = 42;
            this.btnADDSkill.Text = "Add Skills";
            this.btnADDSkill.UseVisualStyleBackColor = true;
            this.btnADDSkill.Click += new System.EventHandler(this.btnADDSkill_Click);
            // 
            // gridEmployment
            // 
            this.gridEmployment.AllowUserToAddRows = false;
            this.gridEmployment.BackgroundColor = System.Drawing.SystemColors.Window;
            this.gridEmployment.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.gridEmployment.GridColor = System.Drawing.SystemColors.Window;
            this.gridEmployment.Location = new System.Drawing.Point(19, 282);
            this.gridEmployment.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.gridEmployment.MultiSelect = false;
            this.gridEmployment.Name = "gridEmployment";
            this.gridEmployment.RowTemplate.Height = 24;
            this.gridEmployment.Size = new System.Drawing.Size(467, 126);
            this.gridEmployment.TabIndex = 43;
            this.gridEmployment.KeyDown += new System.Windows.Forms.KeyEventHandler(this.gridEmployment_KeyDown);
            // 
            // CtrlEmployment
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.gridEmployment);
            this.Controls.Add(this.btnADDSkill);
            this.Controls.Add(this.txtNotes);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.cmbRole);
            this.Controls.Add(this.lblRole);
            this.Controls.Add(this.dtEndDate);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dtStartDate);
            this.Controls.Add(this.lblName);
            this.Controls.Add(this.txtEmployeeName);
            this.Controls.Add(this.lblEmployeeName);
            this.Controls.Add(this.cmbEmployeStatus);
            this.Controls.Add(this.lblEmploymentStatus);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "CtrlEmployment";
            this.Size = new System.Drawing.Size(513, 422);
            ((System.ComponentModel.ISupportInitialize)(this.gridEmployment)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox cmbEmployeStatus;
        private System.Windows.Forms.Label lblEmploymentStatus;
        private System.Windows.Forms.TextBox txtEmployeeName;
        private System.Windows.Forms.Label lblEmployeeName;
        private System.Windows.Forms.DateTimePicker dtStartDate;
        private System.Windows.Forms.Label lblName;
        private System.Windows.Forms.DateTimePicker dtEndDate;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox cmbRole;
        private System.Windows.Forms.Label lblRole;
        private System.Windows.Forms.TextBox txtNotes;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnADDSkill;
        private System.Windows.Forms.DataGridView gridEmployment;
    }
}
