﻿namespace HCUserControls
{
    partial class CtrlTxtControls
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.fileUpload = new System.Windows.Forms.OpenFileDialog();
            this.btnUpload = new System.Windows.Forms.Button();
            this.btnUploadDoc = new System.Windows.Forms.Button();
            this.lblFilename = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // fileUpload
            // 
            this.fileUpload.FileName = "openFileDialog1";
            // 
            // btnUpload
            // 
            this.btnUpload.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnUpload.Location = new System.Drawing.Point(290, 61);
            this.btnUpload.Name = "btnUpload";
            this.btnUpload.Size = new System.Drawing.Size(134, 29);
            this.btnUpload.TabIndex = 0;
            this.btnUpload.Text = "Change Document";
            this.btnUpload.UseVisualStyleBackColor = true;
            this.btnUpload.Click += new System.EventHandler(this.btnUpload_Click);
            // 
            // btnUploadDoc
            // 
            this.btnUploadDoc.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnUploadDoc.Location = new System.Drawing.Point(317, 96);
            this.btnUploadDoc.Name = "btnUploadDoc";
            this.btnUploadDoc.Size = new System.Drawing.Size(75, 29);
            this.btnUploadDoc.TabIndex = 1;
            this.btnUploadDoc.Text = "Upload";
            this.btnUploadDoc.UseVisualStyleBackColor = true;
            this.btnUploadDoc.Visible = false;
            this.btnUploadDoc.Click += new System.EventHandler(this.btnUploadDoc_Click);
            // 
            // lblFilename
            // 
            this.lblFilename.AutoSize = true;
            this.lblFilename.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFilename.Location = new System.Drawing.Point(321, 30);
            this.lblFilename.Name = "lblFilename";
            this.lblFilename.Size = new System.Drawing.Size(80, 17);
            this.lblFilename.TabIndex = 2;
            this.lblFilename.Text = "File Name";
            // 
            // CtrlTxtControls
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.lblFilename);
            this.Controls.Add(this.btnUploadDoc);
            this.Controls.Add(this.btnUpload);
            this.Name = "CtrlTxtControls";
            this.Size = new System.Drawing.Size(848, 601);
            this.Load += new System.EventHandler(this.CtrlTxtControls_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.OpenFileDialog fileUpload;
        private System.Windows.Forms.Button btnUpload;
        private System.Windows.Forms.Button btnUploadDoc;
        private System.Windows.Forms.Label lblFilename;



    }
}
