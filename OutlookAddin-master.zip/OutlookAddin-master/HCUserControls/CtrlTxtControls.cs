﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Net;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using HireLook;
namespace HCUserControls
{
    public partial class CtrlTxtControls : UserControl
    {
        public ControlDetail controls = new ControlDetail();
        string extenstion;
        Int64 SectionId = 0;
        string FileName = string.Empty, ResumeKey = string.Empty;
        public CtrlTxtControls()
        {
            InitializeComponent();
        }
        public CtrlTxtControls(ControlDetail controls, string ResumeKey, Int64 SectionId)
        {
            InitializeComponent();
            this.controls = controls;
            this.ResumeKey = ResumeKey;
            this.SectionId = SectionId;
        }

        private void btnUpload_Click(object sender, EventArgs e)
        {
            OpenFileDialog op1 = new OpenFileDialog();
            op1.Filter = "Documents (*.pdf;*.doc;*.docx;)|*.pdf;*.doc;*.docx;|All files (*.*)|*.*";
            op1.Multiselect = false;

            op1.ShowDialog();

            //textBox1.Text = op1.FileName;

            if (op1.CheckFileExists)
            {
                if (op1.FileName != string.Empty)
                {
                    try
                    {
                        Constants.FilePath = op1.FileName;
                        FileName = op1.SafeFileName;
                        lblFilename.Text = FileName;
                        btnUploadDoc.Visible = true;
                        extenstion = Path.GetExtension(Constants.FilePath);
                    }
                    catch (Exception ex)
                    {
                        Log.LogData("Error in Upload Resume Document: " + ex.Message + ex.StackTrace, Log.Status.Error);
                    }
                }
            }
        }

        private void btnUploadDoc_Click(object sender, EventArgs e)
        {
            this.UseWaitCursor = true;
            try
            {
                byte[] bytes = File.ReadAllBytes(Constants.FilePath);

                string contentType = "application/octet-stream";
                string url = Configuration.ApplicationAPI + "documents/resumedocument/" + Constants.ResumeId;
                Boolean result = UploadMultipart(bytes, FileName, contentType, url);
                if (result)
                    btnUploadDoc.Visible = false;
            }
            catch (Exception ex)
            {
                Log.LogData("Error in Upload Doc" + ex.Message + ex.StackTrace, Log.Status.Error);
            }
            finally
            {
                this.UseWaitCursor = false;
            }
        }

        public Boolean UploadMultipart(byte[] file, string filename, string contentType, string url)
        {
            string ResposeResult = string.Empty;
            try
            {
                var webClient = new WebClient();
                string boundary = "------------------------" + DateTime.Now.Ticks.ToString("x");
                webClient.Headers.Add("Authorization: bearer " + Configuration.access_token);
                webClient.Headers.Add("Content-Type", "multipart/form-data; boundary=" + boundary);
                var fileData = webClient.Encoding.GetString(file);
                var package = string.Format("--{0}\r\nContent-Disposition: form-data; name=\"file\"; filename=\"{1}\"\r\nContent-Type: {2}\r\n\r\n{3}\r\n--{0}--\r\n", boundary, filename, "application/octet-stream", fileData);

                var nfile = webClient.Encoding.GetBytes(package);
                byte[] resp = webClient.UploadData(url, "POST", nfile);
                ResposeResult = System.Text.Encoding.UTF8.GetString(resp);
                ResposeData _responseData = JsonConvert.DeserializeObject<ResposeData>(ResposeResult);
                if (_responseData.Code == "SUCCESS0001")
                    return true;
                else
                    return false;
            }
            catch (System.Exception ex)
            {
                Log.LogData("Error in upload attachmnt" + ex.Message + ex.StackTrace, Log.Status.Error);
                return false;
            }
        }

        private void CtrlTxtControls_Load(object sender, EventArgs e)
        {
            if (!System.String.IsNullOrWhiteSpace(ResumeKey) && SectionId != 0)
            {
                Resume ParseFileData = LoadParseResumeDetails();
                if (ParseFileData != null && ParseFileData.FileName != "")
                    lblFilename.Text = ParseFileData.FileName;
                else
                    lblFilename.Text = "";
            }
        }

        Resume LoadParseResumeDetails()
        {
            string subUrl = "resume/parsing?key=" + ResumeKey + "&SectionId=" + SectionId;
            Resume MasterData = new Resume();
            var request = (HttpWebRequest)WebRequest.Create(Convert.ToString(System.Configuration.ConfigurationManager.AppSettings["ApplicatonAPI"]) + subUrl);

            request.Method = "GET";
            request.ContentType = "application/x-www-form-urlencoded";
            request.Headers.Add("Authorization: Bearer " + HireLook.Configuration.access_token);
            try
            {
                HttpWebResponse response = (HttpWebResponse)request.GetResponse();
                var responseString = new StreamReader(response.GetResponseStream()).ReadToEnd();
                try
                {
                    JObject objRes = JObject.Parse(responseString);
                    string strFileData =objRes["Resume"].ToString();

                    if (strFileData != null && strFileData != "")
                    {
                        JObject objFileData = JObject.Parse(strFileData);
                        MasterData.FileName = objFileData["FileName"].ToString();
                        MasterData.FileType = objFileData["FileType"].ToString();
                    }
                }
                catch (System.Exception ex)
                {
                    Log.LogData("Error in loading master value: " + ex.Message + ex.StackTrace, Log.Status.Error);
                }
            }
            catch (WebException ex)
            {
                Log.LogData("Error in Load Selection: " + ex.Message + ex.StackTrace, Log.Status.Error);
            }
            return MasterData;
        }

    }
}