﻿namespace HCUserControls
{
    partial class CtrlAutoComplete
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblName = new System.Windows.Forms.Label();
            this.cmbDropdown = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // lblName
            // 
            this.lblName.AutoSize = true;
            this.lblName.Location = new System.Drawing.Point(3, 7);
            this.lblName.Name = "lblName";
            this.lblName.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.lblName.Size = new System.Drawing.Size(84, 17);
            this.lblName.TabIndex = 2;
            this.lblName.Text = "Label Name";
            this.lblName.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // cmbDropdown
            // 
            this.cmbDropdown.FormattingEnabled = true;
            this.cmbDropdown.Location = new System.Drawing.Point(108, 7);
            this.cmbDropdown.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.cmbDropdown.Name = "cmbDropdown";
            this.cmbDropdown.Size = new System.Drawing.Size(195, 24);
            this.cmbDropdown.TabIndex = 4;
            this.cmbDropdown.TextUpdate += new System.EventHandler(this.cmbDropdown_TextUpdate);
            // 
            // CtrlAutoComplete
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.cmbDropdown);
            this.Controls.Add(this.lblName);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "CtrlAutoComplete";
            this.Size = new System.Drawing.Size(315, 41);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblName;
        private System.Windows.Forms.ComboBox cmbDropdown;
    }
}
