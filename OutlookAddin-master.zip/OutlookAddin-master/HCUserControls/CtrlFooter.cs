﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace HCUserControls
{
    public partial class CtrlFooter : UserControl
    {
        private BackgroundWorker myWorker = new BackgroundWorker();
        public CtrlFooter()
        {
            InitializeComponent();
            myWorker.DoWork += new DoWorkEventHandler(myWorker_DoWork);
            myWorker.RunWorkerCompleted += new RunWorkerCompletedEventHandler(myWorker_RunWorkerCompleted);
            myWorker.ProgressChanged += new ProgressChangedEventHandler(myWorker_ProgressChanged);
            myWorker.WorkerReportsProgress = true;
            myWorker.WorkerSupportsCancellation = true;
        }
        public void ShowMessage(String message)
        {
            toolslbl.Text = message;
            MsgTimer.Start();
        }

        private void MsgTimer_Tick(object sender, EventArgs e)
        {
            toolslbl.Text = "";
            MsgTimer.Stop();
        }

        protected void myWorker_DoWork(object sender, DoWorkEventArgs e)
        {

        }
        protected void myWorker_ProgressChanged(object sender, ProgressChangedEventArgs e)
        {
            toolslbl.Text = string.Format("Counting number: {0}...", e.ProgressPercentage);
        }
        protected void myWorker_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {

        }
    }
}
