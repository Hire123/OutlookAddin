﻿namespace HCUserControls
{
    partial class CtrlEducation
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblEducationType = new System.Windows.Forms.Label();
            this.cmbEducationType = new System.Windows.Forms.ComboBox();
            this.cmbSpecilization = new System.Windows.Forms.ComboBox();
            this.lblSpecalization = new System.Windows.Forms.Label();
            this.cmbUniversity = new System.Windows.Forms.ComboBox();
            this.lblUniversity = new System.Windows.Forms.Label();
            this.cmbInstitute = new System.Windows.Forms.ComboBox();
            this.lblInstitute = new System.Windows.Forms.Label();
            this.dtFromDate = new System.Windows.Forms.DateTimePicker();
            this.lblName = new System.Windows.Forms.Label();
            this.dtToDate = new System.Windows.Forms.DateTimePicker();
            this.label5 = new System.Windows.Forms.Label();
            this.txtGrade = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.chkGapEducation = new System.Windows.Forms.CheckBox();
            this.txtAutoArea = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.btnAdd = new System.Windows.Forms.Button();
            this.gridEmployment = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.gridEmployment)).BeginInit();
            this.SuspendLayout();
            // 
            // lblEducationType
            // 
            this.lblEducationType.AutoSize = true;
            this.lblEducationType.Location = new System.Drawing.Point(32, 6);
            this.lblEducationType.Name = "lblEducationType";
            this.lblEducationType.Size = new System.Drawing.Size(102, 17);
            this.lblEducationType.TabIndex = 32;
            this.lblEducationType.Text = "Education type";
            // 
            // cmbEducationType
            // 
            this.cmbEducationType.FormattingEnabled = true;
            this.cmbEducationType.Location = new System.Drawing.Point(165, 6);
            this.cmbEducationType.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.cmbEducationType.Name = "cmbEducationType";
            this.cmbEducationType.Size = new System.Drawing.Size(195, 24);
            this.cmbEducationType.TabIndex = 36;
            this.cmbEducationType.TextUpdate += new System.EventHandler(this.cmbEducationType_TextUpdate);
            // 
            // cmbSpecilization
            // 
            this.cmbSpecilization.FormattingEnabled = true;
            this.cmbSpecilization.Location = new System.Drawing.Point(165, 36);
            this.cmbSpecilization.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.cmbSpecilization.Name = "cmbSpecilization";
            this.cmbSpecilization.Size = new System.Drawing.Size(195, 24);
            this.cmbSpecilization.TabIndex = 38;
            this.cmbSpecilization.TextUpdate += new System.EventHandler(this.cmbSpecilization_TextUpdate);
            // 
            // lblSpecalization
            // 
            this.lblSpecalization.AutoSize = true;
            this.lblSpecalization.Location = new System.Drawing.Point(45, 39);
            this.lblSpecalization.Name = "lblSpecalization";
            this.lblSpecalization.Size = new System.Drawing.Size(87, 17);
            this.lblSpecalization.TabIndex = 37;
            this.lblSpecalization.Text = "Specilization";
            // 
            // cmbUniversity
            // 
            this.cmbUniversity.FormattingEnabled = true;
            this.cmbUniversity.Location = new System.Drawing.Point(165, 66);
            this.cmbUniversity.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.cmbUniversity.Name = "cmbUniversity";
            this.cmbUniversity.Size = new System.Drawing.Size(195, 24);
            this.cmbUniversity.TabIndex = 40;
            this.cmbUniversity.TextUpdate += new System.EventHandler(this.cmbUniversity_TextUpdate);
            // 
            // lblUniversity
            // 
            this.lblUniversity.AutoSize = true;
            this.lblUniversity.Location = new System.Drawing.Point(23, 69);
            this.lblUniversity.Name = "lblUniversity";
            this.lblUniversity.Size = new System.Drawing.Size(109, 17);
            this.lblUniversity.TabIndex = 39;
            this.lblUniversity.Text = "University name";
            // 
            // cmbInstitute
            // 
            this.cmbInstitute.FormattingEnabled = true;
            this.cmbInstitute.Location = new System.Drawing.Point(165, 96);
            this.cmbInstitute.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.cmbInstitute.Name = "cmbInstitute";
            this.cmbInstitute.Size = new System.Drawing.Size(195, 24);
            this.cmbInstitute.TabIndex = 42;
            this.cmbInstitute.TextUpdate += new System.EventHandler(this.cmbInstitute_TextUpdate);
            // 
            // lblInstitute
            // 
            this.lblInstitute.AutoSize = true;
            this.lblInstitute.Location = new System.Drawing.Point(36, 97);
            this.lblInstitute.Name = "lblInstitute";
            this.lblInstitute.Size = new System.Drawing.Size(96, 17);
            this.lblInstitute.TabIndex = 41;
            this.lblInstitute.Text = "Institute name";
            // 
            // dtFromDate
            // 
            this.dtFromDate.Location = new System.Drawing.Point(165, 126);
            this.dtFromDate.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.dtFromDate.Name = "dtFromDate";
            this.dtFromDate.Size = new System.Drawing.Size(200, 22);
            this.dtFromDate.TabIndex = 44;
            this.dtFromDate.ValueChanged += new System.EventHandler(this.dtFromDate_ValueChanged);
            // 
            // lblName
            // 
            this.lblName.AutoSize = true;
            this.lblName.Location = new System.Drawing.Point(64, 126);
            this.lblName.Name = "lblName";
            this.lblName.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.lblName.Size = new System.Drawing.Size(72, 17);
            this.lblName.TabIndex = 43;
            this.lblName.Text = "From date";
            this.lblName.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // dtToDate
            // 
            this.dtToDate.Location = new System.Drawing.Point(165, 154);
            this.dtToDate.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.dtToDate.Name = "dtToDate";
            this.dtToDate.Size = new System.Drawing.Size(200, 22);
            this.dtToDate.TabIndex = 46;
            this.dtToDate.ValueChanged += new System.EventHandler(this.dtToDate_ValueChanged);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(84, 154);
            this.label5.Name = "label5";
            this.label5.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.label5.Size = new System.Drawing.Size(57, 17);
            this.label5.TabIndex = 45;
            this.label5.Text = "To date";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txtGrade
            // 
            this.txtGrade.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.txtGrade.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txtGrade.Location = new System.Drawing.Point(165, 182);
            this.txtGrade.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtGrade.Name = "txtGrade";
            this.txtGrade.Size = new System.Drawing.Size(195, 22);
            this.txtGrade.TabIndex = 48;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(5, 181);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(125, 17);
            this.label6.TabIndex = 47;
            this.label6.Text = "Grade/Percentage";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(13, 209);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(117, 17);
            this.label7.TabIndex = 49;
            this.label7.Text = "Gap in Education";
            // 
            // chkGapEducation
            // 
            this.chkGapEducation.AutoSize = true;
            this.chkGapEducation.Location = new System.Drawing.Point(165, 210);
            this.chkGapEducation.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.chkGapEducation.Name = "chkGapEducation";
            this.chkGapEducation.Size = new System.Drawing.Size(18, 17);
            this.chkGapEducation.TabIndex = 50;
            this.chkGapEducation.UseVisualStyleBackColor = true;
            // 
            // txtAutoArea
            // 
            this.txtAutoArea.Location = new System.Drawing.Point(165, 233);
            this.txtAutoArea.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtAutoArea.Multiline = true;
            this.txtAutoArea.Name = "txtAutoArea";
            this.txtAutoArea.Size = new System.Drawing.Size(251, 82);
            this.txtAutoArea.TabIndex = 52;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(21, 257);
            this.label8.Name = "label8";
            this.label8.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.label8.Size = new System.Drawing.Size(110, 17);
            this.label8.TabIndex = 51;
            this.label8.Text = "Education notes";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // btnAdd
            // 
            this.btnAdd.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnAdd.Location = new System.Drawing.Point(165, 324);
            this.btnAdd.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(75, 28);
            this.btnAdd.TabIndex = 53;
            this.btnAdd.Text = "Add";
            this.btnAdd.UseVisualStyleBackColor = true;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // gridEmployment
            // 
            this.gridEmployment.AllowUserToAddRows = false;
            this.gridEmployment.BackgroundColor = System.Drawing.SystemColors.Window;
            this.gridEmployment.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.gridEmployment.GridColor = System.Drawing.SystemColors.Window;
            this.gridEmployment.Location = new System.Drawing.Point(16, 363);
            this.gridEmployment.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.gridEmployment.MultiSelect = false;
            this.gridEmployment.Name = "gridEmployment";
            this.gridEmployment.RowTemplate.Height = 24;
            this.gridEmployment.Size = new System.Drawing.Size(709, 126);
            this.gridEmployment.TabIndex = 54;
            this.gridEmployment.KeyDown += new System.Windows.Forms.KeyEventHandler(this.gridEmployment_KeyDown);
            // 
            // CtrlEducation
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.gridEmployment);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(this.txtAutoArea);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.chkGapEducation);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.txtGrade);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.dtToDate);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.dtFromDate);
            this.Controls.Add(this.lblName);
            this.Controls.Add(this.cmbInstitute);
            this.Controls.Add(this.lblInstitute);
            this.Controls.Add(this.cmbUniversity);
            this.Controls.Add(this.lblUniversity);
            this.Controls.Add(this.cmbSpecilization);
            this.Controls.Add(this.lblSpecalization);
            this.Controls.Add(this.cmbEducationType);
            this.Controls.Add(this.lblEducationType);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "CtrlEducation";
            this.Size = new System.Drawing.Size(743, 502);
            ((System.ComponentModel.ISupportInitialize)(this.gridEmployment)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblEducationType;
        private System.Windows.Forms.ComboBox cmbEducationType;
        private System.Windows.Forms.ComboBox cmbSpecilization;
        private System.Windows.Forms.Label lblSpecalization;
        private System.Windows.Forms.ComboBox cmbUniversity;
        private System.Windows.Forms.Label lblUniversity;
        private System.Windows.Forms.ComboBox cmbInstitute;
        private System.Windows.Forms.Label lblInstitute;
        private System.Windows.Forms.DateTimePicker dtFromDate;
        private System.Windows.Forms.Label lblName;
        private System.Windows.Forms.DateTimePicker dtToDate;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtGrade;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.CheckBox chkGapEducation;
        private System.Windows.Forms.TextBox txtAutoArea;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.DataGridView gridEmployment;
    }
}
