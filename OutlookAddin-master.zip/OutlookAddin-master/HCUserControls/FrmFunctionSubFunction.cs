﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using HireLook;
using System.IO;
using System.Net;
using System.Configuration;
using Newtonsoft.Json;
using System.Collections;
using System.Collections.ObjectModel;
namespace HCUserControls
{
    public partial class FrmFunctionSubFunction : Form
    {
        List<NameSearch> funsubfunctionData = new List<NameSearch>();
        //List<clsMasters.NameSearch> funsubfunctionData = new List<clsMasters.NameSearch>();
        bool type;
        ArrayList functionId = new ArrayList();

        public FrmFunctionSubFunction()
        {
            InitializeComponent();
        }

        public FrmFunctionSubFunction(string lableName, bool type, List<NameSearch> FunctionSubFunctionData)
        {
            InitializeComponent();
            lblName.Text = lableName;
            this.type = type;
            this.funsubfunctionData = FunctionSubFunctionData;
            if (this.funsubfunctionData.Count > 0)
                bindList();
        }

        public FrmFunctionSubFunction(string lableName, bool type, ArrayList FuctionId, List<NameSearch> FunctionSubFunctionData)
        {
            InitializeComponent();
            lblName.Text = lableName;
            this.type = type;
            this.functionId = FuctionId;
            this.funsubfunctionData = FunctionSubFunctionData;
            if (this.funsubfunctionData.Count > 0)
                bindList();
        }


        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        void HandleTextChanged()
        {
            try
            {
                string url = string.Empty;
                List<NameSearch> mstrData = new List<NameSearch>();
                if (cmbFunSubFunction.Text != string.Empty)
                {

                    if (type)
                    {
                        url = "masters/function?name=";
                        mstrData = LoadCMB(url + cmbFunSubFunction.Text);
                    }
                    else
                    {
                        url = url = "masters/function/mappedsubfunctions?name=";
                        mstrData = loadsubFunction(url + cmbFunSubFunction.Text);

                    }
                    List<string> TitleAry = new List<string>();
                    if (mstrData != null)
                    {
                        if (mstrData.Count > 0)
                        {
                            NameSearch mstrDefault = new NameSearch();
                            mstrDefault.RID = 0;
                            mstrDefault.Title = cmbFunSubFunction.Text;
                            mstrData.Insert(0, mstrDefault);
                            cmbFunSubFunction.DataSource = mstrData.ToList();
                            //comboBox1.SelectedIndex = 0;
                            var sText = cmbFunSubFunction.Items[0].ToString();
                            cmbFunSubFunction.SelectionStart = cmbFunSubFunction.Text.Length;
                            cmbFunSubFunction.SelectionLength = sText.Length - cmbFunSubFunction.Text.Length;
                            cmbFunSubFunction.DroppedDown = true;
                            cmbFunSubFunction.ValueMember = "RID";
                            cmbFunSubFunction.DisplayMember = "Title";
                        }
                    }
                    else
                    {
                        cmbFunSubFunction.DroppedDown = false;
                        cmbFunSubFunction.SelectionStart = cmbFunSubFunction.Text.Length;
                    }

                }
                else
                {
                    cmbFunSubFunction.DroppedDown = false;
                    cmbFunSubFunction.SelectionStart = cmbFunSubFunction.Text.Length;
                }
            }
            catch (Exception ex)
            {
                Log.LogData("Error in Function sub function: " + ex.Message + ex.StackTrace, Log.Status.Error);
            }
        }

        List<NameSearch> LoadCMB(string subURL)
        {
            List<NameSearch> objMaster = new List<NameSearch>();
            var request = (HttpWebRequest)WebRequest.Create(Convert.ToString(HireLook.Configuration.ApplicationAPI) + subURL);

            request.Method = "GET";
            request.ContentType = "application/x-www-form-urlencoded";
            request.Headers.Add("Authorization: Bearer " + HireLook.Configuration.access_token);

            try
            {
                HttpWebResponse response = (HttpWebResponse)request.GetResponse();
                var responseString = new StreamReader(response.GetResponseStream()).ReadToEnd();
                try
                {
                    objMaster = JsonConvert.DeserializeObject<List<NameSearch>>(responseString);

                }
                catch (System.Exception ex)
                {
                    Log.LogData("Error in loadSkill result: Registry value: " + ex.Message + ex.StackTrace, Log.Status.Error);
                }
            }
            catch (WebException ex)
            {
                Log.LogData("Error in Load loadSkill: " + ex.Message + ex.StackTrace, Log.Status.Error);
            }
            return objMaster;
        }

        List<NameSearch> loadsubFunction(string subURL)
        {
            List<NameSearch> objMaster = new List<NameSearch>();
            var request = (HttpWebRequest)WebRequest.Create(HireLook.Configuration.ApplicationAPI + subURL);
            //var postData = "SectionId=" + sectionSave.SectionId + "&Values=" + sectionSave.Value;
            var data = Encoding.ASCII.GetBytes(JsonConvert.SerializeObject(functionId));
            request.Method = "Post";
            request.Headers.Add("Authorization: Bearer " + HireLook.Configuration.access_token);
            request.ContentType = "application/json";
            request.ContentLength = data.Length;

            using (var stream = request.GetRequestStream())
            {
                stream.Write(data, 0, data.Length);
            }

            try
            {
                HttpWebResponse response = (HttpWebResponse)request.GetResponse();
                var responseString = new StreamReader(response.GetResponseStream()).ReadToEnd();

                objMaster = JsonConvert.DeserializeObject<List<NameSearch>>(responseString);
                try
                {

                }
                catch (Exception ex)
                {
                    Log.LogData("Error in frmLogin: Registry value: " + ex.Message + ex.StackTrace, Log.Status.Error);
                }

            }
            catch (WebException ex)
            {
                Log.LogData("Invalid In Saving Resume Manager: " + ex.Message + ex.StackTrace, Log.Status.Error);
            }
            return objMaster;
        }


        private void btnAdd_Click(object sender, EventArgs e)
        {
            funsubfunctionData.Add(new NameSearch { RID = Convert.ToInt64(cmbFunSubFunction.SelectedValue), Title = Convert.ToString(cmbFunSubFunction.Text) });
            //   lstItem.ClearSelected();
            lstItem.DataSource = null;
            lstItem.DataSource = funsubfunctionData;
            lstItem.DisplayMember = "Title";
            lstItem.ValueMember = "RID";

            cmbFunSubFunction.Text = "";
            cmbFunSubFunction.DataSource = null;

        }

        public List<NameSearch> opSelectedFunctionSubFunctionDetails()
        {
            return funsubfunctionData;
        }

        private void cmbFunSubFunction_TextUpdate(object sender, EventArgs e)
        {
            HandleTextChanged();
        }

        void bindList()
        {
            lstItem.DataSource = null;
            lstItem.DataSource = funsubfunctionData;
            lstItem.DisplayMember = "Title";
            lstItem.ValueMember = "RID";
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < lstItem.SelectedItems.Count; i++)
            {
                Int64 RID = Convert.ToInt64(lstItem.SelectedValue);
                funsubfunctionData = funsubfunctionData.Except(funsubfunctionData.Where(a => a.RID == RID)).ToList();
                bindList();
            }
        }
    }
}
