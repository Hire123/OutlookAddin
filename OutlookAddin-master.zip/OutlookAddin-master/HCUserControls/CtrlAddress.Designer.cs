﻿namespace HCUserControls
{
    partial class CtrlAddress
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.cmbAddressType = new System.Windows.Forms.ComboBox();
            this.lbladdresstype = new System.Windows.Forms.Label();
            this.txtAddressLine1 = new System.Windows.Forms.TextBox();
            this.lblAddressLine1 = new System.Windows.Forms.Label();
            this.txtAddressLine2 = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtCity = new System.Windows.Forms.TextBox();
            this.lblCity = new System.Windows.Forms.Label();
            this.lblcountry = new System.Windows.Forms.Label();
            this.cmbState = new System.Windows.Forms.ComboBox();
            this.lblState = new System.Windows.Forms.Label();
            this.txtPincode = new System.Windows.Forms.TextBox();
            this.lblPincode = new System.Windows.Forms.Label();
            this.txtCountry = new System.Windows.Forms.TextBox();
            this.btnADD = new System.Windows.Forms.Button();
            this.GridAddress = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.GridAddress)).BeginInit();
            this.SuspendLayout();
            // 
            // cmbAddressType
            // 
            this.cmbAddressType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbAddressType.FormattingEnabled = true;
            this.cmbAddressType.Location = new System.Drawing.Point(131, 9);
            this.cmbAddressType.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.cmbAddressType.Name = "cmbAddressType";
            this.cmbAddressType.Size = new System.Drawing.Size(195, 24);
            this.cmbAddressType.TabIndex = 13;
            this.cmbAddressType.Click += new System.EventHandler(this.cmbAddressType_Click);
            // 
            // lbladdresstype
            // 
            this.lbladdresstype.AutoSize = true;
            this.lbladdresstype.Location = new System.Drawing.Point(11, 12);
            this.lbladdresstype.Name = "lbladdresstype";
            this.lbladdresstype.Size = new System.Drawing.Size(96, 17);
            this.lbladdresstype.TabIndex = 12;
            this.lbladdresstype.Text = "Address Type";
            // 
            // txtAddressLine1
            // 
            this.txtAddressLine1.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.txtAddressLine1.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txtAddressLine1.Location = new System.Drawing.Point(131, 39);
            this.txtAddressLine1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtAddressLine1.Name = "txtAddressLine1";
            this.txtAddressLine1.Size = new System.Drawing.Size(195, 22);
            this.txtAddressLine1.TabIndex = 27;
            // 
            // lblAddressLine1
            // 
            this.lblAddressLine1.AutoSize = true;
            this.lblAddressLine1.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblAddressLine1.Location = new System.Drawing.Point(4, 39);
            this.lblAddressLine1.Name = "lblAddressLine1";
            this.lblAddressLine1.Size = new System.Drawing.Size(103, 17);
            this.lblAddressLine1.TabIndex = 26;
            this.lblAddressLine1.Text = "Address Line 1";
            // 
            // txtAddressLine2
            // 
            this.txtAddressLine2.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.txtAddressLine2.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txtAddressLine2.Location = new System.Drawing.Point(131, 66);
            this.txtAddressLine2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtAddressLine2.Name = "txtAddressLine2";
            this.txtAddressLine2.Size = new System.Drawing.Size(195, 22);
            this.txtAddressLine2.TabIndex = 29;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(4, 66);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(103, 17);
            this.label3.TabIndex = 28;
            this.label3.Text = "Address Line 2";
            // 
            // txtCity
            // 
            this.txtCity.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.txtCity.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txtCity.Location = new System.Drawing.Point(131, 95);
            this.txtCity.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtCity.Name = "txtCity";
            this.txtCity.Size = new System.Drawing.Size(195, 22);
            this.txtCity.TabIndex = 31;
            // 
            // lblCity
            // 
            this.lblCity.AutoSize = true;
            this.lblCity.Location = new System.Drawing.Point(75, 95);
            this.lblCity.Name = "lblCity";
            this.lblCity.Size = new System.Drawing.Size(31, 17);
            this.lblCity.TabIndex = 30;
            this.lblCity.Text = "City";
            // 
            // lblcountry
            // 
            this.lblcountry.AutoSize = true;
            this.lblcountry.Location = new System.Drawing.Point(49, 156);
            this.lblcountry.Name = "lblcountry";
            this.lblcountry.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.lblcountry.Size = new System.Drawing.Size(57, 17);
            this.lblcountry.TabIndex = 32;
            this.lblcountry.Text = "Country";
            this.lblcountry.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // cmbState
            // 
            this.cmbState.FormattingEnabled = true;
            this.cmbState.Location = new System.Drawing.Point(131, 123);
            this.cmbState.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.cmbState.Name = "cmbState";
            this.cmbState.Size = new System.Drawing.Size(195, 24);
            this.cmbState.TabIndex = 35;
            this.cmbState.TextUpdate += new System.EventHandler(this.cmbState_TextUpdate);
            this.cmbState.DropDownClosed += new System.EventHandler(this.cmbState_DropDownClosed);
            // 
            // lblState
            // 
            this.lblState.AutoSize = true;
            this.lblState.Location = new System.Drawing.Point(65, 126);
            this.lblState.Name = "lblState";
            this.lblState.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.lblState.Size = new System.Drawing.Size(41, 17);
            this.lblState.TabIndex = 34;
            this.lblState.Text = "State";
            this.lblState.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // txtPincode
            // 
            this.txtPincode.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.txtPincode.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txtPincode.Location = new System.Drawing.Point(131, 183);
            this.txtPincode.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtPincode.Name = "txtPincode";
            this.txtPincode.Size = new System.Drawing.Size(195, 22);
            this.txtPincode.TabIndex = 37;
            // 
            // lblPincode
            // 
            this.lblPincode.AutoSize = true;
            this.lblPincode.Location = new System.Drawing.Point(47, 183);
            this.lblPincode.Name = "lblPincode";
            this.lblPincode.Size = new System.Drawing.Size(59, 17);
            this.lblPincode.TabIndex = 36;
            this.lblPincode.Text = "Pincode";
            // 
            // txtCountry
            // 
            this.txtCountry.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.txtCountry.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txtCountry.Enabled = false;
            this.txtCountry.Location = new System.Drawing.Point(131, 156);
            this.txtCountry.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtCountry.Name = "txtCountry";
            this.txtCountry.Size = new System.Drawing.Size(195, 22);
            this.txtCountry.TabIndex = 40;
            // 
            // btnADD
            // 
            this.btnADD.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnADD.Location = new System.Drawing.Point(147, 222);
            this.btnADD.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnADD.Name = "btnADD";
            this.btnADD.Size = new System.Drawing.Size(75, 30);
            this.btnADD.TabIndex = 39;
            this.btnADD.Text = "Add";
            this.btnADD.UseVisualStyleBackColor = true;
            this.btnADD.Click += new System.EventHandler(this.btnADD_Click);
            // 
            // GridAddress
            // 
            this.GridAddress.AllowUserToAddRows = false;
            this.GridAddress.BackgroundColor = System.Drawing.SystemColors.Window;
            this.GridAddress.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.GridAddress.GridColor = System.Drawing.SystemColors.Window;
            this.GridAddress.Location = new System.Drawing.Point(13, 260);
            this.GridAddress.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.GridAddress.MultiSelect = false;
            this.GridAddress.Name = "GridAddress";
            this.GridAddress.RowTemplate.Height = 24;
            this.GridAddress.Size = new System.Drawing.Size(531, 126);
            this.GridAddress.TabIndex = 44;
            this.GridAddress.KeyDown += new System.Windows.Forms.KeyEventHandler(this.gridEmployment_KeyDown);
            // 
            // CtrlAddress
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.GridAddress);
            this.Controls.Add(this.btnADD);
            this.Controls.Add(this.txtCountry);
            this.Controls.Add(this.txtPincode);
            this.Controls.Add(this.lblPincode);
            this.Controls.Add(this.cmbState);
            this.Controls.Add(this.lblState);
            this.Controls.Add(this.lblcountry);
            this.Controls.Add(this.txtCity);
            this.Controls.Add(this.lblCity);
            this.Controls.Add(this.txtAddressLine2);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txtAddressLine1);
            this.Controls.Add(this.lblAddressLine1);
            this.Controls.Add(this.cmbAddressType);
            this.Controls.Add(this.lbladdresstype);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "CtrlAddress";
            this.Size = new System.Drawing.Size(563, 399);
            ((System.ComponentModel.ISupportInitialize)(this.GridAddress)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox cmbAddressType;
        private System.Windows.Forms.Label lbladdresstype;
        private System.Windows.Forms.TextBox txtAddressLine1;
        private System.Windows.Forms.Label lblAddressLine1;
        private System.Windows.Forms.TextBox txtAddressLine2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtCity;
        private System.Windows.Forms.Label lblCity;
        private System.Windows.Forms.Label lblcountry;
        private System.Windows.Forms.ComboBox cmbState;
        private System.Windows.Forms.Label lblState;
        private System.Windows.Forms.TextBox txtPincode;
        private System.Windows.Forms.Label lblPincode;
        private System.Windows.Forms.TextBox txtCountry;
        private System.Windows.Forms.Button btnADD;
        private System.Windows.Forms.DataGridView GridAddress;
    }
}
