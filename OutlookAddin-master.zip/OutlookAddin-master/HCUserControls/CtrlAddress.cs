﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net;
using System.IO;
using Newtonsoft.Json;
using System.Configuration;
using HireLook;
using System.Collections;
namespace HCUserControls
{
    public partial class CtrlAddress : UserControl
    {
        ControlDetail controls = new ControlDetail();
        List<StateNameSearch> StateList = new List<StateNameSearch>();
        List<UserAddress> AddressList = new List<UserAddress>();
        public CtrlAddress()
        {
            InitializeComponent();
        }

        public CtrlAddress(ControlDetail controls)
        {
            InitializeComponent();
            this.controls = controls;
            loadDefaultCmbAddressType();
            SetSkillGrid();
            opSetManditory();
        }

        void loadDefaultCmbAddressType()
        {
            NameSearch DefaultValue = new NameSearch();
            DefaultValue.RID = 0;
            DefaultValue.Title = "<-- Select -->";
            List<NameSearch> defaultval = new List<NameSearch>();
            defaultval.Add(DefaultValue);
            cmbAddressType.DisplayMember = "Title";
            cmbAddressType.ValueMember = "RID";
            cmbAddressType.DataSource = defaultval;
        }

        void loadCmbAddressType()
        {
            List<NameSearch> AddressType = LoadMasterData("/masters/addresstype");
            if (AddressType != null)
            {
                if (AddressType.Count > 0)
                {
                    cmbAddressType.DisplayMember = "Title";
                    cmbAddressType.ValueMember = "RID";
                    cmbAddressType.DataSource = AddressType;
                }
            }

        }

        List<NameSearch> LoadMasterData(string subUrl)
        {
            List<NameSearch> MasterData = new List<NameSearch>();
            var request = (HttpWebRequest)WebRequest.Create(Convert.ToString(ConfigurationManager.AppSettings["ApplicatonAPI"]) + subUrl);

            request.Method = "GET";
            request.ContentType = "application/x-www-form-urlencoded";
            request.Headers.Add("Authorization: Bearer " + HireLook.Configuration.access_token);
            try
            {
                HttpWebResponse response = (HttpWebResponse)request.GetResponse();
                var responseString = new StreamReader(response.GetResponseStream()).ReadToEnd();
                try
                {
                    MasterData = JsonConvert.DeserializeObject<List<NameSearch>>(responseString);
                }
                catch (System.Exception ex)
                {
                    Log.LogData("Error in loading master value: " + ex.Message + ex.StackTrace, Log.Status.Error);
                }
            }
            catch (WebException ex)
            {
                Log.LogData("Error in Load Selection: " + ex.Message + ex.StackTrace, Log.Status.Error);
            }
            return MasterData;
        }

        List<StateNameSearch> LoadStateData(string subUrl)
        {
            List<StateNameSearch> MasterData = new List<StateNameSearch>();
            var request = (HttpWebRequest)WebRequest.Create(Convert.ToString(ConfigurationManager.AppSettings["ApplicatonAPI"]) + subUrl);

            request.Method = "GET";
            request.ContentType = "application/x-www-form-urlencoded";
            request.Headers.Add("Authorization: Bearer " + HireLook.Configuration.access_token);
            try
            {
                HttpWebResponse response = (HttpWebResponse)request.GetResponse();
                var responseString = new StreamReader(response.GetResponseStream()).ReadToEnd();
                try
                {
                    MasterData = JsonConvert.DeserializeObject<List<StateNameSearch>>(responseString);
                }
                catch (System.Exception ex)
                {
                    Log.LogData("Error in loading master value: " + ex.Message + ex.StackTrace, Log.Status.Error);
                }
            }
            catch (WebException ex)
            {
                Log.LogData("Error in Load Selection: " + ex.Message + ex.StackTrace, Log.Status.Error);
            }
            return MasterData;
        }

        void loadState(string text)
        {
            StateList = LoadStateData("/masters/states?name=" + text);
            if (StateList != null)
            {
                if (StateList.Count > 0)
                {
                    StateNameSearch mstrDefault = new StateNameSearch();
                    mstrDefault.RID = 0;
                    mstrDefault.Title = text;
                    StateList.Insert(0, mstrDefault);

                    cmbState.DroppedDown = true;
                    cmbState.DataSource = StateList.ToList();
                    var sText = cmbState.Items[0].ToString();
                    cmbState.SelectionStart = cmbState.Text.Length;
                    cmbState.SelectionLength = sText.Length - cmbState.Text.Length;
                    cmbState.ValueMember = "RID";
                    cmbState.DisplayMember = "Title";
                    cmbState.SelectedIndex = 0;
                    Application.DoEvents();
                }
                else
                {
                    cmbState.DroppedDown = false;
                    cmbState.SelectionStart = cmbState.Text.Length;
                }
            }
            else
            {
                cmbState.DroppedDown = false;
                cmbState.SelectionStart = cmbState.Text.Length;
            }

        }

        private void cmbState_TextUpdate(object sender, EventArgs e)
        {
            try
            {
                this.UseWaitCursor = true;
                if (cmbState.Text != string.Empty)
                {
                    Application.DoEvents();
                    loadState(cmbState.Text);
                    Application.DoEvents();
                }
                else
                {
                    cmbState.DroppedDown = false;
                    cmbState.SelectionStart = cmbState.Text.Length;
                }
            }
            catch
            {

            }
            finally
            {
                this.UseWaitCursor = false;
            }

        }

        private void cmbState_DropDownClosed(object sender, EventArgs e)
        {
            Int64 stateValue = Convert.ToInt64(cmbState.SelectedValue);
            if (StateList != null)
                foreach (StateNameSearch state in StateList)
                {
                    if (state.RID == stateValue)
                    {
                        txtCountry.Text = state.Country;
                        txtCountry.Tag = state.CountryID;
                    }
                }
        }

        private void cmbAddressType_Click(object sender, EventArgs e)
        {
            loadCmbAddressType();
        }

        private void btnADD_Click(object sender, EventArgs e)
        {
            if (opValidate())
            {
                UserAddress address = new UserAddress();
                address.AddressTypeID = Convert.ToInt64(cmbAddressType.SelectedValue);
                address.AddressType = cmbAddressType.Text;
                address.Addressline1 = txtAddressLine1.Text;
                address.Addressline2 = txtAddressLine2.Text;
                address.City = txtCity.Text;
                address.StateID = Convert.ToInt64(cmbState.SelectedValue);
                address.State = cmbState.Text;
                address.CountryID = Convert.ToInt64(txtCountry.Tag);
                address.Country = txtCountry.Text;
                address.Pincode = Convert.ToInt32(txtPincode.Text);
                Application.DoEvents();
                Int64 AddressId = opSaveAddress(address);
                Application.DoEvents();
                if (AddressId != 0)
                {
                    address.RID = AddressId;
                    AddressList.Add(address);
                    GridAddress.DataSource = null;
                    GridAddress.DataSource = AddressList;
                    Clear();
                }
            }
        }

        public void SetSkillGrid()
        {
            GridAddress.AutoGenerateColumns = false;
            //Set Columns Count
            GridAddress.ColumnCount = 10;
            GridAddress.Columns[0].Name = "AddressTypeID";
            GridAddress.Columns[0].HeaderText = "AddressTypeID";
            GridAddress.Columns[0].DataPropertyName = "AddressTypeID";
            GridAddress.Columns[0].Visible = false;

            GridAddress.Columns[1].Name = "AddressType";
            GridAddress.Columns[1].HeaderText = "AddressType";
            GridAddress.Columns[1].DataPropertyName = "AddressType";

            GridAddress.Columns[2].Name = "Addressline1";
            GridAddress.Columns[2].HeaderText = "Addressline1";
            GridAddress.Columns[2].DataPropertyName = "Addressline1";

            GridAddress.Columns[3].Name = "Addressline2";
            GridAddress.Columns[3].HeaderText = "Addressline2";
            GridAddress.Columns[3].DataPropertyName = "Addressline2";

            GridAddress.Columns[4].Name = "StateID";
            GridAddress.Columns[4].HeaderText = "StateID";
            GridAddress.Columns[4].DataPropertyName = "StateID";
            GridAddress.Columns[4].Visible = false;

            GridAddress.Columns[5].Name = "City";
            GridAddress.Columns[5].HeaderText = "City";
            GridAddress.Columns[5].DataPropertyName = "City";

            GridAddress.Columns[6].Name = "CountryID";
            GridAddress.Columns[6].HeaderText = "CountryID";
            GridAddress.Columns[6].DataPropertyName = "CountryID";
            GridAddress.Columns[6].Visible = false;

            GridAddress.Columns[7].Name = "Country";
            GridAddress.Columns[7].HeaderText = "Country";
            GridAddress.Columns[7].DataPropertyName = "Country";

            GridAddress.Columns[8].Name = "Pincode";
            GridAddress.Columns[8].HeaderText = "Pincode";
            GridAddress.Columns[8].DataPropertyName = "Pincode";

            GridAddress.Columns[9].Name = "RID";
            GridAddress.Columns[9].HeaderText = "RID";
            GridAddress.Columns[9].DataPropertyName = "RID";
            GridAddress.Columns[9].Visible = false;

        }

        public void Clear()
        {
            cmbAddressType.DataSource = null;
            cmbState.DataSource = null;
            txtAddressLine1.Text = string.Empty;
            txtAddressLine2.Text = string.Empty;
            txtCity.Text = string.Empty;
            txtCountry.Text = string.Empty;
            txtPincode.Text = string.Empty;
        }

        bool opValidate()
        {
            if (Convert.ToInt64(cmbAddressType.SelectedValue) == 0)
            {
                cmbAddressType.Focus();
                return false;
            }
            else if (txtAddressLine1.Text.Trim() == string.Empty)
            {
                txtAddressLine1.Focus();
                return false;
            }
            else if (txtCity.Text == string.Empty)
            {
                txtCity.Focus();
                return false;
            }
            else if (txtCountry.Text == string.Empty)
            {
                txtCountry.Focus();
                return false;
            }
            else if (txtPincode.Text == string.Empty)
            {
                txtPincode.Focus();
                return false;
            }
            else if (Convert.ToInt64(cmbState.SelectedValue) == 0)
            {
                cmbState.Focus();
                return false;
            }
            return true;
        }

        void opSetManditory()
        {
            lblAddressLine1.Text = lblAddressLine1.Text + "*";
            lblAddressLine1.ForeColor = System.Drawing.Color.Red;

            lbladdresstype.Text = lbladdresstype.Text + "*";
            lbladdresstype.ForeColor = System.Drawing.Color.Red;

            lblCity.Text = lblCity.Text + "*";
            lblCity.ForeColor = System.Drawing.Color.Red;

            lblPincode.Text = lblPincode.Text + "*";
            lblPincode.ForeColor = System.Drawing.Color.Red;

            lblcountry.Text = lblcountry.Text + "*";
            lblcountry.ForeColor = System.Drawing.Color.Red;

            lblState.Text = lblState.Text + "*";
            lblState.ForeColor = System.Drawing.Color.Red;
        }

        Int64 opSaveAddress(UserAddress Address)
        {
            var request = (HttpWebRequest)WebRequest.Create(HireLook.Configuration.ApplicationAPI + "user/" + Constants.ResumeId + "/address?enum=resume");
            //var postData = "SectionId=" + sectionSave.SectionId + "&Values=" + sectionSave.Value;
            var data = Encoding.ASCII.GetBytes(JsonConvert.SerializeObject(Address));
            request.Method = "POST";
            request.Headers.Add("Authorization: Bearer " + HireLook.Configuration.access_token);
            request.ContentType = "application/json";
            request.ContentLength = data.Length;

            using (var stream = request.GetRequestStream())
            {
                stream.Write(data, 0, data.Length);
            }

            try
            {
                HttpWebResponse response = (HttpWebResponse)request.GetResponse();
                var responseString = new StreamReader(response.GetResponseStream()).ReadToEnd();
                try
                {
                    ResposeData values = JsonConvert.DeserializeObject<ResposeData>(responseString);
                    return values.RID;
                }
                catch (Exception ex)
                {
                    Log.LogData("Error in frmLogin: Registry value: " + ex.Message + ex.StackTrace, Log.Status.Error);
                    return 0;
                }

            }
            catch (WebException ex)
            {
                Log.LogData("Invalid In Saving Resume Manager: " + ex.Message + ex.StackTrace, Log.Status.Error);
                return 0;
            }
        }

        private void gridEmployment_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Delete)
                opDelete();
        }

        void opDelete()
        {
            if (GridAddress.SelectedRows.Count > 0)
            {
                IList rows = GridAddress.SelectedRows;
                Int64 AddressId = (Int64)GridAddress.SelectedRows[0].Cells["RID"].Value;
                if (opDeleteOperation(AddressId))
                {
                    int selectedIndex = GridAddress.SelectedRows[0].Index;
                    AddressList.RemoveAt(selectedIndex);
                    GridAddress.DataSource = null;
                    GridAddress.DataSource = AddressList;
                }
            }
        }

        bool opDeleteOperation(Int64 AddressId)
        {
            var request = (HttpWebRequest)WebRequest.Create(HireLook.Configuration.ApplicationAPI + "user/" + Constants.ResumeId + "/address/" + AddressId + "?enum=resume");
            //var request = (HttpWebRequest)WebRequest.Create(Convert.ToString(ConfigurationManager.AppSettings["ApplicatonAPI"]) + subUrl);

            request.Method = "DELETE";
            request.ContentType = "application/x-www-form-urlencoded";
            request.Headers.Add("Authorization: Bearer " + HireLook.Configuration.access_token);
            try
            {
                HttpWebResponse response = (HttpWebResponse)request.GetResponse();
                var responseString = new StreamReader(response.GetResponseStream()).ReadToEnd();
                try
                {
                    ResposeData values = JsonConvert.DeserializeObject<ResposeData>(responseString);
                    return true;
                }
                catch (System.Exception ex)
                {
                    Log.LogData("Error in loading master value: " + ex.Message + ex.StackTrace, Log.Status.Error);
                    return false;
                }
            }
            catch (WebException ex)
            {
                Log.LogData("Error in Load Selection: " + ex.Message + ex.StackTrace, Log.Status.Error);
                return false;
            }

        }


    }
}
