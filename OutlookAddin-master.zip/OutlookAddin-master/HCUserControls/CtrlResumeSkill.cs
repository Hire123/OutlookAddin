﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using HireLook;
using System.IO;
using System.Net;
using System.Configuration;
using Newtonsoft.Json;
using System.Collections;
namespace HCUserControls
{
    public partial class CtrlResumeSkill : UserControl
    {

        ControlDetail controls = new ControlDetail();
        ArrayList ResumeSkillArray = new ArrayList();
        ResumeSkill resumeSkill = new ResumeSkill();

        public CtrlResumeSkill()
        {
            InitializeComponent();
        }

        public CtrlResumeSkill(ControlDetail controls)
        {
            InitializeComponent();
            this.controls = controls;
            loadDefaultCmbAddressType();
            loadYear();
            SetSkillGrid();
            opSetMandatory();
        }

        List<NameSearch> loadData(string subURL)
        {
            List<NameSearch> objMaster = new List<NameSearch>();
            var request = (HttpWebRequest)WebRequest.Create(Convert.ToString(ConfigurationManager.AppSettings["ApplicatonAPI"]) + subURL);

            request.Method = "GET";
            request.ContentType = "application/x-www-form-urlencoded";
            request.Headers.Add("Authorization: Bearer " + HireLook.Configuration.access_token);

            try
            {
                HttpWebResponse response = (HttpWebResponse)request.GetResponse();
                var responseString = new StreamReader(response.GetResponseStream()).ReadToEnd();
                try
                {
                    objMaster = JsonConvert.DeserializeObject<List<NameSearch>>(responseString);

                }
                catch (System.Exception ex)
                {
                    Log.LogData("Error in loadSkill result: Registry value: " + ex.Message + ex.StackTrace, Log.Status.Error);
                }
            }
            catch (WebException ex)
            {
                Log.LogData("Error in Load loadSkill: " + ex.Message + ex.StackTrace, Log.Status.Error);
            }
            return objMaster;
        }

        private void cmbSkill_TextUpdate(object sender, EventArgs e)
        {
            Application.DoEvents();
            HandleTextChanged();
            Application.DoEvents();
        }

        void HandleTextChanged()
        {
            try
            {
                if (cmbSkill.Text != string.Empty)
                {
                    List<NameSearch> mstrData = loadData("masters/skills?name=" + cmbSkill.Text);
                    List<string> TitleAry = new List<string>();
                    if (mstrData != null)
                    {
                        if (mstrData.Count > 0)
                        {
                            NameSearch mstrDefault = new NameSearch();
                            mstrDefault.RID = 0;
                            mstrDefault.Title = cmbSkill.Text;
                            mstrData.Insert(0, mstrDefault);
                            cmbSkill.DataSource = mstrData.ToList();
                            //comboBox1.SelectedIndex = 0;
                            var sText = cmbSkill.Items[0].ToString();
                            cmbSkill.SelectionStart = cmbSkill.Text.Length;
                            int SearchKeyLength = sText.Length - cmbSkill.Text.Length;
                            cmbSkill.SelectionLength = (SearchKeyLength == 0) ? 1 : SearchKeyLength;
                            cmbSkill.DroppedDown = true;
                            cmbSkill.ValueMember = "RID";
                            cmbSkill.DisplayMember = "Title";
                            Application.DoEvents();
                        }
                    }
                    else
                    {
                        cmbSkill.DroppedDown = false;
                        cmbSkill.SelectionStart = cmbSkill.Text.Length;
                    }

                }
                else
                {
                    cmbSkill.DroppedDown = false;
                    cmbSkill.SelectionStart = cmbSkill.Text.Length;
                }
            }
            catch (Exception ex)
            {
                Log.LogData("error in resume skill: " + ex.Message + ex.StackTrace, Log.Status.Error);
            }

        }

        void loadProficency()
        {
            List<NameSearch> Proficency = loadData("masters/skillrating");
            if (Proficency != null)
            {
                if (Proficency.Count > 0)
                {
                    cmbFromProficiency.DisplayMember = "Title";
                    cmbFromProficiency.ValueMember = "RID";
                    cmbFromProficiency.DataSource = Proficency;
                }
            }
        }

        void loadDefaultCmbAddressType()
        {
            NameSearch DefaultValue = new NameSearch();
            DefaultValue.RID = 0;
            DefaultValue.Title = "<-- Select -->";
            List<NameSearch> defaultval = new List<NameSearch>();
            defaultval.Add(DefaultValue);
            cmbFromProficiency.DisplayMember = "Title";
            cmbFromProficiency.ValueMember = "RID";
            cmbFromProficiency.DataSource = defaultval;
        }

        void loadYear()
        {
            Int32 Year = Convert.ToInt32(System.DateTime.Now.Year);
            for (Int32 i = Year; i >= 2001; i--)
            {
                cmbLastUserYear.Items.Add(i);
            }
        }

        private void cmbFromProficiency_DropDown(object sender, EventArgs e)
        {
            loadProficency();
        }

        private void btnADDSkill_Click(object sender, EventArgs e)
        {
            try
            {
                this.UseWaitCursor = true;
                if (opValidate())
                {
                    ResumeSkills skilllist = new ResumeSkills();
                    skilllist.SkillId = Convert.ToInt64(cmbSkill.SelectedValue);
                    skilllist.Skill = cmbSkill.Text;
                    skilllist.ResId = Constants.ResumeId;
                    skilllist.Proficiency = cmbFromProficiency.Text;
                    skilllist.ProficiencyId = Convert.ToInt64(cmbFromProficiency.SelectedValue);
                    skilllist.NoofAssignment = Convert.ToInt16((txtnoOfAssignment.Text == "") ? "0" : txtnoOfAssignment.Text);
                    skilllist.LastUsedYear = Convert.ToInt32((cmbLastUserYear.Text == "") ? "2015" : cmbLastUserYear.Text);
                    skilllist.Experience = nmbFromExperience.Value;
                    skilllist.Active = chkCurrentStatus.Checked;
                    ResumeSkillArray.Add(skilllist);
                    saveResumeSkill();

                    gridSkills.DataSource = null;
                    gridSkills.DataSource = ResumeSkillArray;
                    Clear();
                }
            }
            catch (Exception ex)
            {
                Log.LogData("Error in Save Resume skill: " + ex.Message + ex.StackTrace, Log.Status.Error);
            }
            finally
            {
                this.UseWaitCursor = false;
            }
        }

        public void Clear()
        {
            cmbSkill.DataSource = null;
            cmbFromProficiency.DataSource = null;
            cmbLastUserYear.SelectedIndex = 0;
            txtnoOfAssignment.Text = string.Empty;
            nmbFromExperience.Value = 0;
            chkCurrentStatus.Checked = false;
        }

        public void SetSkillGrid()
        {
            gridSkills.AutoGenerateColumns = false;
            //Set Columns Count
            gridSkills.ColumnCount = 9;
            gridSkills.Columns[0].Name = "SkillId";
            gridSkills.Columns[0].HeaderText = "SkillId";
            gridSkills.Columns[0].DataPropertyName = "SkillId";
            gridSkills.Columns[0].Visible = false;

            gridSkills.Columns[1].Name = "Skill";
            gridSkills.Columns[1].HeaderText = "Skill";
            gridSkills.Columns[1].DataPropertyName = "Skill";

            gridSkills.Columns[2].Name = "ResId";
            gridSkills.Columns[2].HeaderText = "ResId";
            gridSkills.Columns[2].DataPropertyName = "ResId";
            gridSkills.Columns[2].Visible = false;

            gridSkills.Columns[3].Name = "Proficiency";
            gridSkills.Columns[3].HeaderText = "Proficiency";
            gridSkills.Columns[3].DataPropertyName = "Proficiency";

            gridSkills.Columns[4].Name = "ProficiencyId";
            gridSkills.Columns[4].HeaderText = "ProficiencyId";
            gridSkills.Columns[4].DataPropertyName = "ProficiencyId";
            gridSkills.Columns[4].Visible = false;

            gridSkills.Columns[5].Name = "Experience";
            gridSkills.Columns[5].HeaderText = "Experience";
            gridSkills.Columns[5].DataPropertyName = "Experience";

            gridSkills.Columns[6].Name = "NoofAssignment";
            gridSkills.Columns[6].HeaderText = "NoofAssignment";
            gridSkills.Columns[6].DataPropertyName = "NoofAssignment";

            gridSkills.Columns[7].Name = "LastUsedYear";
            gridSkills.Columns[7].HeaderText = "Last Used Year";
            gridSkills.Columns[7].DataPropertyName = "LastUsedYear";

            gridSkills.Columns[8].Name = "Active";
            gridSkills.Columns[8].HeaderText = "Active";
            gridSkills.Columns[8].DataPropertyName = "Active";
        }

        void saveResumeSkill()
        {
            resumeSkill.Skills = ResumeSkillArray;
            var request = (HttpWebRequest)WebRequest.Create(HireLook.Configuration.ApplicationAPI + "resume/" + Constants.ResumeId + "/skills");
            //var postData = "SectionId=" + sectionSave.SectionId + "&Values=" + sectionSave.Value;
            var data = Encoding.ASCII.GetBytes(JsonConvert.SerializeObject(resumeSkill));
            request.Method = "PUT";
            request.Headers.Add("Authorization: Bearer " + HireLook.Configuration.access_token);
            request.ContentType = "application/json";
            request.ContentLength = data.Length;

            using (var stream = request.GetRequestStream())
            {
                stream.Write(data, 0, data.Length);
            }

            try
            {
                HttpWebResponse response = (HttpWebResponse)request.GetResponse();
                var responseString = new StreamReader(response.GetResponseStream()).ReadToEnd();

                ResposeData values = JsonConvert.DeserializeObject<ResposeData>(responseString);

                try
                {

                }
                catch (Exception ex)
                {
                    Log.LogData("Error in frmLogin: Registry value: " + ex.Message + ex.StackTrace, Log.Status.Error);
                }

            }
            catch (WebException ex)
            {
                Log.LogData("Invalid In Saving Resume Manager: " + ex.Message + ex.StackTrace, Log.Status.Error);
            }
        }

        Boolean opValidate()
        {
            if (Convert.ToInt64(cmbSkill.SelectedValue) == 0)
            {
                cmbSkill.Focus();
                return false;
            }
            else if (Convert.ToInt64(cmbFromProficiency.SelectedValue) == 0)
            {
                cmbFromProficiency.Focus();
                return false;
            }

            return true;
        }

        void opSetMandatory()
        {
            lblSkill.ForeColor = System.Drawing.Color.Red;
            lblSkill.Text = lblSkill.Text + "*";
            lblProficiency.ForeColor = System.Drawing.Color.Red;
            lblProficiency.Text = lblProficiency.Text + "*";
        }

        private void gridSkills_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Delete)
                opDelete();
        }

        void opDelete()
        {
            if (gridSkills.SelectedRows.Count > 0)
            {
                int selectedIndex = gridSkills.SelectedRows[0].Index;
                ResumeSkillArray.RemoveAt(selectedIndex);
                gridSkills.DataSource = null;
                gridSkills.DataSource = ResumeSkillArray;
            }
        }
    }

    class ResumeSkill
    {
        public object Skills { get; set; }
    }
}
