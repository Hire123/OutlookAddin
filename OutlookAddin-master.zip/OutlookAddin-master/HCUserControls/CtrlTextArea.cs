﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using HireLook;
namespace HCUserControls
{
    public partial class CtrlTextArea : UserControl
    {
        public ControlDetail controls = new ControlDetail();

        public CtrlTextArea()
        {
            InitializeComponent();
        }

        public CtrlTextArea(ControlDetail controls)
        {
            InitializeComponent();
            this.controls = controls;
            if (controls.Mandatory)
            {
                lblName.Text = "*" + this.controls.DisplayName;
                opSetMandatory();
            }
            else
                lblName.Text = this.controls.DisplayName;
        }

        private void lblName_Click(object sender, EventArgs e)
        {

        }

        public string getTextArea()
        {
            return txtAutoArea.Text;
        }

        public void setTextArea(string textArea)
        {
            txtAutoArea.Text = textArea;
        }

        public Boolean opValidate()
        {
            if (controls.Mandatory)
                if (txtAutoArea.Text.Trim() != string.Empty)
                    return true;
                else
                    return false;
            else
                return true;
        }

        void opSetMandatory()
        {
            lblName.ForeColor = System.Drawing.Color.Red;
        }
    }
}
