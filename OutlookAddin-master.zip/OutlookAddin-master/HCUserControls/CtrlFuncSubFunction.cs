﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Net;
using System.Configuration;
using Newtonsoft.Json;
using HireLook;
using System.Collections.ObjectModel;
using System.Collections;
namespace HCUserControls
{
    public partial class CtrlFuncSubFunction : UserControl
    {
        public ControlDetail controls = new ControlDetail();

        List<NameSearch> FunctionData = new List<NameSearch>();
        List<NameSearch> SubfunctionData = new List<NameSearch>();

        ArrayList FunctionId = new ArrayList();
        List<string> FunctionName = new List<string>();
        ArrayList SubFunctionId = new ArrayList();
        List<string> SubFunctionName = new List<string>();

        public CtrlFuncSubFunction()
        {
            InitializeComponent();
        }

        public CtrlFuncSubFunction(ControlDetail contorls)
        {
            InitializeComponent();
            this.controls = contorls;
        }


        private void btnAddFunction_Click(object sender, EventArgs e)
        {
            FrmFunctionSubFunction objFunction = new FrmFunctionSubFunction("Function ", true, FunctionData);
            objFunction.ShowDialog();
            FunctionData = objFunction.opSelectedFunctionSubFunctionDetails();
            objFunction.Dispose();

            foreach (var function in FunctionData)
            {
                FunctionId.Add(function.RID);
                FunctionName.Add(function.Title);
            }
            txtFunction.Text = String.Join(",", FunctionName.ToArray());
            txtFunction.Tag = FunctionId;
        }

        private void btnAddSubFunction_Click(object sender, EventArgs e)
        {
            FrmFunctionSubFunction objFunction = new FrmFunctionSubFunction("Sub Function ", false, FunctionId, SubfunctionData);
            objFunction.ShowDialog();
            SubfunctionData = objFunction.opSelectedFunctionSubFunctionDetails();
            objFunction.Dispose();
            foreach (var Subfunction in SubfunctionData)
            {
                SubFunctionId.Add(Subfunction.RID);
                SubFunctionName.Add(Subfunction.Title);
            }
            txtSubFunction.Tag = SubFunctionId;
            txtSubFunction.Text = string.Join(",", SubFunctionName.ToArray());

        }

        public object getFunctionSubfunctionData()
        {
            FunctionSubFunction funSubFun = new FunctionSubFunction();
            funSubFun.functionalArea = FunctionId;
            funSubFun.subFunctionalArea = SubFunctionId;
            return funSubFun;
        }

    }

    class FunctionSubFunction
    {
        public object functionalArea { get; set; }
        public object subFunctionalArea { get; set; }
    }
}
