﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using HireLook;
using Newtonsoft.Json;
using System.Net;
using System.IO;
using System.Collections;
namespace HCUserControls
{

    public partial class CtrlEducation : UserControl
    {
        public ControlDetail controls = new ControlDetail();
        ArrayList EducationArray = new ArrayList();
        EducationStorage eduStorage = new EducationStorage();

        public CtrlEducation()
        {
            InitializeComponent();
        }

        public CtrlEducation(ControlDetail controls)
        {
            InitializeComponent();
            this.controls = controls;
            opSetMandatory();
            SetSkillGrid();
            setDate();
        }

        void opSetMandatory()
        {
            lblEducationType.ForeColor = System.Drawing.Color.Red; 
            lblEducationType.Text = lblEducationType.Text + "*";
        }

        void loadEducationType()
        {
            try
            {
                if (cmbEducationType.Text != string.Empty)
                {
                    List<NameSearch> mstrData = loadAutoComplete("masters/education?name=" + cmbEducationType.Text);
                    if (mstrData != null)
                    {
                        if (mstrData.Count > 0)
                        {
                            NameSearch mstrDefault = new NameSearch();
                            mstrDefault.RID = 0;
                            mstrDefault.Title = cmbEducationType.Text;
                            mstrData.Insert(0, mstrDefault);
                            cmbEducationType.DataSource = mstrData.ToList();
                            var sText = cmbEducationType.Items[0].ToString();
                            cmbEducationType.SelectionStart = cmbEducationType.Text.Length;
                            cmbEducationType.SelectionLength = sText.Length - cmbEducationType.Text.Length;
                            cmbEducationType.DroppedDown = true;
                            cmbEducationType.ValueMember = "RID";
                            cmbEducationType.DisplayMember = "Title";
                            Application.DoEvents();
                        }
                    }
                    else
                    {
                        cmbEducationType.DroppedDown = false;
                        cmbEducationType.SelectionStart = cmbEducationType.Text.Length;
                    }

                }
                else
                {
                    cmbEducationType.DroppedDown = false;
                    cmbEducationType.SelectionStart = cmbEducationType.Text.Length;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message + ex.StackTrace);
            }

        }

        void loadSpecialization()
        {
            try
            {
                if (cmbSpecilization.Text != string.Empty)
                {
                    List<NameSearch> mstrData = loadAutoComplete("masters/specialization?name=" + cmbSpecilization.Text);
                    if (mstrData != null)
                    {
                        if (mstrData.Count > 0)
                        {
                            NameSearch mstrDefault = new NameSearch();
                            mstrDefault.RID = 0;
                            mstrDefault.Title = cmbSpecilization.Text;
                            mstrData.Insert(0, mstrDefault);
                            cmbSpecilization.DataSource = mstrData.ToList();
                            var sText = cmbSpecilization.Items[0].ToString();
                            cmbSpecilization.SelectionStart = cmbSpecilization.Text.Length;
                            cmbSpecilization.SelectionLength = sText.Length - cmbSpecilization.Text.Length;
                            cmbSpecilization.DroppedDown = true;
                            cmbSpecilization.ValueMember = "RID";
                            cmbSpecilization.DisplayMember = "Title";
                            Application.DoEvents();
                        }
                    }
                    else
                    {
                        cmbSpecilization.DroppedDown = false;
                        cmbSpecilization.SelectionStart = cmbSpecilization.Text.Length;
                    }

                }
                else
                {
                    cmbSpecilization.DroppedDown = false;
                    cmbSpecilization.SelectionStart = cmbSpecilization.Text.Length;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message + ex.StackTrace);
            }

        }

        void loadInstitute()
        {
            try
            {
                if (cmbInstitute.Text != string.Empty)
                {
                    List<NameSearch> mstrData = loadAutoComplete("masters/institute?name=" + cmbInstitute.Text);
                    if (mstrData != null)
                    {
                        if (mstrData.Count > 0)
                        {
                            NameSearch mstrDefault = new NameSearch();
                            mstrDefault.RID = 0;
                            mstrDefault.Title = cmbInstitute.Text;
                            mstrData.Insert(0, mstrDefault);
                            cmbInstitute.DataSource = mstrData.ToList();
                            var sText = cmbInstitute.Items[0].ToString();
                            cmbInstitute.SelectionStart = cmbInstitute.Text.Length;
                            cmbInstitute.SelectionLength = sText.Length - cmbInstitute.Text.Length;
                            cmbInstitute.DroppedDown = true;
                            cmbInstitute.ValueMember = "RID";
                            cmbInstitute.DisplayMember = "Title";
                            Application.DoEvents();
                        }
                    }
                    else
                    {
                        cmbInstitute.DroppedDown = false;
                        cmbInstitute.SelectionStart = cmbInstitute.Text.Length;
                    }

                }
                else
                {
                    cmbInstitute.DroppedDown = false;
                    cmbInstitute.SelectionStart = cmbInstitute.Text.Length;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message + ex.StackTrace);
            }

        }

        void loadUniversity()
        {
            try
            {
                if (cmbUniversity.Text != string.Empty)
                {
                    List<NameSearch> mstrData = loadAutoComplete("masters/university?name=" + cmbUniversity.Text);
                    if (mstrData != null)
                    {
                        if (mstrData.Count > 0)
                        {
                            NameSearch mstrDefault = new NameSearch();
                            mstrDefault.RID = 0;
                            mstrDefault.Title = cmbUniversity.Text;
                            mstrData.Insert(0, mstrDefault);
                            cmbUniversity.DataSource = mstrData.ToList();
                            var sText = cmbUniversity.Items[0].ToString();
                            cmbUniversity.SelectionStart = cmbUniversity.Text.Length;
                            cmbUniversity.SelectionLength = sText.Length - cmbUniversity.Text.Length;
                            cmbUniversity.DroppedDown = true;
                            cmbUniversity.ValueMember = "RID";
                            cmbUniversity.DisplayMember = "Title";
                            Application.DoEvents();
                        }
                    }
                    else
                    {
                        cmbUniversity.DroppedDown = false;
                        cmbUniversity.SelectionStart = cmbUniversity.Text.Length;
                    }

                }
                else
                {
                    cmbUniversity.DroppedDown = false;
                    cmbUniversity.SelectionStart = cmbUniversity.Text.Length;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message + ex.StackTrace);
            }

        }

        List<NameSearch> loadAutoComplete(string Autocompleteurl)
        {
            List<NameSearch> objMaster = new List<NameSearch>();
            var request = (HttpWebRequest)WebRequest.Create(Configuration.ApplicationAPI + Autocompleteurl);

            request.Method = "GET";
            request.ContentType = "application/x-www-form-urlencoded";
            request.Headers.Add("Authorization: Bearer " + HireLook.Configuration.access_token);

            try
            {
                HttpWebResponse response = (HttpWebResponse)request.GetResponse();
                var responseString = new StreamReader(response.GetResponseStream()).ReadToEnd();
                try
                {
                    objMaster = JsonConvert.DeserializeObject<List<NameSearch>>(responseString);
                }
                catch (System.Exception ex)
                {
                    Log.LogData("Error in loadAutoComplete: Error in parsing the Data from server: " + ex.Message + ex.StackTrace, Log.Status.Error);
                }
            }
            catch (WebException ex)
            {
                Log.LogData("Error in loadAutoComplete: Getting Data from Server: " + ex.Message + ex.StackTrace, Log.Status.Error);
            }
            return objMaster;
        }

        private void cmbEducationType_TextUpdate(object sender, EventArgs e)
        {
            Application.DoEvents();
            loadEducationType();
            Application.DoEvents();
        }

        private void cmbSpecilization_TextUpdate(object sender, EventArgs e)
        {
            Application.DoEvents();
            loadSpecialization();
            Application.DoEvents();
        }

        private void cmbUniversity_TextUpdate(object sender, EventArgs e)
        {
            Application.DoEvents();
            loadUniversity();
            Application.DoEvents();
        }

        private void cmbInstitute_TextUpdate(object sender, EventArgs e)
        {
            Application.DoEvents();
            loadInstitute();
            Application.DoEvents();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            if (opValidate())
            {
                ResumeEducation education = new ResumeEducation();
                education.Education = cmbEducationType.Text;
                education.EducationID = Convert.ToInt64(cmbEducationType.SelectedValue);
                education.Specialization = cmbSpecilization.Text;
                education.SpecializationID = Convert.ToInt64(cmbSpecilization.SelectedValue);
                education.UniversityID = Convert.ToInt64(cmbUniversity.SelectedValue);
                education.InstituteID = Convert.ToInt64(cmbInstitute.SelectedValue);
                education.UniversityName = cmbUniversity.Text;
                education.Institute = string.Empty;
                education.InstituteName = cmbInstitute.Text;
                if (dtFromDate.CustomFormat == " ")
                    education.FromDate = "";
                else
                    education.FromDate = dtFromDate.Value.ToString("dd-MMM-yyyy");

                if (dtToDate.CustomFormat == " ")
                    education.ToDate = "";
                else
                    education.ToDate = dtToDate.Value.ToString("dd-MMM-yyyy");
               
                education.Grade = txtGrade.Text;
                education.GapInEdu = chkGapEducation.Checked;
                education.Notes = txtAutoArea.Text;
                Application.DoEvents();
                EducationArray.Add(education);
                Application.DoEvents();
                eduStorage.Education = EducationArray;
                opSaveEducation();
                gridEmployment.DataSource = null;
                gridEmployment.DataSource = EducationArray;
                Clear();
                setDate();
            }

        }

        public void SetSkillGrid()
        {
            gridEmployment.AutoGenerateColumns = false;
            //Set Columns Count
            gridEmployment.ColumnCount = 10;
            gridEmployment.Columns[0].Name = "EducationID";
            gridEmployment.Columns[0].HeaderText = "EducationID";
            gridEmployment.Columns[0].DataPropertyName = "EducationID";
            gridEmployment.Columns[0].Visible = false;

            gridEmployment.Columns[1].Name = "Education";
            gridEmployment.Columns[1].HeaderText = "Education";
            gridEmployment.Columns[1].DataPropertyName = "Education";

            gridEmployment.Columns[2].Name = "SpecializationID";
            gridEmployment.Columns[2].HeaderText = "SpecializationID";
            gridEmployment.Columns[2].DataPropertyName = "SpecializationID";
            gridEmployment.Columns[2].Visible = false;

            gridEmployment.Columns[3].Name = "Specialization";
            gridEmployment.Columns[3].HeaderText = "Specialization";
            gridEmployment.Columns[3].DataPropertyName = "Specialization";

            gridEmployment.Columns[4].Name = "UniversityID";
            gridEmployment.Columns[4].HeaderText = "UniversityID";
            gridEmployment.Columns[4].DataPropertyName = "UniversityID";
            gridEmployment.Columns[4].Visible = false;

            gridEmployment.Columns[5].Name = "UniversityName";
            gridEmployment.Columns[5].HeaderText = "UniversityName";
            gridEmployment.Columns[5].DataPropertyName = "UniversityName";


            gridEmployment.Columns[6].Name = "InstituteID";
            gridEmployment.Columns[6].HeaderText = "InstituteID";
            gridEmployment.Columns[6].DataPropertyName = "InstituteID";
            gridEmployment.Columns[6].Visible = false;


            gridEmployment.Columns[7].Name = "Grade";
            gridEmployment.Columns[7].HeaderText = "Grade";
            gridEmployment.Columns[7].DataPropertyName = "Grade";

            gridEmployment.Columns[8].Name = "StartDate";
            gridEmployment.Columns[8].HeaderText = "StartDate";
            gridEmployment.Columns[8].DataPropertyName = "StartDate";

            gridEmployment.Columns[9].Name = "Enddate";
            gridEmployment.Columns[9].HeaderText = "End Date";
            gridEmployment.Columns[9].DataPropertyName = "Enddate";
        }

        void opSaveEducation()
        {
            var request = (HttpWebRequest)WebRequest.Create(HireLook.Configuration.ApplicationAPI + "resume/" + Constants.ResumeId + "/education");
            var data = Encoding.ASCII.GetBytes(JsonConvert.SerializeObject(eduStorage));
            request.Method = "PUT";
            request.Headers.Add("Authorization: Bearer " + HireLook.Configuration.access_token);
            request.ContentType = "application/json";
            request.ContentLength = data.Length;

            using (var stream = request.GetRequestStream())
            {
                stream.Write(data, 0, data.Length);
            }

            try
            {
                HttpWebResponse response = (HttpWebResponse)request.GetResponse();
                var responseString = new StreamReader(response.GetResponseStream()).ReadToEnd();

                ResposeData values = JsonConvert.DeserializeObject<ResposeData>(responseString);

                try
                {

                }
                catch (Exception ex)
                {
                    Log.LogData("Error in frmLogin: Registry value: " + ex.Message + ex.StackTrace, Log.Status.Error);
                }

            }
            catch (WebException ex)
            {
                Log.LogData("Invalid In Saving Resume Manager: " + ex.Message + ex.StackTrace, Log.Status.Error);
            }
        }

        public void Clear()
        {
            cmbEducationType.DataSource = null;
            cmbSpecilization.DataSource = null;
            cmbUniversity.DataSource = null;
            cmbInstitute.DataSource = null;
            txtGrade.Text = string.Empty;
            txtAutoArea.Text = string.Empty;
            chkGapEducation.Checked = false;
            dtToDate.Value = System.DateTime.Now;
            dtFromDate.Value = System.DateTime.Now;
        }

        Boolean opValidate()
        {
            if (Convert.ToInt64(cmbEducationType.SelectedValue) == 0)
                return false;
            return true;

        }

        void opDelete()
        {
            if (gridEmployment.SelectedRows.Count > 0)
            {
                int selectedIndex = gridEmployment.SelectedRows[0].Index;
                EducationArray.RemoveAt(selectedIndex);
                gridEmployment.DataSource = null;
                gridEmployment.DataSource = EducationArray;
            }
        }

        private void gridEmployment_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Delete)
                opDelete();
        }

        void setDate()
        {
            dtFromDate.Format = DateTimePickerFormat.Custom;
            dtFromDate.CustomFormat = " ";
            dtToDate.Format = DateTimePickerFormat.Custom;
            dtToDate.CustomFormat = " ";
        }

        private void dtFromDate_ValueChanged(object sender, EventArgs e)
        {
            dtFromDate.Format = DateTimePickerFormat.Custom;
            dtFromDate.CustomFormat = "dd-MMM-yyyy";
        }

        private void dtToDate_ValueChanged(object sender, EventArgs e)
        {
            dtToDate.Format = DateTimePickerFormat.Custom;
            dtToDate.CustomFormat = "dd-MMM-yyyy";
        }
        
    }



    class EducationStorage
    {
        public object Education { get; set; }
    }
}
