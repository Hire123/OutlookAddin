﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Net;
using System.Configuration;
using Newtonsoft.Json;
using HireLook;
namespace HCUserControls
{
    public partial class CtrlAutoComplete : UserControl
    {
        ControlDetail controls = new ControlDetail();

        public CtrlAutoComplete()
        {
            InitializeComponent();
        }

        public CtrlAutoComplete(ControlDetail controls)
        {
            InitializeComponent();
            this.controls = controls;
            if (this.controls.Mandatory)
            {
                lblName.Text = "*" + this.controls.DisplayName;
                opSetMandatory();
            }

            else
                lblName.Text = this.controls.DisplayName;
        }

        void HandleTextChanged()
        {
            try
            {

                if (cmbDropdown.Text != string.Empty)
                {

                    List<NameSearch> mstrData = loadAutoComplete(cmbDropdown.Text);
                    List<string> TitleAry = new List<string>();
                    if (mstrData != null)
                    {
                        if (mstrData.Count > 0)
                        {
                            NameSearch mstrDefault = new NameSearch();
                            mstrDefault.RID = 0;
                            mstrDefault.Title = cmbDropdown.Text;
                            mstrData.Insert(0, mstrDefault);
                            cmbDropdown.DataSource = mstrData.ToList();
                            //comboBox1.SelectedIndex = 0;
                            var sText = cmbDropdown.Items[0].ToString();
                            cmbDropdown.SelectionStart = cmbDropdown.Text.Length;
                            cmbDropdown.SelectionLength = sText.Length - cmbDropdown.Text.Length;
                            cmbDropdown.DroppedDown = true;
                            cmbDropdown.ValueMember = "RID";
                            cmbDropdown.DisplayMember = "Title";
                            Application.DoEvents();
                        }
                    }
                    else
                    {
                        cmbDropdown.DroppedDown = false;
                        cmbDropdown.SelectionStart = cmbDropdown.Text.Length;
                    }

                }
                else
                {
                    cmbDropdown.DroppedDown = false;
                    cmbDropdown.SelectionStart = cmbDropdown.Text.Length;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message + ex.StackTrace);
            }

        }

        List<NameSearch> loadAutoComplete(string skilltext)
        {
            List<NameSearch> objMaster = new List<NameSearch>();
            var request = (HttpWebRequest)WebRequest.Create(Convert.ToString(ConfigurationManager.AppSettings["ApplicatonAPI"]) + this.controls.DataToLoad + skilltext);

            request.Method = "GET";
            request.ContentType = "application/x-www-form-urlencoded";
            request.Headers.Add("Authorization: Bearer " + HireLook.Configuration.access_token);

            try
            {
                HttpWebResponse response = (HttpWebResponse)request.GetResponse();
                var responseString = new StreamReader(response.GetResponseStream()).ReadToEnd();
                try
                {
                    objMaster = JsonConvert.DeserializeObject<List<NameSearch>>(responseString);
                }
                catch (System.Exception ex)
                {
                    Log.LogData("Error in loadAutoComplete: Error in parsing the Data from server: " + ex.Message + ex.StackTrace, Log.Status.Error);
                }
            }
            catch (WebException ex)
            {
                Log.LogData("Error in loadAutoComplete: Getting Data from Server: " + ex.Message + ex.StackTrace, Log.Status.Error);
            }
            return objMaster;
        }

        private void cmbDropdown_TextUpdate(object sender, EventArgs e)
        {
            try
            {
                this.UseWaitCursor = true;
                HandleTextChanged();
            }
            catch
            {

            }
            finally
            {
                this.UseWaitCursor = false;
            }
            
        }

        void opSetMandatory()
        {
            lblName.ForeColor = System.Drawing.Color.Red;
        }

        public Boolean opValidate()
        {
            if (controls.Mandatory)
            {
                if (Convert.ToInt64(cmbDropdown.SelectedValue) != 0)
                    return true;
                else
                {
                    cmbDropdown.Focus();
                    return false;
                }
            }
            else
                return true;
        }
    }
}
