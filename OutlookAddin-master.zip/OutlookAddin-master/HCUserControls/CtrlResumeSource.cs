﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Net;
using Newtonsoft.Json;
using HireLook;
namespace HCUserControls
{
    public partial class CtrlResumeSource : UserControl
    {
        public ControlDetail controls = new ControlDetail();
        Int64 SourceId = 0;
        List<ResumeSourceNameSearch> ResumeSrcNameList = new List<ResumeSourceNameSearch>();
        public CtrlResumeSource()
        {
            InitializeComponent();
        }

        public CtrlResumeSource(ControlDetail controls)
        {
            InitializeComponent();
            this.controls = controls;
            opSetMandatory();
        }

        void LoadSourceName()
        {
            try
            {
                if (cmbSourceName.Text != string.Empty)
                {
                    Application.DoEvents();
                    ResumeSrcNameList = loadAutoCompleteSourceName("masters/resumesource?name=" + cmbSourceName.Text + "&withgroup=true");
                    Application.DoEvents();
                    if (ResumeSrcNameList != null)
                    {
                        if (ResumeSrcNameList.Count > 0)
                        {
                            ResumeSourceNameSearch mstrDefault = new ResumeSourceNameSearch();
                            mstrDefault.RID = 0;
                            mstrDefault.Title = cmbSourceName.Text;
                            ResumeSrcNameList.Insert(0, mstrDefault);
                            cmbSourceName.DataSource = ResumeSrcNameList.ToList();
                            var sText = cmbSourceName.Items[0].ToString();
                            cmbSourceName.SelectionStart = cmbSourceName.Text.Length;
                            cmbSourceName.SelectionLength = sText.Length - cmbSourceName.Text.Length;
                            cmbSourceName.DroppedDown = true;
                            cmbSourceName.ValueMember = "RID";
                            cmbSourceName.DisplayMember = "Title";
                        }
                    }
                    else
                    {
                        cmbSourceName.DroppedDown = false;
                        cmbSourceName.SelectionStart = cmbSourceName.Text.Length;
                    }

                }
                else
                {
                    cmbSourceName.DroppedDown = false;
                    cmbSourceName.SelectionStart = cmbSourceName.Text.Length;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message + ex.StackTrace);
            }

        }

        private List<ResumeSourceNameSearch> loadAutoCompleteSourceName(string Autocompleteurl)
        {
            List<ResumeSourceNameSearch> objMaster = new List<ResumeSourceNameSearch>();
            var request = (HttpWebRequest)WebRequest.Create(Configuration.ApplicationAPI + Autocompleteurl);

            request.Method = "GET";
            request.ContentType = "application/x-www-form-urlencoded";
            request.Headers.Add("Authorization: Bearer " + HireLook.Configuration.access_token);

            try
            {
                HttpWebResponse response = (HttpWebResponse)request.GetResponse();
                var responseString = new StreamReader(response.GetResponseStream()).ReadToEnd();
                try
                {
                    objMaster = JsonConvert.DeserializeObject<List<ResumeSourceNameSearch>>(responseString);
                }
                catch (System.Exception ex)
                {
                    Log.LogData("Error in loadAutoComplete: Error in parsing the Data from server: " + ex.Message + ex.StackTrace, Log.Status.Error);
                }
            }
            catch (WebException ex)
            {
                Log.LogData("Error in loadAutoComplete: Getting Data from Server: " + ex.Message + ex.StackTrace, Log.Status.Error);
            }
            return objMaster;
        }

        void loadSourceUser()
        {
            try
            {
                if (cmbSrcUser.Text != string.Empty)
                {
                    Application.DoEvents();
                    List<GetUserName> mstrData = loadAutoCompleteSourceUser("user/" + SourceId + "?name=" + cmbSrcUser.Text);
                    Application.DoEvents();
                    if (mstrData != null)
                    {
                        if (mstrData.Count > 0)
                        {
                            GetUserName mstrDefault = new GetUserName();
                            mstrDefault.RID = 0;
                            mstrDefault.Name = cmbSrcUser.Text;
                            mstrData.Insert(0, mstrDefault);
                            cmbSrcUser.DataSource = mstrData.ToList();
                            var sText = cmbSrcUser.Items[0].ToString();
                            cmbSrcUser.SelectionStart = cmbSrcUser.Text.Length;
                            cmbSrcUser.SelectionLength = sText.Length - cmbSrcUser.Text.Length;
                            cmbSrcUser.DroppedDown = true;
                            cmbSrcUser.ValueMember = "RID";
                            cmbSrcUser.DisplayMember = "Name";
                        }
                    }
                    else
                    {
                        cmbSrcUser.DroppedDown = false;
                        cmbSrcUser.SelectionStart = cmbSrcUser.Text.Length;
                    }

                }
                else
                {
                    cmbSrcUser.DroppedDown = false;
                    cmbSrcUser.SelectionStart = cmbSrcUser.Text.Length;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message + ex.StackTrace);
            }

        }

        List<GetUserName> loadAutoCompleteSourceUser(string Autocompleteurl)
        {
            List<GetUserName> objMaster = new List<GetUserName>();
            var request = (HttpWebRequest)WebRequest.Create(Configuration.ApplicationAPI + Autocompleteurl);

            request.Method = "GET";
            request.ContentType = "application/x-www-form-urlencoded";
            request.Headers.Add("Authorization: Bearer " + HireLook.Configuration.access_token);

            try
            {
                HttpWebResponse response = (HttpWebResponse)request.GetResponse();
                var responseString = new StreamReader(response.GetResponseStream()).ReadToEnd();
                try
                {
                    objMaster = JsonConvert.DeserializeObject<List<GetUserName>>(responseString);
                }
                catch (System.Exception ex)
                {
                    Log.LogData("Error in loadAutoComplete: Error in parsing the Data from server: " + ex.Message + ex.StackTrace, Log.Status.Error);
                }
            }
            catch (WebException ex)
            {
                Log.LogData("Error in loadAutoComplete: Getting Data from Server: " + ex.Message + ex.StackTrace, Log.Status.Error);
            }
            return objMaster;
        }

        private void cmbSourceName_TextUpdate(object sender, EventArgs e)
        {
            LoadSourceName();
        }

        private void cmbSrcUser_TextUpdate(object sender, EventArgs e)
        {
            loadSourceUser();
        }

        private void cmbSourceName_DropDownClosed(object sender, EventArgs e)
        {
            SourceId = Convert.ToInt64(cmbSourceName.SelectedValue);
            if (ResumeSrcNameList != null)
                foreach (ResumeSourceNameSearch state in ResumeSrcNameList)
                {
                    if (state.RID == SourceId)
                    {
                        txtSrcGroup.Text = state.SourceGroup;
                        txtSrcGroup.Tag = state.SourceGroupID;
                    }
                }

        }

        public object getResumeCtrlValue()
        {
            ResumeSource resumeSourc = new ResumeSource();
            resumeSourc.SourceId = Convert.ToInt64(cmbSourceName.SelectedValue);
            resumeSourc.SourceGroupId = Convert.ToInt64(txtSrcGroup.Tag);
            resumeSourc.SourceGroupName = txtSrcGroup.Text;
            resumeSourc.SourceUserId = Convert.ToInt64(cmbSrcUser.SelectedValue);
            return resumeSourc;
        }

        void opSetMandatory()
        {
            lblsrcName.ForeColor = System.Drawing.Color.Red;
            lblsrcName.Text = lblsrcName.Text + "*";
            lblSrcUser.ForeColor = System.Drawing.Color.Red;
            lblSrcUser.Text = lblSrcUser.Text + "*";
        }

        public Boolean opValidate()
        {
            if (Convert.ToInt64(cmbSourceName.SelectedValue) == 0)
            {
                cmbSourceName.Focus();
                return false;
            }
            else if (Convert.ToInt64(cmbSrcUser.SelectedValue) == 0)
            {
                cmbSrcUser.Focus();
                return false;
            }

            return true;
        }
    }

    public class ResumeSource
    {
        public Int64 SourceId { get; set; }
        public Int64 SourceGroupId { get; set; }
        public string SourceGroupName { get; set; }
        public Int64 SourceUserId { get; set; }
    }
}
