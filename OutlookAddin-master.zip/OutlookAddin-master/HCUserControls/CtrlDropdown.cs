﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net;
using System.IO;
using Newtonsoft.Json;
using System.Configuration;
using HireLook;
namespace HCUserControls
{
    public partial class CtrlDropdown : UserControl
    {
        public ControlDetail controls = new ControlDetail();
        public CtrlDropdown()
        {
            InitializeComponent();
        }

        public CtrlDropdown(ControlDetail controls)
        {
            InitializeComponent();
            this.controls = controls;
            if (this.controls.Mandatory)
            {
                lblName.Text = "*" + this.controls.DisplayName;
                opSetMandatory();
            }
            else
                lblName.Text = this.controls.DisplayName;
            loadDefaultCmbAddressType();
        }

        void loadDefaultCmbAddressType()
        {
            NameSearch DefaultValue = new NameSearch();
            DefaultValue.RID = 0;
            DefaultValue.Title = "<-- Select -->";
            List<NameSearch> defaultval = new List<NameSearch>();
            defaultval.Add(DefaultValue);
            cmbDropdown.DisplayMember = "Title";
            cmbDropdown.ValueMember = "RID";
            cmbDropdown.DataSource = defaultval;
        }

        void loadDropdownValue()
        {
            try
            {
                cmbDropdown.UseWaitCursor = true;
                List<NameSearch> LoadMasterData = LoadDropDown();
                if (LoadMasterData != null)
                {
                    if (LoadMasterData.Count > 0)
                    {
                        cmbDropdown.DisplayMember = "Title";
                        cmbDropdown.ValueMember = "RID";
                        cmbDropdown.DataSource = LoadMasterData;
                    }
                }
            }
            catch (Exception ex)
            {
                Log.LogData("Error in load Dropdown: " + ex.Message + ex.StackTrace, Log.Status.Error);
            }
            finally
            {
                cmbDropdown.UseWaitCursor = false;
            }
        }

        List<NameSearch> LoadDropDown()
        {
            var request = (HttpWebRequest)WebRequest.Create(Convert.ToString(ConfigurationManager.AppSettings["ApplicatonAPI"]) + controls.DataToLoad);

            request.Method = "GET";
            request.ContentType = "application/x-www-form-urlencoded";
            request.Headers.Add("Authorization: Bearer " + HireLook.Configuration.access_token);
            List<NameSearch> LoadMasterData = new List<NameSearch>();
            try
            {
                HttpWebResponse response = (HttpWebResponse)request.GetResponse();
                var responseString = new StreamReader(response.GetResponseStream()).ReadToEnd();
                try
                {
                    LoadMasterData = JsonConvert.DeserializeObject<List<NameSearch>>(responseString);
                }
                catch (System.Exception ex)
                {
                    Log.LogData("Error in loading master value: " + ex.Message + ex.StackTrace, Log.Status.Error);
                }
            }
            catch (WebException ex)
            {
                Log.LogData("Error in Load Selection: " + ex.Message + ex.StackTrace, Log.Status.Error);
            }
            return LoadMasterData;
        }

        private void CtrlDropdown_Click(object sender, EventArgs e)
        {
            Application.DoEvents();
            loadDropdownValue();
            Application.DoEvents();
        }

        private void cmbDropdown_MouseCaptureChanged(object sender, EventArgs e)
        {
            Application.DoEvents();
            loadDropdownValue();
            Application.DoEvents();
        }

        public Int64 getDropDownValue()
        {
            Int64 value = Convert.ToInt64(cmbDropdown.SelectedValue);
            return value;
        }

        public Boolean opValidate()
        {
            if (controls.Mandatory)
            {
                if (Convert.ToInt64(cmbDropdown.SelectedValue) != 0)
                    return true;
                else
                    return false;
            }
            else
                return true;
        }

        void opSetMandatory()
        {
            lblName.ForeColor = System.Drawing.Color.Red;
        }
    }

}
