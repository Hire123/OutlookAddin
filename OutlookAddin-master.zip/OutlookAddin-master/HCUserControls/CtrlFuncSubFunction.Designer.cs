﻿namespace HCUserControls
{
    partial class CtrlFuncSubFunction
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.btnAddFunction = new System.Windows.Forms.Button();
            this.btnAddSubFunction = new System.Windows.Forms.Button();
            this.txtFunction = new System.Windows.Forms.TextBox();
            this.txtSubFunction = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(24, 9);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(54, 15);
            this.label1.TabIndex = 12;
            this.label1.Text = "Function";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(-1, 37);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(79, 15);
            this.label2.TabIndex = 14;
            this.label2.Text = "Sub Function";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // btnAddFunction
            // 
            this.btnAddFunction.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnAddFunction.Location = new System.Drawing.Point(235, 6);
            this.btnAddFunction.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnAddFunction.Name = "btnAddFunction";
            this.btnAddFunction.Size = new System.Drawing.Size(56, 25);
            this.btnAddFunction.TabIndex = 39;
            this.btnAddFunction.Text = "Add";
            this.btnAddFunction.UseVisualStyleBackColor = true;
            this.btnAddFunction.Click += new System.EventHandler(this.btnAddFunction_Click);
            // 
            // btnAddSubFunction
            // 
            this.btnAddSubFunction.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnAddSubFunction.Location = new System.Drawing.Point(235, 35);
            this.btnAddSubFunction.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.btnAddSubFunction.Name = "btnAddSubFunction";
            this.btnAddSubFunction.Size = new System.Drawing.Size(56, 23);
            this.btnAddSubFunction.TabIndex = 40;
            this.btnAddSubFunction.Text = "Add";
            this.btnAddSubFunction.UseVisualStyleBackColor = true;
            this.btnAddSubFunction.Click += new System.EventHandler(this.btnAddSubFunction_Click);
            // 
            // txtFunction
            // 
            this.txtFunction.Enabled = false;
            this.txtFunction.Location = new System.Drawing.Point(84, 7);
            this.txtFunction.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txtFunction.Name = "txtFunction";
            this.txtFunction.Size = new System.Drawing.Size(147, 20);
            this.txtFunction.TabIndex = 41;
            // 
            // txtSubFunction
            // 
            this.txtSubFunction.Enabled = false;
            this.txtSubFunction.Location = new System.Drawing.Point(84, 36);
            this.txtSubFunction.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.txtSubFunction.Name = "txtSubFunction";
            this.txtSubFunction.Size = new System.Drawing.Size(147, 20);
            this.txtSubFunction.TabIndex = 42;
            // 
            // CtrlFuncSubFunction
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.txtSubFunction);
            this.Controls.Add(this.txtFunction);
            this.Controls.Add(this.btnAddSubFunction);
            this.Controls.Add(this.btnAddFunction);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "CtrlFuncSubFunction";
            this.Size = new System.Drawing.Size(303, 67);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnAddFunction;
        private System.Windows.Forms.Button btnAddSubFunction;
        private System.Windows.Forms.TextBox txtFunction;
        private System.Windows.Forms.TextBox txtSubFunction;
    }
}
