﻿namespace HCUserControls
{
    partial class CtrlResumeSkill
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtnoOfAssignment = new System.Windows.Forms.TextBox();
            this.lblAssignment = new System.Windows.Forms.Label();
            this.lblProficiency = new System.Windows.Forms.Label();
            this.cmbFromProficiency = new System.Windows.Forms.ComboBox();
            this.chkCurrentStatus = new System.Windows.Forms.CheckBox();
            this.label4 = new System.Windows.Forms.Label();
            this.nmbFromExperience = new System.Windows.Forms.NumericUpDown();
            this.label3 = new System.Windows.Forms.Label();
            this.cmbLastUserYear = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.btnADDSkill = new System.Windows.Forms.Button();
            this.lblSkill = new System.Windows.Forms.Label();
            this.cmbSkill = new System.Windows.Forms.ComboBox();
            this.gridSkills = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.nmbFromExperience)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridSkills)).BeginInit();
            this.SuspendLayout();
            // 
            // txtnoOfAssignment
            // 
            this.txtnoOfAssignment.Location = new System.Drawing.Point(157, 114);
            this.txtnoOfAssignment.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.txtnoOfAssignment.Name = "txtnoOfAssignment";
            this.txtnoOfAssignment.Size = new System.Drawing.Size(193, 22);
            this.txtnoOfAssignment.TabIndex = 3;
            // 
            // lblAssignment
            // 
            this.lblAssignment.AutoSize = true;
            this.lblAssignment.Location = new System.Drawing.Point(8, 117);
            this.lblAssignment.Name = "lblAssignment";
            this.lblAssignment.Size = new System.Drawing.Size(118, 17);
            this.lblAssignment.TabIndex = 2;
            this.lblAssignment.Text = "No of assignment";
            // 
            // lblProficiency
            // 
            this.lblProficiency.AutoSize = true;
            this.lblProficiency.Location = new System.Drawing.Point(57, 36);
            this.lblProficiency.Name = "lblProficiency";
            this.lblProficiency.Size = new System.Drawing.Size(77, 17);
            this.lblProficiency.TabIndex = 9;
            this.lblProficiency.Text = "Proficiency";
            // 
            // cmbFromProficiency
            // 
            this.cmbFromProficiency.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbFromProficiency.FormattingEnabled = true;
            this.cmbFromProficiency.Location = new System.Drawing.Point(157, 33);
            this.cmbFromProficiency.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.cmbFromProficiency.Name = "cmbFromProficiency";
            this.cmbFromProficiency.Size = new System.Drawing.Size(193, 24);
            this.cmbFromProficiency.TabIndex = 11;
            this.cmbFromProficiency.DropDown += new System.EventHandler(this.cmbFromProficiency_DropDown);
            this.cmbFromProficiency.MouseCaptureChanged += new System.EventHandler(this.cmbFromProficiency_DropDown);
            // 
            // chkCurrentStatus
            // 
            this.chkCurrentStatus.AutoSize = true;
            this.chkCurrentStatus.Location = new System.Drawing.Point(157, 91);
            this.chkCurrentStatus.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.chkCurrentStatus.Name = "chkCurrentStatus";
            this.chkCurrentStatus.Size = new System.Drawing.Size(18, 17);
            this.chkCurrentStatus.TabIndex = 17;
            this.chkCurrentStatus.UseVisualStyleBackColor = true;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(33, 92);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(99, 17);
            this.label4.TabIndex = 16;
            this.label4.Text = "Current Status";
            // 
            // nmbFromExperience
            // 
            this.nmbFromExperience.Location = new System.Drawing.Point(157, 63);
            this.nmbFromExperience.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.nmbFromExperience.Name = "nmbFromExperience";
            this.nmbFromExperience.Size = new System.Drawing.Size(195, 22);
            this.nmbFromExperience.TabIndex = 20;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(53, 68);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(78, 17);
            this.label3.TabIndex = 18;
            this.label3.Text = "Experience";
            // 
            // cmbLastUserYear
            // 
            this.cmbLastUserYear.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbLastUserYear.FormattingEnabled = true;
            this.cmbLastUserYear.Location = new System.Drawing.Point(157, 142);
            this.cmbLastUserYear.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.cmbLastUserYear.Name = "cmbLastUserYear";
            this.cmbLastUserYear.Size = new System.Drawing.Size(195, 24);
            this.cmbLastUserYear.TabIndex = 22;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(31, 144);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(102, 17);
            this.label6.TabIndex = 21;
            this.label6.Text = "Last used year";
            // 
            // btnADDSkill
            // 
            this.btnADDSkill.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnADDSkill.Location = new System.Drawing.Point(157, 176);
            this.btnADDSkill.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.btnADDSkill.Name = "btnADDSkill";
            this.btnADDSkill.Size = new System.Drawing.Size(115, 32);
            this.btnADDSkill.TabIndex = 23;
            this.btnADDSkill.Text = "Add Skills";
            this.btnADDSkill.UseVisualStyleBackColor = true;
            this.btnADDSkill.Click += new System.EventHandler(this.btnADDSkill_Click);
            // 
            // lblSkill
            // 
            this.lblSkill.AutoSize = true;
            this.lblSkill.Location = new System.Drawing.Point(97, 10);
            this.lblSkill.Name = "lblSkill";
            this.lblSkill.Size = new System.Drawing.Size(40, 17);
            this.lblSkill.TabIndex = 24;
            this.lblSkill.Text = "Skills";
            // 
            // cmbSkill
            // 
            this.cmbSkill.FormattingEnabled = true;
            this.cmbSkill.Location = new System.Drawing.Point(157, 5);
            this.cmbSkill.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.cmbSkill.Name = "cmbSkill";
            this.cmbSkill.Size = new System.Drawing.Size(195, 24);
            this.cmbSkill.TabIndex = 37;
            this.cmbSkill.TextUpdate += new System.EventHandler(this.cmbSkill_TextUpdate);
            // 
            // gridSkills
            // 
            this.gridSkills.AllowUserToAddRows = false;
            this.gridSkills.BackgroundColor = System.Drawing.SystemColors.Window;
            this.gridSkills.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.gridSkills.GridColor = System.Drawing.SystemColors.Window;
            this.gridSkills.Location = new System.Drawing.Point(13, 222);
            this.gridSkills.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.gridSkills.MultiSelect = false;
            this.gridSkills.Name = "gridSkills";
            this.gridSkills.RowTemplate.Height = 24;
            this.gridSkills.Size = new System.Drawing.Size(664, 126);
            this.gridSkills.TabIndex = 38;
            this.gridSkills.KeyDown += new System.Windows.Forms.KeyEventHandler(this.gridSkills_KeyDown);
            // 
            // CtrlResumeSkill
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.gridSkills);
            this.Controls.Add(this.cmbSkill);
            this.Controls.Add(this.lblSkill);
            this.Controls.Add(this.btnADDSkill);
            this.Controls.Add(this.cmbLastUserYear);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.nmbFromExperience);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.chkCurrentStatus);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.cmbFromProficiency);
            this.Controls.Add(this.lblProficiency);
            this.Controls.Add(this.txtnoOfAssignment);
            this.Controls.Add(this.lblAssignment);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "CtrlResumeSkill";
            this.Size = new System.Drawing.Size(711, 361);
            ((System.ComponentModel.ISupportInitialize)(this.nmbFromExperience)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridSkills)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtnoOfAssignment;
        private System.Windows.Forms.Label lblAssignment;
        private System.Windows.Forms.Label lblProficiency;
        private System.Windows.Forms.ComboBox cmbFromProficiency;
        private System.Windows.Forms.CheckBox chkCurrentStatus;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.NumericUpDown nmbFromExperience;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox cmbLastUserYear;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button btnADDSkill;
        private System.Windows.Forms.Label lblSkill;
        private System.Windows.Forms.ComboBox cmbSkill;
        private System.Windows.Forms.DataGridView gridSkills;
    }
}
