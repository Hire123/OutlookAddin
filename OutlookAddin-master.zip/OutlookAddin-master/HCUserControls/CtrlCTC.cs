﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net;
using System.Configuration;
using System.IO;
using Newtonsoft.Json;
using HireLook;
namespace HCUserControls
{
    public partial class CtrlCTC : UserControl
    {
        public ControlDetail controls = new ControlDetail();

        public CtrlCTC()
        {
            InitializeComponent();
        }

        public CtrlCTC(ControlDetail controls)
        {
            InitializeComponent();
            this.controls = controls;
            lblName.Text = this.controls.DisplayName;
            loadDefaultCmbScale();
            loadDefaultCmbCurrency();
        }

        void loadDefaultCmbScale()
        {
            List<NameSearch> DefaultValue = new List<NameSearch>();
            NameSearch DefaultVal = new NameSearch();
            DefaultVal.RID = 0;
            DefaultVal.Title = "<-- Select -->";
            DefaultValue.Add(DefaultVal);
            cmbScale.DisplayMember = "Title";
            cmbScale.ValueMember = "RID";
            cmbScale.DataSource = DefaultValue;
        }

        void loadDefaultCmbCurrency()
        {
            List<NameSearch> DefaultValue = new List<NameSearch>();
            NameSearch DefaultVal = new NameSearch();
            DefaultVal.RID = 0;
            DefaultVal.Title = "<-- Select -->";
            DefaultValue.Add(DefaultVal);
            cmbCurrency.DisplayMember = "Title";
            cmbCurrency.ValueMember = "RID";
            cmbCurrency.DataSource = DefaultValue;
        }

        List<NameSearch> LoadScale()
        {
            var request = (HttpWebRequest)WebRequest.Create(HireLook.Configuration.ApplicationAPI + "masters/currencyscale/");

            request.Method = "GET";
            request.ContentType = "application/x-www-form-urlencoded";
            request.Headers.Add("Authorization: bearer " + HireLook.Configuration.access_token);
            List<NameSearch> LoadMasterData = new List<NameSearch>();
            try
            {
                HttpWebResponse response = (HttpWebResponse)request.GetResponse();
                var responseString = new StreamReader(response.GetResponseStream()).ReadToEnd();
                try
                {
                    LoadMasterData = JsonConvert.DeserializeObject<List<NameSearch>>(responseString);
                }
                catch (System.Exception ex)
                {
                    Log.LogData("Error in loading master value: " + ex.Message + ex.StackTrace, Log.Status.Error);
                }
            }
            catch (WebException ex)
            {
                Log.LogData("Error in Load Selection: " + ex.Message + ex.StackTrace, Log.Status.Error);
            }
            return LoadMasterData;
        }

        List<NameSearch> LoadCurrency()
        {
            var request = (HttpWebRequest)WebRequest.Create(HireLook.Configuration.ApplicationAPI + "masters/currency/");

            request.Method = "GET";
            request.ContentType = "application/x-www-form-urlencoded";
            request.Headers.Add("Authorization: bearer " + HireLook.Configuration.access_token);
            List<NameSearch> LoadMasterData = new List<NameSearch>();
            try
            {
                HttpWebResponse response = (HttpWebResponse)request.GetResponse();
                var responseString = new StreamReader(response.GetResponseStream()).ReadToEnd();
                try
                {
                    LoadMasterData = JsonConvert.DeserializeObject<List<NameSearch>>(responseString);
                }
                catch (System.Exception ex)
                {
                    Log.LogData("Error in loading master value: " + ex.Message + ex.StackTrace, Log.Status.Error);
                }
            }
            catch (WebException ex)
            {
                Log.LogData("Error in Load Selection: " + ex.Message + ex.StackTrace, Log.Status.Error);
            }
            return LoadMasterData;
        }

        private void cmbScale_Click(object sender, EventArgs e)
        {
            Application.DoEvents();
            List<NameSearch> LoadMasterScale = LoadScale();
            Application.DoEvents();
            if (LoadMasterScale != null)
            {
                if (LoadMasterScale.Count > 0)
                {
                    cmbScale.DisplayMember = "Title";
                    cmbScale.ValueMember = "RID";
                    cmbScale.DataSource = LoadMasterScale;
                    cmbScale.BringToFront();
                }
            }

        }

        private void cmbCurrency_Click(object sender, EventArgs e)
        {
            Application.DoEvents();
            List<NameSearch> LoadMasterCurrency = LoadCurrency();
            Application.DoEvents();
            if (LoadMasterCurrency != null)
            {
                if (LoadMasterCurrency.Count > 0)
                {
                    cmbCurrency.DisplayMember = "Title";
                    cmbCurrency.ValueMember = "RID";
                    cmbCurrency.DataSource = LoadMasterCurrency;
                    cmbCurrency.BringToFront();
                }
            }

        }

        public Object getCTC()
        {
            CTC ctc = new CTC();
            ctc.Scale = Convert.ToInt32(cmbScale.SelectedValue);
            ctc.Currency = Convert.ToInt32(cmbCurrency.SelectedValue);
            ctc.Amount = Convert.ToDouble(nbrSalary.Value);
            return ctc;
        }
    }

    public class CTC
    {
        public int Scale { get; set; }
        public int Currency { get; set; }
        public double Amount { get; set; }
    }
}
