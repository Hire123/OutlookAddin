﻿namespace HCUserControls
{
    partial class CtrlFooter
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.barStatus = new System.Windows.Forms.StatusStrip();
            this.toolslbl = new System.Windows.Forms.ToolStripStatusLabel();
            this.MsgTimer = new System.Windows.Forms.Timer(this.components);
            this.bgWorker = new System.ComponentModel.BackgroundWorker();
            this.barStatus.SuspendLayout();
            this.SuspendLayout();
            // 
            // barStatus
            // 
            this.barStatus.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.barStatus.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolslbl});
            this.barStatus.Location = new System.Drawing.Point(0, -4);
            this.barStatus.Name = "barStatus";
            this.barStatus.Padding = new System.Windows.Forms.Padding(1, 0, 15, 0);
            this.barStatus.Size = new System.Drawing.Size(491, 24);
            this.barStatus.TabIndex = 7;
            this.barStatus.Text = "statusStrip1";
            // 
            // toolslbl
            // 
            this.toolslbl.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Bold);
            this.toolslbl.ForeColor = System.Drawing.Color.Red;
            this.toolslbl.Name = "toolslbl";
            this.toolslbl.Size = new System.Drawing.Size(0, 17);
            // 
            // MsgTimer
            // 
            this.MsgTimer.Enabled = true;
            this.MsgTimer.Interval = 4000;
            this.MsgTimer.Tick += new System.EventHandler(this.MsgTimer_Tick);
            // 
            // bgWorker
            // 
            this.bgWorker.WorkerReportsProgress = true;
            // 
            // CtrlFooter
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.barStatus);
            this.Name = "CtrlFooter";
            this.Size = new System.Drawing.Size(491, 20);
            this.barStatus.ResumeLayout(false);
            this.barStatus.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.StatusStrip barStatus;
        private System.Windows.Forms.ToolStripStatusLabel toolslbl;
        private System.Windows.Forms.Timer MsgTimer;
        private System.ComponentModel.BackgroundWorker bgWorker;
    }
}
