﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using HireLook;
using System.IO;
using System.Net;
using System.Configuration;
using Newtonsoft.Json;
using System.Collections;
namespace HCUserControls
{
    public partial class CtrlRequirementSkills : UserControl
    {
        ArrayList ReqskillArray = new ArrayList();
        public ReqirementSkills reqSkills = new ReqirementSkills();

        public ControlDetail controls = new ControlDetail();
        public CtrlRequirementSkills()
        {
            InitializeComponent();
        }
        public CtrlRequirementSkills(ControlDetail controls)
        {
            InitializeComponent();
            this.controls = controls;
            loadDefaultCmbAddressType();
            loadYear();
        }

        private void btnADDSkill_Click(object sender, EventArgs e)
        {
            ResumeSkills skilllist = new ResumeSkills();
            skilllist.SkillId = Convert.ToInt64(cmbSkill.SelectedValue);
            skilllist.Skill = cmbSkill.Text;
            skilllist.ResId = Constants.ResumeId;
            skilllist.Proficiency = cmbFromProficiency.Text;
            skilllist.ProficiencyId = Convert.ToInt64(cmbFromProficiency.SelectedValue);
            skilllist.NoofAssignment = Convert.ToInt16(txtNoOfAssignment.Text);
            skilllist.LastUsedYear = Convert.ToInt32(cmbLastUserYear.Text);
            skilllist.Experience = nmbFromExperience.Value;
            skilllist.Active = chkCurrentStatus.Checked;
            ReqskillArray.Add(skilllist);
            Application.DoEvents();
            saveResumeSkill();
            Application.DoEvents();
        }

        List<NameSearch> loadData(string subURL)
        {
            List<NameSearch> objMaster = new List<NameSearch>();
            var request = (HttpWebRequest)WebRequest.Create(Convert.ToString(ConfigurationManager.AppSettings["ApplicatonAPI"]) + subURL);

            request.Method = "GET";
            request.ContentType = "application/x-www-form-urlencoded";
            request.Headers.Add("Authorization: Bearer " + HireLook.Configuration.access_token);

            try
            {
                HttpWebResponse response = (HttpWebResponse)request.GetResponse();
                var responseString = new StreamReader(response.GetResponseStream()).ReadToEnd();
                try
                {
                    objMaster = JsonConvert.DeserializeObject<List<NameSearch>>(responseString);

                }
                catch (System.Exception ex)
                {
                    Log.LogData("Error in loadSkill result: Registry value: " + ex.Message + ex.StackTrace, Log.Status.Error);
                }
            }
            catch (WebException ex)
            {
                Log.LogData("Error in Load loadSkill: " + ex.Message + ex.StackTrace, Log.Status.Error);
            }
            return objMaster;
        }

        void HandleTextChanged()
        {
            try
            {

                if (cmbSkill.Text != string.Empty)
                {

                    List<NameSearch> mstrData = loadData("masters/skills?name=" + cmbSkill.Text);
                    List<string> TitleAry = new List<string>();
                    if (mstrData != null)
                    {
                        if (mstrData.Count > 0)
                        {
                            NameSearch mstrDefault = new NameSearch();
                            mstrDefault.RID = 0;
                            mstrDefault.Title = cmbSkill.Text;
                            mstrData.Insert(0, mstrDefault);
                            cmbSkill.DataSource = mstrData.ToList();
                            //comboBox1.SelectedIndex = 0;
                            var sText = cmbSkill.Items[0].ToString();
                            cmbSkill.SelectionStart = cmbSkill.Text.Length;
                            cmbSkill.SelectionLength = sText.Length - cmbSkill.Text.Length;
                            cmbSkill.DroppedDown = true;
                            cmbSkill.ValueMember = "RID";
                            cmbSkill.DisplayMember = "Title";
                        }
                    }
                    else
                    {
                        cmbSkill.DroppedDown = false;
                        cmbSkill.SelectionStart = cmbSkill.Text.Length;
                    }

                }
                else
                {
                    cmbSkill.DroppedDown = false;
                    cmbSkill.SelectionStart = cmbSkill.Text.Length;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message + ex.StackTrace);
            }

        }

        void loadProficency()
        {
            List<NameSearch> Proficency = loadData("masters/skillrating");
            if (Proficency != null)
            {
                if (Proficency.Count > 0)
                {
                    cmbFromProficiency.DisplayMember = "Title";
                    cmbFromProficiency.ValueMember = "RID";
                    cmbFromProficiency.DataSource = Proficency;
                }
            }
        }

        void loadDefaultCmbAddressType()
        {
            NameSearch DefaultValue = new NameSearch();
            DefaultValue.RID = 0;
            DefaultValue.Title = "<-- Select -->";
            List<NameSearch> defaultval = new List<NameSearch>();
            defaultval.Add(DefaultValue);
            cmbFromProficiency.DisplayMember = "Title";
            cmbFromProficiency.ValueMember = "RID";
            cmbFromProficiency.DataSource = defaultval;
        }

        void loadYear()
        {
            Int32 Year = Convert.ToInt32(System.DateTime.Now.Year);
            for (Int32 i = Year; i >= 2001; i--)
            {
                cmbLastUserYear.Items.Add(i);
            }
        }

        void saveResumeSkill()
        {
            reqSkills.Skills = ReqskillArray;
            var request = (HttpWebRequest)WebRequest.Create(HireLook.Configuration.ApplicationAPI + "resume/" + Constants.ResumeId + "/skills");
            //var postData = "SectionId=" + sectionSave.SectionId + "&Values=" + sectionSave.Value;
            var data = Encoding.ASCII.GetBytes(JsonConvert.SerializeObject(ReqskillArray));
            request.Method = "PUT";
            request.Headers.Add("Authorization: Bearer " + HireLook.Configuration.access_token);
            request.ContentType = "application/json";
            request.ContentLength = data.Length;

            using (var stream = request.GetRequestStream())
            {
                stream.Write(data, 0, data.Length);
            }

            try
            {
                HttpWebResponse response = (HttpWebResponse)request.GetResponse();
                var responseString = new StreamReader(response.GetResponseStream()).ReadToEnd();

                ResposeData values = JsonConvert.DeserializeObject<ResposeData>(responseString);

                try
                {

                }
                catch (Exception ex)
                {
                    Log.LogData("Error in frmLogin: Registry value: " + ex.Message + ex.StackTrace, Log.Status.Error);
                }

            }
            catch (WebException ex)
            {
                Log.LogData("Invalid In Saving Resume Manager: " + ex.Message + ex.StackTrace, Log.Status.Error);
            }
        }

    }

    public class ReqirementSkills
    {
        public object Skills { get; set; }
    }
}
