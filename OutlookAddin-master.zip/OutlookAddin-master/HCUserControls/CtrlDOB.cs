﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using HireLook;
using System.Globalization;
namespace HCUserControls
{
    public partial class CtrlDOB : UserControl
    {
        public ControlDetail controls = new ControlDetail();

        public CtrlDOB()
        {
            InitializeComponent();
        }
        public CtrlDOB(ControlDetail controls)
        {
            InitializeComponent();
            this.controls = controls;
            dateTimePicker1.Format = DateTimePickerFormat.Custom;
            dateTimePicker1.CustomFormat = " ";
            if (controls.Mandatory)
            {
                lblName.Text = "*" + this.controls.DisplayName;
                opSetMandatory();
            }
            else
                lblName.Text = this.controls.DisplayName;
        }

        public string getDOB()
        {
            if (dateTimePicker1.CustomFormat == " ")
            {
                return "";
            }
            else  if (dateTimePicker1.Value != null)
                return dateTimePicker1.Value.ToString("dd-MMM-yyyy");
            else
                return "";
        }

        public void setDoB(DateTime DOBData)
        {
            try
            {
                dateTimePicker1.Value = DOBData;
            }
            catch (Exception ex)
            {
                Log.LogData("Error in Set Date : " + ex.Message + ex.StackTrace, Log.Status.Error);
            }
        }

        public Boolean opValidate()
        {
            if (dateTimePicker1 != null)
                return true;
            else
                return false;
        }

        void opSetMandatory()
        {
            lblName.ForeColor = System.Drawing.Color.Red;
        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {
            dateTimePicker1.Format = DateTimePickerFormat.Custom;
            dateTimePicker1.CustomFormat = "dd-MMM-yyyy";
        }
    }
}
