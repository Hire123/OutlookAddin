﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using HireLook;
using Newtonsoft.Json;
using System.Net;
using System.IO;
using System.Collections;
using System.Configuration;
namespace HCUserControls
{
    public partial class CtrlEmployment : UserControl
    {
        #region Declartion
        ControlDetail controls = new ControlDetail();
        ArrayList EmployementArray = new ArrayList();
        EmployementSave EmployementSkill = new EmployementSave();

        #endregion

        #region Constructor
        public CtrlEmployment()
        {
            InitializeComponent();
        }

        public CtrlEmployment(ControlDetail controls)
        {
            InitializeComponent();
            this.controls = controls;
            LoadEmployeeStatus();
            SetSkillGrid();
            opSetMandatory();
            setDate();
        }

        #endregion

        void HandleTextChanged()
        {
            try
            {
                if (cmbRole.Text != string.Empty)
                {
                    List<NameSearch> mstrData = loadData("masters/designation?name=" + cmbRole.Text);
                    List<string> TitleAry = new List<string>();
                    if (mstrData != null)
                    {
                        if (mstrData.Count > 0)
                        {
                            NameSearch mstrDefault = new NameSearch();
                            mstrDefault.RID = 0;
                            mstrDefault.Title = cmbRole.Text;
                            mstrData.Insert(0, mstrDefault);
                            cmbRole.DataSource = mstrData.ToList();
                            //comboBox1.SelectedIndex = 0;
                            var sText = cmbRole.Items[0].ToString();
                            cmbRole.SelectionStart = cmbRole.Text.Length;
                            cmbRole.SelectionLength = sText.Length - cmbRole.Text.Length;
                            cmbRole.DroppedDown = true;
                            cmbRole.ValueMember = "RID";
                            cmbRole.DisplayMember = "Title";
                        }
                    }
                    else
                    {
                        cmbRole.DroppedDown = false;
                        cmbRole.SelectionStart = cmbRole.Text.Length;
                    }

                }
                else
                {
                    cmbRole.DroppedDown = false;
                    cmbRole.SelectionStart = cmbRole.Text.Length;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message + ex.StackTrace);
            }
        }

        List<NameSearch> loadData(string subURL)
        {
            List<NameSearch> objMaster = new List<NameSearch>();
            var request = (HttpWebRequest)WebRequest.Create(Convert.ToString(ConfigurationManager.AppSettings["ApplicatonAPI"]) + subURL);

            request.Method = "GET";
            request.ContentType = "application/x-www-form-urlencoded";
            request.Headers.Add("Authorization: Bearer " + HireLook.Configuration.access_token);

            try
            {
                HttpWebResponse response = (HttpWebResponse)request.GetResponse();
                var responseString = new StreamReader(response.GetResponseStream()).ReadToEnd();
                try
                {
                    objMaster = JsonConvert.DeserializeObject<List<NameSearch>>(responseString);

                }
                catch (System.Exception ex)
                {
                    Log.LogData("Error in loadSkill result: Registry value: " + ex.Message + ex.StackTrace, Log.Status.Error);
                }
            }
            catch (WebException ex)
            {
                Log.LogData("Error in Load loadSkill: " + ex.Message + ex.StackTrace, Log.Status.Error);
            }
            return objMaster;
        }

        void LoadEmployeeStatus()
        {
            List<NameSearch> EmployeeStatusList = new List<NameSearch>();
            EmployeeStatusList.Add(new NameSearch { RID = 1, Title = "Present" });
            EmployeeStatusList.Add(new NameSearch { RID = 0, Title = "Previous" });
            cmbEmployeStatus.DisplayMember = "Title";
            cmbEmployeStatus.ValueMember = "RID";
            cmbEmployeStatus.DataSource = EmployeeStatusList;
        }

        void loadDefaultCmbAddressType()
        {
            NameSearch DefaultValue = new NameSearch();
            DefaultValue.RID = 0;
            DefaultValue.Title = "<-- Select -->";
            List<NameSearch> defaultval = new List<NameSearch>();
            defaultval.Add(DefaultValue);
            cmbEmployeStatus.DisplayMember = "Title";
            cmbEmployeStatus.ValueMember = "RID";
            cmbEmployeStatus.DataSource = defaultval;
        }

        private void btnADDSkill_Click(object sender, EventArgs e)
        {
            if (opValidate())
            {
                ResumeEmployerDetails employerDetails = new ResumeEmployerDetails();
                employerDetails.CurrentEmpStatus = Convert.ToBoolean(cmbEmployeStatus.SelectedValue);
                employerDetails.DesignationID = Convert.ToInt64(cmbRole.SelectedValue);
                employerDetails.DesignationText = cmbRole.Text;
                employerDetails.Employer = txtEmployeeName.Text;
                employerDetails.EmployerID = 0;
                //employerDetails.Enddate = dtEndDate.Value;
                //employerDetails.StartDate = dtStartDate.Value;
                if (dtStartDate.CustomFormat == " ")
                    employerDetails.StartDate = "";
                else
                    employerDetails.StartDate = dtStartDate.Value.ToString("dd-MMM-yyyy");

                if (dtEndDate.CustomFormat == " ")
                    employerDetails.Enddate = "";
                else
                    employerDetails.Enddate = dtEndDate.Value.ToString("dd-MMM-yyyy");
                EmployementArray.Add(employerDetails);
                Application.DoEvents();
                SaveEmployementSkill();
                Application.DoEvents();
                gridEmployment.DataSource = null;
                gridEmployment.DataSource = EmployementArray;
                Clear();
                setDate();
            }
        }

        public void Clear()
        {
            //  cmbEmployeStatus.DataSource = null;
            cmbRole.Text = "";
            txtNotes.Text = string.Empty;
            txtEmployeeName.Text = string.Empty;
            dtEndDate.Value = System.DateTime.Now;
            dtStartDate.Value = System.DateTime.Now;
        }

        public void SetSkillGrid()
        {
            gridEmployment.AutoGenerateColumns = false;
            //Set Columns Count
            gridEmployment.ColumnCount = 7;
            gridEmployment.Columns[0].Name = "CurrentEmpStatus";
            gridEmployment.Columns[0].HeaderText = "CurrentEmpStatus";
            gridEmployment.Columns[0].DataPropertyName = "CurrentEmpStatus";
            gridEmployment.Columns[0].Visible = false;

            gridEmployment.Columns[1].Name = "DesignationText";
            gridEmployment.Columns[1].HeaderText = "Designation";
            gridEmployment.Columns[1].DataPropertyName = "DesignationText";

            gridEmployment.Columns[2].Name = "DesignationID";
            gridEmployment.Columns[2].HeaderText = "DesignationID";
            gridEmployment.Columns[2].DataPropertyName = "DesignationID";
            gridEmployment.Columns[2].Visible = false;

            gridEmployment.Columns[3].Name = "Employer";
            gridEmployment.Columns[3].HeaderText = "Employer";
            gridEmployment.Columns[3].DataPropertyName = "Employer";

            gridEmployment.Columns[4].Name = "EmployerID";
            gridEmployment.Columns[4].HeaderText = "EmployerID";
            gridEmployment.Columns[4].DataPropertyName = "EmployerID";
            gridEmployment.Columns[4].Visible = false;

            gridEmployment.Columns[5].Name = "StartDate";
            gridEmployment.Columns[5].HeaderText = "StartDate";
            gridEmployment.Columns[5].DataPropertyName = "StartDate";

            gridEmployment.Columns[6].Name = "Enddate";
            gridEmployment.Columns[6].HeaderText = "End Date";
            gridEmployment.Columns[6].DataPropertyName = "Enddate";
        }

        void SaveEmployementSkill()
        {
            EmployementSkill.EmployerDetails = EmployementArray;
            var request = (HttpWebRequest)WebRequest.Create(HireLook.Configuration.ApplicationAPI + "resume/" + Constants.ResumeId + "/employer");
            //var postData = "SectionId=" + sectionSave.SectionId + "&Values=" + sectionSave.Value;
            var data = Encoding.ASCII.GetBytes(JsonConvert.SerializeObject(EmployementSkill));
            request.Method = "PUT";
            request.Headers.Add("Authorization: Bearer " + HireLook.Configuration.access_token);
            request.ContentType = "application/json";
            request.ContentLength = data.Length;

            using (var stream = request.GetRequestStream())
            {
                stream.Write(data, 0, data.Length);
            }

            try
            {
                HttpWebResponse response = (HttpWebResponse)request.GetResponse();
                var responseString = new StreamReader(response.GetResponseStream()).ReadToEnd();

                try
                {
                    ResposeData values = JsonConvert.DeserializeObject<ResposeData>(responseString);
                }
                catch (Exception ex)
                {
                    Log.LogData("Error in frmLogin: Registry value: " + ex.Message + ex.StackTrace, Log.Status.Error);
                }

            }
            catch (WebException ex)
            {
                Log.LogData("Invalid In Saving Resume Manager: " + ex.Message + ex.StackTrace, Log.Status.Error);
            }
        }

        private void cmbRole_TextUpdate(object sender, EventArgs e)
        {
            Application.DoEvents();
            HandleTextChanged();
            Application.DoEvents();
        }

        void opSetMandatory()
        {
            lblEmploymentStatus.ForeColor = System.Drawing.Color.Red;
            lblEmploymentStatus.Text = lblEmploymentStatus.Text + "*";
            lblEmployeeName.ForeColor = System.Drawing.Color.Red;
            lblEmployeeName.Text = lblEmployeeName.Text + "*";
        }

        Boolean opValidate()
        {
            //if (Convert.ToInt64(cmbEmployeStatus.SelectedValue) == 0)
            //{
            //    cmbEmployeStatus.Focus();
            //    return false;
            //}

            if (txtEmployeeName.Text.Trim().ToString() == string.Empty)
            {
                txtEmployeeName.Focus();
                return false;
            }


            return true;
        }

        void opDelete()
        {
            if (gridEmployment.SelectedRows.Count > 0)
            {
                int selectedIndex = gridEmployment.SelectedRows[0].Index;
                EmployementArray.RemoveAt(selectedIndex);
                gridEmployment.DataSource = null;
                gridEmployment.DataSource = EmployementArray;
            }
        }

        private void gridEmployment_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Delete)
                opDelete();
        }

        void setDate()
        {
            dtStartDate.Format = DateTimePickerFormat.Custom;
            dtStartDate.CustomFormat = " ";
            dtEndDate.Format = DateTimePickerFormat.Custom;
            dtEndDate.CustomFormat = " ";
        }

        private void dtStartDate_ValueChanged(object sender, EventArgs e)
        {
            dtStartDate.Format = DateTimePickerFormat.Custom;
            dtStartDate.CustomFormat = "dd-MMM-yyyy";
        }

        private void dtEndDate_ValueChanged(object sender, EventArgs e)
        {
            dtEndDate.Format = DateTimePickerFormat.Custom;
            dtEndDate.CustomFormat = "dd-MMM-yyyy";
        }
    }

    class EmployementSave
    {
        public object EmployerDetails { get; set; }
    }
}
