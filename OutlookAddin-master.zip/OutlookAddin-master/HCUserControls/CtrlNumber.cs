﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using HireLook;
namespace HCUserControls
{
    public partial class CtrlNumber : UserControl
    {
        public ControlDetail controls = new ControlDetail();

        public CtrlNumber()
        {
            InitializeComponent();
        }

        public CtrlNumber(ControlDetail controls)
        {
            InitializeComponent();
            this.controls = controls;
            if (this.controls.Mandatory)
            {
                opSetMandatory();
                lblName.Text = "*" + this.controls.DisplayName;
            }
            else
                lblName.Text = this.controls.DisplayName;

        }

        public Int32 getNumbers()
        {
            return Convert.ToInt32(numberText.Value);
        }

        public Boolean opValidate()
        {
            if (controls.Mandatory)
                if (numberText.Value.ToString().Trim() != string.Empty)
                    return true;
                else
                    return false;
            else
                return true;
        }

        void opSetMandatory()
        {
            lblName.ForeColor = System.Drawing.Color.Red;
        }
    }
}
